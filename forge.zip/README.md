# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.

## Novedades (v4)
- Bloques dibujados como piezas conectadas (sombrero, rieles en bucles y "si", espacio entre guiones).
- Bloques nuevos: reproducir sonido y esperar, cambiar vista de cámara, esperar hasta, detener guion, disparar al jugador, quitar vida, velocidad y salto del jugador, reproducir animación, mover al azar.
- Jugador como objeto editable (se mueve en el editor): cámara en primera persona, al hombro o fija (colocable), cuerpo, arma 2D/3D y proyectil (bala, imagen o modelo).
- Enemigo (dispara) y monstruo (cuerpo a cuerpo) con IA: modelo 3D o sprites por acción (quieto, caminar, atacar, daño) y mini animación.
- Colisión de modelos importados con rejilla 64³ fusionada en cajas: casas huecas se pueden recorrer.

## Novedades (v5)
- Tema visual nuevo; importar `.pack` desde la lista de proyectos; escenas reordenables con pulsación larga.
- Miniaturas en todos los selectores de imagen y modelo 3D (los modelos se dibujan con un rasterizador propio en CPU).
- Clones, romper en pedazos, ir/mover hacia un objeto, sacudir pantalla, detener todo.
- Partículas (humo, fuego, chispas, nieve, energía) con color de inicio y fin; ráfagas y bloque encender/apagar.
- Capa de la cámara por escena: imágenes fijas y efectos (VHS, cámara de video, visión nocturna, película vieja) o propios.
- Editor de texturas (lápiz, borrador, cubeta, gotero, espejo, deshacer) que guarda PNG.
- Exportar juego: nombre, paquete, versión, orientación e icono del APK (se compila con GitHub Actions: `game_dir`), opciones de ventana del .exe y paquetes para compilar después.

## Novedades v6
- Eventos nuevos: *Cuando el jugador dispare*, *Cuando se presione el botón X*, *Cuando se mueva (objeto)*, *Cuando el jugador se mueva / salte / reciba daño*.
- Botones en pantalla con acción "Solo bloques": solo lanzan el evento de bloques.
- Objetos bloqueables (botón Libre/Bloq en la ventana Objetos): no se seleccionan ni se mueven tocando la escena.
- El jugador tiene animaciones por estado e imágenes planas (sprites) como los enemigos.
- Diseño de bloques propio (tarjetas oscuras con barra de color).
- Pantalla de inicio blanca con el logo en los juegos exportados (APK y .exe) y fondo con imágenes en el menú de proyectos.
- Editor de fórmulas: Aceptar/Cancelar fijos arriba.

## Novedades v7
- **Editor de animación** (Archivos → Animaciones → Editar): dibujas el esqueleto con círculos y palos sobre el modelo; al mover los huesos la malla 3D se estira (skinning). Poses, clips con línea de tiempo, presets.
- **Importar animaciones** glTF/GLB y FBX (BVH pendiente).
- **Editor de texturas** en pestaña grande.
- **Selectores** de texturas/modelos/archivos en cuadrícula grande con vista previa real.
- **Terreno deformable** (montañas arriba/abajo, aplanar, suavizar) con colisión que sigue la forma.
- Comando **ir al jugador** (2D y 3D), reproducir/detener animación.
- **APK instalable ya compilado** desde la app (se mantiene "Exportar sin compilar").
- Android: pestañas fijas y contenido que se desliza con el dedo.

## Novedades v8
- **Mundo** (ventana Mundo): ambientación (por defecto / amarillento / azulado, suaves), clima (niebla, lluvia, tormenta de arena, nieve, personalizado con cantidad y color) y calidad general (baja/media/alta). Reflejos opcionales por objeto (apagados por defecto).
- **Bloques nuevos**: mientras…, repetir hasta…, fijar objetivo / quitar objetivo (3D), y de video (reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener).
- **Armas**: de fuego, cuerpo a cuerpo, arrojadiza y granada (opcionales); empezar con ella o recogerla del suelo (objeto con "Da esta arma"); balas por cargador, balas iniciales, disparo infinito, retroceso, recarga (botón RECARGAR / tecla R), cambio de arma (botón ARMA / tecla Q).
- **Giro del modelo** (enemigos y jugador): gira hacia donde camina o siempre al frente; distancia de cámara al hombro; ajuste de posición/giro/tamaño del modelo del jugador.
- **Fórmulas**: las funciones son fichas; solo se editan sus parámetros con la calculadora; el teclado sale solo con "abc"; borrar quita la función completa.
- **Animador**: zoom (+/−/rueda), mover la vista arrastrando, esqueleto humano también para la vista de lado; "Elegir animación" / "Crear animación" donde se eligen modelos de enemigos, monstruos y jugador.
- **Video**: importar (Archivos → Videos), verlo en cualquier objeto. Android: MediaPlayer (sonido) + cuadros por MediaMetadataRetriever. Windows: sin reproductor todavía.
- **Importar modelos pesados** en segundo plano con pantalla de carga y porcentaje.
- **Android**: la música se pausa al salir; botones de volumen funcionan; ventanas fijas (una a la vez) que se deslizan con el dedo.

## v8.1
- **Editor para Windows**: GitHub Actions ahora sube el artefacto `P-Maker-Windows` (pmaker_editor.exe + forge_runtime.exe). Ratón izquierdo = 1 dedo, botón derecho = 2 dedos (mover), rueda = acercar. Los proyectos van a Documentos\P-Maker.
- Importación de archivos grandes en Android: el archivo se copia por partes a un archivo temporal (hasta 1.5 GB) y se muestra "Leyendo el archivo…"; barra de progreso hasta 100% real.
- Textos largos: las etiquetas de casillas, barras, colores y listas ahora bajan de renglón en vez de cortarse.

## v9
- Animaciones nuevas (esqueleto humano): agachado, caminar agachado, correr (normal / pistola / arma larga), apuntar (pistola / arma larga), atacar con espada y cuchillo, golpear, sostener y lanzar, cubrirse, saltar, recibir daño, morir, recargar.
- Vegetación pintada con el dedo (realista, animada, lowpoly, textura propia), color y viento editables.
- Reflejos con menos blanco, niebla con color propio, clima realista (opcional), cantidad hasta 3x, agua/mar, modo RTX (apagado por defecto).
- Cámara fija con 3 modos, arma visible en tercera persona, bloques "no salir de la pantalla" (2D), "fijar objetivo: todas las entidades".
- Botón grande "Cerrar" en las ventanas, botones que bajan de renglón en vez de cortarse, "Invertir lado" en el editor de animación, menos lag al mover huesos.
- Importación: se recoge en cualquier pantalla (ya no se queda en 100%).

## v9.1
- Esqueleto humano automático: dos tipos (frente / lado) que sirven en cualquiera de las dos vistas; botón "Cambiar frente/lado" para modelos que salen girados.
- Animación nueva "impacto" (golpe fuerte que empuja hacia atrás).
- Bloques: inclinar la cámara a la derecha / izquierda, enderezar la cámara.
- Lápiz de texturas para el suelo (arena, pasto, roca, nieve, tierra o tu imagen).
- Balanceo de la cámara al caminar en primera persona (opcional, en el panel del jugador).

## v9.2
- Importación de modelos pesados: si pasan de ~400 mil triángulos se simplifican en vez de fallar; zip64 y archivos hasta 1.4 GB; mensajes de error claros; hilo con pila grande.
- Sonidos por defecto estilo militar (pasos, salto, aterrizaje, disparo, pistola, recarga, golpe, lanzar, daño, explosión, linterna). Se cambian en el panel "Sonidos del juego" o importando un audio con el mismo nombre.
- Linterna del jugador (alcance, apertura, color, parpadeo y dibujo opcional), botón LUZ / tecla F, bloques encender/apagar/alternar.
- Oscuridad de las sombras ajustable (clara ↔ oscura).
- Bloques: congelar todo menos al jugador / descongelar, congelar al jugador / descongelar.

## v10
- **APK desde Windows**: `editor/apkbuild.cpp` es la version C++ de `ApkPatcher.java` (manifest binario, resources.arsc, game.pack, zip alineado, firma v2 con SHA-256 + RSA propios). El editor de Windows lo usa si junto a `pmaker_editor.exe` estan `forge_template.apk`, `apk_sign_key.pk8` y `apk_sign_cert.der` (el workflow los mete en `P-Maker-Windows`; el job `windows-editor` ahora espera al `android-apk`).
  Prueba: `java -cp <cls> ApkPatcherSelfTest android/app/src/main/assets build/apkcli` (verificador independiente en Java; usar `LC_ALL=C.UTF-8 java -Dsun.jnu.encoding=UTF-8`).
- **Textos largos**: `wrapui::Button/Selectable/RadioButton` bajan de renglon en vez de cortar; las ventanas usan ajuste de texto; `shorten` ya casi no recorta.
- **Diseno**: botones con dibujos automaticos segun su palabra (`wrapui::iconFor`), mosaicos grandes en Proyectos (`wrapui::Tile`), barra superior con degradado.

## v10.1
- Corregido el error de Dear ImGui "conflicting ID" (niebla/mundo): los widgets envueltos usan prefijos de ID distintos por tipo.
- Botones de ancho fijo: nunca parten una palabra ("Deten/er"); si no cabe, se quita el dibujo y se ensancha.
- Escenas y objetos: sin botón "..."; pulsación larga abre renombrar/duplicar/mover/eliminar. Menos espacio entre renglones.
- Animaciones humanas rehechas (caminar, quieto, atacar, disparar pistola/arma larga) y se agregan solas al abrir el editor de animación en esqueletos de persona.
- Distancia de dibujado (Mundo): limita lo que se dibuja en mapas grandes.
- Torres sugeridas en el buscador de bloques (recetas en pages.cpp `kRecipes`).
- Controles 2D (cruceta / palanca / plataformas) táctiles y de teclado (Windows), con nombres de botón Izquierda, Derecha, Arriba, Abajo, A, B.
- 10 plantillas en Proyectos (`editor/templates.cpp`).

## v10.2
- Importar juegos de Pocket Code: `.catrobat`, `.zip` con `code.xml` o `.rar` → escenas, objetos, apariencias, sonidos, variables y bloques (~70 tipos de bloque traducidos; los que no existen en Forge se omiten y se avisa).
- `.rar`: se leen RAR4 y RAR5 **sin compresión** («Almacenar»). Los RAR comprimidos no se pueden descomprimir aquí: guárdalos como .zip.
- Ajustes por escena / todo el proyecto desde el menú de pulsación larga, orientación vertical/horizontal, bloques de IA entre enemigos, biblioteca de modelos/texturas, plantillas mejoradas, linterna con más alcance y potencia.
- La pantalla de proyectos se desliza con el dedo (sin barra); «Editar la escena» ahora está arriba en la página de la escena (2D y 3D).
- Animación: botones «Girar 90°/180°» (esta o todas) en la pestaña Animar; barra de vista en 2 filas de 4 botones iguales y lienzo más grande. Editor de texturas con botones iguales.
- Desenfoque de movimiento opcional (Mundo → «Desenfoque de movimiento»): mezcla el cuadro anterior según lo rápido que se mueve/gira la cámara (clave `mblur` del proyecto).

## v10.3
- Deformar por golpes (propiedades del modelo 3D): balas, explosiones, golpes de enemigos y choques fuertes abollan la malla (límite de hundimiento ajustable).
- Estudio de música y efectos (menú del proyecto / pestaña de sonidos): secuenciador de 16 pasos (melodía, acordes, bajo, bombo, caja, platillo), 8 tipos de juego, escalas, tono, BPM; generador de 8 efectos; biblioteca de sonidos. Guarda .wav en el proyecto.
- Físicas avanzadas: panel «Física» con casillas (dinámico/estático, masa, rebote, fricción, gravedad del objeto, resistencia del aire, empujable por el jugador, empujable por balas); choques dinámico-dinámico reparten impulso por masa; explosiones empujan; bloques: empujón, explosión de fuerza, resistencia del aire, gravedad del objeto, empujable.
- Iluminación global falsa y gráficos pro (Mundo): rebote del suelo, relleno de lado sombra, sombras con tinte de cielo, oclusión en base de paredes, tono de película. Clave `gi`.

## v10.4
- Plantillas rehechas (15): FPS almacén, shooter, Carreras (botones Izquierda/Derecha/Acelerar/Frenar), plataformas 3D, 2D x2, RPG con espada, hack&slash, FNAF 2D y 3D (puertas, cámaras, sustos), Runner, Flappy, Atrapa frutas, Clicker, Peleas 3D.
- Sombras con descarte alfa: partes transparentes/sin color no proyectan sombra; sombra del jugador.
- Corregido: la animación elegida en propiedades no se reproducía (se tomaba el primer .fanim del modelo).
- Editor de animación: visor del modelo más grande.
- Nuevos modelos procedurales (carro, espada, caballero, orco, esqueleto, luchadores, cámara, monitor, etc.).
- Importar modelos: ahora se abren .zip dentro de otro .zip (ej. descargas de Sketchfab con source/*.zip + textures/). Probado con un Dodge Challenger de 95 mil triángulos.

## v10.4.2
- Escenas: mantén presionada y desliza para moverlas; si no la mueves, se abre su menú.
- Catrobat: posiciones y movimientos (píxeles del proyecto) se convierten al tamaño del escenario; la orientación se copia del original.
- Editor 3D: barra superior más grande y táctil, botón JUGAR verde; doble toque sobre un objeto abre sus propiedades.

## v10.5
- Pantalla del juego (HUD) lista para usar: "Botones y arma" > "Pantalla del juego". Vida, escudo, munición, armas numeradas, minimapa, brújula, velocímetro, reloj, puntos, objetivo, 4 tipos de mira, marcador de impacto, pantalla roja con poca vida, viñeta y estilos de color. 4 estilos rápidos (Doom/COD, mundo abierto, carreras, terror).
- Botones nuevos: Correr y Agacharse (mantener). Un toque agrega Correr, Agacharse y Recargar.
- Variables: vida, escudo, municion, reserva, puntos, tiempo, objetivo.

## v10.5.1
- Windows/Android: corregido el error de compilación en templates.cpp (conversión int a float en una lista con llaves).
- Animaciones sin malla (p. ej. Mixamo "sin piel"): ya se importan. El esqueleto se ajusta a tamaño unitario o se une por nombre al esqueleto del editor (cadera, pecho, hombro_i, codo_d...).
- Editor de animación: el visor usa todo el alto, botones en columna a la derecha, zoom con dos dedos (y mover la vista), pestañas sin cortar.
- Añadir > Modelo 3D abre una ventana de cuadrícula (antes el submenú se encimaba y elegía el primero).

## v10.6
- Ayuda dentro de la app: Inicio > mosaico "Ayuda", o menú Proyecto > "Ayuda: guías paso a paso". Carpetas y subcarpetas, buscador, 76 guías con 333 pasos y dibujos que muestran dónde tocar (barra, menús, pestañas, bloques, HUD, esqueleto).
- El texto está en editor/help_content.cpp (formato: #carpeta, ##subcarpeta, ###guía | intro, - paso, @ dibujo).

## v10.9
- Barra superior flotante (Añadir/Ventanas/JUGAR) y bordes azules estilo sci-fi.
- Escena 2.5D (Scene.side25, línea `scene nombre 3d side`): cámara lateral, movimiento en X, plano fijo.
- Peleas 3D: el jugador ya camina hacia el rival y golpea (puño visible); el inicio quedaba atorado en el ring.
- Plantillas 2D: yaw 90 = sin girar (salían acostadas).

## v10.8
- Teclas/mouse/control: WASD por defecto en Windows (test y .exe), remapeables en Proyecto > Controles; gamepad automático en el .exe.
- "Ocultar botones virtuales": casilla en el test de Windows y opción (apagada) al exportar el .exe. Android conserva palanca y botones.
- Resolución del juego (550p–8K, por defecto 1080p) solo al jugar y en el juego exportado (render a textura + escalado).
- Gizmo X/Y/Z, zoom con rueda y barras de desplazamiento (solo Windows), modos de giro del Jugador, selectores de imagen en cuadrícula.

## v10.7
- **Fijar al enemigo** (Jugador → "Fijar al enemigo"): al atacar o siempre, el personaje gira hacia el enemigo más cercano.
- **Vista lateral 2.5D**, **deslizar el dedo** (botones "Deslizar izquierda/derecha/arriba/abajo") y **corredor infinito de 3 carriles**.
- Barras de pelea (jugador/rival, nombres, reloj, combos) y variable `vidaRival`; variables `jugadorx/y/z`.
- Plantillas rehechas: Hack and slash (vista 3/4), Peleas 3D (2.5D), Peleas 2D (nueva), Plataformas 2D, Flappy pixel, Shooter 2D (soldados, puentes, tanque), Runner 3D, Carreras (coche mirando al frente + 3 rivales), FNAF 2D (oficina, pasillos oscuros, cámaras moradas).
- Modelos redondeados (elipsoides, cilindros, cápsulas, conos): soldados, civiles, policía, zombi, luchadores, armas de fuego y cuerpo a cuerpo, tanque, helicóptero, tren, edificio.
- Sprites pixel-art nuevos (héroe, bicho, ladrillos, tubos, pájaro, soldados, tanque, explosión...).
- El frente de los modelos (+Z) ahora apunta hacia donde mira el jugador y los enemigos.
- "Ambientes listos" (un toque) en la ventana del Mundo.
- Categoría de bloques **Multijugador** (red local UDP, Wi-Fi/hotspot, sin internet): activar automático, crear/unirse, mensajes, variables compartidas; los demás jugadores aparecen como fantasmas 3D. Bluetooth e internet NO incluidos.
- Android: permisos de red + multicast lock.
