# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.

## Novedades (v4)
- Bloques dibujados como piezas conectadas (sombrero, rieles en bucles y "si", espacio entre guiones).
- Bloques nuevos: reproducir sonido y esperar, cambiar vista de cámara, esperar hasta, detener guion, disparar al jugador, quitar vida, velocidad y salto del jugador, reproducir animación, mover al azar.
- Jugador como objeto editable (se mueve en el editor): cámara en primera persona, al hombro o fija (colocable), cuerpo, arma 2D/3D y proyectil (bala, imagen o modelo).
- Enemigo (dispara) y monstruo (cuerpo a cuerpo) con IA: modelo 3D o sprites por acción (quieto, caminar, atacar, daño) y mini animación.
- Colisión de modelos importados con rejilla 64³ fusionada en cajas: casas huecas se pueden recorrer.

## Novedades (v5)
- Tema visual nuevo; importar `.pack` desde la lista de proyectos; escenas reordenables con pulsación larga.
- Miniaturas en todos los selectores de imagen y modelo 3D (los modelos se dibujan con un rasterizador propio en CPU).
- Clones, romper en pedazos, ir/mover hacia un objeto, sacudir pantalla, detener todo.
- Partículas (humo, fuego, chispas, nieve, energía) con color de inicio y fin; ráfagas y bloque encender/apagar.
- Capa de la cámara por escena: imágenes fijas y efectos (VHS, cámara de video, visión nocturna, película vieja) o propios.
- Editor de texturas (lápiz, borrador, cubeta, gotero, espejo, deshacer) que guarda PNG.
- Exportar juego: nombre, paquete, versión, orientación e icono del APK (se compila con GitHub Actions: `game_dir`), opciones de ventana del .exe y paquetes para compilar después.

## Novedades v6
- Eventos nuevos: *Cuando el jugador dispare*, *Cuando se presione el botón X*, *Cuando se mueva (objeto)*, *Cuando el jugador se mueva / salte / reciba daño*.
- Botones en pantalla con acción "Solo bloques": solo lanzan el evento de bloques.
- Objetos bloqueables (botón Libre/Bloq en la ventana Objetos): no se seleccionan ni se mueven tocando la escena.
- El jugador tiene animaciones por estado e imágenes planas (sprites) como los enemigos.
- Diseño de bloques propio (tarjetas oscuras con barra de color).
- Pantalla de inicio blanca con el logo en los juegos exportados (APK y .exe) y fondo con imágenes en el menú de proyectos.
- Editor de fórmulas: Aceptar/Cancelar fijos arriba.

## Novedades v7
- **Editor de animación** (Archivos → Animaciones → Editar): dibujas el esqueleto con círculos y palos sobre el modelo; al mover los huesos la malla 3D se estira (skinning). Poses, clips con línea de tiempo, presets.
- **Importar animaciones** glTF/GLB y FBX (BVH pendiente).
- **Editor de texturas** en pestaña grande.
- **Selectores** de texturas/modelos/archivos en cuadrícula grande con vista previa real.
- **Terreno deformable** (montañas arriba/abajo, aplanar, suavizar) con colisión que sigue la forma.
- Comando **ir al jugador** (2D y 3D), reproducir/detener animación.
- **APK instalable ya compilado** desde la app (se mantiene "Exportar sin compilar").
- Android: pestañas fijas y contenido que se desliza con el dedo.

## Novedades v8
- **Mundo** (ventana Mundo): ambientación (por defecto / amarillento / azulado, suaves), clima (niebla, lluvia, tormenta de arena, nieve, personalizado con cantidad y color) y calidad general (baja/media/alta). Reflejos opcionales por objeto (apagados por defecto).
- **Bloques nuevos**: mientras…, repetir hasta…, fijar objetivo / quitar objetivo (3D), y de video (reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener).
- **Armas**: de fuego, cuerpo a cuerpo, arrojadiza y granada (opcionales); empezar con ella o recogerla del suelo (objeto con "Da esta arma"); balas por cargador, balas iniciales, disparo infinito, retroceso, recarga (botón RECARGAR / tecla R), cambio de arma (botón ARMA / tecla Q).
- **Giro del modelo** (enemigos y jugador): gira hacia donde camina o siempre al frente; distancia de cámara al hombro; ajuste de posición/giro/tamaño del modelo del jugador.
- **Fórmulas**: las funciones son fichas; solo se editan sus parámetros con la calculadora; el teclado sale solo con "abc"; borrar quita la función completa.
- **Animador**: zoom (+/−/rueda), mover la vista arrastrando, esqueleto humano también para la vista de lado; "Elegir animación" / "Crear animación" donde se eligen modelos de enemigos, monstruos y jugador.
- **Video**: importar (Archivos → Videos), verlo en cualquier objeto. Android: MediaPlayer (sonido) + cuadros por MediaMetadataRetriever. Windows: sin reproductor todavía.
- **Importar modelos pesados** en segundo plano con pantalla de carga y porcentaje.
- **Android**: la música se pausa al salir; botones de volumen funcionan; ventanas fijas (una a la vez) que se deslizan con el dedo.

## v8.1
- **Editor para Windows**: GitHub Actions ahora sube el artefacto `P-Maker-Windows` (pmaker_editor.exe + forge_runtime.exe). Ratón izquierdo = 1 dedo, botón derecho = 2 dedos (mover), rueda = acercar. Los proyectos van a Documentos\P-Maker.
- Importación de archivos grandes en Android: el archivo se copia por partes a un archivo temporal (hasta 1.5 GB) y se muestra "Leyendo el archivo…"; barra de progreso hasta 100% real.
- Textos largos: las etiquetas de casillas, barras, colores y listas ahora bajan de renglón en vez de cortarse.

## v9
- Animaciones nuevas (esqueleto humano): agachado, caminar agachado, correr (normal / pistola / arma larga), apuntar (pistola / arma larga), atacar con espada y cuchillo, golpear, sostener y lanzar, cubrirse, saltar, recibir daño, morir, recargar.
- Vegetación pintada con el dedo (realista, animada, lowpoly, textura propia), color y viento editables.
- Reflejos con menos blanco, niebla con color propio, clima realista (opcional), cantidad hasta 3x, agua/mar, modo RTX (apagado por defecto).
- Cámara fija con 3 modos, arma visible en tercera persona, bloques "no salir de la pantalla" (2D), "fijar objetivo: todas las entidades".
- Botón grande "Cerrar" en las ventanas, botones que bajan de renglón en vez de cortarse, "Invertir lado" en el editor de animación, menos lag al mover huesos.
- Importación: se recoge en cualquier pantalla (ya no se queda en 100%).

## v9.1
- Esqueleto humano automático: dos tipos (frente / lado) que sirven en cualquiera de las dos vistas; botón "Cambiar frente/lado" para modelos que salen girados.
- Animación nueva "impacto" (golpe fuerte que empuja hacia atrás).
- Bloques: inclinar la cámara a la derecha / izquierda, enderezar la cámara.
- Lápiz de texturas para el suelo (arena, pasto, roca, nieve, tierra o tu imagen).
- Balanceo de la cámara al caminar en primera persona (opcional, en el panel del jugador).

## v9.2
- Importación de modelos pesados: si pasan de ~400 mil triángulos se simplifican en vez de fallar; zip64 y archivos hasta 1.4 GB; mensajes de error claros; hilo con pila grande.
- Sonidos por defecto estilo militar (pasos, salto, aterrizaje, disparo, pistola, recarga, golpe, lanzar, daño, explosión, linterna). Se cambian en el panel "Sonidos del juego" o importando un audio con el mismo nombre.
- Linterna del jugador (alcance, apertura, color, parpadeo y dibujo opcional), botón LUZ / tecla F, bloques encender/apagar/alternar.
- Oscuridad de las sombras ajustable (clara ↔ oscura).
- Bloques: congelar todo menos al jugador / descongelar, congelar al jugador / descongelar.

## v10
- **APK desde Windows**: `editor/apkbuild.cpp` es la version C++ de `ApkPatcher.java` (manifest binario, resources.arsc, game.pack, zip alineado, firma v2 con SHA-256 + RSA propios). El editor de Windows lo usa si junto a `pmaker_editor.exe` estan `forge_template.apk`, `apk_sign_key.pk8` y `apk_sign_cert.der` (el workflow los mete en `P-Maker-Windows`; el job `windows-editor` ahora espera al `android-apk`).
  Prueba: `java -cp <cls> ApkPatcherSelfTest android/app/src/main/assets build/apkcli` (verificador independiente en Java; usar `LC_ALL=C.UTF-8 java -Dsun.jnu.encoding=UTF-8`).
- **Textos largos**: `wrapui::Button/Selectable/RadioButton` bajan de renglon en vez de cortar; las ventanas usan ajuste de texto; `shorten` ya casi no recorta.
- **Diseno**: botones con dibujos automaticos segun su palabra (`wrapui::iconFor`), mosaicos grandes en Proyectos (`wrapui::Tile`), barra superior con degradado.

## v10.1
- Corregido el error de Dear ImGui "conflicting ID" (niebla/mundo): los widgets envueltos usan prefijos de ID distintos por tipo.
- Botones de ancho fijo: nunca parten una palabra ("Deten/er"); si no cabe, se quita el dibujo y se ensancha.
- Escenas y objetos: sin botón "..."; pulsación larga abre renombrar/duplicar/mover/eliminar. Menos espacio entre renglones.
- Animaciones humanas rehechas (caminar, quieto, atacar, disparar pistola/arma larga) y se agregan solas al abrir el editor de animación en esqueletos de persona.
- Distancia de dibujado (Mundo): limita lo que se dibuja en mapas grandes.
- Torres sugeridas en el buscador de bloques (recetas en pages.cpp `kRecipes`).
- Controles 2D (cruceta / palanca / plataformas) táctiles y de teclado (Windows), con nombres de botón Izquierda, Derecha, Arriba, Abajo, A, B.
- 10 plantillas en Proyectos (`editor/templates.cpp`).

## v10.2
- Importar juegos de Pocket Code: `.catrobat`, `.zip` con `code.xml` o `.rar` → escenas, objetos, apariencias, sonidos, variables y bloques (~70 tipos de bloque traducidos; los que no existen en Forge se omiten y se avisa).
- `.rar`: se leen RAR4 y RAR5 **sin compresión** («Almacenar»). Los RAR comprimidos no se pueden descomprimir aquí: guárdalos como .zip.
- Ajustes por escena / todo el proyecto desde el menú de pulsación larga, orientación vertical/horizontal, bloques de IA entre enemigos, biblioteca de modelos/texturas, plantillas mejoradas, linterna con más alcance y potencia.
- La pantalla de proyectos se desliza con el dedo (sin barra); «Editar la escena» ahora está arriba en la página de la escena (2D y 3D).
- Animación: botones «Girar 90°/180°» (esta o todas) en la pestaña Animar; barra de vista en 2 filas de 4 botones iguales y lienzo más grande. Editor de texturas con botones iguales.
- Desenfoque de movimiento opcional (Mundo → «Desenfoque de movimiento»): mezcla el cuadro anterior según lo rápido que se mueve/gira la cámara (clave `mblur` del proyecto).

## v10.3
- Deformar por golpes (propiedades del modelo 3D): balas, explosiones, golpes de enemigos y choques fuertes abollan la malla (límite de hundimiento ajustable).
- Estudio de música y efectos (menú del proyecto / pestaña de sonidos): secuenciador de 16 pasos (melodía, acordes, bajo, bombo, caja, platillo), 8 tipos de juego, escalas, tono, BPM; generador de 8 efectos; biblioteca de sonidos. Guarda .wav en el proyecto.
- Físicas avanzadas: panel «Física» con casillas (dinámico/estático, masa, rebote, fricción, gravedad del objeto, resistencia del aire, empujable por el jugador, empujable por balas); choques dinámico-dinámico reparten impulso por masa; explosiones empujan; bloques: empujón, explosión de fuerza, resistencia del aire, gravedad del objeto, empujable.
- Iluminación global falsa y gráficos pro (Mundo): rebote del suelo, relleno de lado sombra, sombras con tinte de cielo, oclusión en base de paredes, tono de película. Clave `gi`.

## v10.4
- Plantillas rehechas (15): FPS almacén, shooter, Carreras (botones Izquierda/Derecha/Acelerar/Frenar), plataformas 3D, 2D x2, RPG con espada, hack&slash, FNAF 2D y 3D (puertas, cámaras, sustos), Runner, Flappy, Atrapa frutas, Clicker, Peleas 3D.
- Sombras con descarte alfa: partes transparentes/sin color no proyectan sombra; sombra del jugador.
- Corregido: la animación elegida en propiedades no se reproducía (se tomaba el primer .fanim del modelo).
- Editor de animación: visor del modelo más grande.
- Nuevos modelos procedurales (carro, espada, caballero, orco, esqueleto, luchadores, cámara, monitor, etc.).
- Importar modelos: ahora se abren .zip dentro de otro .zip (ej. descargas de Sketchfab con source/*.zip + textures/). Probado con un Dodge Challenger de 95 mil triángulos.

## v10.4.2
- Escenas: mantén presionada y desliza para moverlas; si no la mueves, se abre su menú.
- Catrobat: posiciones y movimientos (píxeles del proyecto) se convierten al tamaño del escenario; la orientación se copia del original.
- Editor 3D: barra superior más grande y táctil, botón JUGAR verde; doble toque sobre un objeto abre sus propiedades.

## v10.5
- Pantalla del juego (HUD) lista para usar: "Botones y arma" > "Pantalla del juego". Vida, escudo, munición, armas numeradas, minimapa, brújula, velocímetro, reloj, puntos, objetivo, 4 tipos de mira, marcador de impacto, pantalla roja con poca vida, viñeta y estilos de color. 4 estilos rápidos (Doom/COD, mundo abierto, carreras, terror).
- Botones nuevos: Correr y Agacharse (mantener). Un toque agrega Correr, Agacharse y Recargar.
- Variables: vida, escudo, municion, reserva, puntos, tiempo, objetivo.

## v10.5.1
- Windows/Android: corregido el error de compilación en templates.cpp (conversión int a float en una lista con llaves).
- Animaciones sin malla (p. ej. Mixamo "sin piel"): ya se importan. El esqueleto se ajusta a tamaño unitario o se une por nombre al esqueleto del editor (cadera, pecho, hombro_i, codo_d...).
- Editor de animación: el visor usa todo el alto, botones en columna a la derecha, zoom con dos dedos (y mover la vista), pestañas sin cortar.
- Añadir > Modelo 3D abre una ventana de cuadrícula (antes el submenú se encimaba y elegía el primero).

## v10.6
- Ayuda dentro de la app: Inicio > mosaico "Ayuda", o menú Proyecto > "Ayuda: guías paso a paso". Carpetas y subcarpetas, buscador, 76 guías con 333 pasos y dibujos que muestran dónde tocar (barra, menús, pestañas, bloques, HUD, esqueleto).
- El texto está en editor/help_content.cpp (formato: #carpeta, ##subcarpeta, ###guía | intro, - paso, @ dibujo).

## v10.9
- Barra superior flotante (Añadir/Ventanas/JUGAR) y bordes azules estilo sci-fi.
- Escena 2.5D (Scene.side25, línea `scene nombre 3d side`): cámara lateral, movimiento en X, plano fijo.
- Peleas 3D: el jugador ya camina hacia el rival y golpea (puño visible); el inicio quedaba atorado en el ring.
- Plantillas 2D: yaw 90 = sin girar (salían acostadas).

- 31 modelos nuevos (estructuras, vehículos, armas, soldados, vegetación) inspirados en el PDF de referencia (estilo low-poly con paleta).
- Música: la vista previa no sonaba porque el audio en memoria no se puede "streamear"; ahora se reproduce. 24 efectos de sonido; 16 pasos visibles con cursor.

## v10.8
- Teclas/mouse/control: WASD por defecto en Windows (test y .exe), remapeables en Proyecto > Controles; gamepad automático en el .exe.
- "Ocultar botones virtuales": casilla en el test de Windows y opción (apagada) al exportar el .exe. Android conserva palanca y botones.
- Resolución del juego (550p–8K, por defecto 1080p) solo al jugar y en el juego exportado (render a textura + escalado).
- Gizmo X/Y/Z, zoom con rueda y barras de desplazamiento (solo Windows), modos de giro del Jugador, selectores de imagen en cuadrícula.

## v10.7
- **Fijar al enemigo** (Jugador → "Fijar al enemigo"): al atacar o siempre, el personaje gira hacia el enemigo más cercano.
- **Vista lateral 2.5D**, **deslizar el dedo** (botones "Deslizar izquierda/derecha/arriba/abajo") y **corredor infinito de 3 carriles**.
- Barras de pelea (jugador/rival, nombres, reloj, combos) y variable `vidaRival`; variables `jugadorx/y/z`.
- Plantillas rehechas: Hack and slash (vista 3/4), Peleas 3D (2.5D), Peleas 2D (nueva), Plataformas 2D, Flappy pixel, Shooter 2D (soldados, puentes, tanque), Runner 3D, Carreras (coche mirando al frente + 3 rivales), FNAF 2D (oficina, pasillos oscuros, cámaras moradas).
- Modelos redondeados (elipsoides, cilindros, cápsulas, conos): soldados, civiles, policía, zombi, luchadores, armas de fuego y cuerpo a cuerpo, tanque, helicóptero, tren, edificio.
- Sprites pixel-art nuevos (héroe, bicho, ladrillos, tubos, pájaro, soldados, tanque, explosión...).
- El frente de los modelos (+Z) ahora apunta hacia donde mira el jugador y los enemigos.
- "Ambientes listos" (un toque) en la ventana del Mundo.
- Categoría de bloques **Multijugador** (red local UDP, Wi-Fi/hotspot, sin internet): activar automático, crear/unirse, mensajes, variables compartidas; los demás jugadores aparecen como fantasmas 3D. Bluetooth e internet NO incluidos.
- Android: permisos de red + multicast lock.

### v10.9d
- Animaciones por acción: además de Quieto/Caminar/Atacar/Recibir daño ahora hay Correr, Saltar y Apuntar/Disparar (se eligen entre las animaciones del propio modelo). Si no asignas una, se usa Caminar/Atacar.
- Pendiente (siguiente sesión): animaciones ligadas al modelo, cambiar modelo conservando animaciones, y paquetes UAL2/KayKit/Kenney.
- v10.9d (interfaz): barra superior con píldora "+ Añadir | Ventanas" y JUGAR cuadrado; menú Ventanas con iconos; ya no se activa un botón al soltar el dedo tras deslizar; tamaño general (más grande/chico), estirar con asas e inclinación en cualquier posición (3D).
- v10.9e: importar modelos: texturas ya no se estiran (UV por esquina al simplificar y mosaico por triángulo); el recuadro amarillo se ajusta al modelo; palanca virtual en el editor 3D (Windows: WASD/QE y clic derecho); bloques: menú con Subir/Bajar/Mover a otra torre y arrastrar con "=" ya funciona de nuevo.
- v10.9f: bloque "Si" separado en "Si verdadero" y "Si verdadero, sino"; panel Transformar en Objetos (medidas, giro, inclinación, tamaño general) y asas para girar en la vista; editor de animación con el diseño de la referencia (pestaña vertical, lista desplegable, iconos sobre el lienzo).
- v10.9g: Editor de modelos 3D por bloques (menú Archivos o Añadir > Crear modelo 3D): capas de 16x16x16, poner/borrar/pintar/gotero, 32 colores o una textura, espejo, guardar como modelo (.fmdl) y añadir a la escena.
- v10.9h: biblioteca por defecto con paquetes CC0: 19 armas/objetos (Kenney Blaster Kit), 56 piezas de plataforma (KayKit Platformer, 4 colores) y un maniquí animado (Quaternius UAL2) con 16 animaciones. Están en Añadir > Modelo 3D (cuadrícula). Datos en editor/packs_data.cpp (generado, comprimido).
- v10.9i: tipografía Roboto en toda la interfaz; editor de animación reorganizado (reproductor y fotogramas arriba, opciones de animación a la derecha, botones del lienzo funcionando); joystick y flechas quedan debajo de las ventanas; correcciones de CI (zip plano, pruebas, triángulos de modelos).


## v11.0
- Selector de modelos/imágenes en las animaciones por acción: ahora abre la cuadrícula con miniaturas (antes salía una lista vertical).
- Cielos con diseño: 11 estilos procedurales (nubes de día, nublado, noche con luna, noche estrellada, nebulosa violeta/azul, atardecer dorado, amanecer rosa, crepúsculo violeta, cumulonimbo) + cielo con tu propia imagen. Escena > Cielo.
- Motor gráfico ajustable: presets Ahorro/Equilibrado/Alto/Ultra; resolución de sombras (512–4096), sombras suaves (Poisson girado), filtrado anisotrópico, brillo especular del sol, tono de cine ACES y exposición. Se guarda en la línea `gfx` del proyecto.

## v11.1
- Editor de animación: letra y botones más chicos, dibujo del esqueleto mucho más grande, panel derecho solo con los ajustes de la animación elegida (la lista queda en la columna central).
- Mover escenas manteniendo presionado y deslizando funciona otra vez; la ventana de programa de bloques ya no se mueve al arrastrar bloques.
- Nueva escena 2.5D en el menú "+" de escenas. Objetos 2D: capas (delante/detrás de otro) en el menú del objeto.
- Animaciones también para cubos, modelos e ítems (Propiedades > Animaciones del objeto; se activan con "Reproducir animación").
- Hablar: voces (10 tonos/velocidades + voces del sistema), textos largos con pausas por espacio, y el texto se dice tal cual (solo las variables insertadas desde Datos se sustituyen).
- Editor de modelos por bloques: relleno, pincel 1-3, deshacer, mover/girar/voltear, vaciar, formas. 16 modelos por bloques nuevos en la biblioteca (árbol, pino, casa, coche, cofre, barril, roca, espada, escudo, llave, robot, hongo, farol, valla, flor, torre).

## v11.2
- Desenfoque de movimiento: hasta 3.0 (antes 1.0) y más sensible.
- Filtros de pantalla (Mundo/Gráficos): blanco y negro, bandas de color, caricatura (bordes), explosión de contraste, texturas realzadas, borroso, pixelado, retro y sepia, con intensidad.
- Opción "Metálico" en cualquier objeto/modelo/jugador (3D).
- Bloques nuevos: "Cuando X choque con este objeto, este objeto es empujado", "...el otro objeto es empujado", "Colisión: actúa como pared o piso" (2D). "No salir de la pantalla" ahora elige los lados (todos o cualquier combinación).
- Coloque en / Deslizar (2D) y Coloque en 3D: menú del bloque > "Elegir la posición tocando la pantalla".

## v11.3
- Minimapas con varios estilos (GTA / RDR / Watch Dogs…), alcance, tamaño y rotación; dibujan la geometría de la escena.
- Corregido: pantalla negra con filtros o resoluciones distintas de 1080p; aviso de ID duplicado al volver a "Normal"; botón "Animar" cortado.
- Metal real: reflejos en vivo del entorno (cubo que se redibuja una cara por cuadro desde el objeto metálico/reflectante más cercano), con modelos cercanos y jugador.
- Destellos de luz (lens flare) al mirar al Sol, se desactivan en Escena > Sol y luz.

## v11.4
- Desenfoque de movimiento real (direccional + radial), de 0 a 3 (brutal).
- Agua: 7 diseños (actual, caricatura, realista, oscuro, cristal, tropical, pantano).
- Nubes: actuales / realistas / con tu imagen, cantidad y viento.
- Selector de texturas/modelos/sonidos en 3 apartados (importados, creados, por defecto del sistema).
- ~60 sonidos nuevos en la biblioteca (+ variaciones grave/agudo).
- Modelos importados: color glTF lineal→sRGB (los coches ya no salen negros), texturas de materiales spec-gloss y luz horneada, sombreado liso automático (55°), arreglo de texturas/modelos que se quedaban blancos o invisibles para siempre si se pedían antes de existir, arreglo de reflejos al volver a abrir la app, menos manchas oscuras de sombra.
- Biblioteca: 12 autos low poly, 21 vehículos (camión, bus, taxi, patrulla…), Mazda deportivo y 3 autos de calle.

## v11.5
- Vegetación: más estilos (flores, helechos, arbustos…); astros (sol, luna, planetas, anillos) con tamaño ajustable; botones de restablecer (objeto, jugador, cielo, ambiente, mar, gráficos).
- Nubes: 9 estilos con mejor ruido; desenfoque de movimiento ya no deja la pantalla negra.
- Pasos numéricos y menú de proyectos sin textos encimados.
- Física: la colisión de modelos 3D ahora usa los límites reales de la malla (antes usaba el cubo completo y el modelo quedaba flotando o trabado); si un objeto queda metido en el suelo, sube solo en vez de quedarse inmóvil.
