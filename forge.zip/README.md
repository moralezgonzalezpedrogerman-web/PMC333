# Forge

Creador de juegos para Android con motor propio en C++ (sin Unity/Godot).

- **Editor por páginas** (como Pocket Code): Proyecto → Escenas → Escena (Fondo + Actores y objetos) → Objeto con pestañas Scripts / Apariencias / Sonidos.
- **Bloques en español** (Eventos, Control, Movimiento, Sonido, Apariencia, Datos + extras 3D), se ordenan **arrastrando** el asa `=`; tocar el asa da ayuda, duplicar y eliminar.
- **Editor de fórmulas** con teclado de calculadora y listas Funciones / Objeto / Dispositivo / Lógica / Datos.
- Escenas **2D** (menús, juegos planos) y **3D** (niveles en primera persona), que pueden alternarse con "Iniciar escena".
- Exporta a APK (GitHub Actions) y a .exe (el .exe se arma dentro de la app).

## Compilar
Sube a tu repositorio solo `forge.zip` y `.github/workflows/build.yml`; el workflow descomprime y compila (pruebas, runtime de Windows y APK).

## Pruebas locales
`cmake -S tests -B build-tests && cmake --build build-tests && ctest --test-dir build-tests`

## Pendiente
Editor 3D de rejilla estilo FPS Creator, pintor de texturas, listas, lápiz, cámara y sensores en los bloques.

## Novedades (v4)
- Bloques dibujados como piezas conectadas (sombrero, rieles en bucles y "si", espacio entre guiones).
- Bloques nuevos: reproducir sonido y esperar, cambiar vista de cámara, esperar hasta, detener guion, disparar al jugador, quitar vida, velocidad y salto del jugador, reproducir animación, mover al azar.
- Jugador como objeto editable (se mueve en el editor): cámara en primera persona, al hombro o fija (colocable), cuerpo, arma 2D/3D y proyectil (bala, imagen o modelo).
- Enemigo (dispara) y monstruo (cuerpo a cuerpo) con IA: modelo 3D o sprites por acción (quieto, caminar, atacar, daño) y mini animación.
- Colisión de modelos importados con rejilla 64³ fusionada en cajas: casas huecas se pueden recorrer.

## Novedades (v5)
- Tema visual nuevo; importar `.pack` desde la lista de proyectos; escenas reordenables con pulsación larga.
- Miniaturas en todos los selectores de imagen y modelo 3D (los modelos se dibujan con un rasterizador propio en CPU).
- Clones, romper en pedazos, ir/mover hacia un objeto, sacudir pantalla, detener todo.
- Partículas (humo, fuego, chispas, nieve, energía) con color de inicio y fin; ráfagas y bloque encender/apagar.
- Capa de la cámara por escena: imágenes fijas y efectos (VHS, cámara de video, visión nocturna, película vieja) o propios.
- Editor de texturas (lápiz, borrador, cubeta, gotero, espejo, deshacer) que guarda PNG.
- Exportar juego: nombre, paquete, versión, orientación e icono del APK (se compila con GitHub Actions: `game_dir`), opciones de ventana del .exe y paquetes para compilar después.

## Novedades v6
- Eventos nuevos: *Cuando el jugador dispare*, *Cuando se presione el botón X*, *Cuando se mueva (objeto)*, *Cuando el jugador se mueva / salte / reciba daño*.
- Botones en pantalla con acción "Solo bloques": solo lanzan el evento de bloques.
- Objetos bloqueables (botón Libre/Bloq en la ventana Objetos): no se seleccionan ni se mueven tocando la escena.
- El jugador tiene animaciones por estado e imágenes planas (sprites) como los enemigos.
- Diseño de bloques propio (tarjetas oscuras con barra de color).
- Pantalla de inicio blanca con el logo en los juegos exportados (APK y .exe) y fondo con imágenes en el menú de proyectos.
- Editor de fórmulas: Aceptar/Cancelar fijos arriba.

## Novedades v7
- **Editor de animación** (Archivos → Animaciones → Editar): dibujas el esqueleto con círculos y palos sobre el modelo; al mover los huesos la malla 3D se estira (skinning). Poses, clips con línea de tiempo, presets.
- **Importar animaciones** glTF/GLB y FBX (BVH pendiente).
- **Editor de texturas** en pestaña grande.
- **Selectores** de texturas/modelos/archivos en cuadrícula grande con vista previa real.
- **Terreno deformable** (montañas arriba/abajo, aplanar, suavizar) con colisión que sigue la forma.
- Comando **ir al jugador** (2D y 3D), reproducir/detener animación.
- **APK instalable ya compilado** desde la app (se mantiene "Exportar sin compilar").
- Android: pestañas fijas y contenido que se desliza con el dedo.

## Novedades v8
- **Mundo** (ventana Mundo): ambientación (por defecto / amarillento / azulado, suaves), clima (niebla, lluvia, tormenta de arena, nieve, personalizado con cantidad y color) y calidad general (baja/media/alta). Reflejos opcionales por objeto (apagados por defecto).
- **Bloques nuevos**: mientras…, repetir hasta…, fijar objetivo / quitar objetivo (3D), y de video (reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener).
- **Armas**: de fuego, cuerpo a cuerpo, arrojadiza y granada (opcionales); empezar con ella o recogerla del suelo (objeto con "Da esta arma"); balas por cargador, balas iniciales, disparo infinito, retroceso, recarga (botón RECARGAR / tecla R), cambio de arma (botón ARMA / tecla Q).
- **Giro del modelo** (enemigos y jugador): gira hacia donde camina o siempre al frente; distancia de cámara al hombro; ajuste de posición/giro/tamaño del modelo del jugador.
- **Fórmulas**: las funciones son fichas; solo se editan sus parámetros con la calculadora; el teclado sale solo con "abc"; borrar quita la función completa.
- **Animador**: zoom (+/−/rueda), mover la vista arrastrando, esqueleto humano también para la vista de lado; "Elegir animación" / "Crear animación" donde se eligen modelos de enemigos, monstruos y jugador.
- **Video**: importar (Archivos → Videos), verlo en cualquier objeto. Android: MediaPlayer (sonido) + cuadros por MediaMetadataRetriever. Windows: sin reproductor todavía.
- **Importar modelos pesados** en segundo plano con pantalla de carga y porcentaje.
- **Android**: la música se pausa al salir; botones de volumen funcionan; ventanas fijas (una a la vez) que se deslizan con el dedo.

## v8.1
- **Editor para Windows**: GitHub Actions ahora sube el artefacto `P-Maker-Windows` (pmaker_editor.exe + forge_runtime.exe). Ratón izquierdo = 1 dedo, botón derecho = 2 dedos (mover), rueda = acercar. Los proyectos van a Documentos\P-Maker.
- Importación de archivos grandes en Android: el archivo se copia por partes a un archivo temporal (hasta 1.5 GB) y se muestra "Leyendo el archivo…"; barra de progreso hasta 100% real.
- Textos largos: las etiquetas de casillas, barras, colores y listas ahora bajan de renglón en vez de cortarse.

## v9
- Animaciones nuevas (esqueleto humano): agachado, caminar agachado, correr (normal / pistola / arma larga), apuntar (pistola / arma larga), atacar con espada y cuchillo, golpear, sostener y lanzar, cubrirse, saltar, recibir daño, morir, recargar.
- Vegetación pintada con el dedo (realista, animada, lowpoly, textura propia), color y viento editables.
- Reflejos con menos blanco, niebla con color propio, clima realista (opcional), cantidad hasta 3x, agua/mar, modo RTX (apagado por defecto).
- Cámara fija con 3 modos, arma visible en tercera persona, bloques "no salir de la pantalla" (2D), "fijar objetivo: todas las entidades".
- Botón grande "Cerrar" en las ventanas, botones que bajan de renglón en vez de cortarse, "Invertir lado" en el editor de animación, menos lag al mover huesos.
- Importación: se recoge en cualquier pantalla (ya no se queda en 100%).

## v9.1
- Esqueleto humano automático: dos tipos (frente / lado) que sirven en cualquiera de las dos vistas; botón "Cambiar frente/lado" para modelos que salen girados.
- Animación nueva "impacto" (golpe fuerte que empuja hacia atrás).
- Bloques: inclinar la cámara a la derecha / izquierda, enderezar la cámara.
- Lápiz de texturas para el suelo (arena, pasto, roca, nieve, tierra o tu imagen).
- Balanceo de la cámara al caminar en primera persona (opcional, en el panel del jugador).

## v9.2
- Importación de modelos pesados: si pasan de ~400 mil triángulos se simplifican en vez de fallar; zip64 y archivos hasta 1.4 GB; mensajes de error claros; hilo con pila grande.
- Sonidos por defecto estilo militar (pasos, salto, aterrizaje, disparo, pistola, recarga, golpe, lanzar, daño, explosión, linterna). Se cambian en el panel "Sonidos del juego" o importando un audio con el mismo nombre.
- Linterna del jugador (alcance, apertura, color, parpadeo y dibujo opcional), botón LUZ / tecla F, bloques encender/apagar/alternar.
- Oscuridad de las sombras ajustable (clara ↔ oscura).
- Bloques: congelar todo menos al jugador / descongelar, congelar al jugador / descongelar.

## v10
- **APK desde Windows**: `editor/apkbuild.cpp` es la version C++ de `ApkPatcher.java` (manifest binario, resources.arsc, game.pack, zip alineado, firma v2 con SHA-256 + RSA propios). El editor de Windows lo usa si junto a `pmaker_editor.exe` estan `forge_template.apk`, `apk_sign_key.pk8` y `apk_sign_cert.der` (el workflow los mete en `P-Maker-Windows`; el job `windows-editor` ahora espera al `android-apk`).
  Prueba: `java -cp <cls> ApkPatcherSelfTest android/app/src/main/assets build/apkcli` (verificador independiente en Java; usar `LC_ALL=C.UTF-8 java -Dsun.jnu.encoding=UTF-8`).
- **Textos largos**: `wrapui::Button/Selectable/RadioButton` bajan de renglon en vez de cortar; las ventanas usan ajuste de texto; `shorten` ya casi no recorta.
- **Diseno**: botones con dibujos automaticos segun su palabra (`wrapui::iconFor`), mosaicos grandes en Proyectos (`wrapui::Tile`), barra superior con degradado.

## v10.1
- Corregido el error de Dear ImGui "conflicting ID" (niebla/mundo): los widgets envueltos usan prefijos de ID distintos por tipo.
- Botones de ancho fijo: nunca parten una palabra ("Deten/er"); si no cabe, se quita el dibujo y se ensancha.
- Escenas y objetos: sin botón "..."; pulsación larga abre renombrar/duplicar/mover/eliminar. Menos espacio entre renglones.
- Animaciones humanas rehechas (caminar, quieto, atacar, disparar pistola/arma larga) y se agregan solas al abrir el editor de animación en esqueletos de persona.
- Distancia de dibujado (Mundo): limita lo que se dibuja en mapas grandes.
- Torres sugeridas en el buscador de bloques (recetas en pages.cpp `kRecipes`).
- Controles 2D (cruceta / palanca / plataformas) táctiles y de teclado (Windows), con nombres de botón Izquierda, Derecha, Arriba, Abajo, A, B.
- 10 plantillas en Proyectos (`editor/templates.cpp`).

## v10.2
- Importar juegos de Pocket Code: `.catrobat`, `.zip` con `code.xml` o `.rar` → escenas, objetos, apariencias, sonidos, variables y bloques (~70 tipos de bloque traducidos; los que no existen en Forge se omiten y se avisa).
- `.rar`: se leen RAR4 y RAR5 **sin compresión** («Almacenar»). Los RAR comprimidos no se pueden descomprimir aquí: guárdalos como .zip.
- Ajustes por escena / todo el proyecto desde el menú de pulsación larga, orientación vertical/horizontal, bloques de IA entre enemigos, biblioteca de modelos/texturas, plantillas mejoradas, linterna con más alcance y potencia.
- La pantalla de proyectos se desliza con el dedo (sin barra); «Editar la escena» ahora está arriba en la página de la escena (2D y 3D).
- Animación: botones «Girar 90°/180°» (esta o todas) en la pestaña Animar; barra de vista en 2 filas de 4 botones iguales y lienzo más grande. Editor de texturas con botones iguales.
- Desenfoque de movimiento opcional (Mundo → «Desenfoque de movimiento»): mezcla el cuadro anterior según lo rápido que se mueve/gira la cámara (clave `mblur` del proyecto).

## v10.3
- Deformar por golpes (propiedades del modelo 3D): balas, explosiones, golpes de enemigos y choques fuertes abollan la malla (límite de hundimiento ajustable).
- Estudio de música y efectos (menú del proyecto / pestaña de sonidos): secuenciador de 16 pasos (melodía, acordes, bajo, bombo, caja, platillo), 8 tipos de juego, escalas, tono, BPM; generador de 8 efectos; biblioteca de sonidos. Guarda .wav en el proyecto.
- Físicas avanzadas: panel «Física» con casillas (dinámico/estático, masa, rebote, fricción, gravedad del objeto, resistencia del aire, empujable por el jugador, empujable por balas); choques dinámico-dinámico reparten impulso por masa; explosiones empujan; bloques: empujón, explosión de fuerza, resistencia del aire, gravedad del objeto, empujable.
- Iluminación global falsa y gráficos pro (Mundo): rebote del suelo, relleno de lado sombra, sombras con tinte de cielo, oclusión en base de paredes, tono de película. Clave `gi`.

## v10.4
- Plantillas rehechas (15): FPS almacén, shooter, Carreras (botones Izquierda/Derecha/Acelerar/Frenar), plataformas 3D, 2D x2, RPG con espada, hack&slash, FNAF 2D y 3D (puertas, cámaras, sustos), Runner, Flappy, Atrapa frutas, Clicker, Peleas 3D.
- Sombras con descarte alfa: partes transparentes/sin color no proyectan sombra; sombra del jugador.
- Corregido: la animación elegida en propiedades no se reproducía (se tomaba el primer .fanim del modelo).
- Editor de animación: visor del modelo más grande.
- Nuevos modelos procedurales (carro, espada, caballero, orco, esqueleto, luchadores, cámara, monitor, etc.).
- Importar modelos: ahora se abren .zip dentro de otro .zip (ej. descargas de Sketchfab con source/*.zip + textures/). Probado con un Dodge Challenger de 95 mil triángulos.

## v10.4.2
- Escenas: mantén presionada y desliza para moverlas; si no la mueves, se abre su menú.
- Catrobat: posiciones y movimientos (píxeles del proyecto) se convierten al tamaño del escenario; la orientación se copia del original.
- Editor 3D: barra superior más grande y táctil, botón JUGAR verde; doble toque sobre un objeto abre sus propiedades.

## v10.5
- Pantalla del juego (HUD) lista para usar: "Botones y arma" > "Pantalla del juego". Vida, escudo, munición, armas numeradas, minimapa, brújula, velocímetro, reloj, puntos, objetivo, 4 tipos de mira, marcador de impacto, pantalla roja con poca vida, viñeta y estilos de color. 4 estilos rápidos (Doom/COD, mundo abierto, carreras, terror).
- Botones nuevos: Correr y Agacharse (mantener). Un toque agrega Correr, Agacharse y Recargar.
- Variables: vida, escudo, municion, reserva, puntos, tiempo, objetivo.

## v10.5.1
- Windows/Android: corregido el error de compilación en templates.cpp (conversión int a float en una lista con llaves).
- Animaciones sin malla (p. ej. Mixamo "sin piel"): ya se importan. El esqueleto se ajusta a tamaño unitario o se une por nombre al esqueleto del editor (cadera, pecho, hombro_i, codo_d...).
- Editor de animación: el visor usa todo el alto, botones en columna a la derecha, zoom con dos dedos (y mover la vista), pestañas sin cortar.
- Añadir > Modelo 3D abre una ventana de cuadrícula (antes el submenú se encimaba y elegía el primero).

## v10.6
- Ayuda dentro de la app: Inicio > mosaico "Ayuda", o menú Proyecto > "Ayuda: guías paso a paso". Carpetas y subcarpetas, buscador, 76 guías con 333 pasos y dibujos que muestran dónde tocar (barra, menús, pestañas, bloques, HUD, esqueleto).
- El texto está en editor/help_content.cpp (formato: #carpeta, ##subcarpeta, ###guía | intro, - paso, @ dibujo).

## v10.9
- Barra superior flotante (Añadir/Ventanas/JUGAR) y bordes azules estilo sci-fi.
- Escena 2.5D (Scene.side25, línea `scene nombre 3d side`): cámara lateral, movimiento en X, plano fijo.
- Peleas 3D: el jugador ya camina hacia el rival y golpea (puño visible); el inicio quedaba atorado en el ring.
- Plantillas 2D: yaw 90 = sin girar (salían acostadas).

- 31 modelos nuevos (estructuras, vehículos, armas, soldados, vegetación) inspirados en el PDF de referencia (estilo low-poly con paleta).
- Música: la vista previa no sonaba porque el audio en memoria no se puede "streamear"; ahora se reproduce. 24 efectos de sonido; 16 pasos visibles con cursor.

## v10.8
- Teclas/mouse/control: WASD por defecto en Windows (test y .exe), remapeables en Proyecto > Controles; gamepad automático en el .exe.
- "Ocultar botones virtuales": casilla en el test de Windows y opción (apagada) al exportar el .exe. Android conserva palanca y botones.
- Resolución del juego (550p–8K, por defecto 1080p) solo al jugar y en el juego exportado (render a textura + escalado).
- Gizmo X/Y/Z, zoom con rueda y barras de desplazamiento (solo Windows), modos de giro del Jugador, selectores de imagen en cuadrícula.

## v10.7
- **Fijar al enemigo** (Jugador → "Fijar al enemigo"): al atacar o siempre, el personaje gira hacia el enemigo más cercano.
- **Vista lateral 2.5D**, **deslizar el dedo** (botones "Deslizar izquierda/derecha/arriba/abajo") y **corredor infinito de 3 carriles**.
- Barras de pelea (jugador/rival, nombres, reloj, combos) y variable `vidaRival`; variables `jugadorx/y/z`.
- Plantillas rehechas: Hack and slash (vista 3/4), Peleas 3D (2.5D), Peleas 2D (nueva), Plataformas 2D, Flappy pixel, Shooter 2D (soldados, puentes, tanque), Runner 3D, Carreras (coche mirando al frente + 3 rivales), FNAF 2D (oficina, pasillos oscuros, cámaras moradas).
- Modelos redondeados (elipsoides, cilindros, cápsulas, conos): soldados, civiles, policía, zombi, luchadores, armas de fuego y cuerpo a cuerpo, tanque, helicóptero, tren, edificio.
- Sprites pixel-art nuevos (héroe, bicho, ladrillos, tubos, pájaro, soldados, tanque, explosión...).
- El frente de los modelos (+Z) ahora apunta hacia donde mira el jugador y los enemigos.
- "Ambientes listos" (un toque) en la ventana del Mundo.
- Categoría de bloques **Multijugador** (red local UDP, Wi-Fi/hotspot, sin internet): activar automático, crear/unirse, mensajes, variables compartidas; los demás jugadores aparecen como fantasmas 3D. Bluetooth e internet NO incluidos.
- Android: permisos de red + multicast lock.

### v10.9d
- Animaciones por acción: además de Quieto/Caminar/Atacar/Recibir daño ahora hay Correr, Saltar y Apuntar/Disparar (se eligen entre las animaciones del propio modelo). Si no asignas una, se usa Caminar/Atacar.
- Pendiente (siguiente sesión): animaciones ligadas al modelo, cambiar modelo conservando animaciones, y paquetes UAL2/KayKit/Kenney.
- v10.9d (interfaz): barra superior con píldora "+ Añadir | Ventanas" y JUGAR cuadrado; menú Ventanas con iconos; ya no se activa un botón al soltar el dedo tras deslizar; tamaño general (más grande/chico), estirar con asas e inclinación en cualquier posición (3D).
- v10.9e: importar modelos: texturas ya no se estiran (UV por esquina al simplificar y mosaico por triángulo); el recuadro amarillo se ajusta al modelo; palanca virtual en el editor 3D (Windows: WASD/QE y clic derecho); bloques: menú con Subir/Bajar/Mover a otra torre y arrastrar con "=" ya funciona de nuevo.
- v10.9f: bloque "Si" separado en "Si verdadero" y "Si verdadero, sino"; panel Transformar en Objetos (medidas, giro, inclinación, tamaño general) y asas para girar en la vista; editor de animación con el diseño de la referencia (pestaña vertical, lista desplegable, iconos sobre el lienzo).
- v10.9g: Editor de modelos 3D por bloques (menú Archivos o Añadir > Crear modelo 3D): capas de 16x16x16, poner/borrar/pintar/gotero, 32 colores o una textura, espejo, guardar como modelo (.fmdl) y añadir a la escena.
- v10.9h: biblioteca por defecto con paquetes CC0: 19 armas/objetos (Kenney Blaster Kit), 56 piezas de plataforma (KayKit Platformer, 4 colores) y un maniquí animado (Quaternius UAL2) con 16 animaciones. Están en Añadir > Modelo 3D (cuadrícula). Datos en editor/packs_data.cpp (generado, comprimido).
- v10.9i: tipografía Roboto en toda la interfaz; editor de animación reorganizado (reproductor y fotogramas arriba, opciones de animación a la derecha, botones del lienzo funcionando); joystick y flechas quedan debajo de las ventanas; correcciones de CI (zip plano, pruebas, triángulos de modelos).


## v11.0
- Selector de modelos/imágenes en las animaciones por acción: ahora abre la cuadrícula con miniaturas (antes salía una lista vertical).
- Cielos con diseño: 11 estilos procedurales (nubes de día, nublado, noche con luna, noche estrellada, nebulosa violeta/azul, atardecer dorado, amanecer rosa, crepúsculo violeta, cumulonimbo) + cielo con tu propia imagen. Escena > Cielo.
- Motor gráfico ajustable: presets Ahorro/Equilibrado/Alto/Ultra; resolución de sombras (512–4096), sombras suaves (Poisson girado), filtrado anisotrópico, brillo especular del sol, tono de cine ACES y exposición. Se guarda en la línea `gfx` del proyecto.

## v11.1
- Editor de animación: letra y botones más chicos, dibujo del esqueleto mucho más grande, panel derecho solo con los ajustes de la animación elegida (la lista queda en la columna central).
- Mover escenas manteniendo presionado y deslizando funciona otra vez; la ventana de programa de bloques ya no se mueve al arrastrar bloques.
- Nueva escena 2.5D en el menú "+" de escenas. Objetos 2D: capas (delante/detrás de otro) en el menú del objeto.
- Animaciones también para cubos, modelos e ítems (Propiedades > Animaciones del objeto; se activan con "Reproducir animación").
- Hablar: voces (10 tonos/velocidades + voces del sistema), textos largos con pausas por espacio, y el texto se dice tal cual (solo las variables insertadas desde Datos se sustituyen).
- Editor de modelos por bloques: relleno, pincel 1-3, deshacer, mover/girar/voltear, vaciar, formas. 16 modelos por bloques nuevos en la biblioteca (árbol, pino, casa, coche, cofre, barril, roca, espada, escudo, llave, robot, hongo, farol, valla, flor, torre).

## v11.2
- Desenfoque de movimiento: hasta 3.0 (antes 1.0) y más sensible.
- Filtros de pantalla (Mundo/Gráficos): blanco y negro, bandas de color, caricatura (bordes), explosión de contraste, texturas realzadas, borroso, pixelado, retro y sepia, con intensidad.
- Opción "Metálico" en cualquier objeto/modelo/jugador (3D).
- Bloques nuevos: "Cuando X choque con este objeto, este objeto es empujado", "...el otro objeto es empujado", "Colisión: actúa como pared o piso" (2D). "No salir de la pantalla" ahora elige los lados (todos o cualquier combinación).
- Coloque en / Deslizar (2D) y Coloque en 3D: menú del bloque > "Elegir la posición tocando la pantalla".

## v11.3
- Minimapas con varios estilos (GTA / RDR / Watch Dogs…), alcance, tamaño y rotación; dibujan la geometría de la escena.
- Corregido: pantalla negra con filtros o resoluciones distintas de 1080p; aviso de ID duplicado al volver a "Normal"; botón "Animar" cortado.
- Metal real: reflejos en vivo del entorno (cubo que se redibuja una cara por cuadro desde el objeto metálico/reflectante más cercano), con modelos cercanos y jugador.
- Destellos de luz (lens flare) al mirar al Sol, se desactivan en Escena > Sol y luz.

## v11.4
- Desenfoque de movimiento real (direccional + radial), de 0 a 3 (brutal).
- Agua: 7 diseños (actual, caricatura, realista, oscuro, cristal, tropical, pantano).
- Nubes: actuales / realistas / con tu imagen, cantidad y viento.
- Selector de texturas/modelos/sonidos en 3 apartados (importados, creados, por defecto del sistema).
- ~60 sonidos nuevos en la biblioteca (+ variaciones grave/agudo).
- Modelos importados: color glTF lineal→sRGB (los coches ya no salen negros), texturas de materiales spec-gloss y luz horneada, sombreado liso automático (55°), arreglo de texturas/modelos que se quedaban blancos o invisibles para siempre si se pedían antes de existir, arreglo de reflejos al volver a abrir la app, menos manchas oscuras de sombra.
- Biblioteca: 12 autos low poly, 21 vehículos (camión, bus, taxi, patrulla…), Mazda deportivo y 3 autos de calle.

## v11.5
- Vegetación: más estilos (flores, helechos, arbustos…); astros (sol, luna, planetas, anillos) con tamaño ajustable; botones de restablecer (objeto, jugador, cielo, ambiente, mar, gráficos).
- Nubes: 9 estilos con mejor ruido; desenfoque de movimiento ya no deja la pantalla negra.
- Pasos numéricos y menú de proyectos sin textos encimados.
- Física: la colisión de modelos 3D ahora usa los límites reales de la malla (antes usaba el cubo completo y el modelo quedaba flotando o trabado); si un objeto queda metido en el suelo, sube solo en vez de quedarse inmóvil.
- NPC y autos (v11.5): propiedades de un modelo 3D → «Movimiento automático y autos»: deambular por radio, ruta dibujada desde arriba (empujar, lanzar al más cercano o al jugador, ganas de ganar), solo se mueven cerca del jugador. Bloques: Deambular, Seguir ruta, Modo auto, Subir/Bajar del auto.
- Modo auto en modelos: botón «Conducir» al acercarse; dentro, botones Izquierda/Derecha/Acelerar/Frenar/Bajar, el auto tiene vida y si se destruye sigues a pie. Activar «Modo vehículo» del jugador pone los botones de carreras.
- Menú de inicio: columna Inicio (nombre + mosaicos) y panel Mis Juegos / Plantillas por categorías.
- v11.5b: modelos se apoyan sobre montañas (suelo deformable) y botón/opción «Pegarse al suelo»; selector de recursos con 3 botones (Importados / Creados / Por defecto); marca roja de acierto solo en enemigos y objetos elegidos; límites del mapa (círculo o cuadro) y zonas prohibidas dibujadas (jugador, enemigos/NPC, autos con ruta o un objeto por nombre).
- v11.5c: rendimiento del editor y del juego (no se dibuja lo que está fuera de pantalla ni lo que no cae en el mapa de sombras; miniaturas del selector solo las visibles, pocas por cuadro). 2D: ruta dibujada con lápiz sobre la pantalla y estela de copias de colores que se desvanecen.
- v11.5d: reflejos (la mira ya no se dibuja en el cubo de reflejos, el objeto reflectante no se ve a sí mismo, el cubo no salta entre objetos); autos con ruta: aceleran, frenan en curvas, vueltas configurables (3 por defecto, hasta 20, 0 = sin fin), frente del modelo ajustable (por defecto visto por detrás); cámara al hombro con altura; cámara propia de cada auto conducible (distancia y altura); modelo del jugador apoyado en el suelo según su altura real; nubes mucho más ligeras; límites y zonas visibles en el editor (postes de colores y en los mapas de ruta).
- v11.5e: corregido: un auto/NPC con ruta ya se mueve aunque tenga físicas dinámicas y «Pegarse al suelo» (usa la caja real del modelo). 2D: el lienzo de la ruta abarca más que la pantalla (los objetos pueden salir), bucle sin fin o N vueltas, empieza sola, y el bloque «Seguir su ruta» acepta vueltas (0 = sin fin) y sirve para activar/detener. Zoom con dos dedos/rueda y ventanas completas en los editores de dibujo; nuevas herramientas de zonas (formas, borrar). NPC: «Poner clones» con cantidad, radio y «si uno muere aparece otro hasta completar». Datos de cinemáticas listos (editor visual pendiente).
- v11.5f: bloques nuevos: «Apariencia anterior», «Mostrar/Ocultar texto» (con variables), «Guardar en el dispositivo la variable» y «Borrar del dispositivo la variable» (global, persiste al cerrar el juego). Cada escena es independiente por defecto (al cambiar se detiene la música y las variables vuelven a empezar; opción «Mantener variables y música» en Mundo → Escenas). Imágenes: al importar se corrige la orientación de fotos del celular (EXIF, antes salían giradas o espejadas), se aceptan BMP/GIF/TGA/PSD (se convierten a PNG) y se avisa si un archivo no se puede leer; los bordes de PNG transparentes ya no salen negros.
- v11.5g: colisión fiel al modelo: las partes transparentes de la textura ya no tienen colisión; las superficies que miran hacia arriba (rampas, subidas y bajadas, escaleras suaves) se caminan siguiendo la forma real del modelo (el jugador sube y baja pegado a ellas y los objetos se apoyan en su superficie). Reflejos: «Desenfoque del reflejo» por objeto (más borroso = más suave y barato) para Reflejos y Metálico. Programar con texto: botón «Código (texto)» en el programa de cada objeto; cada línea es un bloque (nombre("dato", ...)), se puede escribir, pegar el código que dé una IA y aplicarlo; «Copiar instrucciones para la IA» con estilo GDScript, C# o C++ (la IA responde en el formato de P-Maker). Opción «Ver FPS y milisegundos».
- v11.5h: animaciones por defecto = las 43 de «Universal Animation Library 2» (Quaternius, CC0) para cualquier esqueleto humano del editor (los nombres Unreal/Godot de huesos se reconocen al importar); se quitaron las antiguas (hay un botón «Quitar las antiguas por defecto» para esqueletos ya guardados). Escenas independientes también en la lista de escenas; las variables globales conservan su valor al cambiar de escena. Rutas: selector del frente del modelo con flecha en el mapa. Modo auto (jugador y modelos): arrastrar la pantalla ya no gira la cámara, el vehículo gira de verdad con los botones y solo mientras aceleras o frenas. Importar animaciones: ahora también toma el movimiento de la pelvis (agacharse, deslizarse). build.yml: caché de Gradle desactivada y 3 intentos con --refresh-dependencies.

## v11.5i
- Zonas prohibidas: relleno propio a prueba de figuras raras (antes ImGui podía trabarse/cerrarse), vista del mapa congelada al dibujar, figuras limitadas y saneadas.
- Ruta / modo auto: el rumbo ahora es -yaw-frente (coincide con cómo se dibuja el modelo), así la punta siempre va primero en las vueltas. Panel con el dibujo del modelo visto desde arriba para marcar la PUNTA (se guarda en frontOff).
- Rendimiento (Mundo > Rendimiento): culling de cámara on/off, distancia máxima, tope de FPS 30/60/120, máx. partículas, máx. luces, ahorro de memoria de imágenes (1-3), máx. clones vivos.
- Gizmo Híbrido (por defecto): flechas con punta (mover), aros (girar, de 5° en 5°), cubitos (estirar) y cuadro central (tamaño general). Se elige junto a los modos de asas en Propiedades > tamaño.
- Editor 2D: sin zoom, tocar y arrastrar cualquier objeto lo selecciona y lo mueve, fondo propio del editor (gris con cuadrícula y marco de pantalla), menú Añadir con Modelo 3D y 6 objetos listos.
- Deshacer/Rehacer global (botones abajo al centro, menú Archivo, Ctrl+Z / Ctrl+Y) y autoguardado cada 45 s.
- Sonido por distancia (Mundo): volumen y balance izquierda/derecha de los sonidos que lanza un objeto.
- No hecho aún: oclusión, fusión/instancias, LOD, atlas, pooling, carga perezosa, exportación limpia, térmico, programación con sintaxis Godot/Unity/Unreal, editor de cinemáticas, copias de modelos 3D, pintar caminos, mira.

## v11.5i (parte 2)
- Menú del objeto sin lag con animaciones: los esqueletos (.fanim) ya no se vuelven a leer en cada cuadro (se guardan en memoria y solo se releen si cambian).
- 2D: el marco amarillo de selección gira con el objeto y se ajusta a lo visible de la imagen; la colisión 2D usa ese mismo recuadro (sin bordes transparentes).
- Biblioteca nueva incluida (Añadir > Modelo 3D > Biblioteca): 592 muebles/objetos (lib_mueble_*), 17 personajes (lib_pj_*, modelo estático con textura), 105 piezas de bosque KayKit (lib_bosque_*), 160 texturas pequeñas (lib_stx_*) y 37 fondos 2D (lib_fondo_*).
- Animaciones por defecto: 217 (Universal Animation Library 1 y 2 + KayKit Character Animations). Se ponen en cualquier esqueleto humano del editor de modelos.
- Importador: ahora también acepta .dae, .stl y .ply; .blend/.3ds/.max/.c4d dan un aviso claro (exportar a .glb).
- 13 bloques nuevos: alternar/azar/limitar variable, color RGB, capa, color del cielo, alejarse de, pegar a cuadrícula, velocidad del juego, reiniciar escena, esperar cuadros, curar jugador, reaparecer jugador.

## v11.5j
- Windows: `packs_data.cpp` (34 MB) ahora va partido en 12 archivos `packs_data_N.cpp` para que el compilador no se quede sin memoria.
- Límites con figuras: al soltar el dedo el puntero se volvía inválido y la figura salía lejos; ahora se usa la última posición válida.
- Zoom del editor 2D de vuelta (el marco blanco marca lo que se ve en el juego).
- Tocar la pantalla ya no salta ni dispara (solo botones). Bloque nuevo «Cuando se pulse la pantalla».
- Bloques «Fijar a» / «Soltar», opción por objeto «Movimiento por controles virtuales» (2D, libre o con física).
- Auto: se inclina/gira un poco al dar vuelta; opción «Crear llantas...» (vistas lado/frente/arriba, círculos ajustables, «Recortar»).
- Gizmo 3D más grande y adaptado al tamaño del modelo; importar varios archivos a la vez (Android y Windows, se encolan).
- Sin verificar en dispositivo real: solo pruebas automáticas (3/3).

## v11.5n (Proyecto > Rendimiento)
- LOD: modelos de más de ~1200 triángulos tienen 2 versiones simplificadas (agrupando vértices) que se usan según la distancia y el tamaño. Solo al jugar, no en el editor.
- Resolución dinámica (baja/sube la resolución interna según el tiempo real de cada cuadro) y modo ahorro (30 FPS, resolución máx. 80 %). No lee la temperatura real del teléfono.
- Precarga de modelos e imágenes de la escena antes de jugar (evita tirones al aparecer objetos).
- Resumen de rendimiento por partida en un archivo local (rendimiento_<proyecto>.txt).
- NO incluido: descarga de contenidos/DLC, anti-trampas y analíticas en línea (necesitan servidor), DLSS/FSR real, ray tracing/GI, IK de pies y ragdolls.

## v11.5m
- Modelos «Por defecto»: sub-apartados (personajes, árboles y vegetación, rocas, casas y estructuras, carros, muebles, electrodomésticos, comida, cocina, limpieza, armas, juego, otros), clasificados por nombre.
- Crear mapa 2D: asas amarillas para cambiar el tamaño con dedo/mouse, opción Bloquear, campos [-] valor [+] (tocar el valor para escribir), orilla libre para deslizar. Lo creado ahí ya no se selecciona ni se mueve desde el editor 2D normal.
- Crear llantas: mismos campos compactos; el relleno negro es solo la banda del grosor (no las caras laterales).
- Colisiones 2D: el fondo del mapa y la Meta ya no son paredes. Salto del héroe 2D: un salto / doble / triple / propulsor, y los saltos extra solo se recuperan al tocar suelo.
- Al jugar o cambiar de escena se empieza fuera del auto con los botones normales. Al abrir/crear otro proyecto se cierran todas las ventanas abiertas.
- Arma en la mano: en el arma (modelo 3D) y en objetos con esqueleto, «Ponerla en la mano» con lado, giro, posición y tamaño.
- Sin probar en un dispositivo real ni en el CI de Windows.

## v11.5l
- "Jugar escena actual" (3D y 2D), animaciones Human Basic Motions (32 clips) con selector en cuadrícula, gizmo con asa de tamaño por eje.
- Pintar suelo / pasto: menos puntos por pincelada, más separación y la malla se reconstruye como máximo cada ~0.16 s (antes en cada pincelada).
- Jugador: en el editor se ve su modelo (no solo el cuadro verde); el modo auto del jugador también gira al dar vuelta; pantalla «Orientar el modelo» (frente / atrás desde arriba) al activar el modo vehículo.
- Crear llantas: vista del lado opuesto, panel de ajustes fijo y compacto con scroll, llanta moldeada al cilindro y relleno negro para los huecos. Crear mapa 2D: mismo panel fijo y compacto.
- Sin probar en un dispositivo real ni en el CI de Windows.

## v11.5k
- Windows: faltaba `#include <array>` en importer.cpp (error C2676/C2660).
- «Crear llantas»: se cerraba porque se dibujaban demasiados puntos (límite de 65 mil vértices de ImGui); ahora son pocos.
- Gizmo: el cuadro de tamaño ya no está al centro; hay uno después de la punta de cada flecha.
- «Animaciones por defecto» abre una cuadrícula con vista previa animada (esqueleto de palitos); «Seleccionar» agrega solo las elegidas. Ya no se agregan todas solas.
- Se quitó el bloque «Fijar a». «Movimiento por controles virtuales» ahora está en Propiedades (2D), con imágenes por acción y opción «Es una Meta».
- «Crear mapa 2D» (Mundo, escena 2D): partes del mapa (imagen larga/rectángulos sin límite de tamaño), objetos con colisión, Meta, inicio de la cámara; la pantalla sigue al héroe y el héroe no sale del mapa; con física: salto real (pantalla solo de lado) o pantalla que sube y baja.
- Objeto «Meta» (menú Agregar 2D y mapa): cambia a otra escena al tocarla el héroe.

## v11.5o
- Animaciones: corrección de retarget (modelos en T-pose vs animaciones con brazos abajo). Los clips ya agregados a un rig antes de esta versión hay que volver a agregarlos.
- Jugador: ya no se dibuja el cuadro amarillo si tiene modelo/sprite; "Adaptar la colisión al modelo" y escala `fit`.
- Primera persona: altura de cámara (`eyeH`) con marcador cian en el editor; opción de ver el cuerpo del modelo (no hay brazos dedicados).
- Explosión: bloque "explosión" + panel (por defecto, sprites o modelo 3D; sin animación de rig en modelos).
- Rendimiento: "Trazado de rayos" (Windows: sombras 4096 + anisotrópico 16) / "Simulación liviana" (Android: sombras ≥1024). No es ray tracing real.

## v11.5p
- Las 16 plantillas ahora arrancan en una escena "Menú" (JUGAR), y tienen escenas "Victoria" y "Derrota" (jugar de nuevo / menú). Los finales se reconectan según el mensaje que decía la plantilla (ganaste/perdiste). No hay botón "Salir" porque el motor no tiene bloque de cerrar el juego.
- Las plantillas son las mismas de antes con esa estructura; no se rediseñaron una por una.

## v11.5q
- Repaso gráfico de las plantillas 3D (cielo, luz, niebla, sombras suaves 2048, atmósfera, pasto) y ajustes de calidad/rendimiento (LOD, resolución dinámica, precarga).
- Shooters: derrota si vida ≤ 0, victoria al llegar a los puntos objetivo.
- Plantilla nueva 17: "Asedio zombi" (FPS nocturno, 12 zombis + jefe, botiquines).

## v11.5r
- Pintura de suelo: solo se dibuja sobre suelo/terreno con colisión y se construye por pinceladas nuevas (mucho menos lag).
- Gizmo: aros de girar apagados por defecto (casilla para activarlos).
- Zona prohibida: ahora es UN solo objeto (máscara 512x512 de 1 m) con pincel/borrador de grosor ajustable, rectángulo, círculo, polígono y Deshacer. Las zonas viejas siguen funcionando.
- Animaciones: lista única de 24 acciones (quieto, apuntar, disparar, atacar, agacharse, recargar, interactuar, recoger, soltar, morir, daño, cambiar de arma, saltar, nadar, cubrirse, caminar der/izq/atrás, disparar caminando, desenfundar, guardar, personalizada). Se activan con el bloque "Reproducir animación". Las mini-animaciones numéricas (subir/bajar, balanceo...) ya no se muestran.
- Cámara al hombro: se aleja y sube según el tamaño del modelo (carros, camiones).

## v11.5s
- Colisión del jugador: el cuerpo de choque sale del tamaño real de su modelo (ancho/fondo/alto), ya no es una caja fija de 0.6x1.7.
- Propiedades del objeto: 4 pestañas grandes (Mover, Aspecto, Choque, Acciones); mismas opciones, agrupadas por tema.
- Modo pintar (suelo/vegetación/terreno): aviso visible con botón "Salir del modo pintar" (si se queda activo, el gizmo desaparece).

## v11.5t
- Al deslizar un menú con el dedo en vertical, se suelta el control que se tocaba (ya no cambian números/casillas sin querer).
- Ayuda: carpeta nueva "Guías nuevas: aprende cada función" (pestañas de Propiedades, gizmo, pintar suelo, zona prohibida con pincel, trazado de rayos, colisión, cámara, arma en la mano, lista de animaciones, explosiones, plantillas), con dibujos de dónde tocar.

## v11.5u
- Ayuda: segunda carpeta de guías (autos y llantas, orientar modelo, mapa 2D, saltos 2D, cielo/astros/nubes, mar, límites, biblioteca por categorías, juego completo menú-victoria-derrota, variables, rendimiento).

## v11.5v
- «Conducir» solo sale cerca del auto: ajuste "Distancia a la que sale el botón Conducir" (por auto, por defecto 1.5 m desde la orilla).
- Velocidad del jugador hasta 60.
- Animaciones por acción se guardan con cualquier objeto (antes solo con el jugador: en modelos/enemigos sin IA se perdían al reabrir) y la lista usa el rig del objeto.
- Botón Atrás de Android: sube un nivel (ayuda → menú, ventanas, escena, proyectos) en vez de cerrar el app. No probado en teléfono.
- Ayuda: guías sobre distancia de conducir, velocidad, animaciones y botón Atrás.

## v11.5w
- Animaciones: casilla "No reproducir" por acción; las acciones sin animación ya no caen a la pose de T (se queda con la anterior).
- 2D: «Caminata automática» en Crear mapa 2D (con física solo saltas; sin física mueves la nave por la pantalla).
- 2D: enemigos que disparan (dirección de la bala, vida, salida de pantalla, sprite) o golpean (sprite del golpe), con dibujos por movimiento; presets en Añadir > Objetos listos.
- Bloques nuevos: Ir en línea recta, Desaparecer al salir de pantalla, Desaparecer después de, Deslizar hacia el enemigo, Cancelar daño.
- Sin hacer: rutas de proyectil dibujadas con varios trazos y orden aleatorio.

## v11.5x
- 2D: ruta de la bala dibujada con el dedo (varias rutas, en orden o al azar), probado solo sin pantalla.
- «Modo fácil» en el panel del objeto: oculta opciones avanzadas (activado por defecto). Panel de Mundo y barra 3D aún sin reorganizar.

## v11.5y
- Enemigo 2D: «Tiempo entre cada disparo» (0.1–6 s) y «Velocidad de la bala» (0.5–60) más claros.
- Panel de Mundo (3D) en 4 pestañas: Cielo y luz, Ambiente, Gráficos, Juego. Sin probar en dispositivo. Barra del editor 3D sin reorganizar.

## v11.5z
- Texturas: la bandera global de stb quedaba en 1 y otros hilos (importar) guardaban/leían imágenes al revés a veces; ahora el motor voltea a mano y la bandera siempre es 0. Rectángulo de recorte de sprites ya no sale invertido. Imágenes >4096 se reducen (antes quedaban blancas) y una lectura fallida se reintenta.
- Opciones «Arreglar importación» (voltear de lado / arriba-abajo) para objetos 2D; el ancho/alto negativo se convierte solo en voltear (los bloques «Cuando pulse» ya responden).
- «Ajustar la forma a la de la imagen» y asas con el dedo para agrandar objetos en el editor 2D.
- Miniaturas de objetos con textura ya no salen al revés.
- Los bloques nuevos de las capturas de Catroid quedan pendientes.

## v11.5z2
- 2D: los objetos con imagen dibujaban las 6 caras del cubo sin profundidad; la cara de atrás (espejo) quedaba ENCIMA de la imagen y salía duplicada/volteada. Ahora solo se dibuja la cara de enfrente.

## v11.5z3
- 15 bloques nuevos (de las capturas de Catroid): ancho/alto (poner y cambiar), tono de color, color de partículas, detener otros guiones, repetir con pausa, contar desde-hasta, para cada cosa de la lista y 5 de listas (agregar, quitar, meter, cambiar, vaciar) + fórmulas elemento/largo/contiene de lista. Probados sin pantalla.
- NO hechos (dependen del teléfono o son muy grandes): hilos, diálogos, cámara/foto/captura, linterna ya existe, GIF/spritesheet, preguntar, URL, robot Phiro, proyectos externos, archivos, pegar sprite a cámara, animación suave, esquinas.

## v11.5z4
- Audio: miniaudio no copia los datos; ahora el motor guarda su propia copia y revisa que el archivo se pueda leer (antes un audio importado podía cerrar el programa o no sonar). Aviso si no se puede leer.
- «Elegir la posición» de los bloques Coloque/Deslizar: la marca amarilla se mueve DESLIZANDO un dedo y se confirma con «Aceptar posición».
- Apariencias: manda la primera de la lista de apariencias; si no hay, la imagen de Aspecto.
- Controles táctiles 2D por escena (+ «Solo palanca» y «Solo botones A y B»; botón para aplicar a todas).
- Colisión (Cuando hay una colisión): prueba todos los objetos con ese nombre vivos (clones), «jugador» en 2D y objetos rápidos (medio camino).
- Modo fácil desactivado por defecto. Ruta dibujada: «¿Dónde está la punta del dibujo?» + ajuste fino; distancia entre copias de la estela.
- Pendiente: cámara de fondo (AR), giroscopio, resto de bloques de Catroid.

## v11.5z5
- Ruta dibujada: al terminar puede esperar (segundos fijos, o al azar entre mínimo y máximo) y repetir; bloque «Reproducir la ruta dibujada» (una vez o no).
- Ocultar: el objeto oculto ya no choca, no se toca, no empuja, no dispara ni lo ven los enemigos.
- Cámara como fondo (trasera / delantera / apagar) en el objeto de fondo 2D, e inclinar el teléfono (giroscopio): bloques y fórmulas de giro x/y/z. Android: código Java/JNI NUEVO, sin compilar ni probar en teléfono. No hay cámara ni sensores en Windows.
- Importar audio M4A (también AAC, OGG, OPUS, AMR, 3GP): se convierte a WAV al importar. Android con MediaCodec (AudioConvert.java), Windows con Media Foundation (audioconv.cpp). Ninguno probado en dispositivo real; en pruebas solo se revisó la parte común con un convertidor falso.
- NO hecho: AR 3D, reorganizar la barra del editor 3D, plantillas pulidas, resto de bloques de Catroid.

## v11.5z6
- Menú «Agregar» del editor 3D reorganizado por tipo: Construir, Personajes y enemigos, Armas y cosas para recoger, Puertas y botones, Meta y teletransporte, Más cosas, Modelos 3D (nombres fáciles).
- 3 bloques nuevos «poco a poco»: hacerse de tamaño X %, volverse transparente X %, girar X grados, cada uno con su duración en segundos (el guion espera a que termine).
- v11.5z7: 4 bloques de cámara 2D: acercar/alejar (zoom %), seguir a un objeto, poner la cámara en X/Y, cámara normal. Solo 2D; el toque y el fondo respetan el zoom.

## v11.5z8
- Apuntar con la mira (3D): bloques «Apuntar con la mira», «Dejar de apuntar», «Apuntar / dejar de apuntar» y «Campo de visión». También: clic derecho / gatillo izquierdo (PC y mando) o un botón de pantalla llamado «Apuntar» (Mantener presionado). Al apuntar la imagen se acerca suave, se gira y camina más lento y el arma 3D pasa al lugar que elijas.
- Ajustes del jugador → «Vista del jugador y apuntar con la mira»: campo de visión (POV) normal y al apuntar, rapidez, giro, caminar y posición del arma al apuntar.
- v11.5z9: el arma de dibujo plano (sprite) también se centra, crece y sube al apuntar; «Giro del arma al apuntar» para el arma 3D.
- NO hecho: animación de apuntar con clip de esqueleto del modelo (el arma se desliza suave); en Android no hay clic derecho (usa un botón «Apuntar»).

## v11.5z10
- Arreglo de compilación: Windows (faltaban librerías de Media Foundation en forge_runtime) y pruebas Linux (categoría de bloques mal escrita y ayudante de pruebas faltante).
- Bloques: al arrastrar un bloque cerca del borde de la lista, el desplazamiento automático ahora es lento, suave, por tiempo y con una pequeña espera.

## v11.5z11
- Logo P-Maker como icono de la app Android (drawable-nodpi/app_icon.png) y del .exe de Windows (platform/windows/icon.ico + app.rc, en editor y runtime). Sin probar en CI.
- Sonido de «Probar»: botón Parar; se corta al cambiar de pantalla/escena/objeto y al salir del proyecto o del juego.
- Editor de texturas: «Abrir una textura importada»; lo que dibujes se guarda como una nueva (_editada).
- Ventana Mundo (3D): arreglado texto amontonado (el cursor se restaura al saltar pestañas ocultas).
- Colisión: si el objeto usa el bloque «Establecer colisión» y la tiene apagada, «Cuando haya colisión física» ya no se dispara.
- Rutas fijas: espera inicial (ajuste en 2D y 3D) y bloques: esperar antes de empezar, reiniciar, pausar y continuar ruta fija.

## v11.5z12
- Editor de fórmulas: la fórmula se ve en UNA línea de piezas (funciones dentro de funciones también en orden); tocas una pieza y la cambias con el teclado o con la lista. Teclado fijo de 5 columnas que se ajusta a la pantalla (sin deslizar). Borrar una pieza quita la función completa.
- Elegir objetos en fórmulas: pestaña Objeto → lista de objetos (se inserta 'Nombre'). Funciones nuevas: posición x/y/z de, tamaño de, dirección de, ancho de, alto de, capa de, transparencia de y distancia entre dos objetos.
- Bloques que pedían escribir ahora se eligen: guardar/leer/borrar variable del dispositivo, alternar/aleatoria/limitar/compartir variable, cinemática, ocultar texto, vaciar lista, cámara sigue objeto.
- Bloque nuevo «Leer del dispositivo la variable». «Leer/Borrar» solo ofrecen las variables que ya se guardaron con «Guardar en el dispositivo».
- Sin probar en pantalla real: el editor de fórmulas nuevo (diseño y toques) y los selectores.
- v11.5z13: teclado de fórmulas: caben las 5 filas siempre (sin deslizar), números centrados, zona de piezas más baja.

### v11.5z14
- Mundo (editor 3D): los botones/listas dibujados a mano (wrapui::Button, Selectable, Tile) ya no se pintan en pestañas ocultas (causa de los textos amontonados).
- Formas nuevas en el menú Añadir > Formas (esfera, cilindro, cono, pirámide, rampa, escalera, domo, prisma, tubo, cápsula).
- Editor de texturas: abrir una importada y guardarla como copia; panel más ancho.
- Pendiente: editor de cinemáticas, ruedas del jugador, ragdoll, optimización mundo abierto, pendientes de vehículos.

### v11.5z15
- Llantas del jugador (modo vehículo): botón «Crear llantas del auto del jugador» en Ajustes del jugador; las llantas siguen al cuerpo, giran al avanzar y las delanteras al dar vuelta (wheelOf = objeto Jugador).
- Ragdoll: en un objeto con modelo, «Ragdoll (cae a pedazos)» parte el modelo en cabeza, cuerpo, 2 brazos y 2 piernas (vista previa de colores, 3 ajustes). Bloque «Convertir este objeto en ragdoll» y opción de activarse al morir. Sin articulaciones: cada pedazo cae por separado.
- Mundo abierto: Mundo > «lo lejano duerme» (simDist) + botón «Preparar para mundo abierto». Objetos lejos del jugador no calculan física ni condiciones.

### v11.5z16
- Editor de cinemáticas (Mundo > Cinemáticas): ventana inferior, puntos de cámara grabados desde la vista del editor, pistas de objetos, vista previa de la cámara.
- Fórmulas: ≤ ≥ ≠ ya se ven (faltaban en el atlas de la fuente); mantener presionado < > = (≤ ≥ ≠) pone su contrario.
- 2D: la estela/aura de clones funciona con cualquier movimiento (antes solo con ruta). Nueva «Marcar la ruta en el juego»: puntos, línea punteada, flechas o rombos (color, grosor, cuántos puntos adelante), solo el tramo actual.
- Rendimiento: botón «Optimizar todo para celulares de pocos recursos».

### v11.5z17
- Clones: «por siempre crear clon» ya no se detiene (límite 600 → 100000 y los huecos de clones borrados se reutilizan). Números al azar con mt19937 (std::rand en Windows solo tenía 15 bits y las posiciones quedaban amontonadas).
- Navegación: al cambiar de pantalla se cierran ventanas y el cajón lateral, y todo empieza desde arriba; cerrar la pantalla de un objeto vuelve al editor si venías de él.

### v11.5z18
- Estela 2D: ahora va en la misma capa que el objeto (antes iba debajo y un fondo normal la tapaba); arreglo de tamaño de objetos creados por bloques.
- Bloques «Fin del bucle», «Fin de si» y «De lo contrario» ya no salen en la lista (se ponen solos).
- Nuevo bloque «Cuando se deslice un dedo (arriba→abajo, abajo→arriba, izq→der, der→izq)».
- Proyecto nuevo vacío: pregunta si la primera escena es 2D, 3D o 2.5D (experimental).
- «Colocar visualmente» (antes «elegir la posición arrastrando»): el objeto se ve y se arrastra de verdad; guarda sus coordenadas exactas. Disponible en Coloque (2D/3D), Deslizar a, Teletransportar jugador y Poner la cámara en.
- Texturas: se puede abrir una imagen de cualquier tamaño (se reduce a 256 px de lado mayor para dibujarla y se guarda como copia).
- Aspectos: «Elegir de los archivos» permite varias a la vez; las importadas se ordenan en carpetas por escena donde se usan.
