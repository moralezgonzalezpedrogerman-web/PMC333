#pragma once
#include "zip.h"
#include "../core/scene.h"
namespace forge {
// Convierte un juego de bloques antiguo (.catrobat = zip con code.xml) en un proyecto de Forge.
bool blockGameConvert(const ResMap& files, Project& out, int& nBricks, int& nSkipped, std::string& err);
// Lee un .rar (RAR4 y RAR5) con archivos ALMACENADOS (sin compresion). Devuelve cuantos archivos comprimidos no se pudieron leer.
bool rarRead(const std::vector<uint8_t>& rar, ResMap& out, int& unsupported, std::string& err);
}
