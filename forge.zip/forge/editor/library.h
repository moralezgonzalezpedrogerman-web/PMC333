#pragma once
#include <string>
#include <cstring>
#include <vector>
#include "scene.h"
namespace forge {
// Biblioteca de P-Maker: modelos 3D, texturas y musica/sonidos hechos por codigo. Se agregan al proyecto al elegirlos.
struct LibItem { std::string name; int kind; };  // kind: 0 textura, 1 sonido, 2 modelo
const std::vector<LibItem>& libraryItems();
bool libraryHas(const std::string& name);
const char* voxLibName(int i);
int voxLibCount();
bool voxLibraryAdd(const std::string& name, Files& assets);
bool libraryAdd(const std::string& name, Files& assets);   // agrega el item (y lo que necesite) si falta
void libraryPrune(Files& assets, const std::string& projectText);  // quita lib_* que nadie usa (al exportar)
// Nombre genérico para mostrar (los archivos de la biblioteca pueden recordar a marcas reales: aquí se ven neutros)
inline std::string neutralName(std::string s) {
    static const char* const m[][2] = {{"auto_ghini", "auto_superdeportivo_a"}, {"auto_fenyr", "auto_superdeportivo_b"}, {"auto_lamb", "auto_superdeportivo_c"},
        {"auto_kamaro", "auto_muscle_c"}, {"auto_italia", "auto_deportivo_c"}, {"auto_jeep", "auto_todoterreno"}, {"auto_mazda_deportivo", "auto_deportivo_a"}, {"auto_mobil", "auto_clasico"}};
    for (auto& e : m) { size_t p = s.find(e[0]); if (p != std::string::npos) s.replace(p, strlen(e[0]), e[1]); }
    return s;
}
}
