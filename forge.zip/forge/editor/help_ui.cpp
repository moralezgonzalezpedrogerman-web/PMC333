// Pantalla de Ayuda: carpetas, subcarpetas, buscador y guías paso a paso con dibujos.
#include <algorithm>
#include <cctype>
#include "editor.h"
#include "help.h"
#include "wrapui.h"

namespace forge {

static std::string lower(std::string s) {
    for (auto& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

static const HelpFolder* folderAt(const std::vector<int>& path) {
    const HelpFolder* f = &helpRoot();
    for (int i : path) { if (i < 0 || i >= (int)f->sub.size()) return f; f = &f->sub[i]; }
    return f;
}

// busca una guía por su título en todo el árbol (para abrir una guía desde un enlace)
static bool findGuide(const HelpFolder& f, const std::string& title, std::vector<int>& path, int& gi) {
    for (size_t i = 0; i < f.guides.size(); i++) if (f.guides[i].title == title) { gi = (int)i; return true; }
    for (size_t i = 0; i < f.sub.size(); i++) {
        path.push_back((int)i);
        if (findGuide(f.sub[i], title, path, gi)) return true;
        path.pop_back();
    }
    return false;
}

void Editor::helpOpenGuide(const std::string& title) {
    std::vector<int> path;
    int gi = -1;
    if (findGuide(helpRoot(), title, path, gi)) { helpOpen_ = true; helpPath_ = path; helpGuide_ = gi; helpStep_ = 0; }
}

static void collect(const HelpFolder& f, const std::string& q, std::vector<std::pair<std::vector<int>, int>>& out, std::vector<int>& path) {
    for (size_t i = 0; i < f.guides.size(); i++) {
        const HelpGuide& g = f.guides[i];
        bool hit = lower(g.title).find(q) != std::string::npos || lower(g.intro).find(q) != std::string::npos;
        for (auto& st : g.steps) if (!hit && lower(st.text).find(q) != std::string::npos) hit = true;
        if (hit) out.push_back({path, (int)i});
    }
    for (size_t i = 0; i < f.sub.size(); i++) {
        path.push_back((int)i);
        collect(f.sub[i], q, out, path);
        path.pop_back();
    }
}

void Editor::helpUI(Renderer* r) {
    if (r) r->clear(w_, h_, 0.055f, 0.070f, 0.088f);
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    wrapui::Begin("##ayuda", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | kNoSB);
    const HelpFolder* F = folderAt(helpPath_);
    bool inGuide = helpGuide_ >= 0 && helpGuide_ < (int)F->guides.size();
    // ---- barra de arriba
    {
        float bh = fs * 2.6f, bw = fs * 7.f;
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.22f, 0.40f, 0.78f, 1.f));
        if (wrapui::Button(inGuide || !helpPath_.empty() ? "< Atrás" : "< Salir", ImVec2(bw, bh)) && tapped()) {
            if (inGuide) helpGuide_ = -1;
            else if (!helpPath_.empty()) helpPath_.pop_back();
            else helpOpen_ = false;
            helpStep_ = 0;
        }
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        std::string title = inGuide ? F->guides[helpGuide_].title : (helpPath_.empty() ? "Ayuda: aprende a hacer juegos" : F->title);
        ImGui::TextWrapped("%s", title.c_str());
    }
    ImGui::Separator();
    wrapui::BeginChild("##helpbody", ImVec2(0, 0), false, kNoSB);
    dragScroll();

    if (inGuide) {
        const HelpGuide& G = F->guides[helpGuide_];
        int n = (int)G.steps.size();
        helpStep_ = std::max(0, std::min(n - 1, helpStep_));
        if (helpStep_ == 0 && !G.intro.empty()) {
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.9f, 1.f, 1.f));
            ImGui::TextWrapped("%s", G.intro.c_str());
            ImGui::PopStyleColor();
            ImGui::Spacing();
        }
        if (n == 0) ImGui::TextDisabled("Esta guía todavía no tiene pasos.");
        else {
            const HelpStep& S = G.steps[helpStep_];
            // numero de paso y barra de avance
            ImGui::Text("Paso %d de %d", helpStep_ + 1, n);
            ImVec2 p = ImGui::GetCursorScreenPos();
            float bwid = ImGui::GetContentRegionAvail().x - fs * 0.5f;
            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->AddRectFilled(p, ImVec2(p.x + bwid, p.y + fs * 0.45f), IM_COL32(50, 56, 76, 255), 4.f);
            dl->AddRectFilled(p, ImVec2(p.x + bwid * (helpStep_ + 1) / n, p.y + fs * 0.45f), IM_COL32(40, 190, 150, 255), 4.f);
            ImGui::Dummy(ImVec2(1, fs * 0.8f));
            // dibujo
            bool wide = w_ > h_;
            if (!S.pic.empty()) {
                float pw = ImGui::GetContentRegionAvail().x - fs * 0.5f, ph = std::min(pw * (wide ? 0.34f : 0.55f), h_ * (wide ? 0.5f : 0.34f));
                ImVec2 org = ImGui::GetCursorScreenPos();
                ImGui::Dummy(ImVec2(pw, ph));
                helpDrawPic(ImGui::GetWindowDrawList(), org, ImVec2(pw, ph), S.pic, fs, ImGui::GetTime());
                ImGui::Spacing();
            }
            // texto grande y fácil
            ImGui::SetWindowFontScale(1.18f);
            ImGui::TextWrapped("%s", S.text.c_str());
            ImGui::SetWindowFontScale(1.f);
            ImGui::Dummy(ImVec2(1, fs * 0.6f));
            // botones
            float sp = ImGui::GetStyle().ItemSpacing.x, bw = (ImGui::GetContentRegionAvail().x - sp - fs * 0.5f) / 2.f, bh = fs * 3.f;
            ImGui::BeginDisabled(helpStep_ == 0);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.34f, 0.46f, 1.f));
            if (wrapui::Button("< Anterior", ImVec2(bw, bh)) && tapped()) helpStep_--;
            ImGui::PopStyleColor();
            ImGui::EndDisabled();
            ImGui::SameLine();
            bool last = helpStep_ >= n - 1;
            ImGui::PushStyleColor(ImGuiCol_Button, last ? ImVec4(0.15f, 0.62f, 0.34f, 1.f) : ImVec4(0.12f, 0.58f, 0.55f, 1.f));
            if (wrapui::Button(last ? "¡Listo!" : "Siguiente >", ImVec2(bw, bh)) && tapped()) {
                if (last) { helpGuide_ = -1; helpStep_ = 0; } else helpStep_++;
            }
            ImGui::PopStyleColor();
        }
    } else {
        // buscador
        ImGui::SetNextItemWidth(-fs * 0.5f);
        textInput("##hq", "Buscar en la ayuda (por ejemplo: carro, bloque, sonido)", helpQuery_, "buscar...");
        ImGui::Spacing();
        std::string q = lower(helpQuery_);
        if (!q.empty()) {
            std::vector<std::pair<std::vector<int>, int>> hits;
            std::vector<int> path;
            collect(helpRoot(), q, hits, path);
            ImGui::TextDisabled("%zu guías encontradas", hits.size());
            for (size_t i = 0; i < hits.size(); i++) {
                const HelpFolder* hf = folderAt(hits[i].first);
                ImGui::PushID((int)i);
                std::string lab = hf->guides[hits[i].second].title + "   (" + hf->title + ")";
                if (wrapui::Button(lab.c_str(), ImVec2(ImGui::GetContentRegionAvail().x - fs * 0.5f, fs * 2.8f)) && tapped()) {
                    helpPath_ = hits[i].first; helpGuide_ = hits[i].second; helpStep_ = 0; helpQuery_.clear();
                }
                ImGui::PopID();
            }
        } else {
            if (helpPath_.empty()) {
                ImGui::TextWrapped("Toca una carpeta, elige una guía y sigue los pasos. Cada paso tiene un dibujo que te enseña dónde tocar.");
                ImGui::Spacing();
            }
            static const ImVec4 pal[8] = {{0.03f, 0.60f, 0.72f, 1}, {0.30f, 0.32f, 0.82f, 1}, {0.14f, 0.40f, 0.82f, 1}, {0.46f, 0.30f, 0.84f, 1},
                                          {0.20f, 0.26f, 0.70f, 1}, {0.05f, 0.52f, 0.64f, 1}, {0.34f, 0.28f, 0.76f, 1}, {0.10f, 0.46f, 0.74f, 1}};
            static const int ics[8] = {wrapui::IcHome, wrapui::IcCube, wrapui::IcPen, wrapui::IcBolt, wrapui::IcGear, wrapui::IcFolder, wrapui::IcPlay, wrapui::IcImage};
            float avail = ImGui::GetContentRegionAvail().x - fs * 0.5f, sp = ImGui::GetStyle().ItemSpacing.x;
            int cols = w_ > h_ ? 4 : 2;
            float tw = (avail - sp * (cols - 1)) / cols, th = std::min(fs * 6.5f, tw * 0.75f);
            for (size_t i = 0; i < F->sub.size(); i++) {
                if (i % cols) ImGui::SameLine();
                ImGui::PushID((int)i);
                if (wrapui::Tile("##hf", F->sub[i].title.c_str(), ics[(i + helpPath_.size()) % 8], pal[(i + helpPath_.size()) % 8], ImVec2(tw, th)) && tapped()) { helpPath_.push_back((int)i); helpStep_ = 0; }
                ImGui::PopID();
            }
            if (!F->guides.empty()) {
                ImGui::Spacing();
                ImGui::SeparatorText("Guías");
                for (size_t i = 0; i < F->guides.size(); i++) {
                    ImGui::PushID(1000 + (int)i);
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.18f, 0.24f, 0.40f, 1.f));
                    if (wrapui::Button(F->guides[i].title.c_str(), ImVec2(avail, fs * 2.8f)) && tapped()) { helpGuide_ = (int)i; helpStep_ = 0; }
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    ImGui::End();
}

}  // namespace forge
