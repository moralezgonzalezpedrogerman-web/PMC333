#include "blkimport.h"
#include <cstring>
#include <functional>
#include <memory>

namespace forge {
namespace {

struct Node {
    std::string tag, text;
    std::map<std::string, std::string> at;
    std::vector<std::unique_ptr<Node>> kids;
    const Node* child(const char* t) const { for (auto& k : kids) if (k->tag == t) return k.get(); return nullptr; }
    std::string attr(const char* a) const { auto i = at.find(a); return i == at.end() ? "" : i->second; }
};

std::string dec(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '&') {
            size_t e = s.find(';', i);
            if (e != std::string::npos && e - i < 8) {
                std::string k = s.substr(i + 1, e - i - 1);
                char c = 0;
                if (k == "amp") c = '&'; else if (k == "lt") c = '<'; else if (k == "gt") c = '>'; else if (k == "quot") c = '"'; else if (k == "apos") c = '\'';
                if (c) { o += c; i = e; continue; }
            }
        }
        o += s[i];
    }
    return o;
}

std::unique_ptr<Node> parseXml(const std::string& s) {
    auto root = std::make_unique<Node>();
    std::vector<Node*> st{root.get()};
    size_t i = 0, n = s.size();
    while (i < n) {
        if (s[i] != '<') {
            size_t e = s.find('<', i);
            if (e == std::string::npos) e = n;
            if (st.size() > 1) st.back()->text += dec(s.substr(i, e - i));
            i = e;
            continue;
        }
        if (s.compare(i, 4, "<!--") == 0) { size_t e = s.find("-->", i); i = e == std::string::npos ? n : e + 3; continue; }
        if (s.compare(i, 2, "<?") == 0 || s.compare(i, 2, "<!") == 0) { size_t e = s.find('>', i); i = e == std::string::npos ? n : e + 1; continue; }
        if (s.compare(i, 2, "</") == 0) { size_t e = s.find('>', i); i = e == std::string::npos ? n : e + 1; if (st.size() > 1) st.pop_back(); continue; }
        size_t e = i + 1;
        char q = 0;
        while (e < n && (q || s[e] != '>')) { if (q) { if (s[e] == q) q = 0; } else if (s[e] == '"' || s[e] == '\'') q = s[e]; e++; }
        std::string tg = s.substr(i + 1, e - i - 1);
        bool selfClose = !tg.empty() && tg.back() == '/';
        if (selfClose) tg.pop_back();
        auto nd = std::make_unique<Node>();
        size_t p = 0;
        while (p < tg.size() && !isspace((unsigned char)tg[p])) p++;
        nd->tag = tg.substr(0, p);
        while (p < tg.size()) {
            while (p < tg.size() && isspace((unsigned char)tg[p])) p++;
            size_t k = p;
            while (p < tg.size() && tg[p] != '=' && !isspace((unsigned char)tg[p])) p++;
            std::string key = tg.substr(k, p - k);
            while (p < tg.size() && (isspace((unsigned char)tg[p]) || tg[p] == '=')) p++;
            if (p < tg.size() && (tg[p] == '"' || tg[p] == '\'')) {
                char qq = tg[p++];
                size_t v = p;
                while (p < tg.size() && tg[p] != qq) p++;
                if (!key.empty()) nd->at[key] = dec(tg.substr(v, p - v));
                p++;
            } else if (key.empty()) break;
        }
        Node* raw = nd.get();
        st.back()->kids.push_back(std::move(nd));
        if (!selfClose) st.push_back(raw);
        i = e + 1;
    }
    return root;
}

std::string trim(std::string s) {
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

std::string fx(const Node* f, float sc);
float gNumScale = 1.f;  // escala para números sueltos de fórmulas de posición (píxeles del proyecto -> pasos del escenario)
std::string fxNode(const Node* f, float sc) {
    if (!f) return "0";
    std::string type = trim(f->child("type") ? f->child("type")->text : "");
    std::string val = trim(f->child("value") ? f->child("value")->text : "");
    const Node* l = f->child("leftChild");
    const Node* r = f->child("rightChild");
    if (type == "NUMBER") {
        if (val.empty()) return "0";
        if (gNumScale != 1.f) { char nb[48]; snprintf(nb, sizeof nb, "%g", atof(val.c_str()) * gNumScale); return nb; }
        return val;
    }
    if (type == "STRING") return "'" + val + "'";
    if (type == "USER_VARIABLE" || type == "USER_LIST") return val;
    if (type == "BRACKET") return "(" + fxNode(r ? r : l, sc) + ")";
    if (type == "OPERATOR") {
        if (val == "MINUS") return "-" + fxNode(r ? r : l, sc);
        if (val == "LOGICAL_NOT") return "no " + fxNode(r ? r : l, sc);
        const char* o = val == "PLUS" || val == "ADD" ? "+" : val == "MINUS" || val == "SUB" ? "-" : val == "MULT" ? "*" : val == "DIVIDE" ? "/" :
                        val == "EQUAL" ? "==" : val == "NOT_EQUAL" ? "!=" : val == "SMALLER_THAN" ? "<" : val == "GREATER_THAN" ? ">" :
                        val == "SMALLER_OR_EQUAL" ? "<=" : val == "GREATER_OR_EQUAL" ? ">=" : val == "LOGICAL_AND" ? " y " : val == "LOGICAL_OR" ? " o " : "+";
        return fxNode(l, sc) + std::string(o) + fxNode(r, sc);
    }
    if (type == "FUNCTION") {
        std::string a = fxNode(l, sc);
        if (val == "SIN") return "sen(" + a + ")";
        if (val == "COS") return "cos(" + a + ")";
        if (val == "SQRT") return "raiz(" + a + ")";
        if (val == "ABS") return "abs(" + a + ")";
        if (val == "RAND") return "aleatorio(" + a + "," + fxNode(r, sc) + ")";
        return a;
    }
    return "0";
}
std::string fx(const Node* f, float sc) { return fxNode(f, sc); }

bool pngSize(const std::vector<uint8_t>& d, int& w, int& h) {
    if (d.size() < 24 || d[1] != 'P' || d[2] != 'N' || d[3] != 'G') return false;
    w = (d[16] << 24) | (d[17] << 16) | (d[18] << 8) | d[19];
    h = (d[20] << 24) | (d[21] << 16) | (d[22] << 8) | d[23];
    return w > 0 && h > 0;
}

void collect(const Node* n, const char* tag, std::vector<const Node*>& out) {
    for (auto& k : n->kids) { if (k->tag == tag) out.push_back(k.get()); }
}
void findAll(const Node* n, const char* tag, std::vector<const Node*>& out) {
    for (auto& k : n->kids) { if (k->tag == tag) out.push_back(k.get()); findAll(k.get(), tag, out); }
}

struct Map { const char* type; Op op; };
const Map kBricks[] = {
    {"WaitBrick", Op::Wait}, {"ForeverBrick", Op::Forever}, {"RepeatBrick", Op::Repeat}, {"LoopEndBrick", Op::LoopEnd}, {"LoopEndlessBrick", Op::LoopEnd},
    {"IfLogicBeginBrick", Op::If}, {"IfLogicElseBrick", Op::Else}, {"IfLogicEndBrick", Op::EndIf}, {"IfThenLogicBeginBrick", Op::If}, {"IfThenLogicEndBrick", Op::EndIf},
    {"PlaceAtBrick", Op::PlaceAt}, {"SetXBrick", Op::SetX}, {"SetYBrick", Op::SetY}, {"ChangeXByNBrick", Op::ChangeX}, {"ChangeYByNBrick", Op::ChangeY},
    {"MoveNStepsBrick", Op::Move}, {"TurnLeftBrick", Op::TurnLeft}, {"TurnRightBrick", Op::TurnRight}, {"PointInDirectionBrick", Op::PointDir},
    {"GlideToBrick", Op::GlideTo}, {"IfOnEdgeBounceBrick", Op::BounceEdge}, {"GoNStepsBackBrick", Op::GoBack}, {"ComeToFrontBrick", Op::GoFront},
    {"VibrationBrick", Op::Vibrate}, {"SetSizeToBrick", Op::SetSize}, {"ChangeSizeByNBrick", Op::ChangeSize}, {"ShowBrick", Op::Show}, {"HideBrick", Op::Hide},
    {"SetTransparencyBrick", Op::SetTransp}, {"ChangeTransparencyByNBrick", Op::ChangeTransp}, {"SetBrightnessBrick", Op::SetBright},
    {"ChangeBrightnessByNBrick", Op::ChangeBright}, {"ClearGraphicEffectBrick", Op::ClearFx}, {"NextLookBrick", Op::NextLook},
    {"SetLookBrick", Op::SetLook}, {"StopAllSoundsBrick", Op::StopSounds}, {"SetVolumeToBrick", Op::SetVolume}, {"ChangeVolumeByNBrick", Op::ChangeVolume},
    {"SpeakBrick", Op::Speak}, {"SayBubbleBrick", Op::Say}, {"SayForBubbleBrick", Op::Say}, {"ThinkBubbleBrick", Op::Say}, {"NoteBrick", Op::Note},
    {"SetVariableBrick", Op::SetVar}, {"ChangeVariableBrick", Op::ChangeVar}, {"ShowTextBrick", Op::ShowVar}, {"HideTextBrick", Op::HideVar},
    {"BroadcastBrick", Op::Broadcast}, {"BroadcastWaitBrick", Op::BroadcastWait}, {"StopScriptBrick", Op::StopScript}, {"StopAllScriptsBrick", Op::StopAll},
    {"CloneBrick", Op::CreateClone}, {"DeleteThisCloneBrick", Op::DeleteClone}, {"WaitUntilBrick", Op::WaitUntil}, {"RepeatUntilBrick", Op::RepeatUntil},
    {"SceneTransitionBrick", Op::StartScene}, {"SceneStartBrick", Op::StartScene}, {"PlaySoundBrick", Op::StartSound}, {"PlaySoundAndWaitBrick", Op::PlaySoundWait},
    {"SetGravityBrick", Op::SetGravity}, {"SetMassBrick", Op::SetMass}, {"SetBounceBrick", Op::SetBounce}, {"SetFrictionBrick", Op::SetFriction},
    {"PointToBrick", Op::PointTowards}, {"TurnRightSpeedBrick", Op::SpinRight}, {"TurnLeftSpeedBrick", Op::SpinLeft},
    {"GoToBrick", Op::GoToObject},
};
const Map kScripts[] = {
    {"StartScript", Op::WhenStart}, {"WhenScript", Op::WhenTap}, {"BroadcastScript", Op::WhenReceive}, {"WhenTouchDownScript", Op::WhenTap},
    {"WhenClonedScript", Op::WhenCloneStart}, {"WhenConditionScript", Op::WhenTrue}, {"WhenBounceOffScript", Op::WhenCollide},
};
bool lookup(const Map* m, size_t n, const std::string& t, Op& op) {
    for (size_t i = 0; i < n; i++) if (t == m[i].type) { op = m[i].op; return true; }
    return false;
}
std::string lc(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }

}  // namespace

bool blockGameConvert(const ResMap& files, Project& out, int& nBricks, int& nSkipped, std::string& err) {
    auto it = files.find("code.xml");
    if (it == files.end()) { err = "no tiene code.xml"; return false; }
    auto root = parseXml(std::string(it->second.begin(), it->second.end()));
    std::vector<const Node*> progs;
    findAll(root.get(), "program", progs);
    const Node* prog = progs.empty() ? root.get() : progs[0];
    Project P;
    if (const Node* h = prog->child("header")) if (const Node* pn = h->child("programName")) P.name = trim(pn->text);
    float sc = 1.f;
    int sw = 720, sh = 1280;
    if (const Node* h = prog->child("header")) {
        if (const Node* a = h->child("screenHeight")) sh = std::max(1, atoi(a->text.c_str()));
        if (const Node* a = h->child("screenWidth")) sw = std::max(1, atoi(a->text.c_str()));
    }
    float scale = 1000.f / (float)sh;
    if (sw > sh) scale = 1000.f / (float)sh;
    std::vector<const Node*> sceneNodes;
    findAll(prog, "scene", sceneNodes);
    std::vector<const Node*> holders;
    if (sceneNodes.empty()) holders.push_back(prog);
    else holders = sceneNodes;
    std::vector<const Node*> gv;
    findAll(prog, "userVariable", gv);
    for (auto* v : gv) { std::string nm = trim(v->text); if (nm.empty()) nm = v->attr("name"); if (!nm.empty() && std::find(P.globalVars.begin(), P.globalVars.end(), nm) == P.globalVars.end()) P.globalVars.push_back(nm); }
    std::vector<const Node*> uv2;
    findAll(prog, "programVariableList", uv2);
    for (auto* l : uv2) for (auto& k : l->kids) { std::string nm = trim(k->text); if (!nm.empty() && std::find(P.globalVars.begin(), P.globalVars.end(), nm) == P.globalVars.end()) P.globalVars.push_back(nm); }
    nBricks = nSkipped = 0;
    int si = 0;
    for (const Node* h : holders) {
        Scene S;
        S.is3d = false;
        S.name = "escena" + std::to_string(++si);
        if (const Node* nm = h->child("name")) { std::string t = trim(nm->text); if (!t.empty()) S.name = t; }
        const Node* ol = h->child("objectList");
        std::vector<const Node*> objs;
        if (ol) for (auto& k : ol->kids) if (k->tag == "object") objs.push_back(k.get());
        int idx = 0;
        for (const Node* on : objs) {
            Obj o;
            o.kind = Kind::Cube;
            std::string nm = on->attr("name");
            if (nm.empty() && on->child("name")) nm = trim(on->child("name")->text);
            if (nm.empty()) nm = "objeto" + std::to_string(idx + 1);
            o.name = nm;
            o.pos = V3{0, 0, 0};
            o.scale = V3{200, 200, 1};
            o.noColor = true;
            o.color[0] = o.color[1] = o.color[2] = 1.f;
            o.layer = idx;
            o.bg = (idx == 0);
            std::map<std::string, std::string> lookFile, sndFile;
            if (const Node* ll = on->child("lookList"))
                for (auto& k : ll->kids) if (k->tag == "look") {
                    std::string rawk = lc(k->attr("fileName"));
                    size_t sl0 = rawk.find_last_of("/\\");
                    if (sl0 != std::string::npos) rawk = rawk.substr(sl0 + 1);
                    auto ff = files.find(rawk);
                    if (rawk.empty() || ff == files.end()) continue;
                    std::string fn = rawk;
                    for (auto& c : fn) if (c == ' ') c = '_';
                    P.assets[fn] = ff->second;
                    lookFile[k->attr("name")] = fn;
                    o.looks.push_back(fn);
                }
            if (const Node* sl2 = on->child("soundList"))
                for (auto& k : sl2->kids) if (k->tag == "sound") {
                    std::string raw = lc(k->attr("fileName"));
                    size_t sl = raw.find_last_of("/\\");
                    if (sl != std::string::npos) raw = raw.substr(sl + 1);
                    auto f = files.find(raw);
                    if (raw.empty() || f == files.end()) continue;
                    std::string fn = raw;
                    for (auto& c : fn) if (c == ' ') c = '_';
                    P.assets[fn] = f->second;
                    sndFile[k->attr("name")] = fn;
                    o.sounds.push_back(fn);
                }
            if (!o.looks.empty()) {
                o.tex = o.looks[0];
                int w = 0, hh = 0;
                if (pngSize(P.assets[o.tex], w, hh)) o.scale = V3{w * scale, hh * scale, 1};
                if (o.bg) o.scale = V3{1000.f * sw / sh, 1000.f, 1};
            }
            if (const Node* sl3 = on->child("scriptList"))
                for (auto& sn : sl3->kids) {
                    if (sn->tag != "script") continue;
                    Op hop;
                    std::string st = sn->attr("type");
                    if (!lookup(kScripts, sizeof(kScripts) / sizeof(kScripts[0]), st, hop)) { nSkipped++; continue; }
                    Block hb;
                    hb.op = hop;
                    if (hop == Op::WhenReceive) { const Node* m = sn->child("receivedMessage"); hb.t = m ? trim(m->text) : "mensaje1"; }
                    o.blocks.push_back(hb);
                    const Node* bl = sn->child("brickList");
                    if (!bl) continue;
                    for (auto& bn : bl->kids) {
                        if (bn->tag != "brick") continue;
                        Op op;
                        if (!lookup(kBricks, sizeof(kBricks) / sizeof(kBricks[0]), bn->attr("type"), op)) { nSkipped++; continue; }
                        Block b;
                        b.op = op;
                        std::vector<const Node*> fl;
                        if (const Node* fln = bn->child("formulaList")) collect(fln, "formula", fl);
                        else if (const Node* fm = bn->child("formulaMap")) collect(fm, "formula", fl);
                        int nfm = 0;
                        for (auto* f : fl) {
                            std::string cat = f->attr("category");
                            if (op == Op::SetVar || op == Op::ChangeVar) { b.f[0] = fx(f, scale); break; }
                            if (nfm < 3) {
                                bool px = ((op == Op::PlaceAt) && nfm < 2) || op == Op::SetX || op == Op::SetY || op == Op::ChangeX ||
                                          op == Op::ChangeY || op == Op::Move || (op == Op::GlideTo && nfm >= 1);
                                gNumScale = px ? scale : 1.f;
                                b.f[nfm++] = fx(f, scale);
                                gNumScale = 1.f;
                            }
                        }
                        const OpInfo& oi = opInfo(op);
                        if (nfm == 0 && op != Op::SetVar && op != Op::ChangeVar) { b.f[0] = oi.f0; b.f[1] = oi.f1; b.f[2] = oi.f2; }
                        if (op == Op::Broadcast || op == Op::BroadcastWait) { const Node* m = bn->child("broadcastMessage"); if (!m) m = bn->child("message"); b.t = m ? trim(m->text) : "mensaje1"; }
                        else if (op == Op::SetVar || op == Op::ChangeVar) {
                            const Node* u = bn->child("userVariable");
                            b.t = u ? (u->text.empty() ? u->attr("name") : trim(u->text)) : "variable";
                            if (const Node* uv = bn->child("userVariableName")) b.t = trim(uv->text);
                            if (b.f[0].empty()) b.f[0] = "0";
                        } else if (op == Op::SetLook) {
                            const Node* lk = bn->child("look");
                            std::string ln = lk ? lk->attr("name") : "";
                            b.t = lookFile.count(ln) ? lookFile[ln] : (o.looks.empty() ? "" : o.looks[0]);
                        } else if (op == Op::StartSound || op == Op::PlaySoundWait) {
                            const Node* sd = bn->child("sound");
                            std::string sn2 = sd ? sd->attr("name") : "";
                            b.t = sndFile.count(sn2) ? sndFile[sn2] : (o.sounds.empty() ? "" : o.sounds[0]);
                        } else if (op == Op::Note) {
                            b.t = fl.empty() ? "" : trim(fxNode(fl[0], scale)); if (!b.t.empty() && b.t[0] == '\'') b.t = b.t.substr(1, b.t.size() - 2);
                        } else if (op == Op::StartScene) {
                            const Node* sc2 = bn->child("sceneToStart"); if (!sc2) sc2 = bn->child("scene");
                            b.t = sc2 ? (sc2->attr("name").empty() ? trim(sc2->text) : sc2->attr("name")) : "";
                        } else if (op == Op::Wait && b.f[0].empty()) b.f[0] = "1";
                        // bloques que en otros creadores de bloques usan milisegundos
                        o.blocks.push_back(b);
                        nBricks++;
                    }
                }
            // cerrar bucles sin cierre para que el guion sea valido
            S.objs.push_back(std::move(o));
            idx++;
        }
        if (S.objs.empty()) { Obj bg; bg.name = "Fondo"; bg.bg = true; bg.noColor = false; bg.scale = V3{1000.f * sw / sh, 1000.f, 1}; S.objs.push_back(bg); }
        P.scenes.push_back(std::move(S));
    }
    if (P.scenes.empty()) { err = "no se encontraron escenas"; return false; }
    P.hudDefault = false;
    P.ctl2d = 0;
    P.exportCfg.orient = sh > sw ? 1 : 0;  // misma orientación que el proyecto original
    out = std::move(P);
    return true;
}

// ------------------------------------------------------------------ RAR (solo archivos almacenados)
namespace {
uint32_t le32(const uint8_t* p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((uint32_t)p[3] << 24); }
bool vint(const std::vector<uint8_t>& d, size_t& p, uint64_t& v) {
    v = 0;
    for (int s = 0; s < 70 && p < d.size(); s += 7) { uint8_t b = d[p++]; v |= (uint64_t)(b & 0x7f) << s; if (!(b & 0x80)) return true; }
    return false;
}
std::string baseName(std::string n) {
    for (auto& c : n) { if (c == '\\') c = '/'; }
    size_t sl = n.find_last_of('/');
    if (sl != std::string::npos) n = n.substr(sl + 1);
    for (auto& c : n) c = (char)tolower((unsigned char)c);
    return n;
}
}  // namespace

bool rarRead(const std::vector<uint8_t>& d, ResMap& out, int& unsupported, std::string& err) {
    unsupported = 0;
    if (d.size() < 8 || memcmp(d.data(), "Rar!\x1a\x07", 6) != 0) { err = "no es un .rar"; return false; }
    bool v5 = d[6] == 1;
    size_t p = v5 ? 8 : 7;
    if (v5) {
        while (p + 7 < d.size()) {
            p += 4;  // crc
            uint64_t hs, type, fl, extra = 0, dsz = 0;
            if (!vint(d, p, hs)) break;
            size_t hend = p + (size_t)hs;
            if (hend > d.size()) break;
            if (!vint(d, p, type) || !vint(d, p, fl)) break;
            if (fl & 1) vint(d, p, extra);
            if (fl & 2) vint(d, p, dsz);
            if (type == 2) {
                uint64_t ff, usz, attr, comp, os, nl;
                vint(d, p, ff); vint(d, p, usz); vint(d, p, attr);
                if (ff & 2) p += 4;
                if (ff & 4) p += 4;
                vint(d, p, comp); vint(d, p, os); vint(d, p, nl);
                std::string name((const char*)d.data() + std::min(p, d.size()), (size_t)std::min<uint64_t>(nl, d.size() - std::min(p, d.size())));
                bool isDir = ff & 1;
                if (!isDir) {
                    if (((comp >> 7) & 7) == 0 && hend + dsz <= d.size()) out[baseName(name)] = std::vector<uint8_t>(d.begin() + hend, d.begin() + hend + (size_t)dsz);
                    else unsupported++;
                }
            }
            p = hend + (size_t)dsz;
            if (type == 5) break;
        }
    } else {
        while (p + 7 <= d.size()) {
            uint8_t type = d[p + 2];
            uint16_t fl = d[p + 3] | (d[p + 4] << 8), hs = d[p + 5] | (d[p + 6] << 8);
            if (hs < 7) break;
            uint32_t add = 0;
            if (type == 0x74) {
                if (p + 32 > d.size()) break;
                uint32_t pack = le32(&d[p + 7]);
                uint8_t method = d[p + 25];
                uint16_t nl = d[p + 26] | (d[p + 27] << 8);
                size_t np = p + 32;
                if (fl & 0x100) { np += 8; }
                add = pack;
                if (np + nl <= d.size()) {
                    std::string name((const char*)&d[np], nl);
                    size_t z = name.find('\0');
                    if (z != std::string::npos) name = name.substr(0, z);
                    bool isDir = (fl & 0xE0) == 0xE0;
                    if (!isDir) {
                        if (method == 0x30 && p + hs + (size_t)pack <= d.size()) out[baseName(name)] = std::vector<uint8_t>(d.begin() + p + hs, d.begin() + p + hs + pack);
                        else unsupported++;
                    }
                }
            } else if (fl & 0x8000) {
                if (p + 11 <= d.size()) add = le32(&d[p + 7]);
            }
            if (type == 0x7b) break;
            p += (size_t)hs + add;
        }
    }
    return true;
}

}  // namespace forge
