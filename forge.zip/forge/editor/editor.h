#pragma once
#include <deque>
#include "zip.h"
#include "musicstudio.h"
#include <climits>
#include <memory>
#include "imgui.h"
// v10.8: en Windows las ventanas muestran su barra de desplazamiento y la rueda del mouse; en Android se desliza con el dedo.
#ifdef _WIN32
#define kNoSB ImGuiWindowFlags_None
#define kNoSW ImGuiWindowFlags_None
#else
#define kNoSB ImGuiWindowFlags_NoScrollbar
#define kNoSW ImGuiWindowFlags_NoScrollWithMouse
#endif
#include "rig.h"
#include "model.h"
#include <ctime>
#include "audio.h"
#include "playview.h"
#include "renderer.h"
#include <functional>
#include <set>
#include <string>
#include <map>
#include <vector>

namespace forge {

// Servicios que la plataforma ofrece al editor.
struct EditorHost {
    std::string dataDir;  // carpeta privada: proyectos y exportaciones
    std::function<void()> pickFile;  // abre el selector; el archivo llega a Editor::onFile
    std::function<void(const std::string& displayName, const std::string& path)> saveOut;  // copiar a donde elija el usuario
    std::function<bool(std::vector<uint8_t>&)> loadRuntime;  // forge_runtime.exe (para exportar)
    std::function<void(const std::string& title, const std::string& initial)> prompt;  // cuadro de texto nativo (Android)
    std::function<void(float)> vibrate;                      // segundos
    std::function<void(const std::string&)> speak;           // texto a voz
    std::function<void(bool)> flash;                         // linterna
    std::function<void(int)> camera;                         // cámara de fondo (0 apagar, 1 atrás, 2 adelante)
    std::function<bool(int&, int&, std::vector<uint8_t>&)> cameraFrame;
    std::function<bool(float*)> sensors;                     // aceleración, brújula, giro
    // Android: crear un APK ya compilado e instalable dentro del telefono (vacio = no disponible)
    std::function<void(const std::string& packPath, const std::string& label, const std::string& appId, const std::string& iconPath,
                       const std::string& verName, const std::string& outName, int orient, int verCode)> buildApk;
    std::function<std::string()> buildApkStatus;             // "" trabajando, "OK:<ruta>[|AVISO:..]" o "ERROR:<mensaje>"
    std::function<void(const std::string& path)> installApk;  // abre el instalador de Android
};

// Exportacion (editor/exporter.cpp)
bool makeIconPng(const std::vector<uint8_t>& src, int size, std::vector<uint8_t>& out);
std::string exportSlug(const std::string& s);
bool validAppId(const std::string& id);

// Tema visual de toda la aplicacion (colores, bordes redondeados, espacios). Llamar antes de ScaleAllSizes.
void applyTheme();

enum class Screen { Projects, Edit, Play };
// Dentro de un proyecto (con bloques): lista de escenas -> escena (fondo y objetos) -> objeto (pestañas) -> editor visual.
enum class Page { Scenes, SceneHome, Object, Viewport };

constexpr int kShapeCount = 10;
const char* shapeName(int id);
struct ModelData;
bool makeShape(int id, ModelData& out);
bool posOpFields(Op op, bool is3d, int& base, int& dims);

class Editor {
public:
    explicit Editor(EditorHost h) : host_(std::move(h)) {}
    void init(Audio* audio);

    // Una vez por frame, con ImGui::NewFrame() ya llamado. r puede ser null (pruebas).
    void frame(Renderer* r, int w, int h, float dt);
    void openMusic();
    void closeMusic();
    bool importPack(const std::string& fileName, const std::vector<uint8_t>& data);
    bool saveImported(const std::string& baseName, Files& files);
    bool importBlockGame(const std::string& fileName, const ResMap& res);
    bool importRar(const std::string& fileName, const std::vector<uint8_t>& data);
    void onFile(const std::string& name, std::vector<uint8_t> data);  // archivo elegido por el usuario
    void onText(const std::string& text, bool ok);                    // respuesta del cuadro de texto nativo
    PlayControls& controls() { return play_.ctl; }

    // --- proyectos
    bool newProject(const std::string& name, bool demo);
    int newTemplate_ = -1;
    bool openProject(const std::string& name);
    bool saveProject(bool quiet = false);
    // v11.5i: deshacer / rehacer global (instantáneas del proyecto) y autoguardado
    std::vector<std::string> undo_, redo_;
    std::string undoCur_;
    float undoSettle_ = 0.f, autoSaveT_ = 0.f;
    bool undoReady_ = false;
    void undoTick(float dt);
    void doUndo(bool redo);
    void closeProject();
    bool buildPack(std::vector<uint8_t>& out);
    bool buildExe(std::vector<uint8_t>& out, std::string& err);

    // --- edicion (tambien usados por las pruebas)
    void addObject(Kind k, const std::string& modelName = "");
    void addShape(int id);   // esfera, cilindro, cono, pirámide, rampa, escalera, domo, prisma, tubo, cápsula
    void addScene(bool is3d);
    void select(int i) { sel_ = i; }
    void startPlay(bool current = false);
    void stopPlay();
    bool handleBack();   // botón/gesto Atrás del teléfono: sube un nivel (ayuda, ventanas, escena, proyecto). false = nada que cerrar
    Screen screen() const { return screen_; }
    Project& project() { return edit_.proj; }
    PlayView& play() { return play_; }
    int sceneIndex() const { return sceneIdx_; }
    void setScene(int i);
    int selected() const { return sel_; }
    const std::vector<std::string>& projectNames() const { return projList_; }
    bool dirty() const { return dirty_; }

    // Ventanas visibles (publico para poder activarlas desde pruebas).
    bool showObjs = false, showProps = true, showWorld = false, showHud = false, showAssets = false;
    Page page() const { return page_; }
    void setPage(Page p) { page_ = p; }
    struct PosPick { bool on = false; int obj = -1, blk = -1; bool init = false; V3 c; float lx = 0, ly = 0; V3 orig; bool moved = false; } posPick_;   // elegir una posición tocando la escena (bloques Coloque / Deslizar)
    void posPickUI();
    void posPickEnd();
    void openObject(int i) { sel_ = i; objBack_ = page_ == Page::Viewport ? Page::Viewport : Page::SceneHome; page_ = Page::Object; tab_ = 0; }
    int tab() const { return tab_; }
    void addObjectPreset(int id) { addPreset(id); }
    void openPalette() { pal_ = -1; }
    void openFormula(int blk, int field, const std::string& cur) { fe_.open = true; fe_.blk = blk; fe_.field = field; fe_.buf = cur; fe_.sel = -1; fe_.selArg = 0; fe_.replaceNext = false; fe_.kbPending = false; fe_.abcOn = false; }
    void openChoose(int blk) { te_.open = true; te_.blk = blk; }
    void setTab(int t) { tab_ = t; }
    // Bloques (usados tambien por las pruebas)
    int addBlock(Obj& o, Op op, bool withElse = false);                       // agrega con sus cierres (si, bucles); devuelve el indice
    static bool blockRange(const std::vector<Block>& B, int i, int& end);  // [i, end) que se mueve junto con el bloque i
    static bool moveRange(std::vector<Block>& B, int from, int to);       // mueve el grupo i antes del bloque "to"

#ifdef FORGE_TESTING
public:   // las pruebas sin pantalla acceden a los miembros internos
#else
private:
#endif
    EditorHost host_;
    Audio* audio_ = nullptr;
    Screen screen_ = Screen::Projects;
    Game edit_;                 // el proyecto en edicion (edit_.proj)
    PlayView play_;
    bool showAbout_ = false;
    void aboutWin();
    std::vector<std::string> loadQ_;   // pantalla de carga: archivos por preparar antes de jugar
    size_t loadTot_ = 0;
    void loadScreen(Renderer* r, float dt, bool* done, const char* title);
    std::string name_, newName_ = "mi_juego";
    std::vector<std::string> projList_;
    std::set<std::string> assetDirty_;
    int sceneIdx_ = 0, sel_ = -1;
    int audioCtx_ = INT_MIN; std::string previewName_;   // sonido de prueba en curso
    bool dirty_ = false;
    float snap_ = 0.25f;
    int w_ = 1, h_ = 1;

    // mensaje temporal
    std::string toast_;
    float toastT_ = 0;
    void toast(const std::string& t) { toast_ = t; toastT_ = 3.5f; }

    // camara del editor
    float yaw_ = 0.6f, pitch_ = 0.55f, dist_ = 14.f;
    V3 target_;
    float cx_ = 0, cy_ = 0, h2d_ = kView2DHeight;

    // gestos
    int prevN_ = 0;
    // v10.6: ayuda
    bool helpOpen_ = false;
    std::vector<int> helpPath_;
    int helpGuide_ = -1, helpStep_ = 0;
    std::string helpQuery_;
    void helpUI(Renderer* r);
    bool gestOk_ = false, dragObj_ = false;
    int gAxis_ = -1;               // v10.8: asa de mover activa (0 X, 1 Y, 2 Z)
    float gT0_ = 0;
    V3 gPos0_, gScale0_, gRot0_;
    bool gRotate_ = false;         // las asas giran el objeto (X=adelante/atrás, Y=horizontal, Z=de lado)
    int g2h_ = -1; V3 g2p_, g2s_;   // 2D: asa de tamaño que se está arrastrando (máscara 1 izq, 2 der, 4 arriba, 8 abajo)
    int worldTab_ = 0;             // pestaña del panel de Mundo
    bool easy_ = false;            // «Modo fácil»: el panel del objeto muestra solo lo básico
    int propTab_ = 0;              // pestaña del panel de propiedades: 0 Mover, 1 Aspecto, 2 Choque, 3 Acciones
    bool gRings_ = false;          // aros de girar en las asas (apagados: solo mover y estirar, así no giras sin querer)
    bool gHyb_ = true;             // v11.5i: asas híbridas (mover + girar + estirar a la vez, como otros editores)
    int gHk_ = 0;                  // qué asa híbrida se agarró: 0 flecha (mover), 1 aro (girar), 2 cubo (estirar), 3 centro (tamaño general)
    float gAng0_ = 0, gAcc_ = 0, gUni0_ = 1.f, gY0_ = 0;
    bool gStretch_ = false;        // v10.9d: las asas estiran el objeto en vez de moverlo
    bool toScreen(const EditorView& ev, V3 p, float& sx, float& sy) const;
    void drawGizmo();
    bool handles2D(Obj* o, ImVec2* pts, int* masks, int& n) const;
    float gizmoLen(const Obj& o) const;
    float lastX_ = 0, lastY_ = 0, lastDist_ = 0, moveAcc_ = 0;
    Page page_ = Page::Scenes;
    int tab_ = 0;
    float dragAcc_ = 0;
    V3 grab_;

    // ayudantes
    Scene& scene() { return edit_.proj.scenes[sceneIdx_]; }
    bool hasScene() const { return sceneIdx_ >= 0 && sceneIdx_ < (int)edit_.proj.scenes.size(); }
    Obj* selObj();
    std::string uniqueName(const std::string& base);
    void listProjects();
    void resetView();
    EditorView view() const;
    void rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const;
    int pick(float x, float y, const EditorView& ev);
    void gestures();
    std::vector<std::string> assetsOf(int kind) const;  // 0 imagen, 1 audio, 2 modelo
    void doExportExe();
    void doExportPack();
    bool showExport_ = false;
    bool buildApkPackage(std::vector<uint8_t>& out, std::string& err);
    bool buildExePackage(std::vector<uint8_t>& out, std::string& err);
    void exportWin();

    // pantallas y ventanas
    void projectsUI(Renderer* r);
    void editFrame(Renderer* r, float dt);
    void playFrame(Renderer* r, float dt);
    void menuBar();
    void objectsWin();
    void propsWin();
    void worldWin();
    void hudWin(Renderer* r);
    void assetsWin();
    void toastUI();

    // paginas (pages.cpp)
    void pageScenes(Renderer* r);
    void pageSceneHome(Renderer* r);
    void pageObject(Renderer* r);
    void scriptsTab(Obj& o);
    void codeWindow(Obj& o);
    bool codeOpen_ = false;
    int codeStyle_ = 0;
    std::string codeBuf_, codeErr_;
    void looksTab(Obj& o, Renderer* r);
    void soundsTab(Obj& o);
    void palettePage(Obj& o);
    void formulaPage(Obj& o);
    void choosePage(Obj& o);
    void dragScroll();
    bool sizeTiltPanel(Obj& o, bool tilt);
    void gesturesCore();
    int joyId_ = -1;               // dedo que sostiene la palanca virtual del editor 3D
    bool tapped() const;  // el ultimo item se solto sin arrastrar
    bool beginPage(const char* id);
    void endPage();
    bool topBar(const std::string& title, bool* back, bool* menu);
    void fab(bool* play, bool* plus);
    void objectMenuItems(int idx);
    void thumb(Renderer* r, const Obj& o, float size);
    Obj* currentObj() { return hasScene() && sel_ >= 0 && sel_ < (int)scene().objs.size() ? &scene().objs[sel_] : nullptr; }
    std::vector<std::string> varNames(const Obj& o) const;
    std::vector<std::string> messageNames() const;

    int pal_ = -2;  // -2 cerrada, -1 categorias, 0.. categoria
    std::string palSearch_;
    struct FEdit { bool open = false; int blk = -1, field = 0; std::string buf; int sel = -1, selArg = 0; bool replaceNext = false, kbPending = false, abcOn = false; std::string kb; } fe_;
    struct TEdit { bool open = false; int blk = -1; std::string buf; } te_;
    bool newVarOpen_ = false, newVarLocal_ = false;
    std::string newVarName_;
    int formulaList_ = 0;  // sublista abierta en el editor de formulas
    std::string renameBuf_;
    int renameWhat_ = 0, renameIdx_ = -1;  // 1 escena, 2 objeto
    bool pendingNewObj_ = false, pendingNewModel_ = false;
    std::string* promptDst_ = nullptr;
    bool promptActive_ = false;
    bool textInput(const char* id, const char* title, std::string& s, const char* hint = nullptr, float width = 0.f);
    void applyRename();
    void modalOpen(const char* name);  // la proxima imagen importada crea un objeto
    bool plusOpen_ = false, projMenu_ = false;
    int firstKind_ = 1; bool pickFirst_ = false;   // primera escena de un proyecto nuevo: 0 = 2D, 1 = 3D, 2 = 2.5D
    Page objBack_ = Page::SceneHome;   // a dónde vuelve la pantalla de un objeto al cerrarla
    Page lastPage_ = Page::Scenes; Screen lastScreen_ = Screen::Projects; int lastTab_ = 0; bool keepWin_ = false;
    void closeFloating();
    void resetScrollAll();
    int drawerOpen_ = -1;          // v10.9: cajón lateral derecho (-1 = por definir según la pantalla)
    int homeTab_ = 1;              // v10.9: pestaña vertical de la escena (0 Mundo, 1 Objetos)
    float drawerW() const;
    void renameUI();
    bool stepper(const char* label, float& v, float step);
    bool resetBtn(const char* key, const char* label);   // botón rojo de dos toques (confirmar antes de restablecer)
    std::string armedReset_;
    bool routeOpen_ = false;
    bool wheelsOpen_ = false;
    bool mapOpen_ = false;
    void openMap();
    bool mapWindow();
    bool orientOpen_ = false;
    void closeAllWindows();
    bool handFields(int& side, float* rot, float* off, float& hs);
    bool stepField(const char* label, float& v, float step, float mn, float mx, float w, const char* fmt = "%.0f");
    void orientWindow();
    std::vector<Obj> wheelNew_;
    void openWheels(Obj& o);
    bool wheelsPlayer_ = false; float wheelBminY_ = 0.f; Obj wheelProxy_;
    void openPlayerWheels();
    bool ragdollUI(Obj& o, Scene& S);
    bool cineOpen_ = false; int cineSel_ = 0; float cinePrev_ = -1.f, cinePrevDist_ = 14.f;
    void cineWindow();
    bool wheelsWindow(Obj& o, Scene& S);
    int startTab_ = 0;
    bool mvInit_ = false, mvPinch_ = false;
    float mvZoom_ = 1.f, mvCx_ = 0.f, mvCz_ = 0.f, mvPD_ = 0.f, mvPX_ = 0.f, mvPY_ = 0.f;
    void mapView(float k0, float bcx, float bcz, ImVec2 org, ImVec2 av, bool flipY, float& k, float& cx, float& cz);
    bool route2DOpen_ = false;
    std::vector<int> strokes_;
    bool vctlPanel(Obj& o, Scene& S);
    bool route2DPanel(Obj& o, Scene& S);
    bool route2DWindow(Obj& o, Scene& S, std::vector<float>* tgt = nullptr, bool rel = false, bool* openFlag = nullptr);
    bool bpathOpen_ = false; int bpathIdx_ = 0;
    bool zoneOpen_ = false;
    bool zoneWindow(Scene& S);
    bool autoPanel(Obj& o, Scene& S);
    bool routeWindow(Obj& o, Scene& S);
    void assetThumb(const std::string& name, int kind, float size);
    bool gridPicker(const char* id, std::string& cur, int kind, const char* none, bool open);
    std::vector<std::string>* gridMulti_ = nullptr;   // si no es nulo, el selector deja elegir VARIAS y las devuelve aquí
    bool assetCombo(const char* label, std::string& cur, int kind, const char* none);
    Renderer* rend_ = nullptr;
    int menuBg_ = (int)(std::time(nullptr) % 2);  // fondo del menú: pasillo o bosque
    std::map<int, float> lastObjRowMid_;  // centro de cada fila de la lista de objetos (para soltar)
    int objHold_ = -1;                 // objeto que se esta moviendo en la lista (pulsacion larga + arrastrar)
    int sceneHold_ = -1;               // escena que se esta moviendo (pulsacion larga)
    std::vector<std::pair<float, float>> sceneRows_;  // alto de cada fila (pantalla) para saber donde soltar
    bool playerPanel(Scene& S, Obj& o);
    bool aiPanel(Obj& o);
    bool enemy2dPanel(Obj& o);
    bool terrainPanel(Obj& o);
    bool skelPanel(Obj& o);
    std::vector<std::string> clipsFor(const Obj& o) const;
    bool clipCombo(const char* label, const Obj& o, std::string& clip);
    bool terrainPaint_ = false;
    // v9: vegetacion
    bool vegPaint_ = false, vegErase_ = false;
    int vegSel_ = 0;
    float vegRadius_ = 2.5f, vegDensity_ = 1.f, vegLastX_ = 1e9f, vegLastZ_ = 1e9f;
    bool gndPaint_ = false, gndErase_ = false;
    int gndSel_ = 0;
    float gndRadius_ = 3.f;
    bool gndPanel(Scene& S);
    void gndStamp(Scene& S, V3 hit);
    std::vector<std::string> soundList() const;   // sonidos del proyecto + los de por defecto
    bool soundPanel();
    bool flashPanel();
    bool vegPanel(Scene& S);
    bool groundHit(Scene& S, V3 ro, V3 rd, V3& hit);
    void vegStamp(Scene& S, V3 hit);
    int terrMode_ = 0;
    float terrRadius_ = 3.f, terrStrength_ = 4.f, terrTarget_ = 0.f;
    bool animPanel(Obj& o);
    bool fxPanel(Obj& o);
    // editor de texturas (dibujar pixeles)
    // editor de animación con esqueleto
    bool animOpen_ = false, animImportPending_ = false, animImgDirty_ = true, animWDirty_ = true, animAdd_ = false, animPlay_ = false, animMdOk_ = false;
    std::string animName_;
    Rig animRig_;
    ModelData animMd_;
    RigWeights animW_;
    RigPose animPose_;
    bool animFlip_ = false, animSwap_ = false;
    int animTab_ = 0, animView_ = 0, animSel_ = -1, animClip_ = 0, animKey_ = -1;
    float animT_ = 0;
    std::vector<uint8_t> animPx_;
    void openAnimEditor(const std::string& name, const std::string& modelHint = "");
    void animWin();
    // editor de modelos por bloques (voxel)
    bool voxOpen_ = false, voxDirty_ = true;
    std::vector<uint8_t> vox_, voxPx_;
    int voxY_ = 0, voxTool_ = 0, voxCol_ = 3, voxBrush_ = 1;
    std::vector<std::vector<uint8_t>> voxUndo_;
    std::string voxName_ = "mi_modelo", voxTex_;
    float voxYaw_ = 0.6f;
    void voxWin();
    void openVoxEditor(const std::string& name = "");
    bool voxSave(bool toScene);
    // v8: importar modelos pesados en otro hilo con pantalla de carga
    std::shared_ptr<struct ImpJob> imp_;
    std::deque<std::pair<std::string, std::vector<uint8_t>>> impQ_;   // modelos en espera (importar varios a la vez)
    void startModelImport(const std::string& name, std::vector<uint8_t> data);
    void pollImport();
    void importOverlay();
    bool reading_ = false;
    float readingT_ = 0.f;
    float animZoom_ = 1.f, animPanX_ = 0.f, animPanY_ = 0.f;
    bool animSave();
    void animLoadModel();
    void animFixSizes();
    void animPresets(const std::set<std::string>* only = nullptr);
    void animGridWin();
    bool animGridOpen_ = false, animGridFocus_ = false;
    std::set<std::string> animGridSel_;
    void animEnsureHuman();
    bool paintOpen_ = false;
    bool musicOpen_ = false, musicPlaying_ = false;
    MusicSong song_;
    int musicTab_ = 0, musicPage_ = 0, musicBrush_ = 0, sfxKind_ = 0, sfxSeed_ = 1;
    float sfxPitch_ = 1.f, sfxLen_ = 1.f;
    std::string musicName_ = "mi_musica", sfxName_ = "mi_efecto";
    std::string paintName_;
    int paintW_ = 32, paintH_ = 32, paintTool_ = 0, paintBrush_ = 1, paintNewSize_ = 32;
    std::vector<uint8_t> paintPx_;
    std::vector<std::vector<uint8_t>> paintUndo_, paintRedo_;
    float paintCol_[4] = {0.9f, 0.2f, 0.2f, 1.f};
    bool paintSym_ = false;
    void openPaint(const std::string& existing);
    bool paintSave();
    void paintWin();
    void musicWin();
    bool layerPanel(Scene& S);
    bool layerPreview_ = true;
    bool weaponPanel();
    bool weaponFields(Weapon& w, bool primary);
    bool hideVirtTest_ = false;   // v10.8: Windows: ocultar botones virtuales en el test
    int rebindAct_ = -1;          // v10.8: accion de teclado esperando una tecla
    void keymapUI(bool& ch);
    bool numField(const char* label, float& v, float mn, float mx, const char* fmt = "%.2f");
    bool numFieldI(const char* l, int& v, int mn, int mx) { float f = (float)v; bool c = numField(l, f, (float)mn, (float)mx, "%.0f"); if (c) v = (int)(f + 0.5f); return c; }
    void enforceOneWindow();
    float* promptNum_ = nullptr;
    float promptLo_ = -1e9f, promptHi_ = 1e9f;
    std::string numBuf_;
    bool prevW_[5] = {false, false, false, false, false};
    void addPreset(int id);
    bool grid3dOpen_ = false, modelsOpen_ = false;
    void projectMenu();
public:
    void helpOpenGuide(const std::string& title);
    void helpSetStep(int s) { helpStep_ = s; }
    void closeHelp() { helpOpen_ = false; helpGuide_ = -1; }
    void openCineEditor() { cineOpen_ = true; }
    bool helpIsOpen() const { return helpOpen_; }
    void openHelp() { helpOpen_ = true; helpPath_.clear(); helpGuide_ = -1; helpStep_ = 0; }
private:
    void newObjectMenu();
    void markDirty() { dirty_ = true; }
};

}  // namespace forge
