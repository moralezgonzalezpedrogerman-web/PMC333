// Editor de animación con esqueleto: se dibujan palos y puntos sobre el modelo y el modelo se deforma con ellos.
#include "editor.h"
#include "importer.h"
#include "preview.h"
#include "renderer.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <cstring>

#include <sstream>
#include <functional>
#include <set>

namespace forge {

static const float kZoom = 0.94f;  // el modelo (cubo unitario) ocupa 0.94 del lienzo

static bool endsWith(const std::string& s, const char* e) {
    size_t n = std::strlen(e);
    return s.size() >= n && s.compare(s.size() - n, n, e) == 0;
}

void Editor::animLoadModel() {
    animMdOk_ = false;
    auto a = edit_.proj.assets.find(animRig_.model);
    if (a != edit_.proj.assets.end() && modelRead(a->second.data(), a->second.size(), animMd_) && animMd_.idx.size() >= 3) animMdOk_ = true;
    animWDirty_ = animImgDirty_ = true;
}

void Editor::openAnimEditor(const std::string& name, const std::string& modelHint) {
    animOpen_ = true;
    animTab_ = 0; animView_ = 0; animSel_ = -1; animClip_ = 0; animKey_ = -1; animT_ = 0;
    animPlay_ = false; animAdd_ = false;
    animZoom_ = 1.f; animPanX_ = animPanY_ = 0.f;
    animRig_ = Rig();
    animName_ = name;
    Files& A = edit_.proj.assets;
    if (!name.empty()) {
        auto a = A.find(name);
        if (a != A.end()) rigRead(std::string(a->second.begin(), a->second.end()), animRig_);
    } else {
        std::string base = "esqueleto";
        animName_ = base + ".fanim";
        for (int i = 2; A.count(animName_); i++) animName_ = base + std::to_string(i) + ".fanim";
    }
    if (!modelHint.empty() && name.empty()) animRig_.model = modelHint;
    if (animRig_.model.empty()) {
        Obj* o = selObj();
        if (o && o->kind == Kind::Model && !o->model.empty()) animRig_.model = o->model;
        else {
            auto m = assetsOf(2);
            if (!m.empty()) animRig_.model = m[0];
        }
    }
    animEnsureHuman();
    animPose_ = rigRestPose(animRig_);
    animLoadModel();
}

bool Editor::animSave() {
    if (animName_.empty()) animName_ = "esqueleto.fanim";
    if (!endsWith(animName_, ".fanim")) animName_ += ".fanim";
    std::string t = rigWrite(animRig_);
    edit_.proj.assets[animName_] = std::vector<uint8_t>(t.begin(), t.end());
    assetDirty_.insert(animName_);
    edit_.clearRigCache();
    markDirty();
    toast("Animación guardada: " + animName_);
    return true;
}

// Mantiene las poses del mismo tamaño que la lista de huesos.
void Editor::animFixSizes() {
    size_t n = animRig_.bones.size();
    animPose_.rot.resize(n);
    for (auto& c : animRig_.clips)
        for (auto& k : c.keys) k.pose.rot.resize(n);
    animWDirty_ = animImgDirty_ = true;
}

// Animaciones por defecto: las de la biblioteca "Universal Animation Library 2" (editor/ual_data.cpp).
// Se aplican a cualquier esqueleto humano del editor (por el nombre de sus huesos).
const std::vector<const char*>& ualChunks();
static void humanoidPtr(Rig& R, const std::vector<float>& v);
static void ualFill(Rig& R, const std::function<bool(const std::string&)>& want) {
    static const char* BN[17] = {"cadera", "columna", "pecho", "cuello", "cabeza", "hombro_i", "codo_i", "mano_i", "muslo_i", "rodilla_i", "pie_i",
                                 "hombro_d", "codo_d", "mano_d", "muslo_d", "rodilla_d", "pie_d"};
    int idx[17];
    for (int i = 0; i < 17; i++) idx[i] = rigFindBone(R, BN[i]);
    size_t nb = R.bones.size();
    int cab = idx[4], piei = idx[10];
    float H = 1.7f;
    if (cab >= 0 && piei >= 0) H = std::max(0.2f, (R.bones[cab].head.y - R.bones[piei].head.y) / 0.84f);
    // El esqueleto del modelo puede estar en T (brazos abiertos) y las animaciones están hechas con brazos hacia abajo (A):
    // C[i] gira el hueso del modelo hasta la dirección de reposo de las animaciones, para que la pose salga igual.
    Quat Cq[17];
    {
        static Rig canon; static bool cb = false;
        if (!cb) { cb = true; std::vector<float> none; humanoidPtr(canon, none); }
        static const int child[17] = {1, 2, 3, 4, -1, 6, 7, -1, 9, 10, -1, 12, 13, -1, 15, 16, -1};
        for (int i = 0; i < 17; i++) {
            int c = child[i];
            if (c < 0 || idx[i] < 0 || idx[c] < 0) continue;
            int ci = rigFindBone(canon, BN[i]), cc = rigFindBone(canon, BN[c]);
            if (ci < 0 || cc < 0) continue;
            V3 a = R.bones[idx[c]].head - R.bones[idx[i]].head, b = canon.bones[cc].head - canon.bones[ci].head;
            float la = std::sqrt(a.x * a.x + a.y * a.y + a.z * a.z), lb = std::sqrt(b.x * b.x + b.y * b.y + b.z * b.z);
            if (la < 1e-5f || lb < 1e-5f) continue;
            a = a * (1.f / la); b = b * (1.f / lb);
            V3 ax{a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
            float sn = std::sqrt(ax.x * ax.x + ax.y * ax.y + ax.z * ax.z), cs = a.x * b.x + a.y * b.y + a.z * b.z;
            if (sn < 1e-4f) continue;   // ya coinciden (o son opuestas: no se toca)
            float ang = std::atan2(sn, cs);
            if (ang < 0.1f) continue;   // menos de ~6°: se deja igual
            Cq[i] = qAxisAngle(ax * (1.f / sn), ang);
        }
    }
    int parN[17];   // padre de cada hueso entre los 17 con nombre (-1 = ninguno)
    for (int i = 0; i < 17; i++) {
        parN[i] = -1;
        if (idx[i] < 0) continue;
        int pb = R.bones[idx[i]].parent;
        for (int j = 0; j < 17; j++) if (idx[j] == pb && pb >= 0) parN[i] = j;
    }
    std::string all;
    for (const char* c : ualChunks()) all += c;
    std::istringstream in(all);
    std::string line;
    RigClip cur;
    bool have = false;
    auto flush = [&]() {
        if (!have) return;
        int ex = rigFindClip(R, cur.name);
        if (ex >= 0) R.clips[ex] = cur; else R.clips.push_back(cur);
        have = false;
    };
    while (std::getline(in, line)) {
        std::istringstream ls(line);
        std::string tag;
        ls >> tag;
        if (tag == "C") {
            flush();
            cur = RigClip();
            int lp = 1; size_t nk = 0;
            ls >> cur.name >> cur.len >> lp >> nk;
            cur.loop = lp != 0;
            have = want(cur.name);
        } else if (tag == "K" && have) {
            RigKey k;
            ls >> k.t >> k.pose.root.x >> k.pose.root.y >> k.pose.root.z;
            k.pose.root = k.pose.root * H;
            k.pose.rot.assign(nb, Quat());
            for (int i = 0; i < 17; i++) {
                float x, y, z;
                ls >> x >> y >> z;
                if (idx[i] < 0) continue;
                float w2 = 1.f - x * x - y * y - z * z;
                k.pose.rot[idx[i]] = qNorm(qMul(qMul(parN[i] >= 0 ? qInv(Cq[parN[i]]) : Quat(), Quat{x, y, z, w2 > 0.f ? std::sqrt(w2) : 0.f}), Cq[i]));
            }
            cur.keys.push_back(std::move(k));
        }
    }
    flush();
}

void Editor::animPresets(const std::set<std::string>* only) {
    ualFill(animRig_, [&](const std::string& n) { return !only || only->count(n) > 0; });
    animFixSizes();
}

// Si el esqueleto es de persona, agrega las animaciones que falten (y reemplaza las basicas viejas de 4 poses o menos).
void Editor::animEnsureHuman() {
    Rig& R = animRig_;
    if (rigFindBone(R, "muslo_i") < 0 || rigFindBone(R, "hombro_d") < 0 || rigFindBone(R, "pecho") < 0) return;
    // (ya no se agregan todas solas: «Animaciones por defecto» abre una cuadrícula para elegir)
}

// Gira todas las poses de una animación 90° alrededor del eje vertical (arregla animaciones hechas "de lado" en un esqueleto "de frente" y al revés).
static void rotateClipYaw(RigClip& c, float deg) {
    Quat R = qAxisAngle(V3{0, 1, 0}, deg * 0.0174532925f), Ri = qInv(R);
    for (auto& k : c.keys) {
        for (auto& q : k.pose.rot) q = qNorm(qMul(R, qMul(q, Ri)));
        k.pose.root = qRotate(R, k.pose.root);
    }
}

// Esqueleto humano ajustado al tamaño del modelo.
static void humanoid(Rig& R, const std::vector<float>& v, bool side = false, bool flip = false) {
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    for (size_t i = 0; i + 7 < v.size(); i += 8)
        for (int c = 0; c < 3; c++) { mn[c] = std::min(mn[c], v[i + c]); mx[c] = std::max(mx[c], v[i + c]); }
    if (v.size() < 8) { mn[0] = mn[1] = mn[2] = -0.5f; mx[0] = mx[1] = mx[2] = 0.5f; }
    float H = std::max(0.1f, mx[1] - mn[1]), cx = (mn[0] + mx[0]) * 0.5f, cz = (mn[2] + mx[2]) * 0.5f, y0 = mn[1];
    auto P = [&](float fx, float fy, float fz = 0.f) { return V3{cx + fx * H, y0 + fy * H, cz + (side ? (flip ? -fz : fz) * H : 0.f)}; };
    R.bones.clear();
    auto add = [&](const char* n, int par, V3 h) { R.bones.push_back({n, par, h}); return (int)R.bones.size() - 1; };
    int cad = add("cadera", -1, P(0, 0.52f));
    int col = add("columna", cad, P(0, 0.62f));
    int pec = add("pecho", col, P(0, 0.72f));
    int cue = add("cuello", pec, P(0, 0.84f));
    add("cabeza", cue, P(0, 0.89f));
    for (int s = 0; s < 2; s++) {
        float sg = s ? 1.f : -1.f;
        const char* sf = s ? "_d" : "_i";
        int ho = add((std::string("hombro") + sf).c_str(), pec, P(sg * 0.14f, 0.80f));
        int co = add((std::string("codo") + sf).c_str(), ho, P(sg * 0.18f, 0.62f, 0.03f));
        add((std::string("mano") + sf).c_str(), co, P(sg * 0.19f, 0.46f, 0.05f));
        int mu = add((std::string("muslo") + sf).c_str(), cad, P(sg * 0.07f, 0.50f));
        int ro = add((std::string("rodilla") + sf).c_str(), mu, P(sg * 0.07f, 0.27f, 0.02f));
        add((std::string("pie") + sf).c_str(), ro, P(sg * 0.07f, 0.05f, 0.07f));
    }
}

static void humanoidPtr(Rig& R, const std::vector<float>& v) { humanoid(R, v); }

// Cuadrícula para elegir animaciones por defecto: cada una se ve en movimiento con un esqueleto de palitos.
void Editor::animGridWin() {
    if (!animGridOpen_) return;
    static Rig P; static bool built = false;
    if (!built) {
        built = true;
        std::vector<float> none;
        humanoid(P, none);
        ualFill(P, [](const std::string&) { return true; });
        for (auto& c : P.clips) for (auto& k : c.keys) k.pose.rot.resize(P.bones.size());
    }
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    if (animGridFocus_) { ImGui::SetNextWindowFocus(); animGridFocus_ = false; }
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.06f, 0.08f, 0.12f, 1.f));
    bool open = wrapui::Begin("Elegir animaciones", &animGridOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB | kNoSW | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleColor();
    if (!open) { ImGui::End(); return; }
    ImGui::TextWrapped("Toca las animaciones que quieras. Se agregan solo las elegidas a la lista de animaciones del modelo.");
    float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
    float bw = (aw - sp * 3) / 4;
    char lab[64]; snprintf(lab, sizeof lab, "Seleccionar (%d)", (int)animGridSel_.size());
    if (wrapui::Button(lab, ImVec2(bw * 1.4f, fs * 2.2f)) && tapped()) {
        if (animGridSel_.empty()) toast("Elige al menos una animación");
        else { size_t n = animGridSel_.size(); animPresets(&animGridSel_); toast("Agregadas " + std::to_string(n) + " animaciones"); animGridOpen_ = false; }
    }
    ImGui::SameLine();
    if (wrapui::Button("Todas", ImVec2(bw * 0.9f, fs * 2.2f)) && tapped()) for (auto& c : P.clips) animGridSel_.insert(c.name);
    ImGui::SameLine();
    if (wrapui::Button("Ninguna", ImVec2(bw * 0.9f, fs * 2.2f)) && tapped()) animGridSel_.clear();
    ImGui::SameLine();
    if (wrapui::Button("Cancelar", ImVec2(bw * 0.8f, fs * 2.2f)) && tapped()) animGridOpen_ = false;
    wrapui::BeginChild("##agrid", ImVec2(0, 0), true, kNoSB);
    dragScroll();
    float cw = fs * 7.2f, ch2 = fs * 9.f;
    int cols = std::max(2, (int)(ImGui::GetContentRegionAvail().x / (cw + sp)));
    float cellW = (ImGui::GetContentRegionAvail().x - sp * (cols - 1)) / cols;
    double now = ImGui::GetTime();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    std::vector<V3> J;
    for (size_t i = 0; i < P.clips.size(); i++) {
        if (i % cols) ImGui::SameLine();
        const RigClip& c = P.clips[i];
        ImGui::PushID((int)i);
        ImVec2 a = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##cell", ImVec2(cellW, ch2));
        bool tap = ImGui::IsItemDeactivated() && tapped();
        ImVec2 b(a.x + cellW, a.y + ch2);
        bool sel = animGridSel_.count(c.name) > 0;
        if (tap) { if (sel) animGridSel_.erase(c.name); else animGridSel_.insert(c.name); sel = !sel; }
        dl->AddRectFilled(a, b, sel ? IM_COL32(30, 80, 120, 255) : IM_COL32(24, 30, 42, 255), 8.f);
        dl->AddRect(a, b, sel ? IM_COL32(110, 210, 255, 255) : IM_COL32(80, 95, 115, 160), 8.f, 0, sel ? 3.f : 1.f);
        if (ImGui::IsRectVisible(a, b) && c.len > 0.01f && !c.keys.empty()) {
            float t = (float)std::fmod(now, (double)c.len);
            RigPose pose = rigSample(P, c, t);
            rigJointPositions(P, pose, J);
            float pad = fs * 0.5f, ph = ch2 - fs * 2.4f, pw = cellW - pad * 2;
            float sc = std::min(pw, ph) / 1.9f;
            ImVec2 o2(a.x + cellW * 0.5f, a.y + pad + ph * 0.5f);
            float ymid = 0.9f;   // centro vertical aproximado del esqueleto
            dl->PushClipRect(a, b, true);
            for (size_t k = 0; k < P.bones.size() && k < J.size(); k++) {
                int par = P.bones[k].parent;
                if (par < 0 || par >= (int)J.size()) continue;
                ImVec2 p0(o2.x + J[par].x * sc, o2.y - (J[par].y - ymid) * sc), p1(o2.x + J[k].x * sc, o2.y - (J[k].y - ymid) * sc);
                dl->AddLine(p0, p1, IM_COL32(150, 225, 255, 255), 2.4f);
            }
            for (size_t k = 0; k < J.size(); k++) dl->AddCircleFilled(ImVec2(o2.x + J[k].x * sc, o2.y - (J[k].y - ymid) * sc), 2.4f, IM_COL32(255, 255, 255, 255));
            dl->PopClipRect();
        }
        dl->AddText(ImVec2(a.x + 6, b.y - fs * 2.0f), IM_COL32(235, 240, 250, 255), c.name.c_str());
        char sb[32]; snprintf(sb, sizeof sb, "%.1fs%s", c.len, c.loop ? " (bucle)" : "");
        dl->AddText(ImVec2(a.x + 6, b.y - fs * 1.05f), IM_COL32(150, 165, 185, 255), sb);
        if (sel) dl->AddText(ImVec2(b.x - fs * 1.4f, a.y + 4), IM_COL32(120, 230, 150, 255), "OK");
        ImGui::PopID();
    }
    ImGui::EndChild();
    ImGui::End();
}

void Editor::animWin() {
    if (!animOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.07f, 0.09f, 0.13f, 1.f));   // opaca: no se transparentan las ventanas de atrás
    bool animOk = wrapui::Begin("Editor de animación", &animOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB |
                                                             kNoSW | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleColor();
    if (!animOk) {
        ImGui::End();
        return;
    }
    ImGui::SetWindowFontScale(0.8f);   // todo un poco más chico: caben más cosas y el dibujo queda grande
    fs = ImGui::GetFontSize();
    Rig& R = animRig_;
    // encabezado como la referencia: ≡ | ‹ VOLVER A ESCENA ....... EDITOR DE ANIMACIÓN ....... Cerrar x
    static bool listOpen = true;
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, fs * 0.6f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.14f, 0.19f, 0.26f, 0.95f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.28f, 0.38f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.45f, 0.58f, 0.70f, 0.35f));
    {
        float hw = ImGui::GetContentRegionAvail().x;
        ImVec2 hp = ImGui::GetCursorScreenPos();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
        if (wrapui::Button("##ham", ImVec2(fs * 2.0f, fs * 1.9f)) && tapped()) listOpen = !listOpen;
        {   // icono ≡
            ImDrawList* d0 = ImGui::GetWindowDrawList();
            for (int k = 0; k < 3; k++) d0->AddLine(ImVec2(hp.x + fs * 0.6f, hp.y + fs * (0.65f + k * 0.45f)), ImVec2(hp.x + fs * 1.8f, hp.y + fs * (0.65f + k * 0.45f)), IM_COL32(220, 228, 240, 255), 2.f);
        }
        ImGui::SameLine();
        if (wrapui::Button("<  VOLVER A ESCENA", ImVec2(fs * 11.f, fs * 1.9f)) && tapped()) animOpen_ = false;
        ImGui::SameLine();
        const char* ttl = "EDITOR DE ANIMACIÓN";
        ImGui::SetCursorPosX((hw - ImGui::CalcTextSize(ttl).x) * 0.5f);
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(ttl);
        ImGui::SameLine(hw - fs * 6.f);
        if (wrapui::Button("Cerrar x", ImVec2(fs * 6.f, fs * 1.9f)) && tapped()) animOpen_ = false;
        ImGui::PopStyleColor(2);
    }
    // reproductor de la animación elegida + sus fotogramas (arriba, donde antes quedaba espacio vacío)
    auto playerStrip = [&]() {
        if (animTab_ != 2 || animClip_ < 0 || animClip_ >= (int)R.clips.size()) return;
        RigClip& C = R.clips[animClip_];
        float totW = ImGui::GetContentRegionAvail().x;
        if (wrapui::Button(animPlay_ ? "Parar" : "Reproducir", ImVec2(fs * 9.f, fs * 2.0f)) && tapped()) { animPlay_ = !animPlay_; animImgDirty_ = true; }
        ImGui::SameLine();
        if (wrapui::Button("Inicio", ImVec2(fs * 6.f, fs * 2.0f)) && tapped()) { animT_ = 0; animPlay_ = false; animPose_ = rigSample(R, C, 0.f); animPose_.rot.resize(R.bones.size()); animImgDirty_ = true; }
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%s  %.2f s", C.name.c_str(), animT_);
        ImGui::SameLine();
            // línea de tiempo
            ImVec2 p = ImGui::GetCursorScreenPos();
            float bw = std::max(fs * 6.f, ImGui::GetContentRegionAvail().x), bh = fs * 2.0f;
            ImGui::InvisibleButton("##timeline", ImVec2(bw, bh));
            ImDrawList* dl = ImGui::GetWindowDrawList();
            dl->AddRectFilled(p, ImVec2(p.x + bw, p.y + bh), IM_COL32(28, 33, 45, 255), 6.f);
            for (int i = 0; i < (int)C.keys.size(); i++) {
                float x = p.x + (C.len > 0 ? C.keys[i].t / C.len : 0) * bw;
                dl->AddCircleFilled(ImVec2(x, p.y + bh * 0.5f), fs * 0.5f, animKey_ == i ? IM_COL32(255, 170, 40, 255) : IM_COL32(60, 200, 190, 255));
            }
            float cx = p.x + (C.len > 0 ? std::min(1.f, animT_ / C.len) : 0) * bw;
            dl->AddLine(ImVec2(cx, p.y), ImVec2(cx, p.y + bh), IM_COL32(255, 255, 255, 220), 2.f);
            if (ImGui::IsItemActive()) {
                float f = std::max(0.f, std::min(1.f, (ImGui::GetIO().MousePos.x - p.x) / bw));
                animT_ = f * C.len;
                animPlay_ = false;
                if (ImGui::IsMouseClicked(0)) {  // si tocas un fotograma, se elige
                    animKey_ = -1;
                    for (int i = 0; i < (int)C.keys.size(); i++)
                        if (std::fabs(p.x + C.keys[i].t / std::max(0.01f, C.len) * bw - ImGui::GetIO().MousePos.x) < fs * 0.9f) { animKey_ = i; animT_ = C.keys[i].t; }
                }
                if (animKey_ >= 0 && animKey_ < (int)C.keys.size() && std::fabs(C.keys[animKey_].t - animT_) < 0.001f) animPose_ = C.keys[animKey_].pose;
                else animPose_ = rigSample(R, C, animT_);
                animPose_.rot.resize(R.bones.size());
                animImgDirty_ = true;
            }
    };
    playerStrip();
    bool wide = w_ >= h_;
    float panelW = wide ? fs * 12.f : 0.f;
    auto bonesChanged = [&]() { animWDirty_ = animImgDirty_ = true; };

    // pestaña vertical "LISTA DE ANIMACIONES" (abre/cierra la columna del centro)
    if (wide) {
        float tw0 = fs * 2.3f, th0 = fs * 14.f;
        ImVec2 tp = ImGui::GetCursorScreenPos();
        ImGui::SetCursorScreenPos(ImVec2(tp.x, tp.y + fs * 3.f));
        ImVec2 q0 = ImGui::GetCursorScreenPos();
        if (ImGui::InvisibleButton("##vtab", ImVec2(tw0, th0)) && tapped()) listOpen = !listOpen;
        ImDrawList* d1 = ImGui::GetWindowDrawList();
        d1->AddRectFilled(q0, ImVec2(q0.x + tw0, q0.y + th0), IM_COL32(26, 34, 46, 255), fs * 0.8f);
        d1->AddRect(q0, ImVec2(q0.x + tw0, q0.y + th0), listOpen ? IM_COL32(110, 200, 190, 200) : IM_COL32(110, 140, 170, 110), fs * 0.8f, 0, 1.5f);
        const char* vt = "LISTA DE ANIMACIONES";
        ImVec2 ts = ImGui::CalcTextSize(vt);
        int v0 = d1->VtxBuffer.Size;
        ImVec2 tpos(q0.x + tw0 * 0.5f - ts.x * 0.5f, q0.y + th0 * 0.5f - ts.y * 0.5f);
        d1->AddText(tpos, IM_COL32(215, 225, 240, 255), vt);
        ImVec2 cc(q0.x + tw0 * 0.5f, q0.y + th0 * 0.5f);
        for (int k = v0; k < d1->VtxBuffer.Size; k++) {   // girar el texto 90° (lee de abajo hacia arriba)
            ImVec2 pv = d1->VtxBuffer[k].pos;
            float rx = pv.x - cc.x, ry = pv.y - cc.y;
            d1->VtxBuffer[k].pos = ImVec2(cc.x + ry, cc.y - rx);
        }
        ImGui::SetCursorScreenPos(tp);
        ImGui::SameLine(0, 0);
        ImGui::SetCursorScreenPos(ImVec2(tp.x + tw0 + fs * 0.3f, tp.y));
    }
    // =========================== panel de herramientas
    wrapui::BeginChild("##atools", wide ? ImVec2(panelW, 0) : ImVec2(0, h_ * 0.32f), true, kNoSB);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.38f, 0.44f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.96f, 1.f, 1.f));
    textInput("##aname", "Nombre", animName_, "esqueleto.fanim");
    ImGui::PopStyleColor(2);
    if (wrapui::Button("Lista de Animaciones", ImVec2(-1, fs * 2.0f)) && tapped()) listOpen = !listOpen;
    if (wrapui::Button("Guardar", ImVec2(-1, fs * 2.0f)) && tapped()) animSave();
    if (wrapui::Button("Guardar y cerrar", ImVec2(-1, fs * 2.0f)) && tapped()) { animSave(); animOpen_ = false; }
    static const char* tabs[3] = {"Esqueleto", "Poses", "Animar"};
    float tsp = ImGui::GetStyle().ItemSpacing.x, tw = (ImGui::GetContentRegionAvail().x - tsp * 2.f - 2.f) / 3.f;
    for (int i = 0; i < 3; i++) {
        if (i) ImGui::SameLine(0, tsp);
        ImGui::PushStyleColor(ImGuiCol_Button, animTab_ == i ? ImVec4(0.03f, 0.58f, 0.70f, 1.f) : ImVec4(0.12f, 0.14f, 0.28f, 1.f));
        if (ImGui::Button(tabs[i], ImVec2(tw, fs * 2.0f)) && tapped()) { animTab_ = i; animAdd_ = false; animPlay_ = false; animImgDirty_ = true; }
        ImGui::PopStyleColor();
    }
    auto animarBody = [&]() {
        if (R.bones.empty()) ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Primero dibuja el esqueleto en la pestaña Esqueleto.");
        if (!wide) {
        ImGui::SeparatorText("Animaciones");
        for (int i = 0; i < (int)R.clips.size(); i++) {
            if (i) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, animClip_ == i ? ImVec4(0.03f, 0.58f, 0.70f, 1.f) : ImVec4(0.12f, 0.14f, 0.28f, 1.f));
            if (wrapui::Button((R.clips[i].name + "##c" + std::to_string(i)).c_str(), ImVec2(0, fs * 1.9f)) && tapped()) { animClip_ = i; animKey_ = -1; animT_ = 0; animPlay_ = false; }
            ImGui::PopStyleColor();
        }
        }
        if (!wide) {
        if (wrapui::Button("+ Nueva animación", ImVec2(0, fs * 1.9f)) && tapped() && !R.bones.empty()) {
            RigClip c;
            c.name = "animacion" + std::to_string(R.clips.size() + 1);
            R.clips.push_back(c);
            animClip_ = (int)R.clips.size() - 1; animKey_ = -1; animT_ = 0;
        }
        wrapui::Next("Poner las animaciones por defecto");
        if (wrapui::Button("Poner las animaciones por defecto", ImVec2(0, fs * 1.9f)) && tapped()) { animGridOpen_ = true; animGridSel_.clear(); animGridFocus_ = true; }
        }
        if (animClip_ >= 0 && animClip_ < (int)R.clips.size()) {
            RigClip& C = R.clips[animClip_];
            ImGui::SeparatorText("Esta animación");
            textInput("##cname", "Nombre", C.name, "animacion");
            numField("Duración (s)", C.len, 0.1f, 20.f, "%.2f");
            wrapui::Checkbox("Se repite (bucle)", &C.loop);
            wrapui::Next("Borrar animación");
            if (wrapui::Button("Borrar animación", ImVec2(0, fs * 2.0f)) && tapped()) {
                R.clips.erase(R.clips.begin() + animClip_);
                animClip_ = std::max(0, animClip_ - 1); animKey_ = -1; animPlay_ = false;
                return;
            }
            ImGui::Text("Tiempo: %.2f s", animT_);
            if (wrapui::Button("Poner la pose actual como fotograma aquí", ImVec2(-1, fs * 2.0f)) && tapped() && !R.bones.empty()) {
                RigKey k;
                k.t = animT_;
                k.pose = animPose_;
                k.pose.rot.resize(R.bones.size());
                bool rep = false;
                for (auto& e : C.keys) if (std::fabs(e.t - k.t) < 0.02f) { e.pose = k.pose; rep = true; }
                if (!rep) C.keys.push_back(k);
                std::stable_sort(C.keys.begin(), C.keys.end(), [](const RigKey& a, const RigKey& b) { return a.t < b.t; });
                animKey_ = -1;
                for (int i = 0; i < (int)C.keys.size(); i++) if (std::fabs(C.keys[i].t - animT_) < 0.02f) animKey_ = i;
            }
            if (animKey_ >= 0 && animKey_ < (int)C.keys.size()) {
                RigKey& K = C.keys[animKey_];
                ImGui::SeparatorText("Fotograma elegido");
                if (numField("Momento (s)", K.t, 0.f, C.len, "%.2f")) animT_ = K.t;
                if (wrapui::Button("Cargar su pose", ImVec2(0, fs * 1.9f)) && tapped()) { animPose_ = K.pose; animPose_.rot.resize(R.bones.size()); animImgDirty_ = true; }
                wrapui::Next("Actualizar con la pose actual");
                if (wrapui::Button("Actualizar con la pose actual", ImVec2(0, fs * 1.9f)) && tapped()) { K.pose = animPose_; K.pose.rot.resize(R.bones.size()); }
                if (wrapui::Button("Borrar fotograma", ImVec2(-1, fs * 1.9f)) && tapped()) { C.keys.erase(C.keys.begin() + animKey_); animKey_ = -1; }
            }
            std::stable_sort(C.keys.begin(), C.keys.end(), [](const RigKey& a, const RigKey& b) { return a.t < b.t; });
        }
        if (!R.clips.empty()) {
            ImGui::SeparatorText("Dirección de la animación");
            ImGui::TextWrapped("Si el movimiento sale de lado en un modelo de frente (o al revés), gira la animación 90°.");
            auto rot = [&](bool all, float deg) {
                if (all) { for (auto& c : R.clips) rotateClipYaw(c, deg); }
                else if (animClip_ >= 0 && animClip_ < (int)R.clips.size()) rotateClipYaw(R.clips[animClip_], deg);
                if (animClip_ >= 0 && animClip_ < (int)R.clips.size()) { animPose_ = rigSample(R, R.clips[animClip_], animT_); animPose_.rot.resize(R.bones.size()); }
                animImgDirty_ = true;
                toast(all ? "Todas las animaciones giradas" : "Animación girada");
            };
            float bw4 = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
            if (wrapui::Button("Girar esta 90°", ImVec2(bw4, fs * 2.0f)) && tapped()) rot(false, 90.f);
            ImGui::SameLine();
            if (wrapui::Button("Girar esta 180°", ImVec2(bw4, fs * 2.0f)) && tapped()) rot(false, 180.f);
            if (wrapui::Button("Girar TODAS 90°", ImVec2(bw4, fs * 2.0f)) && tapped()) rot(true, 90.f);
            ImGui::SameLine();
            if (wrapui::Button("Girar TODAS 180°", ImVec2(bw4, fs * 2.0f)) && tapped()) rot(true, 180.f);
        }
        ImGui::SeparatorText("Importar");
        ImGui::TextWrapped("Trae animaciones de un archivo .glb, .gltf o .fbx. Se asignan a los puntos del esqueleto por su nombre (o crean el esqueleto si el archivo trae el modelo).");
        if (wrapui::Button("Importar animaciones de un archivo...", ImVec2(-1, fs * 2.0f)) && tapped() && host_.pickFile) {
            animImportPending_ = true;
            host_.pickFile();
        }
    };
    wrapui::BeginChild("##atab", ImVec2(0, 0), false, kNoSB);
    dragScroll();

    if (animTab_ == 0) {
        ImGui::TextWrapped("1) Elige el modelo.  2) Dibuja el esqueleto: toca el lienzo para poner puntos (cada punto nuevo se une con un palo al punto elegido).  3) Pasa a Poses.");
        if (assetCombo("Modelo", R.model, 2, nullptr)) { animLoadModel(); }
        ImGui::PushStyleColor(ImGuiCol_Button, animAdd_ ? ImVec4(0.46f, 0.30f, 0.84f, 1.f) : ImVec4(0.18f, 0.40f, 0.75f, 1.f));
        if (wrapui::Button(animAdd_ ? "Dibujando: toca el lienzo (toca aquí para parar)" : "Dibujar puntos y palos", ImVec2(-1, fs * 2.0f)) && tapped()) animAdd_ = !animAdd_;
        ImGui::PopStyleColor();
        const int animGeo = animView_ ^ (animSwap_ ? 1 : 0);
        ImGui::TextWrapped("Esqueleto humano automático. Elige el tipo; sirve en cualquiera de las dos vistas (se adapta a la vista que estás viendo):");
        for (int side = 0; side < 2; side++) {
            if (wrapui::Button(side ? "Tipo LADO (brazos y piernas hacia adelante)" : "Tipo FRENTE (brazos abiertos a los lados)", ImVec2(-1, fs * 1.9f)) && tapped() && animMdOk_) {
                humanoid(R, animMd_.v, side == 1, animFlip_);
                if (animGeo != side) {  // el tipo está dibujado para el otro eje: se gira para que quede en la vista actual
                    float mn[2] = {1e9f, 1e9f}, mx[2] = {-1e9f, -1e9f};
                    for (size_t i = 0; i + 7 < animMd_.v.size(); i += 8) {
                        mn[0] = std::min(mn[0], animMd_.v[i]); mx[0] = std::max(mx[0], animMd_.v[i]);
                        mn[1] = std::min(mn[1], animMd_.v[i + 2]); mx[1] = std::max(mx[1], animMd_.v[i + 2]);
                    }
                    float cx = (mn[0] + mx[0]) * 0.5f, cz = (mn[1] + mx[1]) * 0.5f;
                    for (auto& bn : R.bones) { float dx = bn.head.x - cx, dz = bn.head.z - cz; bn.head.x = cx + dz; bn.head.z = cz + dx; }
                }
                R.clips.clear();
                animSel_ = -1;
                animFixSizes();
                toast("Esqueleto creado. Muévelo con el dedo para ajustarlo al modelo.");
            }
        }
        if (wrapui::Button("Borrar todo el esqueleto", ImVec2(-1, fs * 1.9f)) && tapped()) { R.bones.clear(); R.clips.clear(); animSel_ = -1; animFixSizes(); }
        numField("Dureza de las juntas", R.stiff, 1.f, 8.f, "%.1f");
        if (animSel_ >= 0 && animSel_ < (int)R.bones.size()) {
            RigBone& b = R.bones[animSel_];
            ImGui::SeparatorText("Punto elegido");
            textInput("##bname", "Nombre del punto", b.name, "hueso");
            int cur = b.parent;
            std::string pl = cur >= 0 ? R.bones[cur].name : "(ninguno: es la raíz)";
            ImGui::Text("Unido a: %s", pl.c_str());
            if (wrapui::BeginCombo("Unir a", "elegir...")) {
                if (wrapui::Selectable("(ninguno)", cur < 0)) { b.parent = -1; bonesChanged(); }
                for (int i = 0; i < animSel_; i++)
                    if (wrapui::Selectable(R.bones[i].name.c_str(), cur == i)) { b.parent = i; bonesChanged(); }
                ImGui::EndCombo();
            }
            if (wrapui::Button("Borrar este punto", ImVec2(-1, fs * 1.9f)) && tapped()) {
                int d = animSel_;
                int np = R.bones[d].parent;
                for (auto& bb : R.bones) { if (bb.parent == d) bb.parent = np; }
                for (auto& bb : R.bones) if (bb.parent > d) bb.parent--;
                R.bones.erase(R.bones.begin() + d);
                for (auto& c : R.clips) for (auto& k : c.keys) if ((int)k.pose.rot.size() > d) k.pose.rot.erase(k.pose.rot.begin() + d);
                if ((int)animPose_.rot.size() > d) animPose_.rot.erase(animPose_.rot.begin() + d);
                animSel_ = -1;
                animFixSizes();
            }
        }
        ImGui::SeparatorText("Puntos");
        for (int i = 0; i < (int)R.bones.size(); i++) {
            ImGui::PushID(i);
            if (wrapui::Selectable(R.bones[i].name.c_str(), animSel_ == i)) animSel_ = i;
            ImGui::PopID();
        }
    } else if (animTab_ == 1) {
        ImGui::TextWrapped("Arrastra un punto del lienzo para girar el palo al que está unido. El modelo se estira y se dobla con él. La raíz mueve todo el cuerpo.");
        if (R.bones.empty()) ImGui::TextColored(ImVec4(1, 0.7f, 0.3f, 1), "Primero dibuja el esqueleto en la pestaña Esqueleto.");
        if (animSel_ >= 0 && animSel_ < (int)R.bones.size() && animSel_ < (int)animPose_.rot.size()) {
            ImGui::SeparatorText(R.bones[animSel_].name.c_str());
            float ex, ey, ez;
            qToEulerDeg(animPose_.rot[animSel_], ex, ey, ez);
            bool ch = false;
            ch |= numField("Girar X", ex, -180.f, 180.f, "%.0f");
            ch |= numField("Girar Y", ey, -180.f, 180.f, "%.0f");
            ch |= numField("Girar Z", ez, -180.f, 180.f, "%.0f");
            if (ch) { animPose_.rot[animSel_] = qFromEulerDeg(ex, ey, ez); animImgDirty_ = true; }
            if (wrapui::Button("Enderezar este punto", ImVec2(-1, fs * 1.9f)) && tapped()) { animPose_.rot[animSel_] = Quat(); animImgDirty_ = true; }
        }
        ImGui::SeparatorText("Todo el cuerpo");
        bool ch = false;
        ch |= numField("Mover X", animPose_.root.x, -0.5f, 0.5f, "%.2f");
        ch |= numField("Mover Y", animPose_.root.y, -0.5f, 0.5f, "%.2f");
        ch |= numField("Mover Z", animPose_.root.z, -0.5f, 0.5f, "%.2f");
        if (ch) animImgDirty_ = true;
        if (wrapui::Button("Pose de reposo", ImVec2(-1, fs * 1.9f)) && tapped()) { animPose_ = rigRestPose(R); animImgDirty_ = true; }
        ImGui::TextDisabled("Cuando te guste la pose, ve a Animar y ponla como fotograma.");
        ImGui::SeparatorText("Puntos");
        for (int i = 0; i < (int)R.bones.size(); i++) {
            ImGui::PushID(1000 + i);
            if (wrapui::Selectable(R.bones[i].name.c_str(), animSel_ == i)) animSel_ = i;
            ImGui::PopID();
        }
    } else {
        // Animar: en pantalla ancha sus opciones van a la derecha del lienzo (más cómodo)
        if (!wide) animarBody();
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    ImGui::EndChild();
    if (wide) ImGui::SameLine();

    // =========================== lista de animaciones (columna central)
    if (wide && listOpen) {
        wrapui::BeginChild("##alist", ImVec2(fs * 9.f, 0), true, kNoSB);
        dragScroll();
        if (R.clips.empty()) ImGui::TextWrapped("Aún no hay animaciones. En la pestaña Animación toca «Crear animaciones básicas».");
        ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.08f, 0.5f));
        for (int i = 0; i < (int)R.clips.size(); i++) {
            ImGui::PushID(2000 + i);
            bool cur = animClip_ == i && animTab_ == 2;
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.16f, 0.22f, 0.98f));
            ImGui::PushStyleColor(ImGuiCol_Border, cur ? ImVec4(0.45f, 0.80f, 0.95f, 1.f) : ImVec4(0.45f, 0.55f, 0.65f, 0.30f));
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, cur ? 2.f : 1.f);
            ImVec2 p0 = ImGui::GetCursorScreenPos();
            if (wrapui::Button(R.clips[i].name.c_str(), ImVec2(-1, fs * 2.1f)) && tapped()) { animTab_ = 2; animClip_ = i; animKey_ = -1; animT_ = 0; animPlay_ = false; animImgDirty_ = true; }
            ImVec2 p1 = ImGui::GetItemRectMax();
            ImDrawList* d3 = ImGui::GetWindowDrawList();   // flecha ˅ a la derecha, como un menú desplegable
            float cx = p1.x - fs * 1.1f, cy = (p0.y + p1.y) * 0.5f;
            d3->AddLine(ImVec2(cx - fs * 0.3f, cy - fs * 0.15f), ImVec2(cx, cy + fs * 0.15f), IM_COL32(215, 225, 240, 255), 2.f);
            d3->AddLine(ImVec2(cx, cy + fs * 0.15f), ImVec2(cx + fs * 0.3f, cy - fs * 0.15f), IM_COL32(215, 225, 240, 255), 2.f);
            ImGui::PopStyleVar();
            ImGui::PopStyleColor(2);
            ImGui::PopID();
        }
        ImGui::PopStyleVar();
        ImGui::Spacing();
        if (wrapui::Button("+ Nueva", ImVec2(-1, fs * 1.9f)) && tapped() && !R.bones.empty()) {
            RigClip c;
            c.name = "animacion" + std::to_string(R.clips.size() + 1);
            R.clips.push_back(c);
            animTab_ = 2; animClip_ = (int)R.clips.size() - 1; animKey_ = -1; animT_ = 0;
        }
        if (wrapui::Button("Animaciones por defecto", ImVec2(-1, fs * 1.9f)) && tapped()) { animGridOpen_ = true; animGridSel_.clear(); animGridFocus_ = true; }
        if (wrapui::Button("Quitar las antiguas por defecto", ImVec2(-1, fs * 1.9f)) && tapped()) {
            static const char* old[] = {"agachado", "apuntar_arma_larga", "apuntar_pistola", "atacar", "atacar_cuchillo", "atacar_espada", "caminar", "caminar_agachado", "correr", "correr_arma_larga", "correr_pistola", "cubrirse", "disparar_arma_larga", "disparar_pistola", "golpear", "impacto", "lanzar", "morir", "quieto", "recargar", "recibir_dano", "saltar", "sostener_para_lanzar"};
            int rm = 0;
            for (int i = (int)R.clips.size() - 1; i >= 0; i--)
                for (const char* o : old) if (R.clips[i].name == o) { R.clips.erase(R.clips.begin() + i); rm++; break; }
            if (animClip_ >= (int)R.clips.size()) animClip_ = R.clips.empty() ? -1 : 0;
            toast(rm ? "Se quitaron " + std::to_string(rm) + " animaciones antiguas" : "No había animaciones antiguas");
        }
        ImGui::EndChild();
        ImGui::SameLine();
    }

    // =========================== lienzo
    ImVec2 av = ImGui::GetContentRegionAvail();
    const float barW = 0.f;   // los botones de la vista van encima del lienzo
    float Q = wide ? std::max(fs * 8.f, std::min(av.x - barW - ImGui::GetStyle().ItemSpacing.x, av.y - fs * 0.4f))
                   : std::max(fs * 8.f, std::min(av.x, av.y - fs * 5.f));
    if (wide && animTab_ == 2) Q = std::max(fs * 8.f, std::min(Q, av.x - fs * 15.f));
    ImGui::BeginGroup();
    auto drawBar = [&](bool vert) {
        // dos filas de 4 botones iguales (nunca se cortan ni se apilan)
        float sp = ImGui::GetStyle().ItemSpacing.x, cw = vert ? ImGui::GetContentRegionAvail().x : (std::min(av.x, Q) - sp * 3.f) / 4.f, bh = fs * 1.9f;
        auto same = [&]() { if (!vert) ImGui::SameLine(); };
        auto tog = [&](const char* l, bool on, bool* flag, bool dirty = true) {
            ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.03f, 0.58f, 0.70f, 1.f) : ImVec4(0.12f, 0.14f, 0.28f, 1.f));
            bool hit = wrapui::Button(l, ImVec2(cw, bh)) && tapped();
            ImGui::PopStyleColor();
            if (hit && flag) { *flag = !*flag; if (dirty) animImgDirty_ = true; }
            return hit;
        };
        if (tog("Frente", animView_ == 0, nullptr)) { animView_ = 0; animImgDirty_ = true; }
        same();
        if (tog("Lado", animView_ == 1, nullptr)) { animView_ = 1; animImgDirty_ = true; }
        same();
        tog("Cambiar ejes", animSwap_, &animSwap_);
        same();
        tog("Invertir", animFlip_, &animFlip_);
        if (wrapui::Button("Zoom +", ImVec2(cw, bh)) && tapped()) { animZoom_ = std::min(6.f, animZoom_ * 1.3f); animImgDirty_ = true; }
        same();
        if (wrapui::Button("Zoom -", ImVec2(cw, bh)) && tapped()) { animZoom_ = std::max(0.3f, animZoom_ / 1.3f); animImgDirty_ = true; }
        same();
        if (wrapui::Button("Centrar", ImVec2(cw, bh)) && tapped()) { animZoom_ = 1.f; animPanX_ = animPanY_ = 0.f; animImgDirty_ = true; }
    };
    if (!wide) drawBar(false);
    ImVec2 org = ImGui::GetCursorScreenPos();
    ImGui::SetNextItemAllowOverlap();   // los botones con icono encima del lienzo deben recibir los toques
    ImGui::InvisibleButton("##acanvas", ImVec2(Q, Q));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(org, ImVec2(org.x + Q, org.y + Q), IM_COL32(24, 28, 38, 255), 8.f);
    for (int g = 1; g < 10; g++) {
        float o = Q * g / 10.f;
        dl->AddLine(ImVec2(org.x + o, org.y), ImVec2(org.x + o, org.y + Q), IM_COL32(255, 255, 255, g == 5 ? 36 : 14));
        dl->AddLine(ImVec2(org.x, org.y + o), ImVec2(org.x + Q, org.y + o), IM_COL32(255, 255, 255, g == 5 ? 36 : 14));
    }

    const float flipS = animFlip_ ? -1.f : 1.f;
    const int animGeo = animView_ ^ (animSwap_ ? 1 : 0);
    // pose que se muestra
    RigPose shown = (animTab_ == 0) ? rigRestPose(R) : animPose_;
    shown.rot.resize(R.bones.size());
    if (animPlay_ && animTab_ == 2 && animClip_ >= 0 && animClip_ < (int)R.clips.size()) {
        RigClip& C = R.clips[animClip_];
        animT_ += ImGui::GetIO().DeltaTime;
        if (animT_ > C.len) animT_ = C.loop ? std::fmod(animT_, std::max(0.05f, C.len)) : (animPlay_ = false, C.len);
        shown = rigSample(R, C, animT_);
        shown.rot.resize(R.bones.size());
        animPose_ = shown;
        animImgDirty_ = true;
    }
    // imagen del modelo (deformado)
    if (animMdOk_ && rend_) {
        if (animImgDirty_) {
            std::vector<float> verts = animMd_.v;
            if (!R.bones.empty() && animTab_ != 0) {
                if (animWDirty_) { rigComputeWeights(R, animMd_.v, animW_, &animMd_.idx); animWDirty_ = false; }
                std::vector<float> mats;
                rigSkinMatrices(R, shown, mats);
                rigSkin(animMd_.v, animW_, mats, verts);
            }
            // mientras arrastras se dibuja a menor resolución para que no se trabe
            const bool lite = ImGui::IsMouseDragging(0, 2.f) && ImGui::IsWindowFocused(ImGuiFocusedFlags_ChildWindows);
            int RN = lite ? 192 : 384;
            float ya = (animGeo ? 1.5707963f : 0.f) + (animFlip_ ? (animGeo ? -3.1415927f : 3.1415927f) : 0.f);
            if (meshRaster(animMd_, verts, edit_.proj.assets, RN, ya, 0.f, animPx_, kZoom * animZoom_, animPanX_, animPanY_)) rend_->updateRGBA("::animprev", RN, RN, animPx_.data());
            if (lite) animImgDirty_ = true;  // al soltar se vuelve a dibujar en calidad completa
            else animImgDirty_ = false;
        }
        unsigned id = rend_->rawTexture("::animprev");
        if (id) dl->AddImage((ImTextureID)(intptr_t)id, org, ImVec2(org.x + Q, org.y + Q), ImVec2(0, 0), ImVec2(1, 1), IM_COL32(255, 255, 255, animTab_ == 0 ? 150 : 255));
    } else if (!animMdOk_) {
        dl->AddText(ImVec2(org.x + fs, org.y + fs), IM_COL32(255, 200, 120, 255), "Elige un modelo 3D en la pestaña Esqueleto");
    }
    // esqueleto: palos y puntos
    std::vector<V3> pj;
    rigJointPositions(R, shown, pj);
    auto toS = [&](V3 p) {
        float h = flipS * (animGeo ? p.z : p.x) - animPanX_;
        float Zm = kZoom * animZoom_;
        return ImVec2(org.x + (0.5f + h * Zm) * Q, org.y + (0.5f - (p.y - animPanY_) * Zm) * Q);
    };
    for (size_t i = 0; i < R.bones.size(); i++)
        if (R.bones[i].parent >= 0) dl->AddLine(toS(pj[R.bones[i].parent]), toS(pj[i]), IM_COL32(40, 220, 200, 255), 4.f);
    for (size_t i = 0; i < R.bones.size(); i++) {
        ImVec2 s = toS(pj[i]);
        bool sel = animSel_ == (int)i;
        dl->AddCircleFilled(s, fs * (sel ? 0.8f : 0.6f), sel ? IM_COL32(255, 170, 40, 255) : IM_COL32(255, 255, 255, 255));
        dl->AddCircle(s, fs * (sel ? 0.8f : 0.6f), IM_COL32(10, 20, 30, 255), 0, 2.f);
        if (R.bones[i].parent < 0) dl->AddCircle(s, fs * 1.0f, IM_COL32(255, 90, 90, 255), 0, 2.f);
    }

    // toques sobre el lienzo
    static int dragJ = -1;
    static bool panning = false;
    static bool pinching = false;
    static float pinchD = 0, pinchX = 0, pinchY = 0;
    {   // zoom con dos dedos (y mover la vista con el punto medio)
        auto& Pt = play_.ctl.p;
        int ids[2], n = 0;
        for (int i = 0; i < 10 && n < 2; i++) if (Pt[i].down) ids[n++] = i;
        if (n == 2 && play_.ctl.downCount() == 2) {
            float mx = (Pt[ids[0]].lx + Pt[ids[1]].lx) * 0.5f, my2 = (Pt[ids[0]].ly + Pt[ids[1]].ly) * 0.5f;
            float dd = std::sqrt((Pt[ids[0]].lx - Pt[ids[1]].lx) * (Pt[ids[0]].lx - Pt[ids[1]].lx) + (Pt[ids[0]].ly - Pt[ids[1]].ly) * (Pt[ids[0]].ly - Pt[ids[1]].ly));
            bool inside = mx >= org.x && mx <= org.x + Q && my2 >= org.y && my2 <= org.y + Q;
            if (pinching || inside) {
                if (pinching && pinchD > 1.f && dd > 1.f) {
                    animZoom_ = std::max(0.3f, std::min(8.f, animZoom_ * dd / pinchD));
                    animPanX_ -= (mx - pinchX) / (Q * kZoom * animZoom_);
                    animPanY_ += (my2 - pinchY) / (Q * kZoom * animZoom_);
                }
                pinching = true; pinchD = dd; pinchX = mx; pinchY = my2;
                animImgDirty_ = true;
            }
        } else pinching = false;
    }
    if (ImGui::IsItemHovered() && ImGui::GetIO().MouseWheel != 0.f) {
        animZoom_ = std::max(0.3f, std::min(6.f, animZoom_ * (ImGui::GetIO().MouseWheel > 0 ? 1.15f : 1.f / 1.15f)));
        animImgDirty_ = true;
    }
    if (ImGui::IsItemActive() && !animPlay_ && !pinching) {
        ImVec2 m = ImGui::GetIO().MousePos;
        float u = (m.x - org.x) / Q, v = (m.y - org.y) / Q;
        float mh = flipS * ((u - 0.5f) / (kZoom * animZoom_) + animPanX_), my = (0.5f - v) / (kZoom * animZoom_) + animPanY_;  // medidas del modelo
        if (ImGui::IsMouseClicked(0)) {
            dragJ = -1;
            float best = fs * 1.6f;
            for (size_t i = 0; i < R.bones.size(); i++) {
                ImVec2 s = toS(pj[i]);
                float d = std::sqrt((s.x - m.x) * (s.x - m.x) + (s.y - m.y) * (s.y - m.y));
                if (d < best) { best = d; dragJ = (int)i; }
            }
            panning = false;
            if (dragJ >= 0) animSel_ = dragJ;
            else if (!(animTab_ == 0 && animAdd_)) panning = true;   // arrastrar en vacio = mover la vista
            else if (animTab_ == 0 && animAdd_) {
                RigBone b;
                b.name = "punto" + std::to_string(R.bones.size() + 1);
                b.parent = (animSel_ >= 0 && animSel_ < (int)R.bones.size()) ? animSel_ : -1;
                V3 base = b.parent >= 0 ? R.bones[b.parent].head : V3{0, 0, 0};
                b.head = animGeo ? V3{base.x, my, mh} : V3{mh, my, base.z};
                R.bones.push_back(b);
                animSel_ = (int)R.bones.size() - 1;
                animFixSizes();
                dragJ = -1;
            }
        }
        if (panning && ImGui::IsMouseDragging(0, 2.f)) {
            ImVec2 dd = ImGui::GetIO().MouseDelta;
            animPanX_ -= dd.x / (Q * kZoom * animZoom_);
            animPanY_ += dd.y / (Q * kZoom * animZoom_);
            animImgDirty_ = true;
        }
        if (dragJ >= 0 && ImGui::IsMouseDragging(0, 2.f) && dragJ < (int)R.bones.size()) {
            if (animTab_ == 0) {
                V3& hd = R.bones[dragJ].head;
                hd.y = my;
                if (animGeo) hd.z = mh; else hd.x = mh;
                animImgDirty_ = true; animWDirty_ = true;
            } else {
                int P = R.bones[dragJ].parent;
                if (P < 0) {  // la raíz mueve todo el cuerpo
                    V3 cur = pj[dragJ];
                    float ch = animGeo ? cur.z : cur.x;
                    float dh = mh - ch, dv = my - cur.y;
                    if (animGeo) animPose_.root.z += dh; else animPose_.root.x += dh;
                    animPose_.root.y += dv;
                } else {
                    float ah = (animGeo ? pj[dragJ].z : pj[dragJ].x) - (animGeo ? pj[P].z : pj[P].x), av2 = pj[dragJ].y - pj[P].y;
                    float bh = mh - (animGeo ? pj[P].z : pj[P].x), bv = my - pj[P].y;
                    if (std::sqrt(bh * bh + bv * bv) > 0.01f && std::sqrt(ah * ah + av2 * av2) > 0.001f) {
                        float th = std::atan2(ah * bv - av2 * bh, ah * bh + av2 * bv);
                        V3 axis = animGeo ? V3{-1, 0, 0} : V3{0, 0, 1};
                        Quat Qd = qAxisAngle(axis, th);
                        std::vector<Quat> rw;
                        rigWorldRots(R, animPose_, rw);
                        int pp = R.bones[P].parent;
                        Quat rpp = pp >= 0 ? rw[pp] : Quat();
                        Quat delta = qMul(qInv(rpp), qMul(Qd, rpp));
                        animPose_.rot.resize(R.bones.size());
                        animPose_.rot[P] = qNorm(qMul(delta, animPose_.rot[P]));
                    }
                }
                animImgDirty_ = true;
            }
        }
    } else {
        dragJ = -1;
        panning = false;
    }
    if (wide) {   // botones con icono encima del lienzo (arriba izquierda: vista; arriba derecha: invertir/centrar)
        float bs = fs * 2.7f, gp = fs * 0.35f;
        ImGuiStyle& st = ImGui::GetStyle();
        (void)st;
        auto ib = [&](const char* id, ImVec2 pos, int kind, bool on) {
            ImGui::SetCursorScreenPos(pos);
            ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.20f, 0.36f, 0.42f, 0.95f) : ImVec4(0.16f, 0.20f, 0.26f, 0.92f));
            bool hit = ImGui::Button(id, ImVec2(bs, bs)) && tapped();
            ImGui::PopStyleColor();
            ImDrawList* d4 = ImGui::GetWindowDrawList();
            ImVec2 c(pos.x + bs * 0.5f, pos.y + bs * 0.5f);
            ImU32 col = IM_COL32(225, 232, 245, 255);
            float r = bs * 0.26f;
            switch (kind) {
                case 0: d4->AddRectFilled(ImVec2(c.x - r, c.y - r * 0.7f), ImVec2(c.x + r * 0.5f, c.y + r * 0.7f), col, 3.f); d4->AddTriangleFilled(ImVec2(c.x + r * 0.6f, c.y), ImVec2(c.x + r * 1.2f, c.y - r * 0.6f), ImVec2(c.x + r * 1.2f, c.y + r * 0.6f), col); break;   // cámara = Frente
                case 1: d4->AddCircleFilled(ImVec2(c.x, c.y - r * 0.8f), r * 0.35f, col); d4->AddRectFilled(ImVec2(c.x - r * 0.25f, c.y - r * 0.4f), ImVec2(c.x + r * 0.25f, c.y + r), col, 2.f); break;   // persona = Lado
                case 2: d4->AddLine(ImVec2(c.x - r, c.y - r * 0.4f), ImVec2(c.x + r, c.y - r * 0.4f), col, 2.5f); d4->AddLine(ImVec2(c.x + r, c.y + r * 0.4f), ImVec2(c.x - r, c.y + r * 0.4f), col, 2.5f);
                        d4->AddTriangleFilled(ImVec2(c.x + r, c.y - r * 0.9f), ImVec2(c.x + r * 1.5f, c.y - r * 0.4f), ImVec2(c.x + r, c.y + r * 0.1f), col); d4->AddTriangleFilled(ImVec2(c.x - r, c.y + r * 0.9f), ImVec2(c.x - r * 1.5f, c.y + r * 0.4f), ImVec2(c.x - r, c.y - r * 0.1f), col); break;   // cambiar ejes
                case 3: case 4: d4->AddCircle(ImVec2(c.x - r * 0.15f, c.y - r * 0.15f), r * 0.85f, col, 0, 2.5f); d4->AddLine(ImVec2(c.x + r * 0.5f, c.y + r * 0.5f), ImVec2(c.x + r * 1.2f, c.y + r * 1.2f), col, 3.f);
                        d4->AddLine(ImVec2(c.x - r * 0.55f, c.y - r * 0.15f), ImVec2(c.x + r * 0.25f, c.y - r * 0.15f), col, 2.f); if (kind == 3) d4->AddLine(ImVec2(c.x - r * 0.15f, c.y - r * 0.55f), ImVec2(c.x - r * 0.15f, c.y + r * 0.25f), col, 2.f); break;   // lupa + / -
                case 5: d4->AddLine(ImVec2(c.x - r, c.y), ImVec2(c.x + r, c.y), col, 2.5f); d4->AddTriangleFilled(ImVec2(c.x + r * 1.2f, c.y), ImVec2(c.x + r * 0.5f, c.y - r * 0.5f), ImVec2(c.x + r * 0.5f, c.y + r * 0.5f), col); d4->AddTriangleFilled(ImVec2(c.x - r * 1.2f, c.y), ImVec2(c.x - r * 0.5f, c.y - r * 0.5f), ImVec2(c.x - r * 0.5f, c.y + r * 0.5f), col); break;   // invertir
                default: for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) { d4->AddLine(ImVec2(c.x + sx * r * 1.1f, c.y + sy * r * 1.1f), ImVec2(c.x + sx * r * 0.45f, c.y + sy * r * 1.1f), col, 2.5f); d4->AddLine(ImVec2(c.x + sx * r * 1.1f, c.y + sy * r * 1.1f), ImVec2(c.x + sx * r * 1.1f, c.y + sy * r * 0.45f), col, 2.5f); } break;   // centrar
            }
            return hit;
        };
        ImVec2 o1(org.x + fs * 0.5f, org.y + fs * 0.5f);
        if (ib("##vF", o1, 0, animView_ == 0)) { animView_ = 0; animImgDirty_ = true; }
        if (ib("##vL", ImVec2(o1.x + bs + gp, o1.y), 1, animView_ == 1)) { animView_ = 1; animImgDirty_ = true; }
        if (ib("##vE", ImVec2(o1.x + (bs + gp) * 2.f, o1.y), 2, animSwap_)) { animSwap_ = !animSwap_; animImgDirty_ = true; }
        if (ib("##zP", ImVec2(o1.x, o1.y + bs + gp), 3, false)) { animZoom_ = std::min(6.f, animZoom_ * 1.3f); animImgDirty_ = true; }
        if (ib("##zM", ImVec2(o1.x + bs + gp, o1.y + bs + gp), 4, false)) { animZoom_ = std::max(0.3f, animZoom_ / 1.3f); animImgDirty_ = true; }
        if (ib("##fl", ImVec2(org.x + Q - bs * 2.f - gp - fs * 0.5f, org.y + fs * 0.5f), 5, animFlip_)) { animFlip_ = !animFlip_; animImgDirty_ = true; }
        if (ib("##ce", ImVec2(org.x + Q - bs - fs * 0.5f, org.y + fs * 0.5f), 6, false)) { animZoom_ = 1.f; animPanX_ = animPanY_ = 0.f; animImgDirty_ = true; }
        dl->AddText(ImVec2(org.x + fs * 0.6f, org.y + Q - fs * 1.6f), IM_COL32(170, 185, 205, 200), "Zoom: pellizca con dos dedos");
    }
    ImGui::EndGroup();
    if (wide && animTab_ == 2) {   // opciones de animación a la derecha
        ImGui::SameLine();
        wrapui::BeginChild("##aopts", ImVec2(0, 0), true, kNoSB);
        dragScroll();
        animarBody();
        ImGui::Dummy(ImVec2(1, fs * 2.f));
        ImGui::EndChild();
    }
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar(2);
    ImGui::End();
}

}  // namespace forge
