package com.forge.maker;

import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.opengl.EGL14;
import android.opengl.EGLConfig;
import android.opengl.EGLContext;
import android.opengl.EGLDisplay;
import android.opengl.EGLSurface;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;

/**
 * Video para los objetos del juego. MediaPlayer pone el sonido y el reloj; los cuadros se sacan con
 * MediaMetadataRetriever (unos 10-15 por segundo, en baja resolucion) y el motor C++ los sube como textura.
 */
public class VideoBridge {
    static class Vid {
        MediaPlayer mp;
        MediaMetadataRetriever mmr;
        File file;
        int w, h, tw, th;
        volatile boolean playing, finished, alive = true, fresh, wasPlaying;
        volatile byte[] frame;
        volatile int fw, fh;
        volatile long seekReq = -1;
        Thread th_;
        // reproduccion real: el video se dibuja en un SurfaceTexture y se lee de ahi (30 cuadros por segundo)
        volatile boolean useGl;
        volatile boolean newFrame, glStop;
        Surface surface;
        SurfaceTexture st;
        CountDownLatch ready;
    }

    private final HashMap<Integer, Vid> vids = new HashMap<>();
    private final File cache;

    public VideoBridge(File cacheDir) { cache = cacheDir; }

    public synchronized boolean open(int id, byte[] data, String name) {
        close(id);
        try {
            String ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : ".mp4";
            final Vid v = new Vid();
            v.file = new File(cache, "vid" + id + ext);
            try (FileOutputStream o = new FileOutputStream(v.file)) { o.write(data); }
            v.mp = new MediaPlayer();
            v.mp.setDataSource(v.file.getAbsolutePath());
            v.mp.setLooping(false);
            v.mp.setOnCompletionListener(m -> { v.finished = true; v.playing = false; });
            v.mp.prepare();
            v.mmr = new MediaMetadataRetriever();
            v.mmr.setDataSource(v.file.getAbsolutePath());
            try {
                v.w = Integer.parseInt(v.mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH));
                v.h = Integer.parseInt(v.mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT));
            } catch (Throwable t) { v.w = 640; v.h = 360; }
            float k = Math.min(1f, 480f / Math.max(1, v.w));
            v.tw = Math.max(2, (int) (v.w * k)); v.th = Math.max(2, (int) (v.h * k));
            v.seekReq = 0;
            try {   // primero se intenta la reproduccion real (SurfaceTexture); si falla, cuadros sueltos como antes
                int rot = 0;
                try { rot = Integer.parseInt(v.mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)); } catch (Throwable t) { }
                int vw = v.mp.getVideoWidth() > 0 ? v.mp.getVideoWidth() : v.w, vh = v.mp.getVideoHeight() > 0 ? v.mp.getVideoHeight() : v.h;
                if (rot == 90 || rot == 270) { int t0 = vw; vw = vh; vh = t0; }
                float kk = Math.min(1f, 640f / Math.max(1, vw));
                v.tw = Math.max(2, ((int) (vw * kk)) & ~1); v.th = Math.max(2, ((int) (vh * kk)) & ~1);
                v.ready = new CountDownLatch(1);
                v.th_ = new Thread(() -> glLoop(v), "forge-video-gl");
                v.th_.setDaemon(true);
                v.th_.start();
                if (v.ready.await(3, TimeUnit.SECONDS) && v.useGl && v.surface != null) {
                    v.mp.setSurface(v.surface);
                } else {
                    v.useGl = false;
                    v.glStop = true;
                }
            } catch (Throwable t) { v.useGl = false; }
            if (!v.useGl) {
                v.th_ = new Thread(() -> loop(v), "forge-video");
                v.th_.setDaemon(true);
                v.th_.start();
            }
            vids.put(id, v);
            return true;
        } catch (Throwable t) {
            close(id);
            return false;
        }
    }

    private static final String VS = "attribute vec4 aPos; attribute vec2 aTc; uniform mat4 uTex; varying vec2 vTc; void main(){ gl_Position = aPos; vTc = (uTex * vec4(aTc, 0.0, 1.0)).xy; }";
    private static final String FS = "#extension GL_OES_EGL_image_external : require\nprecision mediump float; varying vec2 vTc; uniform samplerExternalOES uSam; void main(){ gl_FragColor = texture2D(uSam, vTc); }";

    private static int shader(int type, String src) {
        int sh = GLES20.glCreateShader(type);
        GLES20.glShaderSource(sh, src);
        GLES20.glCompileShader(sh);
        int[] ok = new int[1];
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) throw new RuntimeException("shader");
        return sh;
    }

    /** Hilo con su propio contexto GL: recibe los cuadros del reproductor y los lee como RGBA (de arriba hacia abajo). */
    private void glLoop(final Vid v) {
        EGLDisplay dpy = EGL14.EGL_NO_DISPLAY;
        EGLSurface surf = EGL14.EGL_NO_SURFACE;
        EGLContext ctx = EGL14.EGL_NO_CONTEXT;
        try {
            dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY);
            int[] ver = new int[2];
            EGL14.eglInitialize(dpy, ver, 0, ver, 1);
            int[] ca = {EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE};
            EGLConfig[] cfg = new EGLConfig[1];
            int[] n = new int[1];
            EGL14.eglChooseConfig(dpy, ca, 0, cfg, 0, 1, n, 0);
            if (n[0] < 1) throw new RuntimeException("config");
            ctx = EGL14.eglCreateContext(dpy, cfg[0], EGL14.EGL_NO_CONTEXT, new int[] {EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE}, 0);
            surf = EGL14.eglCreatePbufferSurface(dpy, cfg[0], new int[] {EGL14.EGL_WIDTH, v.tw, EGL14.EGL_HEIGHT, v.th, EGL14.EGL_NONE}, 0);
            if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw new RuntimeException("current");
            int prog = GLES20.glCreateProgram();
            GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, VS));
            GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, FS));
            GLES20.glLinkProgram(prog);
            int[] ok = new int[1];
            GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, ok, 0);
            if (ok[0] == 0) throw new RuntimeException("link");
            int[] tex = new int[1];
            GLES20.glGenTextures(1, tex, 0);
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex[0]);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE);
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE);
            v.st = new SurfaceTexture(tex[0]);
            v.st.setDefaultBufferSize(v.tw, v.th);
            v.st.setOnFrameAvailableListener(t -> v.newFrame = true);
            v.surface = new Surface(v.st);
            FloatBuffer quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            quad.put(new float[] {-1, -1, 0, 0, 1, -1, 1, 0, -1, 1, 0, 1, 1, 1, 1, 1}).position(0);
            int aPos = GLES20.glGetAttribLocation(prog, "aPos"), aTc = GLES20.glGetAttribLocation(prog, "aTc");
            int uTex = GLES20.glGetUniformLocation(prog, "uTex");
            float[] mtx = new float[16];
            ByteBuffer pix = ByteBuffer.allocateDirect(v.tw * v.th * 4).order(ByteOrder.nativeOrder());
            v.useGl = true;
            v.ready.countDown();
            while (v.alive && !v.glStop) {
                if (!v.newFrame) { Thread.sleep(4); continue; }
                v.newFrame = false;
                v.st.updateTexImage();
                v.st.getTransformMatrix(mtx);
                GLES20.glViewport(0, 0, v.tw, v.th);
                GLES20.glUseProgram(prog);
                GLES20.glUniformMatrix4fv(uTex, 1, false, mtx, 0);
                quad.position(0);
                GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad);
                GLES20.glEnableVertexAttribArray(aPos);
                quad.position(2);
                GLES20.glVertexAttribPointer(aTc, 2, GLES20.GL_FLOAT, false, 16, quad);
                GLES20.glEnableVertexAttribArray(aTc);
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
                pix.position(0);
                GLES20.glReadPixels(0, 0, v.tw, v.th, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, pix);
                byte[] out = new byte[v.tw * v.th * 4];
                int row = v.tw * 4;
                for (int y = 0; y < v.th; y++) {   // GL lee de abajo hacia arriba: se voltea para que la primera fila sea la de arriba
                    pix.position((v.th - 1 - y) * row);
                    pix.get(out, y * row, row);
                }
                for (int i = 3; i < out.length; i += 4) out[i] = (byte) 255;
                v.fw = v.tw; v.fh = v.th; v.frame = out; v.fresh = true;
            }
        } catch (Throwable t) {
            v.useGl = false;
        } finally {
            if (v.ready != null) v.ready.countDown();
            try { if (v.surface != null) v.surface.release(); } catch (Throwable t) { }
            try { if (v.st != null) v.st.release(); } catch (Throwable t) { }
            try {
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT);
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf);
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx);
            } catch (Throwable t) { }
        }
    }

    private void loop(Vid v) {
        long lastPos = -1;
        while (v.alive) {
            try {
                long posMs;
                boolean need;
                if (v.seekReq >= 0) {
                    posMs = v.seekReq;
                    v.seekReq = -1;
                    need = true;
                    lastPos = -1;
                } else {
                    posMs = v.mp.getCurrentPosition();
                    need = v.playing && posMs != lastPos;
                }
                if (need) {
                    lastPos = posMs;
                    Bitmap b;
                    if (android.os.Build.VERSION.SDK_INT >= 27)
                        b = v.mmr.getScaledFrameAtTime(posMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST, v.tw, v.th);
                    else
                        b = v.mmr.getFrameAtTime(posMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST);
                    if (b != null) {
                        int w = b.getWidth(), h = b.getHeight();
                        int[] px = new int[w * h];
                        b.getPixels(px, 0, w, 0, 0, w, h);
                        byte[] out = new byte[w * h * 4];
                        for (int i = 0; i < px.length; i++) {
                            int c = px[i];
                            out[i * 4] = (byte) (c >> 16); out[i * 4 + 1] = (byte) (c >> 8); out[i * 4 + 2] = (byte) c; out[i * 4 + 3] = (byte) 255;
                        }
                        v.fw = w; v.fh = h; v.frame = out; v.fresh = true;
                    }
                }
                Thread.sleep(need ? 15 : 40);
            } catch (Throwable t) {
                try { Thread.sleep(50); } catch (InterruptedException e) { return; }
            }
        }
    }

    public synchronized void control(int id, int cmd, float arg) {
        Vid v = vids.get(id);
        if (v == null) return;
        try {
            if (cmd == 0) { v.finished = false; v.mp.start(); v.playing = true; }
            else if (cmd == 1) { v.mp.pause(); v.playing = false; }
            else if (cmd == 2) { v.mp.pause(); v.mp.seekTo(0); v.playing = false; v.finished = false; v.seekReq = 0; }
            else if (cmd == 3) { v.mp.seekTo((int) (arg * 1000f)); v.finished = false; v.seekReq = (long) (arg * 1000f); }
        } catch (Throwable t) { /* estado raro del reproductor: se ignora */ }
    }

    /** {ancho, alto, hay cuadro nuevo, termino} */
    public synchronized int[] info(int id) {
        Vid v = vids.get(id);
        if (v == null) return new int[] {0, 0, 0, 1};
        return new int[] {v.fw, v.fh, v.fresh ? 1 : 0, v.finished ? 1 : 0};
    }

    public synchronized byte[] frame(int id) {
        Vid v = vids.get(id);
        if (v == null) return null;
        v.fresh = false;
        return v.frame;
    }

    public synchronized void close(int id) {
        Vid v = vids.remove(id);
        if (v == null) return;
        v.alive = false;
        try { v.mp.release(); } catch (Throwable t) { }
        try { v.mmr.release(); } catch (Throwable t) { }
        try { v.file.delete(); } catch (Throwable t) { }
    }

    public synchronized void pauseAll() {
        for (Vid v : vids.values()) {
            v.wasPlaying = v.playing;
            if (v.playing) { try { v.mp.pause(); } catch (Throwable t) { } v.playing = false; }
        }
    }

    public synchronized void resumeAll() {
        for (Vid v : vids.values())
            if (v.wasPlaying) { try { v.mp.start(); } catch (Throwable t) { } v.playing = true; v.wasPlaying = false; }
    }
}
