// Prueba de importadores de modelos: OBJ (con caras de 4 vertices), GLB hecho a mano y,
// si se pasa la ruta de un .fbx como argumento, un FBX real.
#include <cstdio>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iterator>

#include "importer.h"
#include "preview.h"
#include "editor.h"
#include "stb_image.h"
#include "stb_image_write.h"
#include "model.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static std::vector<uint8_t> makeGlb() {
    std::string json =
        R"({"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"mesh":0}],)"
        R"("meshes":[{"primitives":[{"attributes":{"POSITION":0,"TEXCOORD_0":1},"indices":2,"material":0}]}],)"
        R"("materials":[{"pbrMetallicRoughness":{"baseColorFactor":[1,0.5,0.25,1]}}],)"
        R"("accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3","min":[0,0,0],"max":[2,1,0]},)"
        R"({"bufferView":1,"componentType":5126,"count":3,"type":"VEC2"},)"
        R"({"bufferView":2,"componentType":5123,"count":3,"type":"SCALAR"}],)"
        R"("bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":36},{"buffer":0,"byteOffset":36,"byteLength":24},)"
        R"({"buffer":0,"byteOffset":60,"byteLength":6}],"buffers":[{"byteLength":68}]})";
    while (json.size() % 4) json += ' ';
    float pos[9] = {0, 0, 0, 2, 0, 0, 0, 1, 0};
    float uv[6] = {0, 0, 1, 0, 0, 1};
    unsigned short idx[3] = {0, 1, 2};
    std::vector<uint8_t> bin(68, 0);
    memcpy(bin.data(), pos, 36);
    memcpy(bin.data() + 36, uv, 24);
    memcpy(bin.data() + 60, idx, 6);
    auto w32 = [](std::vector<uint8_t>& o, uint32_t v) { for (int i = 0; i < 4; i++) o.push_back((v >> (8 * i)) & 255); };
    std::vector<uint8_t> g;
    g.insert(g.end(), {'g', 'l', 'T', 'F'});
    w32(g, 2);
    w32(g, (uint32_t)(12 + 8 + json.size() + 8 + bin.size()));
    w32(g, (uint32_t)json.size());
    g.insert(g.end(), {'J', 'S', 'O', 'N'});
    g.insert(g.end(), json.begin(), json.end());
    w32(g, (uint32_t)bin.size());
    g.insert(g.end(), {'B', 'I', 'N', 0});
    g.insert(g.end(), bin.begin(), bin.end());
    return g;
}

static bool check(const Files& a, const std::string& name, size_t minTris, float* bboxMax = nullptr) {
    auto it = a.find(name);
    if (it == a.end()) return false;
    ModelData m;
    if (!modelRead(it->second.data(), it->second.size(), m)) return false;
    if (m.idx.size() / 3 < minTris) return false;
    float mx = 0;
    for (size_t i = 0; i < m.v.size(); i += 8)
        for (int c = 0; c < 3; c++) mx = std::max(mx, std::fabs(m.v[i + c]));
    if (bboxMax) *bboxMax = mx;
    return mx <= 0.5001f;  // normalizado a un cubo unitario centrado
}

int main(int argc, char** argv) {
    Files assets;
    std::string name, err;

    // OBJ: un cubo con 6 caras de 4 vertices -> 12 triangulos, 8 vertices unicos.
    std::string obj =
        "v -5 -5 -5\nv 5 -5 -5\nv 5 5 -5\nv -5 5 -5\nv -5 -5 5\nv 5 -5 5\nv 5 5 5\nv -5 5 5\n"
        "f 1 2 3 4\nf 5 8 7 6\nf 1 5 6 2\nf 2 6 7 3\nf 3 7 8 4\nf 4 8 5 1\n";
    CHECK(importModel("Mi Cubo.obj", std::vector<uint8_t>(obj.begin(), obj.end()), assets, name, err));
    CHECK(name == "Mi_Cubo.fmdl");
    ModelData m;
    CHECK(modelRead(assets[name].data(), assets[name].size(), m));
    CHECK(m.idx.size() == 36);
    CHECK(check(assets, name, 12));
    printf("OBJ ok: %zu triangulos, %zu vertices\n", m.idx.size() / 3, m.v.size() / 8);

    // El mismo nombre dos veces no pisa el anterior.
    CHECK(importModel("Mi Cubo.obj", std::vector<uint8_t>(obj.begin(), obj.end()), assets, name, err));
    CHECK(name == "Mi_Cubo_2.fmdl");

    // OBJ roto.
    std::string bad = "f 1 2 3\n";
    CHECK(!importModel("roto.obj", std::vector<uint8_t>(bad.begin(), bad.end()), assets, name, err));

    // GLB.
    auto glb = makeGlb();
    CHECK(importModel("tri.glb", glb, assets, name, err));
    ModelData g;
    CHECK(modelRead(assets[name].data(), assets[name].size(), g));
    CHECK(g.idx.size() == 3);
    CHECK(g.color[0] > 0.99f && std::fabs(g.color[1] - 0.735f) < 0.01f && std::fabs(g.color[2] - 0.537f) < 0.01f);  // color del material (glTF lineal -> sRGB)
    CHECK(check(assets, name, 1));
    printf("GLB ok: %zu triangulos, color %.2f %.2f %.2f\n", g.idx.size() / 3, g.color[0], g.color[1], g.color[2]);

    // Formato no compatible.
    // zip (almacenado) con obj + mtl de 2 materiales -> atlas con color
    {
        auto crc = [](const std::string& d) { uint32_t c = 0xFFFFFFFFu; for (unsigned char b : d) { c ^= b; for (int k = 0; k < 8; k++) c = (c >> 1) ^ (0xEDB88320u & (0u - (c & 1))); } return ~c; };
        std::string z, cd; int cnt = 0;
        auto le = [](std::string& o, uint32_t v, int n) { for (int i = 0; i < n; i++) o += (char)((v >> (8 * i)) & 255); };
        auto add = [&](const std::string& nm, const std::string& d) {
            uint32_t off = (uint32_t)z.size();
            le(z, 0x04034b50, 4); le(z, 20, 2); le(z, 0, 2); le(z, 0, 2); le(z, 0, 2); le(z, 0, 2);
            le(z, crc(d), 4); le(z, (uint32_t)d.size(), 4); le(z, (uint32_t)d.size(), 4); le(z, (uint32_t)nm.size(), 2); le(z, 0, 2);
            z += nm; z += d;
            le(cd, 0x02014b50, 4); le(cd, 20, 2); le(cd, 20, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2);
            le(cd, crc(d), 4); le(cd, (uint32_t)d.size(), 4); le(cd, (uint32_t)d.size(), 4); le(cd, (uint32_t)nm.size(), 2);
            le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 2); le(cd, 0, 4); le(cd, off, 4); cd += nm; cnt++;
        };
        add("m/a.mtl", "newmtl rojo\nKd 1 0 0\nnewmtl azul\nKd 0 0 1\n");
        add("m/a.obj", "mtllib a.mtl\nv 0 0 0\nv 1 0 0\nv 0 1 0\nv 1 1 0\nusemtl rojo\nf 1 2 3\nusemtl azul\nf 2 4 3\n");
        uint32_t cdOff = (uint32_t)z.size();
        z += cd; le(z, 0x06054b50, 4); le(z, 0, 2); le(z, 0, 2); le(z, cnt, 2); le(z, cnt, 2); le(z, (uint32_t)cd.size(), 4); le(z, cdOff, 4); le(z, 0, 2);
        Files a2; std::string n2, e2;
        CHECK(importModelZip(std::vector<uint8_t>(z.begin(), z.end()), a2, n2, e2));
        ModelData zm;
        CHECK(modelRead(a2[n2].data(), a2[n2].size(), zm));
        CHECK(zm.idx.size() == 6);
        CHECK(!zm.tex.empty() && a2.count(zm.tex));
    }
    // miniatura de un modelo
    {
        std::vector<uint8_t> px;
        CHECK(modelPreviewRGBA(assets[name], assets, 64, px));
        size_t opaque = 0;
        for (size_t i = 3; i < px.size(); i += 4) if (px[i]) opaque++;
        CHECK(opaque > 20);
        CHECK(!modelPreviewRGBA(std::vector<uint8_t>{1, 2, 3}, assets, 64, px));
    }
    // exportacion: paquete zip, icono, nombre de paquete
    {
        CHECK(validAppId("com.juan.aventura") && validAppId("mx.edu.mi_juego2"));
        CHECK(!validAppId("MiJuego") && !validAppId("com..x") && !validAppId("1com.x") && !validAppId("com.") && !validAppId("com juego.x"));
        CHECK(exportSlug("Mi Juego Épico!") == "mi_juego_pico");
        std::vector<std::pair<std::string, std::vector<uint8_t>>> fl;
        fl.push_back({"games/x/game.pack", std::vector<uint8_t>{1, 2, 3, 4, 5}});
        fl.push_back({"games/x/apk.properties", std::vector<uint8_t>{'a', '=', 'b'}});
        std::vector<uint8_t> z;
        CHECK(zipStore(fl, z));
        ResMap rm;
        std::string e3;
        CHECK(unzipAll(z, rm, e3));
        CHECK(rm.size() == 2 && rm["game.pack"].size() == 5 && rm["game.pack"][4] == 5 && rm["apk.properties"].size() == 3);
        // icono: cualquier png se convierte en 192x192
        std::vector<uint8_t> big, icon;
        std::vector<uint8_t> px(40 * 20 * 4, 200);
        stbi_write_png_to_func([](void* c, void* d, int n) { ((std::vector<uint8_t>*)c)->insert(((std::vector<uint8_t>*)c)->end(), (uint8_t*)d, (uint8_t*)d + n); }, &big, 40, 20, 4, px.data(), 40 * 4);
        CHECK(makeIconPng(big, 192, icon));
        int iw, ih, ic;
        unsigned char* d = stbi_load_from_memory(icon.data(), (int)icon.size(), &iw, &ih, &ic, 4);
        CHECK(d && iw == 192 && ih == 192);
        if (d) stbi_image_free(d);
        // las opciones se guardan y se cargan
        Project q;
        q.scenes.push_back(Scene());
        q.exportCfg.appName = "Mi Juego Épico"; q.exportCfg.appId = "com.juan.epico"; q.exportCfg.verName = "2.1 beta"; q.exportCfg.verCode = 7;
        q.exportCfg.orient = 1; q.exportCfg.icon = "icono.png"; q.exportCfg.exeName = "epico"; q.exportCfg.winTitle = "Mi título";
        q.exportCfg.fullscreen = true; q.exportCfg.winW = 1600; q.exportCfg.winH = 900;
        std::string txt = writeProject(q);
        Files ff; ff["project.forge"].assign(txt.begin(), txt.end());
        Project r;
        std::string e4;
        CHECK(loadProject(ff, r, e4) || (printf("%s\n", e4.c_str()), false));
        CHECK(r.exportCfg.appName == "Mi Juego Épico" && r.exportCfg.appId == "com.juan.epico" && r.exportCfg.verName == "2.1 beta");
        CHECK(r.exportCfg.verCode == 7 && r.exportCfg.orient == 1 && r.exportCfg.icon == "icono.png" && r.exportCfg.exeName == "epico");
        CHECK(r.exportCfg.winTitle == "Mi título" && r.exportCfg.fullscreen && r.exportCfg.winW == 1600 && r.exportCfg.winH == 900);
    }
    CHECK(!importModel("x.stl", {1, 2, 3}, assets, name, err));

    // FBX opcional.
    if (argc > 1) {
        std::ifstream f(argv[1], std::ios::binary);
        std::vector<uint8_t> fbx((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
        CHECK(!fbx.empty());
        CHECK(importModel("prueba.fbx", fbx, assets, name, err));
        ModelData fm;
        CHECK(modelRead(assets[name].data(), assets[name].size(), fm));
        CHECK(check(assets, name, 1));
        printf("FBX ok: %zu triangulos, %zu vertices\n", fm.idx.size() / 3, fm.v.size() / 8);
    }
    {   // animaciones de esqueleto (glTF hecho a mano: un hueso que gira 90 grados) + deformación
        std::string g = R"GL({"asset":{"version":"2.0"},"buffers":[{"byteLength":84,"uri":"data:application/octet-stream;base64,AAAAvwAAAAAAAAAAAAAAPwAAAAAAAAAAAAAAAAAAAEAAAAAAAAABAAIAAAAAAAAAAACAPwAAAAAAAAAAAAAAAAAAgD8AAAAAAAAAAPMENT/zBDU/"}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":36},{"buffer":0,"byteOffset":36,"byteLength":6},{"buffer":0,"byteOffset":44,"byteLength":8},{"buffer":0,"byteOffset":52,"byteLength":32}],"accessors":[{"bufferView":0,"componentType":5126,"count":3,"type":"VEC3","min":[-0.5,0,0],"max":[0.5,2,0]},{"bufferView":1,"componentType":5123,"count":3,"type":"SCALAR"},{"bufferView":2,"componentType":5126,"count":2,"type":"SCALAR","min":[0],"max":[1]},{"bufferView":3,"componentType":5126,"count":2,"type":"VEC4"}],"meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1}]}],"nodes":[{"name":"raiz","children":[1]},{"name":"brazo","translation":[0,1,0]},{"mesh":0}],"skins":[{"joints":[0,1]}],"animations":[{"name":"girar","samplers":[{"input":2,"output":3,"interpolation":"LINEAR"}],"channels":[{"sampler":0,"target":{"node":1,"path":"rotation"}}]}],"scenes":[{"nodes":[0,2]}],"scene":0})GL";
        Files assets2;
        Rig rg;
        int added = 0;
        std::string e2, mname = "tri.fmdl";
        CHECK(importAnimations("anim.gltf", std::vector<uint8_t>(g.begin(), g.end()), mname, rg, added, e2));
        CHECK(added == 1 && rg.bones.size() == 2 && rg.clips.size() == 1);
        CHECK(rg.bones[1].parent == 0 && std::fabs(rg.bones[1].head.y - rg.bones[0].head.y) > 0.1f);
        RigPose p1 = rigSample(rg, rg.clips[0], rg.clips[0].len * 0.999f);
        float ex, ey, ez;
        qToEulerDeg(p1.rot[1], ex, ey, ez);
        CHECK(std::fabs(std::fabs(ez) - 90.f) < 8.f);
        // texto ida y vuelta
        Rig rb;
        CHECK(rigRead(rigWrite(rg), rb) && rb.bones.size() == 2 && rb.clips.size() == 1 && rb.clips[0].keys.size() == rg.clips[0].keys.size());
        // deformación: un vértice cerca de la punta del segundo hueso se mueve al girarlo
        std::vector<float> v8 = {0.f, rg.bones[1].head.y + 0.2f, 0.f, 0, 0, 1, 0, 0};
        RigWeights w;
        rigComputeWeights(rg, v8, w);
        std::vector<float> mats, out;
        rigSkinMatrices(rg, p1, mats);
        rigSkin(v8, w, mats, out);
        CHECK(std::fabs(out[0] - v8[0]) > 0.05f || std::fabs(out[1] - v8[1]) > 0.05f);
    }
    {   // piezas sueltas (brazo pegado al torso, modelo sin pose en T): cada pieza se mueve rígida con un solo hueso
        Rig rg; rg.stiff = 3.f;
        RigBone b0; b0.name = "torso"; b0.head = V3{0, 0, 0}; RigBone b1; b1.name = "brazo"; b1.parent = 0; b1.head = V3{0.3f, 0.5f, 0};
        RigBone b2; b2.name = "mano"; b2.parent = 1; b2.head = V3{0.3f, -0.2f, 0}; rg.bones = {b0, b1, b2};
        std::vector<float> v8; std::vector<uint32_t> ix;
        auto tri = [&](float x, float y) { uint32_t b = (uint32_t)(v8.size() / 8); for (int i = 0; i < 3; i++) { float px = x + (i == 1 ? 0.1f : 0.f), py = y + (i == 2 ? 0.1f : 0.f); float vv[8] = {px, py, 0, 0, 0, 1, 0, 0}; v8.insert(v8.end(), vv, vv + 8); } ix.insert(ix.end(), {b, b + 1, b + 2}); };
        tri(0.f, 0.f); tri(0.28f, 0.2f);
        RigWeights w; rigComputeWeights(rg, v8, w, &ix);
        for (size_t v = 0; v < 3; v++) CHECK(w.bw[v * 4] == 1.f && w.bi[v * 4] == w.bi[0]);
        for (size_t v = 3; v < 6; v++) CHECK(w.bw[v * 4] == 1.f && w.bi[v * 4] == w.bi[12]);
    }
    {   // modelo muy pesado: se simplifica en vez de fallar
        std::string obj;
        const int N = 450;
        obj.reserve(40u << 20);
        for (int y = 0; y <= N; y++)
            for (int x = 0; x <= N; x++) obj += "v " + std::to_string(x * 0.01f) + " " + std::to_string(std::sin(x * 0.05f) * std::cos(y * 0.05f)) + " " + std::to_string(y * 0.01f) + "\n";
        for (int y = 0; y < N; y++)
            for (int x = 0; x < N; x++) {
                int a = y * (N + 1) + x + 1, b = a + 1, c = a + N + 1, d = c + 1;
                obj += "f " + std::to_string(a) + " " + std::to_string(c) + " " + std::to_string(b) + "\nf " + std::to_string(b) + " " + std::to_string(c) + " " + std::to_string(d) + "\n";
            }
        Files assets; std::string name, err;
        CHECK(importModel("grande.obj", std::vector<uint8_t>(obj.begin(), obj.end()), assets, name, err));
        CHECK(!name.empty() && assets.count(name));
    }
    printf("OK\n");
    return 0;
}
