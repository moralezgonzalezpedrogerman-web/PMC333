#include <cctype>
#include <cmath>
#include "scene.h"
#include <cstdio>
#include <cstdlib>
#include <sstream>

namespace forge {

static const char* const kAnimNames[kAnimCount] = {
    "Quieto", "Caminar", "Atacar cuerpo a cuerpo", "Recibir daño", "Correr", "Saltar", "Disparar",
    "Apuntar", "Agacharse", "Recargar", "Interactuar", "Recoger", "Soltar", "Morir", "Cambiar de arma", "Nadar",
    "Cubrirse", "Caminar a la derecha", "Caminar a la izquierda", "Caminar hacia atrás", "Disparar caminando", "Desenfundar arma", "Guardar arma", "Acción personalizada"};
const char* animActionName(int k) { return k >= 0 && k < kAnimCount ? kAnimNames[k] : "?"; }
static std::string animKey(const std::string& in) {
    std::string r;
    for (unsigned char c : in) { if (c == ' ' || c == '_' || c == '-') continue; r += (char)std::tolower(c); }
    return r;
}
int animFromName(const std::string& n) {
    std::string k = animKey(n);
    if (k.empty()) return -1;
    for (int i = 0; i < kAnimCount; i++) if (animKey(kAnimNames[i]) == k) return i;
    struct W { const char* w; int id; };
    static const W t[] = {   // palabras sueltas y partes de nombre (las más específicas primero)
        {"derecha", kStrafeR}, {"izquierda", kStrafeL}, {"atras", kBack}, {"disparandocamin", kShootWalk}, {"dispararcamin", kShootWalk},
        {"desenfund", kDraw}, {"guardar", kHolster}, {"cambiar", kSwap}, {"recarg", kReload}, {"reload", kReload}, {"agach", kCrouch}, {"crouch", kCrouch},
        {"interact", kInteract}, {"recog", kPickup}, {"pick", kPickup}, {"solt", kDrop}, {"drop", kDrop}, {"mor", kDie}, {"die", kDie}, {"dead", kDie},
        {"nad", kSwim}, {"swim", kSwim}, {"cubr", kCover}, {"cover", kCover}, {"apunt", kAim}, {"aim", kAim}, {"disp", kShoot}, {"shoot", kShoot},
        {"personal", kCustom}, {"custom", kCustom}, {"camin", kWalk}, {"walk", kWalk}, {"atac", kAttack}, {"attack", kAttack},
        {"da", kHurt}, {"hurt", kHurt}, {"corr", kRun}, {"run", kRun}, {"salt", kJump}, {"jump", kJump}, {"quiet", kIdle}, {"idle", kIdle}};
    for (auto& e : t) if (k.find(e.w) != std::string::npos) return e.id;
    return -1;
}

static std::vector<std::string> split(const std::string& l) {
    std::vector<std::string> t;
    std::istringstream ss(l);
    std::string w;
    while (ss >> w) t.push_back(w);
    return t;
}

void fxPreset(FxCfg& f, int id) {
    std::string tex = f.tex;
    f = FxCfg();
    f.tex = tex;
    f.on = true;
    f.kind = id;
    auto col = [&](float r0, float g0, float b0, float r1, float g1, float b1) {
        f.c0[0] = r0; f.c0[1] = g0; f.c0[2] = b0; f.c1[0] = r1; f.c1[1] = g1; f.c1[2] = b1;
    };
    switch (id) {
        case 0: f.rate = 12; f.life = 2.4f; f.size = 0.5f; f.speed = 1.0f; f.spread = 0.25f; f.gravity = -0.3f; f.grow = 1.5f; f.a0 = 0.5f; col(0.6f, 0.6f, 0.62f, 0.25f, 0.25f, 0.27f); break;
        case 1: f.rate = 40; f.life = 0.9f; f.size = 0.35f; f.speed = 1.6f; f.spread = 0.3f; f.gravity = -1.0f; f.grow = -0.6f; f.a0 = 0.9f; f.glow = true; col(1.f, 0.85f, 0.25f, 1.f, 0.2f, 0.05f); break;
        case 2: f.rate = 60; f.life = 0.7f; f.size = 0.08f; f.speed = 4.5f; f.spread = 1.4f; f.gravity = 9.f; f.a0 = 1.f; f.glow = true; col(1.f, 0.95f, 0.5f, 1.f, 0.4f, 0.1f); break;
        case 3: f.rate = 40; f.life = 4.f; f.size = 0.12f; f.speed = 0.3f; f.spread = 3.5f; f.gravity = 1.2f; f.a0 = 0.9f; col(1.f, 1.f, 1.f, 0.85f, 0.9f, 1.f); break;
        default: f.rate = 35; f.life = 1.1f; f.size = 0.25f; f.speed = 2.0f; f.spread = 1.0f; f.gravity = -0.5f; f.grow = -0.4f; f.a0 = 0.9f; f.glow = true; col(0.4f, 0.9f, 1.f, 0.3f, 0.2f, 1.f); break;
    }
}

void sfxPreset(ScreenFx& f, int id) {
    f = ScreenFx();
    auto tint = [&](float a, float r, float g, float b) { f.tint = a; f.tintC[0] = r; f.tintC[1] = g; f.tintC[2] = b; };
    switch (id) {
        case 1: f.scan = 0.6f; f.noise = 0.5f; f.vignette = 0.5f; f.track = 1.f; tint(0.15f, 0.2f, 0.6f, 0.7f); break;
        case 2: f.scan = 0.25f; f.noise = 0.15f; f.vignette = 0.45f; f.track = 0.3f; f.rec = true; break;
        case 3: f.scan = 0.4f; f.noise = 0.6f; f.vignette = 0.7f; tint(0.55f, 0.1f, 1.f, 0.25f); break;
        case 4: f.noise = 0.8f; f.vignette = 0.6f; f.track = 0.2f; tint(0.35f, 0.8f, 0.6f, 0.3f); break;
        default: break;
    }
}

int playerIndex(const Scene& s) {
    for (size_t i = 0; i < s.objs.size(); i++)
        if (s.objs[i].kind == Kind::Player) return (int)i;
    return -1;
}

void ensurePlayer(Scene& s) {
    if (!s.is3d) return;
    int i = playerIndex(s);
    if (i < 0) {
        Obj o;
        o.name = "Jugador";
        o.kind = Kind::Player;
        o.pos = {s.start.x, s.start.y + 0.85f, s.start.z};
        o.scale = {0.6f, 1.7f, 0.6f};
        o.solid = false;
        o.color[0] = 0.2f; o.color[1] = 1.f; o.color[2] = 0.3f;
        s.objs.push_back(o);
    } else {
        s.objs[i].solid = false;
        s.start = {s.objs[i].pos.x, s.objs[i].pos.y - 0.85f, s.objs[i].pos.z};
    }
}

const char* kindName(Kind k) {
    switch (k) {
        case Kind::Cube: return "cube";
        case Kind::Floor: return "floor";
        case Kind::Wall: return "wall";
        case Kind::Item: return "item";
        case Kind::Model: return "model";
        case Kind::Light: return "light";
        case Kind::Player: return "player";
    }
    return "cube";
}

static bool kindFromName(const std::string& s, Kind& k) {
    for (int i = 0; i <= (int)Kind::Player; i++)
        if (s == kindName((Kind)i)) { k = (Kind)i; return true; }
    return false;
}

static const char* actName(HudAct a) {
    switch (a) {
        case HudAct::None: return "none";
        case HudAct::Jump: return "jump";
        case HudAct::Shoot: return "shoot";
        case HudAct::Interact: return "interact";
        case HudAct::Script: return "script";
        case HudAct::NextWeapon: return "nextweapon";
        case HudAct::Reload: return "reload";
        case HudAct::Flashlight: return "flashlight";
        case HudAct::Hold: return "hold";
        case HudAct::Sprint: return "sprint";
        case HudAct::Crouch: return "crouch";
    }
    return "none";
}

std::vector<HudBtn> defaultHud() {
    HudBtn s;
    s.label = "DISPARAR"; s.x = 0.88f; s.y = 0.68f; s.r = 0.12f; s.act = HudAct::Shoot;
    s.color[0] = 1.f; s.color[1] = 0.35f; s.color[2] = 0.3f;
    HudBtn j;
    j.label = "SALTAR"; j.x = 0.73f; j.y = 0.86f; j.r = 0.09f; j.act = HudAct::Jump;
    j.color[0] = 0.3f; j.color[1] = 0.7f; j.color[2] = 1.f;
    return {s, j};
}

// ---------------------------------------------------------------- tabla de bloques
// Nombres y descripciones tomados del PDF de bloques (Pocket Code).
#define H 2
static const OpInfo kOps[] = {
    // ---- Eventos
    {Op::WhenStart, "cuandoempieza", Cat::Eventos, "Cuando empieza el programa", "Ejecuta los bloques de código cuando el programa arranca.", "", "", "", "", H},
    {Op::WhenTap, "cuandopulse", Cat::Eventos, "Cuando pulse", "Ejecuta los bloques de código cuando se pulsa sobre el objeto.", "", "", "", "", H},
    {Op::WhenReceive, "cuandorecibo", Cat::Eventos, "Cuando recibo {t}", "Ejecuta los bloques de código cuando el objeto recibe un mensaje específico.", "mensaje1", "", "", "", H},
    {Op::WhenCollide, "cuandocolision", Cat::Eventos, "Cuando hay una colisión física con {t}", "Permite la ejecución de una secuencia de bloques cuando el objeto colisiona con otro objeto determinado.", "", "", "", "", H},
    {Op::WhenTrue, "cuandoverdadero", Cat::Eventos, "Cuando {0} se convierta en verdadero", "Ejecuta los bloques cuando la fórmula pasa de falsa a verdadera.", "", "1 = 2", "", "", H},
    {Op::WhenShot, "cuandodisparo", Cat::Forge3D, "Cuando reciba un disparo", "3D: se ejecuta cuando el jugador dispara a este objeto.", "", "", "", "", H},
    {Op::WhenInteract, "cuandointeractua", Cat::Forge3D, "Cuando se interactúe", "Se ejecuta al tocar el objeto o pulsar el botón de interactuar mirándolo de cerca (puertas, interruptores, carteles).", "", "", "", "", H},
    {Op::WhenPlayerShoots, "cuandodispares", Cat::Eventos, "Cuando el jugador dispare", "Se ejecuta cada vez que el jugador dispara su arma (sonidos, retroceso, gastar munición).", "", "", "", "", H},
    {Op::WhenButton, "cuandoboton", Cat::Eventos, "Cuando se presione el botón {t}", "Se ejecuta al presionar un botón en pantalla. Elige uno de los botones de la ventana \"Botones\" (puedes crear botones nuevos que solo ejecuten bloques).", "DISPARAR", "", "", "", H},
    {Op::WhenObjMoves, "cuandosemueva", Cat::Eventos, "Cuando se mueva {t}", "Se ejecuta cuando el objeto elegido cambia de lugar (déjalo vacío para este mismo objeto).", "", "", "", "", H},
    {Op::WhenPlayerMoves, "cuandojugadormueve", Cat::Eventos, "Cuando el jugador se mueva", "Se ejecuta cuando el jugador empieza a caminar.", "", "", "", "", H},
    {Op::WhenPlayerHurt, "cuandojugadordano", Cat::Eventos, "Cuando el jugador reciba daño", "Se ejecuta cada vez que algo lastima al jugador.", "", "", "", "", H},
    {Op::WhenPlayerJumps, "cuandojugadorsalta", Cat::Eventos, "Cuando el jugador salte", "Se ejecuta cuando el jugador despega del suelo.", "", "", "", "", H},
    {Op::WhenNear, "cuandocerca", Cat::Forge3D, "Cuando el jugador se acerque", "3D: se ejecuta cuando el jugador entra en el radio del objeto.", "", "", "", "", H},
    // ---- Control
    {Op::Wait, "espera", Cat::Control, "Espera {0} segundos", "Espera un número específico de segundos y después continúa con la ejecución del siguiente bloque.", "", "1", "", "", 0},
    {Op::BroadcastWait, "enviayespera", Cat::Control, "Envía y espera {t}", "Envía un mensaje específico a todos los objetos y espera.", "mensaje1", "", "", "", 0},
    {Op::PauseTower, "pausartorre", Cat::Control, "Pausar {t}", "Detiene una torre de bloques (un guion con su evento arriba): no avanza ni se puede volver a iniciar mientras esté pausada. Elige: esta torre, una torre en específico, todas las de este objeto, todas las demás o todas las de todos los objetos. Para seguir usa «Reanudar torre».", "Esta torre", "", "", "", 0},
    {Op::ResumeTower, "reanudartorre", Cat::Control, "Reanudar {t}", "Deja que la torre (o torres) pausadas vuelvan a funcionar y sigan donde se quedaron. Si pausaste todas las de un objeto, reanúdalas desde otro objeto o con «Pausar todas las demás».", "Todas las torres de este objeto", "", "", "", 0},
    {Op::StopTowers, "detenertorres", Cat::Control, "Detener {t}", "Termina las torres de bloques que elijas: todas de todos los objetos, las de este mismo objeto, las de un solo objeto (o varios, separados por coma: «Objeto: A, B»), o todas menos esta torre.", "Todas las torres de todos los objetos", "", "", "", 0},
    {Op::GoRandom, "irazar", Cat::Movimiento, "Ir a una posición al azar de la pantalla", "Solo 2D. El objeto salta a un lugar cualquiera visible.", "", "", "", "", 0},
    {Op::GoTouch, "iratoque", Cat::Movimiento, "Ir a donde tocó el dedo", "Solo 2D. El objeto salta al último punto que tocaste en la pantalla.", "", "", "", "", 0},
    {Op::SayFor, "decirdurante", Cat::Apariencia, "Decir {0} durante {1} segundos", "Muestra el texto y espera ese tiempo.", "'¡Hola!'", "2", "", "", 0},
    {Op::SetLookNum, "aparienciaN", Cat::Apariencia, "Cambiar a la apariencia número {0}", "1 = la primera apariencia de la lista del objeto.", "1", "", "", "", 0},
    {Op::CloneOf, "clonde", Cat::Control, "Crear un clon de {t}", "Crea una copia de OTRO objeto (con sus bloques).", "", "", "", "", 0},
    {Op::NextScene, "siguienteescena", Cat::Control, "Ir a la siguiente escena", "Pasa a la escena que sigue en la lista (la última vuelve a la primera).", "", "", "", "", 0},
    {Op::ResetVars, "reiniciarvariables", Cat::Datos, "Poner todas las variables en 0", "Reinicia todas las variables y listas del juego.", "", "", "", "", 0},
    {Op::PenDown, "lapizbajar", Cat::Movimiento, "Bajar el lápiz (dibuja por donde se mueva)", "Solo 2D. El objeto deja una línea mientras se mueve.", "", "", "", "", 0},
    {Op::PenUp, "lapizsubir", Cat::Movimiento, "Subir el lápiz (deja de dibujar)", "", "", "", "", "", 0},
    {Op::PenSize, "lapizgrosor", Cat::Movimiento, "Grosor del lápiz: {0}", "En unidades del mundo 2D.", "6", "", "", "", 0},
    {Op::PenColor, "lapizcolor", Cat::Movimiento, "Color del lápiz: rojo {0} verde {1} azul {2} (0 a 255)", "", "255", "80", "80", "", 0},
    {Op::PenClear, "lapizborrar", Cat::Movimiento, "Borrar todo lo dibujado con lápiz", "", "", "", "", "", 0},
    {Op::Jumpscare, "susto", Cat::Forge3D, "¡Susto! Sonido {t}", "Sacude la pantalla, la pone roja un instante y suena el sonido que elijas. Ideal para juegos de terror.", "", "", "", "", 0},
    {Op::Blackout, "apagon", Cat::Forge3D, "Apagón: todo se oscurece durante {0} segundos", "La luz del mundo parpadea y se apaga; solo queda tu linterna. Después vuelve a la normalidad.", "5", "", "", "", 0},
    {Op::SetFear, "miedo", Cat::Forge3D, "Nivel de miedo del jugador: {0} (0 a 100)", "Oscurece los bordes de la pantalla con un latido: más miedo = más fuerte y rápido. 0 lo quita.", "50", "", "", "", 0},
    {Op::SetCheckpoint, "puntocontrol", Cat::Forge3D, "Guardar punto de control aquí (el jugador reaparece en este lugar)", "Desde ahora «Mandar al jugador al punto de inicio» lo regresa a este lugar, no al inicio.", "", "", "", "", 0},
    {Op::Broadcast, "difundir", Cat::Control, "Difundir mensaje {t}", "Envía un determinado mensaje a todos los objetos.", "mensaje1", "", "", "", 0},
    {Op::Forever, "parasiempre", Cat::Control, "Para siempre", "Ejecuta indefinidamente las instrucciones colocadas dentro del bloque.", "", "", "", "", 1},
    {Op::Repeat, "repetir", Cat::Control, "Repetir {0} veces", "Ejecuta un número específico de veces las instrucciones definidas dentro del bloque.", "", "10", "", "", 1},
    {Op::While, "mientras", Cat::Control, "Mientras {0} sea verdadero", "Repite las instrucciones de adentro mientras la condición sea verdadera. Si deja de serlo, sigue después del bloque.", "", "1 = 1", "", "", 1},
    {Op::RepeatUntil, "repetirhasta", Cat::Control, "Repetir hasta que {0} sea verdadero", "Repite las instrucciones de adentro hasta que la condición sea verdadera.", "", "1 = 2", "", "", 1},
    {Op::SetTarget, "fijarobjetivo", Cat::Forge3D, "Fijar objetivo: {t}", "3D: la mira se queda apuntando automáticamente a ese objetivo (el enemigo o monstruo más cercano, o el objeto que elijas).", "Enemigo más cercano", "", "", "", 0},
    {Op::KeepOnScreen, "nosalirpantalla", Cat::Movimiento, "No salir de la pantalla por: {t}", "2D: este objeto no puede salirse por los lados de la pantalla que elijas (los 4, o solo algunos: arriba, abajo, izquierda, derecha).", "Todos los lados", "", "", "", 0},
    {Op::PushedBy, "empujadopor", Cat::Movimiento, "Cuando {t} choque con este objeto, este objeto es empujado", "Regla permanente: si el objeto elegido choca con este, este objeto se aparta (lo empuja). Funciona en 2D y 3D; ponlo al inicio.", "", "", "", "", 0},
    {Op::PushOther, "empujaaotro", Cat::Movimiento, "Cuando {t} choque con este objeto, el otro objeto es empujado", "Regla permanente: si el objeto elegido choca con este, el objeto elegido sale empujado. Ponlo al inicio.", "", "", "", "", 0},
    {Op::AutoWander, "deambular", Cat::Forge3D, "Deambular solo por el mapa (1 sí, 0 no): {0}  radio: {1} m", "Activa o desactiva que este objeto (NPC) camine solo por la zona. Solo se mueve cuando el jugador está cerca (rendimiento).", "", "1", "8", "", 0},
    {Op::AutoRoute, "seguirruta", Cat::Forge3D, "Seguir su ruta dibujada (1 sí, 0 no): {0} vueltas: {1} (0 = sin fin)", "Activa o detiene la ruta dibujada del objeto (2D y 3D). Vueltas: cuántas veces la repite; 0 = en bucle sin fin; vacío = lo configurado en el objeto.", "", "1", "", "", 0},
    {Op::CarMode, "modoauto", Cat::Forge3D, "Modo auto: el jugador puede conducirlo (1 sí, 0 no): {0}", "Si está activo, al acercarte sale el botón «Conducir».", "", "1", "", "", 0},
    {Op::EnterCar, "subirauto", Cat::Forge3D, "El jugador se sube a este auto", "Equivale a pulsar «Conducir».", "", "", "", "", 0},
    {Op::ExitCar, "bajarauto", Cat::Forge3D, "El jugador se baja del auto", "Equivale a pulsar «Bajar».", "", "", "", "", 0},
    {Op::PlayCine, "cinematica", Cat::Control, "Reproducir cinemática {t} y esperar a que termine", "Corre la cinemática que grabaste en el editor de cinemáticas: la cámara y los objetos se mueven solos.", "Cinemática 1", "", "", "", 0},
    {Op::PrevLook, "aparienciaanterior", Cat::Apariencia, "Apariencia anterior", "Cambia la apariencia del objeto por la anterior de su lista.", "", "", "", "", 0},
    {Op::SaveDevVar, "guardarendispositivo", Cat::Datos, "Guardar en el dispositivo la variable {t} con el valor {0}", "El valor se queda guardado en el dispositivo (global, aunque cierres el juego o cambies de escena) y vuelve a cargarse en esa variable al abrir el juego.", "", "0", "", "", 0},
    {Op::DelDevVar, "borrardedispositivo", Cat::Datos, "Borrar del dispositivo la variable {t}", "Borra el valor guardado en el dispositivo y deja la variable en 0.", "", "", "", "", 0},
    {Op::ReadDevVar, "leerdedispositivo", Cat::Datos, "Leer del dispositivo la variable {t} (la trae a esta escena)", "Trae el valor guardado en el dispositivo a la variable. Sirve para usar en cualquier escena lo que se guardó antes. Si nunca se guardó, no cambia nada.", "", "", "", "", 0},
    {Op::ShowText, "mostrartexto", Cat::Apariencia, "Mostrar texto {t}: {0} en X: {1} Y: {2}", "Pone un texto en pantalla (puede mezclar variables, por ejemplo 'Puntos: ' + puntos). El nombre {t} identifica el texto para ocultarlo o cambiarlo.", "", "'Hola'", "0", "0", 0},
    {Op::HideText, "ocultartexto", Cat::Apariencia, "Ocultar el texto {t}", "Quita de la pantalla el texto con ese nombre.", "", "", "", "", 0},
    {Op::StopCine, "pararcine", Cat::Control, "Parar la cinemática", "Termina la cinemática que esté sonando.", "", "", "", "", 0},
    {Op::SolidWall, "colision", Cat::Movimiento, "Colisión: este objeto actúa como pared o piso", "2D: cualquier objeto (imagen, forma...) se vuelve sólido y quieto: los demás chocan con él como con una pared o un piso.", "", "", "", "", 0},
    {Op::KeepAllOnScreen, "nadiesale", Cat::Movimiento, "Ninguno sale de la pantalla, excepto: {t}", "2D: ningún objeto puede salirse de la pantalla, menos el que elijas.", "(ninguno)", "", "", "", 0},
    {Op::AllowLeaveScreen, "permitirsalir", Cat::Movimiento, "Permitir salir de la pantalla: {t}", "2D: deja de limitar al objeto elegido (o a todos).", "Este objeto", "", "", "", 0},
    {Op::TiltCamRight, "inclinarder", Cat::Apariencia, "Inclinar la cámara a la derecha {f0} grados", "3D: la cámara se inclina (se acomoda suave).", "", "15", "", "", 0},
    {Op::TiltCamLeft, "inclinarizq", Cat::Apariencia, "Inclinar la cámara a la izquierda {f0} grados", "3D: la cámara se inclina (se acomoda suave).", "", "15", "", "", 0},
    {Op::LevelCam, "enderezarcam", Cat::Apariencia, "Enderezar la cámara", "3D: la cámara vuelve a quedar derecha.", "", "", "", "", 0},
    {Op::FlashOn, "linternaon", Cat::Apariencia, "Encender la linterna", "3D: enciende la linterna del jugador.", "", "", "", "", 0},
    {Op::FlashOff, "linternaoff", Cat::Apariencia, "Apagar la linterna", "3D: apaga la linterna del jugador.", "", "", "", "", 0},
    {Op::FlashToggle, "linternaalt", Cat::Apariencia, "Alternar la linterna", "3D: la enciende si está apagada y viceversa.", "", "", "", "", 0},
    {Op::EnemiesFightAll, "todosseatacan", Cat::Forge3D, "Todos los enemigos se atacan entre sí e incluso a ti", "Cada enemigo ataca al más cercano: otros enemigos o a ti. Funciona con enemigos y monstruos de la escena.", "", "", "", "", 0},
    {Op::EnemiesFightEachOther, "seatacanmenostu", Cat::Forge3D, "Todos los enemigos se atacan entre sí, menos a ti", "Los enemigos pelean unos contra otros y te ignoran.", "", "", "", "", 0},
    {Op::EnemiesAttackYou, "todostateacan", Cat::Forge3D, "Todos los enemigos te atacan", "Vuelve al comportamiento normal: todos los enemigos van contra ti.", "", "", "", "", 0},
    {Op::PhysImpulse, "impulso", Cat::Movimiento, "Dar un empujón X: {0} Y: {1} Z: {2}", "Le da un empujón instantáneo al objeto físico (suma a su velocidad). Ejemplo: un salto fuerte, un golpe de lado.", "", "0", "8", "0", 0},
    {Op::PhysBlast, "explosionfuerza", Cat::Movimiento, "Explosión de fuerza: radio {0} potencia {1}", "Empuja lejos a todos los objetos físicos cercanos, más fuerte cuanto más cerca están. Los objetos más pesados se mueven menos.", "", "5", "10", "", 0},
    {Op::SetDrag, "resistenciaaire", Cat::Movimiento, "Resistencia del aire en {0} %", "Frena poco a poco al objeto físico mientras se mueve (0 = nada, 100 = mucha).", "", "10", "", "", 0},
    {Op::SetGravScale, "gravedadobjeto", Cat::Movimiento, "Gravedad de este objeto en {0} %", "Cuánto le afecta la gravedad al objeto físico: 0 flota, 100 normal, 200 cae el doble de rápido.", "", "100", "", "", 0},
    {Op::SetPushable, "empujable", Cat::Movimiento, "Se puede empujar (1 sí, 0 no): {0}", "Si vale 1, el jugador y las balas pueden empujar este objeto físico.", "", "1", "", "", 0},
    {Op::SetPlayerYaw, "mirarangulo", Cat::Forge3D, "Hacer que el jugador mire hacia {0} grados", "3D: gira la cámara del jugador (0 = hacia el frente del mapa, 90 = a la derecha, 180 = atrás, 270 = a la izquierda).", "", "0", "", "", 0},
    {Op::NetAuto, "multijugador", Cat::Multijugador, "Activar multijugador local (automático)", "Un solo bloque: busca otros jugadores con este mismo juego en tu Wi-Fi o punto de acceso (sin internet). Se ven entre sí solos, y tienes las variables jugadores (cuántos hay) y soyhost (1 si eres el anfitrión).", "", "", "", "", 0},
    {Op::NetHost, "crearpartidalocal", Cat::Multijugador, "Crear partida local llamada {t}", "Crea una sala con ese nombre. Los demás se unen con «Unirse a la partida» y el mismo nombre. Funciona con Wi-Fi o con el hotspot de un teléfono, sin internet.", "sala1", "", "", "", 0},
    {Op::NetJoin, "unirsepartidalocal", Cat::Multijugador, "Unirse a la partida local {t}", "Entra a la sala con ese nombre (la misma que escribió el anfitrión).", "sala1", "", "", "", 0},
    {Op::NetSend, "enviarmensajered", Cat::Multijugador, "Enviar el mensaje {t} a todos los jugadores", "Hace que en los demás dispositivos se ejecute «Cuando reciba el mensaje …» con ese mismo nombre.", "mensaje1", "", "", "", 0},
    {Op::NetShare, "compartirvariable", Cat::Multijugador, "Compartir la variable {t} con todos", "Cada vez que esta variable cambie aquí, también cambia en los demás dispositivos (puntos, vidas, quién ganó…).", "puntos", "", "", "", 0},
    {Op::NetStop, "salirpartida", Cat::Multijugador, "Salir de la partida local", "Deja de buscar y de enviar datos por la red.", "", "", "", "", 0},
    {Op::FreezeWorld, "congelartodo", Cat::Control, "Congelar todo menos al jugador", "Los enemigos, objetos, proyectiles y partículas se detienen. Siguen funcionando los guiones de toque y mensajes.", "", "", "", "", 0},
    {Op::UnfreezeWorld, "descongelartodo", Cat::Control, "Descongelar todo", "Vuelve a moverse todo lo demás.", "", "", "", "", 0},
    {Op::FreezePlayer, "congelarjugador", Cat::Control, "Congelar al jugador (todo lo demás se mueve)", "El jugador no puede moverse, mirar, saltar ni disparar.", "", "", "", "", 0},
    {Op::UnfreezePlayer, "descongelarjugador", Cat::Control, "Descongelar al jugador", "El jugador vuelve a controlarse.", "", "", "", "", 0},
    {Op::ClearTarget, "quitarobjetivo", Cat::Forge3D, "Quitar objetivo", "3D: la mira vuelve a ser libre y se controla con el dedo.", "", "", "", "", 0},
    {Op::PlayVideo, "reproducirvideo", Cat::Apariencia, "Reproducir video {t}", "Reproduce un video en este objeto (se importa en Archivos → Videos). Si lo dejas vacío usa el video del objeto.", "", "", "", "", 0},
    {Op::PauseVideo, "pausarvideo", Cat::Apariencia, "Pausar video", "Detiene el video donde va.", "", "", "", "", 0},
    {Op::ResumeVideo, "reanudarvideo", Cat::Apariencia, "Volver a reproducir video (reanudar)", "Continúa el video pausado.", "", "", "", "", 0},
    {Op::LoopVideo, "ciclovideo", Cat::Apariencia, "Reproducir video en ciclo (siempre)", "El video se repite sin parar.", "", "", "", "", 0},
    {Op::PlayVideoTimes, "videoveces", Cat::Apariencia, "Reproducir video {0} veces", "Reproduce el video esa cantidad de veces y se detiene.", "", "2", "", "", 0},
    {Op::RestartVideo, "reiniciarvideo", Cat::Apariencia, "Reiniciar reproducción del video", "Vuelve al inicio y lo reproduce otra vez.", "", "", "", "", 0},
    {Op::StopVideo, "detenervideo", Cat::Apariencia, "Detener video", "Lo detiene y lo regresa al inicio.", "", "", "", "", 0},
    {Op::LoopEnd, "finbucle", Cat::Control, "Fin del bucle", "Define el fin del bucle (PARA SIEMPRE o REPETIR).", "", "", "", "", -1},
    {Op::Note, "nota", Cat::Control, "Nota {t}", "Con este bloque se pueden poner comentarios en el código sin cambiar la ejecución del programa.", "escribe aquí", "", "", "", 0},
    {Op::If, "si", Cat::Control, "Si {0} es verdadero entonces", "Si la condición es verdadera, ejecuta los bloques de adentro. Si es falsa, no hace nada y sigue.", "", "1 = 1", "", "", 1},
    {Op::Else, "contrario", Cat::Control, "De lo contrario", "Define el área de instrucciones alternativas cuando la condición del bloque \"Si ... verdadero, sino\" es falsa.", "", "", "", "", 3},
    {Op::EndIf, "finsi", Cat::Control, "Fin del si", "Siempre va con la condición si.", "", "", "", "", -1},
    {Op::StartScene, "iniciarescena", Cat::Control, "Iniciar escena {t}", "Cambia a otra escena del proyecto.", "", "", "", "", 0},
    // ---- Movimiento
    {Op::PlaceAt, "coloque", Cat::Movimiento, "Coloque en X: {0} Y: {1}", "Coloca el objeto en las coordenadas definidas en X e Y.", "", "0", "0", "", 0},
    {Op::SetX, "establecax", Cat::Movimiento, "Establezca X en: {0}", "Establece la coordenada X del objeto.", "", "0", "", "", 0},
    {Op::SetY, "establecay", Cat::Movimiento, "Establezca Y en: {0}", "Establece la coordenada Y del objeto.", "", "0", "", "", 0},
    {Op::ChangeX, "incrementax", Cat::Movimiento, "Incrementar X en: {0}", "Al valor actual de la coordenada X se suma el incremento especificado si es positivo o se resta si es negativo.", "", "10", "", "", 0},
    {Op::ChangeY, "incrementay", Cat::Movimiento, "Incrementar Y en: {0}", "Al valor actual de la coordenada Y se suma el incremento especificado si es positivo o se resta si es negativo.", "", "10", "", "", 0},
    {Op::BounceEdge, "rebotaborde", Cat::Movimiento, "Si en el borde, rebota", "Si el objeto toca el borde de la pantalla rebota contra él.", "", "", "", "", 0},
    {Op::Move, "mover", Cat::Movimiento, "Mover {0} pasos", "Mueve el objeto un número determinado de pasos (por ejemplo 10).", "", "10", "", "", 0},
    {Op::TurnLeft, "girarizq", Cat::Movimiento, "Girar a la izquierda: {0} ° (grados)", "Gira el objeto hacia la izquierda (en sentido opuesto a las agujas del reloj) un número específico de grados.", "", "15", "", "", 0},
    {Op::TurnRight, "girarder", Cat::Movimiento, "Girar a la derecha: {0} ° (grados)", "Gira el objeto hacia la derecha (en el sentido de las agujas del reloj) un número específico de grados.", "", "15", "", "", 0},
    {Op::PointDir, "apuntardir", Cat::Movimiento, "Apuntar en la dirección: {0} ° (grados)", "Establece la dirección del objeto (en grados).", "", "90", "", "", 0},
    {Op::PointTowards, "apuntarhacia", Cat::Movimiento, "Apuntar hacia {t}", "Apunta el objeto actual en la dirección de otro objeto.", "", "", "", "", 0},
    {Op::GlideTo, "deslizar", Cat::Movimiento, "Deslizar {0} segundos a X: {1} Y: {2}", "Desliza el objeto un número determinado de segundos hasta las coordenadas especificadas X e Y.", "", "1", "100", "100", 0},
    {Op::GoBack, "llevaratras", Cat::Movimiento, "Llevar atrás {0} capas", "Mueve el objeto un número específico de capas hacia el fondo (el objeto va pasando detrás de otros).", "", "1", "", "", 0},
    {Op::GoFront, "alfrente", Cat::Movimiento, "Ir al frente", "Mueve el objeto delante de todos los demás, a la capa más alta.", "", "", "", "", 0},
    {Op::Vibrate, "vibrar", Cat::Movimiento, "Vibrar por {0} segundos", "Usa la función de vibración del dispositivo por un dado número de segundos.", "", "1", "", "", 0},
    {Op::PhysDynamic, "fisicadinamica", Cat::Movimiento, "Establece el tipo de movimiento como: Rebotar con la gravedad", "Define un objeto físico que está afectado por la gravedad, colisiones, etc. Por ejemplo una pelota de ping-pong que choca y rebota con otros objetos que responden a la fuerza de la gravedad.", "", "", "", "", 0},
    {Op::PhysStatic, "fisicaestatica", Cat::Movimiento, "Establece el tipo de movimiento como: solo otros rebotan", "Define un objeto físico que no está afectado por la gravedad - por ejemplo un muro o el suelo - pero que permite a los objetos físicos chocar y rebotar contra él.", "", "", "", "", 0},
    {Op::PhysNone, "fisicanada", Cat::Movimiento, "Establece el tipo de movimiento como: No rebotar", "Define un objeto no físico que no está afectado por la gravedad y que no interacciona con los otros objetos físicos – por ejemplo el fondo - que no colisiona con otros objetos físicos.", "", "", "", "", 0},
    {Op::SetForce, "fuerza", Cat::Movimiento, "Establecer la intensidad de la fuerza en X: {0} Y: {1} pasos/segundos", "Establece la intensidad de la fuerza a lo largo de las componentes en los ejes X e Y. La trayectoria del objeto está determinada por la fuerza y la gravedad si el objeto es un objeto físico.", "", "0", "100", "", 0},
    {Op::SpinLeft, "giroizq", Cat::Movimiento, "Girar a la izquierda {0} grados/segundo", "Establece la velocidad de rotación hacia la izquierda (en sentido opuesto a las agujas del reloj) de un objeto en grados por segundo.", "", "15", "", "", 0},
    {Op::SpinRight, "giroder", Cat::Movimiento, "Girar a la derecha {0} grados/segundo", "Establece la velocidad de rotación hacia la derecha (en sentido de las agujas del reloj) de un objeto en grados por segundo.", "", "15", "", "", 0},
    {Op::SetGravity, "gravedad", Cat::Movimiento, "Establecer la gravedad para todos los objetos en X: {0} Y: {1} pasos/segundos²", "Cambia la dirección del campo gravitacional en las componentes X e Y en pasos por segundos al cuadrado. La aproximación del campo gravitacional de la tierra es X:0 Y:-10.", "", "0", "-10", "", 0},
    {Op::SetMass, "masa", Cat::Movimiento, "Establecer la masa a {0} kilogramos", "Determina la masa de un objeto. Los valores admitidos son 0 y superiores.", "", "1", "", "", 0},
    {Op::SetBounce, "rebote", Cat::Movimiento, "Ajustar el factor de rebote al {0} %", "Determina cuánta energía/velocidad de un objeto se pierde (o gana) tras colisionar con otro objeto físico. Si es 0 no rebota en absoluto.", "", "80", "", "", 0},
    {Op::SetFriction, "friccion", Cat::Movimiento, "Ajustar la fricción al {0} %", "Determina la rapidez/facilidad con la que un objeto puede deslizarse a lo largo de otro. Cuanto más alto, menos se deslizará.", "", "20", "", "", 0},
    {Op::PlaceAt3, "coloque3d", Cat::Forge3D, "Coloque en X: {0} Y: {1} Z: {2}", "3D: coloca el objeto en el espacio (Y es la altura).", "", "0", "0", "0", 0},
    {Op::SetZ, "establecaz", Cat::Forge3D, "Establezca Z en: {0}", "3D: establece la coordenada Z (profundidad).", "", "0", "", "", 0},
    {Op::ChangeZ, "incrementaz", Cat::Forge3D, "Incrementar Z en: {0}", "3D: suma al valor actual de Z.", "", "1", "", "", 0},
    // ---- Sonido
    {Op::StartSound, "iniciarsonido", Cat::Sonido, "Iniciar sonido {t}", "Empezar a reproducir el sonido especificado.", "", "", "", "", 0},
    {Op::StopSounds, "pararsonidos", Cat::Sonido, "Parar todos los sonidos", "Parar todos los sonidos que se están reproduciendo.", "", "", "", "", 0},
    {Op::SetVolume, "volumen", Cat::Sonido, "Ajustar el volumen a {0} %", "Ajustar el volumen de un sonido al porcentaje especificado.", "", "60", "", "", 0},
    {Op::ChangeVolume, "incvolumen", Cat::Sonido, "Incrementar el volumen en {0}", "Al valor actual del volumen del sonido se le incrementa el valor especificado.", "", "-10", "", "", 0},
    {Op::Speak, "hablar", Cat::Sonido, "Hablar {0} con voz {t}", "Dice el texto en voz alta. Puedes escribir frases largas: cada espacio es una pausa al hablar. Lo que escribes se dice tal cual; para decir el valor de una variable insértala desde Datos.", "Normal", "Hola, bienvenido al juego", "", "", 0},
    {Op::SetSolid, "establecesolido", Cat::Forge3D, "Establecer colisión a {0} (1 = choca, 0 = atraviesa)", "Activa o quita la colisión del objeto (por ejemplo, una puerta que se abre).", "", "0", "", "", 0},
    {Op::TeleportPlayer, "teletransportar", Cat::Forge3D, "Teletransportar al jugador a X: {0} Y: {1} Z: {2}", "3D: mueve al jugador a otra posición (Y es la altura).", "", "0", "0.05", "0", 0},
    {Op::MoveToPlayer, "moverhaciajugador", Cat::Forge3D, "Mover {0} pasos hacia el jugador", "3D: acerca el objeto al jugador (enemigos). Los pasos son metros por vuelta de bucle.", "", "0.05", "", "", 0},
    {Op::Music, "musica", Cat::Forge3D, "Música en bucle {t}", "Reproduce una música en bucle (pausa la anterior).", "", "", "", "", 0},
    {Op::PlaySoundWait, "sonidoyespera", Cat::Sonido, "Reproducir sonido o música {t} y esperar a que termine", "Reproduce el sonido una sola vez y este guion no sigue con el siguiente bloque hasta que termina.", "", "", "", "", 0},
    {Op::SetCamera, "camara", Cat::Forge3D, "Cambiar vista de cámara a {t}", "3D: cambia entre primera persona, cámara al hombro y cámara fija en tercera persona (la que colocaste en la escena).", "Primera persona", "", "", "", 0},
    {Op::WaitUntil, "esperahasta", Cat::Control, "Esperar hasta que {0} sea verdadero", "El guion se detiene aquí hasta que la condición sea verdadera.", "", "1 = 1", "", "", 0},
    {Op::StopScript, "detenerguion", Cat::Control, "Detener este guion", "Termina este guion en este punto (los demás siguen).", "", "", "", "", 0},
    {Op::ShootPlayer, "dispararjugador", Cat::Forge3D, "Disparar un proyectil al jugador", "3D: este objeto lanza su proyectil hacia el jugador (usa el proyectil que configuraste para el enemigo).", "", "", "", "", 0},
    {Op::HurtPlayer, "danojugador", Cat::Forge3D, "Quitar {0} de vida al jugador", "3D: resta a la variable \"vida\" del jugador.", "", "1", "", "", 0},
    {Op::SetSpeed, "velocidadjugador", Cat::Forge3D, "Velocidad del jugador {0} metros/segundo", "3D: cambia qué tan rápido camina el jugador.", "", "4.5", "", "", 0},
    {Op::SetJump, "saltojugador", Cat::Forge3D, "Fuerza de salto del jugador {0}", "3D: cambia qué tan alto salta el jugador (7 es normal).", "", "7", "", "", 0},
    {Op::PlayAnim, "animacion", Cat::Apariencia, "Reproducir animación {t}", "Reproduce una acción de la lista de animaciones (quieto, recargar, morir, acción personalizada...). Úsalo con Difundir mensaje.", "caminar", "", "", "", 0},
    {Op::MoveRandom, "moveralazar", Cat::Movimiento, "Mover al azar hasta {0} pasos", "Mueve el objeto una distancia al azar (hasta el número indicado) en cualquier dirección.", "", "50", "", "", 0},
    {Op::CreateClone, "crearclon", Cat::Control, "Crear un clon de mí", "Crea una copia de este objeto (con sus mismos bloques). El clon empieza con \"Cuando empiece como clon\".", "", "", "", "", 0},
    {Op::DeleteClone, "borrarclon", Cat::Control, "Borrar este clon", "Si este objeto es un clon, desaparece. El objeto original no se borra.", "", "", "", "", 0},
    {Op::WhenCloneStart, "cuandoclon", Cat::Eventos, "Cuando empiece como clon", "Se ejecuta en cada clon recién creado (no en el original).", "", "", "", "", H},
    {Op::BreakApart, "romper", Cat::Apariencia, "Romper en {0} pedazos y desaparecer", "El objeto se rompe en pedazos con su color y textura que caen, y después desaparece.", "", "8", "", "", 0},
    {Op::PlayClip, "reproducirclip", Cat::Apariencia, "Reproducir animación de esqueleto {t}", "Hace que el modelo de este objeto se mueva con una animación creada en el editor de animación (o importada).", "", "", "", "", 0},
    {Op::StopClip, "detenerclip", Cat::Apariencia, "Detener animación de esqueleto", "El modelo vuelve a su postura de reposo.", "", "", "", "", 0},
    {Op::GoToPlayer, "iraljugador", Cat::Movimiento, "Ir al jugador en {0} segundos", "3D: lleva este objeto hasta donde está el jugador (0 = al instante). 2D: va al objeto llamado Jugador, o al último toque.", "", "0", "", "", 0},
    {Op::GoToObject, "iraobjeto", Cat::Movimiento, "Ir a la posición de {t}", "Coloca este objeto en la misma posición que otro objeto.", "", "", "", "", 0},
    {Op::MoveTowards, "moverhacia", Cat::Movimiento, "Mover {0} pasos hacia {t}", "Acerca este objeto al objeto elegido (perseguir). En 2D los pasos son píxeles, en 3D metros.", "", "5", "", "", 0},
    {Op::ShakeScreen, "sacudir", Cat::Apariencia, "Sacudir la pantalla {0} segundos", "Hace temblar la cámara (explosiones, golpes).", "", "0.5", "", "", 0},
    {Op::StopAll, "detenertodo", Cat::Control, "Detener todos los guiones", "Termina todos los guiones de todos los objetos.", "", "", "", "", 0},
    {Op::SetFx, "particulas", Cat::Apariencia, "{t} partículas de este objeto", "Enciende o apaga las partículas (humo, fuego...) que lanza este objeto. Se configuran en sus Propiedades.", "encender", "", "", "", 0},
    {Op::SetWidth, "ponerancho", Cat::Apariencia, "Poner el ANCHO en {0} %", "Cambia solo lo ancho del objeto (100 = tamaño original). Útil para barras de vida que se encogen.", "", "60", "", "", 0},
    {Op::SetHeight, "poneralto", Cat::Apariencia, "Poner el ALTO en {0} %", "Cambia solo lo alto del objeto (100 = tamaño original).", "", "60", "", "", 0},
    {Op::ChangeWidth, "cambiarancho", Cat::Apariencia, "Hacer más ANCHO en {0} %", "Suma (o resta, si es negativo) al ancho del objeto.", "", "10", "", "", 0},
    {Op::ChangeHeight, "cambiaralto", Cat::Apariencia, "Hacer más ALTO en {0} %", "Suma (o resta, si es negativo) al alto del objeto.", "", "10", "", "", 0},
    {Op::SetHue, "ponertono", Cat::Apariencia, "Poner el tono de color en {0} (0 a 200)", "Cambia el color del dibujo: va dando la vuelta por todos los colores del 0 al 200.", "", "50", "", "", 0},
    {Op::SetFxColor, "colorparticulas", Cat::Apariencia, "Color de las partículas: rojo {0} verde {1} azul {2} (0 a 255)", "Cambia el color del humo, fuego o chispas de este objeto.", "", "255", "128", "0", 0},
    {Op::StopOthers, "detenerotros", Cat::Control, "Detener los otros guiones de este objeto", "Para todos los demás guiones de este objeto; este sigue.", "", "", "", "", 0},
    {Op::RepeatEvery, "repetirpausa", Cat::Control, "Repetir {0} veces, con una pausa de {1} s entre cada una", "Repite lo de adentro y espera un poquito entre vuelta y vuelta.", "", "5", "1", "", 1},
    {Op::ForRange, "paranumeros", Cat::Control, "Contar con la variable {t} desde {0} hasta {1}", "Repite lo de adentro; la variable va valiendo cada número, uno por vuelta (si empiezas más alto que el final, cuenta hacia atrás).", "contador", "1", "10", "", 1},
    {Op::ForEach, "paracadaelemento", Cat::Control, "Para cada cosa de la lista {0}, guardarla en la variable {t}", "Repite lo de adentro una vez por cada cosa de la lista; la variable guarda la cosa de esa vuelta.", "cosa", "'mi lista'", "", "", 1},
    {Op::ListAdd, "listaagregar", Cat::Datos, "Agregar {0} al final de la lista {t}", "Pone un dato nuevo al final de la lista. La lista se crea sola.", "mi lista", "1", "", "", 0},
    {Op::ListRemove, "listaquitar", Cat::Datos, "Quitar la cosa número {0} de la lista {t}", "Saca de la lista la cosa que está en esa posición (la primera es la 1).", "mi lista", "1", "", "", 0},
    {Op::ListClear, "listavaciar", Cat::Datos, "Vaciar la lista {t}", "Borra todo lo que hay dentro de la lista.", "mi lista", "", "", "", 0},
    {Op::ListInsert, "listainsertar", Cat::Datos, "Meter {0} en la lista {t} en la posición {1}", "Inserta un dato en medio de la lista.", "mi lista", "1", "1", "", 0},
    {Op::ListReplace, "listacambiar", Cat::Datos, "Cambiar la cosa número {0} de la lista {t} por {1}", "Reemplaza un dato de la lista por otro.", "mi lista", "1", "1", "", 0},
    {Op::PlayRoute, "reproducirruta", Cat::Movimiento, "Reproducir la ruta dibujada, {0} veces (1 = una sola vez, 0 = sin parar)", "El objeto sigue el camino que dibujaste con el dedo. Con 1 lo hace una vez y se detiene; con otro número lo repite; con 0 no para nunca.", "", "1", "", "", 0},
    {Op::CamBack, "camaraatras", Cat::Apariencia, "Poner la cámara de ATRÁS como fondo (como realidad aumentada)", "El fondo del juego se ve con la cámara del teléfono, la de atrás (la que apunta al mundo). No abre la app de cámara. Pide permiso la primera vez. En 2D.", "", "", "", "", 0},
    {Op::CamFront, "camaraadelante", Cat::Apariencia, "Poner la cámara de ADELANTE como fondo (selfie)", "El fondo del juego se ve con la cámara de adelante (la de selfies, como espejo). No abre la app de cámara. En 2D.", "", "", "", "", 0},
    {Op::CamOff, "quitarcamara", Cat::Apariencia, "Quitar la cámara del fondo", "Apaga la cámara y el fondo vuelve a ser el de antes.", "", "", "", "", 0},
    {Op::TiltMove, "moverinclinando", Cat::Movimiento, "Mover este objeto al inclinar el teléfono, velocidad {0}", "Cuando inclinas el teléfono el objeto se desliza hacia ese lado (usa el giroscopio/acelerómetro). Con 0 deja de moverse. En PC no hace nada.", "", "300", "", "", 0},
    {Op::GlideSize, "tamanosuave", Cat::Apariencia, "Hacerse de tamaño {0} % poco a poco en {1} segundos", "El objeto crece o se encoge despacito hasta el tamaño que digas (100 = normal) y luego sigue con el siguiente bloque.", "", "150", "1", "", 0},
    {Op::GlideTransp, "transpsuave", Cat::Apariencia, "Volverse transparente {0} % poco a poco en {1} segundos", "El objeto se desvanece (o aparece) despacito. 0 = se ve todo, 100 = invisible.", "", "100", "1", "", 0},
    {Op::GlideTurn, "girarsuave", Cat::Movimiento, "Girar {0} grados poco a poco en {1} segundos", "El objeto da el giro despacito (en vez de dar el giro de golpe) y luego sigue con el siguiente bloque.", "", "90", "1", "", 0},
    {Op::RouteDelay, "esperarantesruta", Cat::Movimiento, "Esperar {0} segundos antes de empezar la ruta fija", "El objeto se queda quieto ese tiempo y después empieza (o sigue) su ruta fija. También se puede poner en Ajustes del objeto → ruta.", "", "3", "", "", 0},
    {Op::RouteRestart, "reiniciarruta", Cat::Movimiento, "Reiniciar la ruta fija de este objeto (vuelve al primer punto)", "El objeto regresa al inicio de su ruta fija y la empieza otra vez (espera el tiempo de inicio si lo pusiste).", "", "", "", "", 0},
    {Op::RoutePause, "pausarruta", Cat::Movimiento, "Pausar la ruta fija de este objeto", "El objeto se detiene donde está. Con «Continuar la ruta fija» sigue desde ahí.", "", "", "", "", 0},
    {Op::RouteResume, "continuarruta", Cat::Movimiento, "Continuar la ruta fija de este objeto", "Quita la pausa y el objeto sigue su ruta fija desde donde se quedó.", "", "", "", "", 0},
    {Op::Ragdoll, "ragdoll", Cat::Forge3D, "Convertir este objeto en ragdoll (se cae a pedazos)", "Hay que crear antes el ragdoll del modelo (en el objeto: «Crear ragdoll»). El objeto se desarma en cabeza, cuerpo, brazos y piernas que caen y ruedan por el suelo.", "", "", "", "", 0},
    {Op::AimOn, "apuntar", Cat::Forge3D, "Apuntar con la mira", "El jugador levanta el arma y apunta con la mira (la imagen se acerca y el arma pasa al centro). Los números se cambian en Ajustes del jugador → Apuntar.", "", "", "", "", 0},
    {Op::AimOff, "dejarapuntar", Cat::Forge3D, "Dejar de apuntar", "Baja el arma y vuelve a la vista normal.", "", "", "", "", 0},
    {Op::AimToggle, "apuntaralternar", Cat::Forge3D, "Apuntar / dejar de apuntar (cambia cada vez)", "Si no apuntaba, empieza a apuntar. Si apuntaba, deja de apuntar. Ideal para un botón de pantalla.", "", "", "", "", 0},
    {Op::SetFov, "campovision", Cat::Forge3D, "Campo de visión (qué tan ancho ves): {0} grados", "Cambia la vista del jugador. 70 es normal, más grande ve más ancho (como ojo de pez), más chico acerca.", "", "70", "", "", 0},
    {Op::Cam2Zoom, "camzoom", Cat::Apariencia, "Acercar o alejar la cámara: {0} % (100 = normal, 200 = más cerca)", "Solo en juegos 2D. Con un número grande ves todo más cerca; con uno chico ves más lejos.", "", "150", "", "", 0},
    {Op::Cam2Follow, "camseguir", Cat::Apariencia, "Que la cámara siga al objeto {t}", "Solo en juegos 2D. La pantalla se mueve junto con ese objeto.", "Jugador", "", "", "", 0},
    {Op::Cam2Center, "camcentrar", Cat::Apariencia, "Poner la cámara en X: {0} Y: {1}", "Solo en juegos 2D. La cámara se queda quieta mirando ese lugar.", "", "0", "0", "", 0},
        {Op::LockLook, "bloqueaaspecto", Cat::Apariencia, "Bloquear aspecto (seleccionar): dejar con {t}", "Pone al objeto la textura que elijas (de su lista «Texturas para bloquear», en la pestaña de apariencias) y la deja fija: ya no puede cambiar de apariencia, tamaño, color ni transparencia. Se detienen sus «por siempre» de apariencia y cualquier bloque de apariencia que intente activarse queda bloqueado. Para volver a la normalidad usa «Desbloquear cambio de apariencia».", "", "", "", "", 0},
        {Op::UnlockLook, "desbloqueaaspecto", Cat::Apariencia, "Desbloquear cambio de apariencia", "Vuelve a permitir que este objeto cambie su aspecto (deshace «Bloquear aspecto»). Se ejecuta el evento «Cuando se desbloquee el cambio de apariencia».", "", "", "", "", 0},
        {Op::LockLookSw, "bloquearcambioapariencia", Cat::Apariencia, "Bloquear SOLO cambiar de apariencia (seleccionar): dejar con {t}", "Pone la textura que elijas (de «Texturas para bloquear») y bloquea únicamente «Próxima apariencia», «Apariencia anterior» y «Cambiar apariencia a». El tamaño, color, etc. siguen funcionando. Detiene los «por siempre» que usan esos bloques; después puedes seguirlos con «Continuar ciclos de apariencia».", "", "", "", "", 0},
        {Op::UnlockLookSw, "desbloquearcambioapariencia", Cat::Apariencia, "Desbloquear SOLO cambiar de apariencia", "Deshace «Bloquear SOLO cambiar de apariencia» en este objeto.", "", "", "", "", 0},
        {Op::ResumeLook, "continuarciclosapariencia", Cat::Apariencia, "Continuar los ciclos de apariencia que se bloquearon", "Vuelve a iniciar los «por siempre» de apariencia de este objeto que se detuvieron mientras estaba bloqueado. Úsalo después de desbloquear (por ejemplo dentro de «Cuando se desbloquee el cambio de apariencia»).", "", "", "", "", 0},
    {Op::Cam2Auto, "camnormal", Cat::Apariencia, "Cámara normal (como al empezar)", "Solo en juegos 2D. Quita el zoom y deja que la cámara vuelva a funcionar sola.", "", "", "", "", 0},
    {Op::GlideEnemy, "deslizarenemigo", Cat::Movimiento, "Deslizar hacia el enemigo más cercano en {0} s", "Se desliza hasta el enemigo más cercano (de cualquier tipo). Úsalo en balas o ataques que persiguen.", "1", "1", "", "", 0},
    {Op::CancelDamage, "cancelardano", Cat::Control, "Cancelar daño por {0} s", "Este objeto (jugador o enemigo) no recibe daño durante ese tiempo.", "1", "1", "", "", 0},
    {Op::GoDir, "irhacia", Cat::Movimiento, "Ir en línea recta hacia {0} a velocidad {1}", "Mueve este objeto sin parar en línea recta (como una bala). Dirección: x, -x, y o -y. Se mueve solo hasta que lo borres.", "x", "400", "", "", 0},
    {Op::DespawnOffscreen, "desapsalir", Cat::Control, "Desaparecer al salir de la pantalla: {0}", "Si pones 1, este objeto en línea recta (bala) desaparece cuando sale de la vista. 0 = no desaparece. Por defecto es 1.", "1", "1", "", "", 0},
    {Op::DespawnAfter, "desaptiempo", Cat::Control, "Desaparecer después de {0} s", "Este objeto en línea recta (bala) desaparece pasado ese tiempo. 0 = nunca.", "3", "3", "", "", 0},
    {Op::Explode, "explosion", Cat::Apariencia, "Explosión aquí: tamaño {0}", "Hace explotar este objeto: efecto de explosión del proyecto (Proyecto > Explosión), empuje, sacudida y daño cercano.", "", "4", "", "", 0},
    {Op::BurstFx, "rafagapart", Cat::Apariencia, "Lanzar {0} partículas de golpe", "Suelta una ráfaga de partículas (explosión, chispas) con la configuración del objeto.", "", "30", "", "", 0},
    {Op::SetScreenFx, "efectopantalla", Cat::Forge3D, "Efecto de pantalla {t}", "Cambia el efecto de la capa de cámara: ninguno, VHS, cámara de video, visión nocturna o película vieja.", "VHS", "", "", "", 0},
    // ---- Apariencia
    {Op::NextLook, "proximaapariencia", Cat::Apariencia, "Próxima apariencia", "Cambia la apariencia del objeto con la siguiente apariencia. Puedes cambiar el orden de las apariencias de un objeto.", "", "", "", "", 0},
    {Op::SetSize, "tamano", Cat::Apariencia, "Ajustar el tamaño en {0} %", "Establece el tamaño del objeto actual al valor especificado.", "", "100", "", "", 0},
    {Op::ChangeSize, "inctamano", Cat::Apariencia, "Incrementar el tamaño en {0} %", "Al tamaño actual del objeto se le incrementa el porcentaje especificado.", "", "10", "", "", 0},
    {Op::Show, "mostrar", Cat::Apariencia, "Mostrar", "Hacer el objeto visible en la pantalla.", "", "", "", "", 0},
    {Op::Hide, "ocultar", Cat::Apariencia, "Ocultar", "Hacer el objeto invisible.", "", "", "", "", 0},
    {Op::SetTransp, "transparencia", Cat::Apariencia, "Ajustar el nivel de transparencia en un {0} %", "Fijar el nivel de transparencia al valor especificado.", "", "50", "", "", 0},
    {Op::ChangeTransp, "inctransparencia", Cat::Apariencia, "Incrementar el nivel de transparencia en {0}", "Al valor actual de la transparencia del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::SetBright, "brillo", Cat::Apariencia, "Ajustar el nivel de brillo en un {0} %", "Fijar el nivel de brillo al valor especificado.", "", "50", "", "", 0},
    {Op::ChangeBright, "incbrillo", Cat::Apariencia, "Incrementar el nivel de brillo en {0}", "Al valor actual del brillo del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::ClearFx, "limpiarefectos", Cat::Apariencia, "Limpiar los efectos gráficos", "Borra cualquier efecto gráfico del objeto como el brillo y la transparencia.", "", "", "", "", 0},
    {Op::SetLook, "cambiarapariencia", Cat::Apariencia, "Cambiar apariencia a {t}", "Cambia el objeto con la apariencia especificada. Un objeto puede tener varias apariencias. Distintas apariencias de un mismo objeto se pueden usar para crear animaciones sencillas.", "", "", "", "", 0},
    {Op::Flash, "flash", Cat::Apariencia, "Encender el flash {0}", "Enciende el flash del dispositivo (1 = encender, 0 = apagar).", "", "1", "", "", 0},
    {Op::ChangeColor, "inccolor", Cat::Apariencia, "Incrementar el nivel de color en {0}", "Al valor actual del color del objeto se le incrementa el valor especificado.", "", "25", "", "", 0},
    {Op::Say, "decir", Cat::Forge3D, "Decir {0}", "Muestra un texto en pantalla unos segundos.", "", "Hola", "", "", 0},
    {Op::Destroy, "eliminar", Cat::Forge3D, "Eliminar este objeto", "Quita el objeto del juego (ya no se ve ni choca).", "", "", "", "", 0},
    // ---- Datos
    {Op::ToggleVar, "alternarvariable", Cat::Datos, "Alternar la variable {t} (0 y 1)", "Si vale 0 pasa a 1; si vale otra cosa pasa a 0. Sirve para interruptores.", "", "", "", "", 0},
    {Op::RandomVar, "variablealeatoria", Cat::Datos, "Poner la variable {t} en un número al azar entre {0} y {1}", "Número entero al azar (incluye los dos extremos).", "", "1", "10", "", 0},
    {Op::ClampVar, "limitarvariable", Cat::Datos, "Limitar la variable {t} entre {0} y {1}", "Si la variable se sale del rango, queda en el mínimo o en el máximo.", "", "0", "100", "", 0},
    {Op::SetColorRGB, "colorrgb", Cat::Apariencia, "Poner el color en rojo {0} verde {1} azul {2} (0 a 255)", "Cambia el color del objeto con valores de 0 a 255.", "", "255", "128", "0", 0},
    {Op::SetLayer, "capa", Cat::Apariencia, "Poner en la capa {0}", "2D: capa de dibujo; mayor número = más adelante.", "", "1", "", "", 0},
    {Op::SetSkyColor, "colorcielo", Cat::Apariencia, "Color del cielo: rojo {0} verde {1} azul {2} (0 a 255)", "Cambia el color del fondo/cielo de la escena actual.", "", "120", "170", "255", 0},
    {Op::MoveAway, "alejarse", Cat::Movimiento, "Alejarse {0} pasos de {t}", "Aleja este objeto del objeto elegido (huir). En 2D los pasos son píxeles, en 3D metros.", "", "5", "", "", 0},
    {Op::SnapGrid, "cuadricula", Cat::Movimiento, "Pegar a la cuadrícula de {0}", "Redondea la posición del objeto a múltiplos del tamaño indicado.", "", "1", "", "", 0},
    {Op::SetTimeScale, "velocidadtiempo", Cat::Control, "Velocidad del juego a {0} % (100 = normal)", "Cámara lenta (50) o rápida (200) para todo el juego.", "", "50", "", "", 0},
    {Op::RestartScene, "reiniciarescena", Cat::Control, "Reiniciar esta escena", "Vuelve a empezar la escena actual.", "", "", "", "", 0},
    {Op::WaitFrames, "esperarcuadros", Cat::Control, "Esperar {0} cuadros", "Pausa corta medida en cuadros (60 cuadros ≈ 1 segundo).", "", "10", "", "", 0},
    {Op::WhenLookUnlocked, "cuandodesbloqueeapariencia", Cat::Eventos, "Cuando se desbloquee el cambio de apariencia", "Se ejecuta en este objeto cuando se usa «Desbloquear cambio de apariencia» (o «Desbloquear SOLO cambiar de apariencia»). Ahí puedes poner «Continuar los ciclos de apariencia».", "", "", "", "", H},
    {Op::WhenSwipe, "cuandodeslice", Cat::Eventos, "Cuando se deslice un dedo {t}", "Se ejecuta al deslizar un dedo por la pantalla en esa dirección (arriba→abajo, abajo→arriba, izquierda→derecha o derecha→izquierda). Sirve para esquivar, cambiar de carril, hacer un ataque, etc.", "de izquierda a derecha", "", "", "", H},
    {Op::WhenScreenTap, "cuandopantalla", Cat::Eventos, "Cuando se pulse la pantalla", "Se ejecuta al tocar la pantalla (en cualquier parte). Tocar la pantalla NO salta ni dispara: eso solo lo hacen los botones; esto solo actúa si lo usas.", "", "", "", "", H},
    {Op::HealPlayer, "curarjugador", Cat::Forge3D, "Curar {0} de vida al jugador", "3D: suma a la variable \"vida\" (sin pasar del máximo).", "", "20", "", "", 0},
    {Op::RespawnPlayer, "reaparecerjugador", Cat::Forge3D, "Mandar al jugador al punto de inicio", "3D: vuelve a poner al jugador donde empieza la escena.", "", "", "", "", 0},
    {Op::SetVar, "variable", Cat::Datos, "Establezca una variable {t} en: {0}", "Fijar la variable a un valor concreto.", "", "0", "", "", 0},
    {Op::ChangeVar, "incvariable", Cat::Datos, "Incrementar la variable {t} en: {0}", "Al valor actual de la variable se le incrementa el valor especificado.", "", "1", "", "", 0},
    {Op::ShowVar, "mostrarvariable", Cat::Datos, "Mostrar la variable {t} en X: {0} Y: {1}", "Muestra el valor de la variable en las coordenadas específicas X e Y de la escena.", "", "0", "0", "", 0},
    {Op::HideVar, "ocultarvariable", Cat::Datos, "Ocultar la variable {t}", "Oculta la variable, por lo tanto no es visible en la escena.", "", "", "", "", 0},
};
#undef H

const OpInfo& opInfo(Op op) {
    for (auto& i : kOps) if (i.op == op) return i;
    return kOps[0];
}

const OpInfo* opInfoByKey(const std::string& key) {
    for (auto& i : kOps) if (key == i.key) return &i;
    return nullptr;
}

const char* catName(Cat c) {
    switch (c) {
        case Cat::Eventos: return "Eventos";
        case Cat::Control: return "Control";
        case Cat::Movimiento: return "Movimiento";
        case Cat::Sonido: return "Sonido";
        case Cat::Apariencia: return "Apariencia";
        case Cat::Datos: return "Datos";
        case Cat::Forge3D: return "Extras 3D";
        case Cat::Multijugador: return "Multijugador";
    }
    return "";
}

bool isHat(Op op) { return opInfo(op).indent == 2; }

static std::string esc(const std::string& s) {
    if (s.empty()) return "~";
    std::string o;
    for (char c : s) {
        if (c == '%') o += "%25";
        else if (c == ' ') o += "%20";
        else if (c == '\n') o += "%0A";
        else if (c == '\t') o += "%09";
        else if (c == '\r') continue;
        else o += c;
    }
    if (o == "~") return "%7E";
    return o;
}

static std::string unesc(const std::string& s) {
    if (s == "~") return "";
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '%' && i + 2 < s.size() + 0 && i + 2 <= s.size() - 1 + 0) {
            std::string h = s.substr(i + 1, 2);
            o += (char)strtol(h.c_str(), nullptr, 16);
            i += 2;
        } else o += s[i];
    }
    return o;
}

static std::string unders(std::string s) {
    for (auto& c : s) if (c == '_') c = ' ';
    return s;
}

bool loadProject(const Files& files, Project& p, std::string& err) {
    auto it = files.find("project.forge");
    if (it == files.end()) { err = "falta project.forge"; return false; }

    std::vector<std::string> lines;
    {
        std::string text(it->second.begin(), it->second.end());
        std::istringstream ss(text);
        std::string l;
        while (std::getline(ss, l)) {
            if (!l.empty() && l.back() == '\r') l.pop_back();
            lines.push_back(l);
        }
    }
    size_t li = 0;
    p = Project();
    for (auto& f : files)
        if (f.first != "project.forge") p.assets[f.first] = f.second;

    while (li < lines.size()) {
        auto t = split(lines[li]);
        li++;
        if (t.empty() || t[0][0] == '#') continue;
        auto F = [&](size_t k) { return k < t.size() ? (float)atof(t[k].c_str()) : 0.f; };

        if (t[0] == "project") { if (t.size() > 1) p.name = t[1]; continue; }
        if (t[0] == "hud") {
            p.hudDefault = !(t.size() > 1 && (t[1] == "custom" || t[1] == "none"));
            continue;
        }
        if (t[0] == "button") {
            HudBtn b;
            b.label = t.size() > 1 ? unders(t[1]) : "OK";
            b.x = F(2); b.y = F(3); b.r = F(4);
            std::string a = t.size() > 5 ? t[5] : "none";
            b.act = a == "jump" ? HudAct::Jump : a == "shoot" ? HudAct::Shoot : a == "interact" ? HudAct::Interact : a == "script" ? HudAct::Script : a == "nextweapon" ? HudAct::NextWeapon : a == "reload" ? HudAct::Reload : a == "flashlight" ? HudAct::Flashlight : a == "hold" ? HudAct::Hold : a == "sprint" ? HudAct::Sprint : a == "crouch" ? HudAct::Crouch : HudAct::None;
            for (int k = 0; k < 3; k++) b.color[k] = t.size() > (size_t)(6 + k) ? F(6 + k) : 1.f;
            p.hud.push_back(b);
            continue;
        }
        std::string wk = t[0];
        bool xw = wk.compare(0, 7, "xweapon") == 0;
        if (xw) { wk = wk.substr(1); if (wk == "weapon") p.extraWeapons.push_back(Weapon()); if (p.extraWeapons.empty()) continue; }
        if (wk == "weapon") {
            Weapon& w = xw ? p.extraWeapons.back() : p.weapon;
            w.tex = (t.size() > 1 && t[1] != "-") ? t[1] : "";
            w.scale = F(2); w.ox = F(3); w.oy = F(4); w.rate = F(5); w.range = F(6);
            w.enabled = t.size() > 7 ? F(7) != 0 : true;
            if (w.scale <= 0) w.scale = 0.5f;
            if (w.rate <= 0) w.rate = 0.25f;
            if (w.range <= 0) w.range = 60.f;
            continue;
        }
        if (wk == "weapon3") {
            Weapon& w = xw ? p.extraWeapons.back() : p.weapon;
            w.type = std::max(0, std::min(3, (int)F(1))); w.startWith = F(2) != 0; w.magSize = std::max(0, (int)F(3));
            w.startAmmo = std::max(0, (int)F(4)); w.infinite = F(5) != 0; w.recoilAmt = F(6); w.reloadTime = F(7);
            w.meleeRange = F(8); w.blast = F(9); w.fuse = F(10);
            w.name = t.size() > 11 ? unesc(t[11]) : "Arma";
            continue;
        }
        if (wk == "weapon4") {
            Weapon& w = xw ? p.extraWeapons.back() : p.weapon;
            w.inHand = F(1) != 0; w.handSide = F(2) != 0 ? 1 : 0;
            for (int k = 0; k < 3; k++) { w.hrot[k] = F(3 + k); w.hoff[k] = F(6 + k); }
            w.hscale = t.size() > 9 && F(9) > 0.f ? F(9) : 1.f;
            continue;
        }
        if (wk == "weapon2") {
            Weapon& w = xw ? p.extraWeapons.back() : p.weapon;
            w.model = (t.size() > 1 && t[1] != "-") ? t[1] : "";
            w.projTex = (t.size() > 2 && t[2] != "-") ? t[2] : "";
            w.projModel = (t.size() > 3 && t[3] != "-") ? t[3] : "";
            w.projSize = F(4); w.projSpeed = F(5);
            for (int k = 0; k < 3; k++) w.projColor[k] = F(6 + k);
            w.damage = F(9); w.projShape = (int)F(10);
            if (w.projSize <= 0) w.projSize = 0.2f;
            if (w.damage <= 0) w.damage = 1.f;
            continue;
        }
        if (t[0] == "controls") {  // v10.8: resolucion + teclas propias ("-" = por defecto)
            p.resH = t.size() > 1 ? (int)F(1) : 1080;
            if (p.resH < 0) p.resH = 0;
            for (int i = 0; i < 12; i++) p.keys[i] = t.size() > (size_t)(2 + i) && t[2 + i] != "-" ? t[2 + i] : std::string();
            continue;
        }
        if (t[0] == "export") {
            ExportCfg& e = p.exportCfg;
            auto S = [&](size_t i) { return t.size() > i ? unesc(t[i]) : std::string(); };
            e.appName = S(1); e.appId = S(2); e.verName = S(3); e.verCode = (int)F(4); e.orient = (int)F(5);
            e.icon = S(6); e.exeName = S(7); e.winTitle = S(8); e.fullscreen = F(9) != 0; e.winW = (int)F(10); e.winH = (int)F(11);
            e.hideVirtual = F(12) != 0;
            if (e.verCode < 1) e.verCode = 1;
            if (e.winW < 320) e.winW = 1280;
            if (e.winH < 240) e.winH = 720;
            if (e.appId.empty()) e.appId = "com.mijuego.app";
            continue;
        }
        if (t[0] == "player") {
            p.player.cam = (int)F(1);
            p.player.model = (t.size() > 2 && t[2] != "-") ? t[2] : "";
            p.player.speed = F(3); p.player.jump = F(4);
            if (p.player.speed <= 0) p.player.speed = 4.5f;
            if (p.player.jump <= 0) p.player.jump = 7.f;
            continue;
        }
        if (t[0] == "cine") { Cine c; c.name = t.size() > 1 ? unders(t[1]) : "Cinemática"; c.dur = std::max(0.5f, F(2)); c.mode = (int)F(3); c.skip = F(4) != 0; p.cines.push_back(c); continue; }
        if (t[0] == "ck" && !p.cines.empty()) { CineKey k; k.t = F(1); k.eye = V3{F(2), F(3), F(4)}; k.yaw = F(5); k.pitch = F(6); p.cines.back().cam.push_back(k); continue; }
        if (t[0] == "ct" && !p.cines.empty()) { CineTrack tr; tr.obj = t.size() > 1 ? unders(t[1]) : ""; p.cines.back().tracks.push_back(tr); continue; }
        if (t[0] == "ctk" && !p.cines.empty() && !p.cines.back().tracks.empty()) { CineTrackKey k; k.t = F(1); k.p = V3{F(2), F(3), F(4)}; k.yaw = F(5); p.cines.back().tracks.back().keys.push_back(k); continue; }
        if (t[0] == "pfit") { p.player.fit = F(1) != 0; p.player.eyeH = F(2); p.player.fpBody = F(3) != 0; continue; }
        if (t[0] == "boom") { p.boom.mode = std::max(0, std::min(2, (int)F(1))); p.boom.size = std::max(0.1f, F(2)); p.boom.time = std::max(0.1f, F(3)); p.boom.model = t.size() > 4 && t[4] != "-" ? unders(t[4]) : ""; continue; }
        if (t[0] == "boomf") { if (t.size() > 1) p.boom.frames.push_back(unders(t[1])); continue; }
        if (t[0] == "vehicle") { p.player.vehicle = F(1) != 0; continue; }
        if (t[0] == "player2") {
            PlayerCfg& pc = p.player;
            pc.faceMove = F(1) != 0; pc.shoulderDist = F(2);
            pc.mox = F(3); pc.moy = F(4); pc.moz = F(5); pc.myaw = F(6); pc.mscale = F(7);
            if (t.size() > 8) pc.shoulderH = F(8);
            if (pc.shoulderDist < 0.5f) pc.shoulderDist = 2.8f;
            if (pc.mscale <= 0.01f) pc.mscale = 1.f;
            continue;
        }
        if (t[0] == "paim" && t.size() > 9) {
            PlayerCfg& pc = p.player;
            pc.fov = std::max(30.f, std::min(120.f, F(1))); pc.aimFov = std::max(10.f, std::min(110.f, F(2))); pc.aimSpeed = std::max(1.f, F(3));
            pc.aimLook = std::max(0.05f, F(4)); pc.aimMove = std::max(0.f, F(5)); pc.aimWx = F(6); pc.aimWy = F(7); pc.aimWz = F(8); pc.aimRoll = F(9);
            pc.aimHold = t.size() > 10 ? F(10) != 0 : true;
            continue;
        }
        if (t[0] == "player3") { p.player.fixedMode = std::max(0, std::min(2, (int)F(1))); p.player.headBob = t.size() > 2 && F(2) != 0; if (t.size() > 3) p.player.bobAmt = F(3); continue; }
        if (t[0] == "player4") { p.player.lockOn = std::max(0, std::min(2, (int)F(1))); p.player.sideView = t.size() > 2 && F(2) != 0; p.player.swipe = t.size() > 3 && F(3) != 0; if (t.size() > 4) p.player.lockRange = F(4); if (t.size() > 5) p.player.runner = F(5) != 0; if (t.size() > 6) p.player.laneW = F(6); if (t.size() > 7) p.player.faceExtra = (int)F(7); continue; }
        if (t[0] == "snd") { int k = (int)F(1); if (k >= 0 && k < 8 && t.size() > 2) p.snd[k] = unesc(t[2]); continue; }
        if (t[0] == "flash") {
            PlayerCfg& pc = p.player;
            pc.flashlight = F(1) != 0; pc.flashOnStart = F(2) != 0; pc.flashFlicker = F(3) != 0;
            pc.flashRange = F(4); pc.flashAngle = F(5); pc.flashInt = F(6);
            for (int k = 0; k < 3; k++) pc.flashCol[k] = F(7 + k);
            pc.flashTex = t.size() > 10 ? unesc(t[10]) : "";
            continue;
        }
        if (t[0] == "ui" && t.size() >= 20) {
            GameUi& u = p.ui;
            bool* bs[12] = {&u.on, &u.health, &u.shield, &u.ammo, &u.slots, &u.minimap, &u.compass, &u.speedo, &u.timer, &u.score, &u.objective, &u.hitmark};
            for (int k = 0; k < 12; k++) *bs[k] = F(1 + k) != 0;
            u.lowHp = F(13) != 0; u.crosshair = std::max(0, std::min(4, (int)F(14))); u.vignette = std::max(0.f, std::min(1.f, F(15)));
            u.grade = std::max(0, std::min(5, (int)F(16)));
            for (int k = 0; k < 3; k++) u.accent[k] = F(17 + k);
            continue;
        }
        if (t[0] == "uimap") { p.ui.mapStyle = std::max(0, std::min(5, (int)F(1))); p.ui.mapRange = std::max(6.f, std::min(200.f, F(2))); p.ui.mapSize = std::max(0.5f, std::min(2.f, F(3))); p.ui.mapRotate = F(4) != 0; continue; }
        if (t[0] == "uifight") { p.ui.fight = F(1) != 0; if (t.size() > 2) p.ui.nameA = unesc(t[2]); if (t.size() > 3) p.ui.nameB = unesc(t[3]); continue; }
        if (t[0] == "gi") { p.gi = std::max(0.f, std::min(1.5f, F(1))); continue; }
        if (t[0] == "mblur") { p.mblur = std::max(0.f, std::min(3.f, F(1))); continue; }
        if (t[0] == "gfx") { p.gfxShadow = std::max(0, std::min(4, (int)F(1))); p.gfxSoft = std::max(0, std::min(2, (int)F(2))); p.gfxSpec = std::max(0.f, std::min(1.f, F(3))); p.gfxTone = std::max(0.f, std::min(1.f, F(4))); p.gfxEv = std::max(-1.f, std::min(1.f, F(5))); p.gfxAniso = std::max(1, std::min(16, (int)F(6))); p.gfxPreset = std::max(-1, std::min(3, (int)F(7))); continue; }
        if (t[0] == "perf2" && t.size() >= 7) { auto& q = p.perf; q.lod = F(1) != 0; q.dynRes = F(2) != 0; q.dynTarget = std::max(20, std::min(144, (int)F(3))); q.saver = F(4) != 0; q.warm = F(5) != 0; q.telem = F(6) != 0; q.rt = t.size() > 7 && F(7) != 0; continue; }
        if (t[0] == "perf" && t.size() >= 15) { auto& q = p.perf; q.cull = F(1) != 0; q.distOn = F(2) != 0; q.dist = F(3); q.fpsOn = F(4) != 0; q.fps = (int)F(5);
            q.partOn = F(6) != 0; q.part = (int)F(7); q.lightOn = F(8) != 0; q.light = (int)F(9); q.texOn = F(10) != 0; q.tex = (int)F(11); q.aliveOn = F(12) != 0; q.alive = (int)F(13); continue; }
        if (t[0] == "spatial") { p.spatial = F(1) != 0; if (t.size() > 2) p.spatialR = F(2); continue; }
        if (t[0] == "showfps") { p.showFps = F(1) != 0; continue; }
        if (t[0] == "keepscenes") { p.keepAcrossScenes = F(1) != 0; continue; }
        if (t[0] == "btnstyle") { p.btnStyle = std::max(0, std::min(6, (int)F(1))); continue; }
        if (t[0] == "filter") { p.gfxFilter = std::max(0, std::min(19, (int)F(1))); p.gfxFilterAmt = std::max(0.f, std::min(1.f, F(2))); continue; }
        if (t[0] == "rtx") { p.rtx = F(1) != 0; continue; }
        if (t[0] == "ctl2d") { p.ctl2d = std::max(0, std::min(5, (int)F(1))); continue; }
        if (t[0] == "quality") { p.quality = std::max(0, std::min(2, (int)F(1))); continue; }
        if (t[0] == "showvars") { p.showVars = F(1) != 0; continue; }
        if (t[0] == "gvar") { if (t.size() > 1) p.globalVars.push_back(unesc(t[1])); continue; }

        if (t[0] == "scene") {
            Scene s;
            s.name = t.size() > 1 ? t[1] : "escena";
            s.is3d = !(t.size() > 2 && t[2] == "2d");
            s.side25 = t.size() > 3 && t[3] == "side";
            p.scenes.push_back(s);
            continue;
        }
        if (p.scenes.empty()) { err = "linea fuera de una escena: " + t[0]; return false; }
        Scene& s = p.scenes.back();

        if (t[0] == "ctl2ds") { s.ctl2d = std::max(-1, std::min(5, (int)F(1))); continue; }
        if (t[0] == "sky") {
            for (int k = 0; k < 3; k++) { s.skyTop[k] = F(1 + k); s.skyBot[k] = F(4 + k); }
        } else if (t[0] == "clouds") {
            s.cloudStyle = std::max(0, std::min(8, (int)F(1)));
            if (t.size() > 2) { s.cloudTex = unesc(t[2]); if (s.cloudTex == "-") s.cloudTex.clear(); }
            if (t.size() > 3) s.cloudAmt = std::max(0.f, std::min(1.f, F(3)));
            if (t.size() > 4) s.cloudWind = std::max(0.f, std::min(5.f, F(4)));
        } else if (t[0] == "sunbody") {
            s.sunBody = std::max(0, std::min(9, (int)F(1)));
            if (t.size() > 2) s.sunSize = std::max(0.1f, std::min(30.f, F(2)));
        } else if (t[0] == "noflare") {
            s.flare = false;
        } else if (t[0] == "skystyle") {
            s.skyStyle = std::max(0, std::min(10, (int)F(1)));
            if (t.size() > 2) { s.skyTex = unesc(t[2]); if (s.skyTex == "-") s.skyTex.clear(); }
        } else if (t[0] == "sun") {
            s.sunDir = {F(1), F(2), F(3)};
            for (int k = 0; k < 3; k++) s.sun[k] = F(4 + k);
        } else if (t[0] == "env") {
            s.ambient = F(1); s.fog = F(2);
        } else if (t[0] == "atmo") {
            s.tone = std::max(0, std::min(2, (int)F(1))); s.atmo = std::max(0, std::min(5, (int)F(2))); s.atmoAmt = std::max(0.f, std::min(3.f, F(3)));
            for (int k = 0; k < 3; k++) s.atmoCol[k] = F(4 + k);
        } else if (t[0] == "shade") {
            s.shadowAmt = std::max(0.f, std::min(1.6f, F(1)));
        } else if (t[0] == "drawdist") {
            s.drawDist = std::max(0.f, std::min(5000.f, F(1)));
        } else if (t[0] == "simdist") {
            s.simDist = std::max(0.f, std::min(5000.f, F(1)));
        } else if (t[0] == "atmo2") {
            s.atmoStyle = std::max(0, std::min(1, (int)F(1))); s.fogMode = F(2) != 0 ? 1 : 0;
            for (int k = 0; k < 3; k++) s.fogCol[k] = F(3 + k);
        } else if (t[0] == "map2") {
            s.map2on = F(1) != 0; s.map2jump = std::max(0, std::min(1, (int)F(2))); s.map2x = F(3); s.map2y = F(4);
        } else if (t[0] == "limit") {
            s.limMode = std::max(0, std::min(2, (int)F(1))); s.limR = std::max(1.f, F(2)); s.limCx = F(3); s.limCz = F(4);
        } else if (t[0] == "zmask") {   // máscara de zona prohibida: tramos alternados (vacío, lleno, vacío...)
            s.blk.assign((size_t)Scene::kBlkN * Scene::kBlkN, 0);
            size_t pos = 0; uint8_t val = 0;
            for (size_t k = 1; k < t.size() && pos < s.blk.size(); k++, val ^= 1) {
                size_t run = (size_t)std::max(0, std::atoi(t[k].c_str()));
                for (size_t q = 0; q < run && pos < s.blk.size(); q++) s.blk[pos++] = val;
            }
        } else if (t[0] == "zone") {
            Scene::Zone z; z.who = (int)F(1); z.only = t.size() > 2 && t[2] != "-" ? unders(t[2]) : "";
            for (size_t k = 3; k < t.size(); k++) z.pts.push_back((float)std::atof(t[k].c_str()));
            if (z.pts.size() >= 6) s.zones.push_back(z);
        } else if (t[0] == "seastyle") {
            s.seaStyle = std::max(0, std::min(6, (int)F(1)));
        } else if (t[0] == "sea") {
            s.sea = F(1) != 0; s.seaY = F(2); s.seaAlpha = F(3);
            for (int k = 0; k < 3; k++) s.seaCol[k] = F(4 + k);
        } else if (t[0] == "vegl") {
            VegLayer v;
            v.style = std::max(0, std::min(11, (int)F(1)));
            for (int k = 0; k < 3; k++) { v.col[k] = F(2 + k); v.col2[k] = F(5 + k); }
            v.h = F(8); v.w = F(9); v.sway = F(10);
            v.name = t.size() > 11 ? unesc(t[11]) : "Pasto";
            v.tex = t.size() > 12 ? unesc(t[12]) : "";
            s.veg.push_back(v);
        } else if (t[0] == "gndl") {
            GroundLayer v;
            v.preset = std::max(0, std::min(5, (int)F(1)));
            v.scale = std::max(0.02f, F(2));
            v.name = t.size() > 3 ? unesc(t[3]) : "Suelo";
            v.tex = t.size() > 4 ? unesc(t[4]) : "";
            s.gnd.push_back(v);
        } else if (t[0] == "gndp") {
            if (s.gnd.empty()) { err = "'gndp' sin capa de suelo"; return false; }
            for (size_t k = 1; k + 3 < t.size(); k += 4)
                for (int q = 0; q < 4; q++) s.gnd.back().pts.push_back(F(k + q));
        } else if (t[0] == "vegp") {
            if (s.veg.empty()) { err = "'vegp' sin capa de vegetacion"; return false; }
            for (size_t k = 1; k + 4 < t.size(); k += 5)
                for (int q = 0; q < 5; q++) s.veg.back().pts.push_back(F(k + q));
        } else if (t[0] == "start") {
            s.start = {F(1), F(2), F(3)};
        } else if (t[0] == "cam") {
            s.cam = {F(1), F(2), F(3)};
        } else if (t[0] == "emit") {
            if (s.objs.empty()) { err = "'emit' sin objeto"; return false; }
            FxCfg& f = s.objs.back().fx;
            f.on = F(1) != 0; f.kind = (int)F(2); f.rate = F(3); f.life = F(4); f.size = F(5); f.speed = F(6); f.spread = F(7);
            f.gravity = F(8); f.grow = F(9); f.a0 = F(10); f.glow = F(11) != 0;
            for (int k = 0; k < 3; k++) { f.c0[k] = F(12 + k); f.c1[k] = F(15 + k); }
            f.tex = (t.size() > 18 && t[18] != "-") ? t[18] : "";
        } else if (t[0] == "ovl") {
            Overlay o;
            o.tex = (t.size() > 1 && t[1] != "-") ? t[1] : "";
            o.x = F(2); o.y = F(3); o.w = F(4); o.h = F(5); o.alpha = F(6);
            s.overlays.push_back(o);
        } else if (t[0] == "sfx") {
            ScreenFx& f = s.sfx;
            f.scan = F(1); f.noise = F(2); f.vignette = F(3); f.tint = F(4); f.track = F(5);
            for (int k = 0; k < 3; k++) f.tintC[k] = F(6 + k);
            f.rec = F(9) != 0;
        } else if (t[0] == "map2auto") {
            s.map2auto = F(1) != 0; if (t.size() > 2) s.map2autoSpd = std::max(20.f, std::min(2000.f, F(2)));
        } else if (t[0] == "ai3") {
            if (s.objs.empty()) { err = "'ai3' sin objeto"; return false; }
            AiCfg& a = s.objs.back().ai;
            a.bdir = std::max(0, std::min(4, (int)F(1))); a.blife = std::max(0.f, F(2)); a.boff = F(3) != 0;
            if (t.size() > 4) a.meleeTex = unesc(t[4]);
            if (t.size() > 5) a.bpathMode = std::max(0, std::min(1, (int)F(5)));
        } else if (t[0] == "bpath") {
            if (!s.objs.empty()) { std::vector<float> pth; for (size_t k = 1; k < t.size() && pth.size() < 4000; k++) pth.push_back(F(k)); if (pth.size() >= 4) s.objs.back().ai.bpaths.push_back(pth); }
        } else if (t[0] == "acoff") {
            if (!s.objs.empty()) { int k = (int)F(1); if (k >= 0 && k < kAnimCount) s.objs.back().ai.anim[k].off = true; }
        } else if (t[0] == "ai") {
            if (s.objs.empty()) { err = "'ai' sin objeto"; return false; }
            AiCfg& a = s.objs.back().ai;
            a.type = t.size() > 1 && t[1] == "shooter" ? AiType::Shooter : t.size() > 1 && t[1] == "melee" ? AiType::Melee : AiType::None;
            a.sprite = F(2) != 0; a.hp = F(3); a.speed = F(4); a.sight = F(5); a.dmg = F(6); a.rate = F(7); a.reach = F(8);
            a.projSize = F(9); a.projSpeed = F(10);
            for (int k = 0; k < 3; k++) a.projColor[k] = F(11 + k);
            a.projTex = (t.size() > 14 && t[14] != "-") ? t[14] : "";
            a.projModel = (t.size() > 15 && t[15] != "-") ? t[15] : "";
        } else if (t[0] == "ast") {
            if (s.objs.empty()) { err = "'ast' sin objeto"; return false; }
            int k = (int)F(1);
            if (k < 0 || k >= kAnimCount) { err = "animacion invalida"; return false; }
            AnimState& a = s.objs.back().ai.anim[k];
            a.fps = F(2); a.bob = F(3); a.sway = F(4); a.lunge = F(5); a.squash = F(6);
        } else if (t[0] == "afr") {
            if (s.objs.empty()) { err = "'afr' sin objeto"; return false; }
            int k = (int)F(1);
            if (k < 0 || k >= kAnimCount) { err = "animacion invalida"; return false; }
            s.objs.back().ai.anim[k].frames.push_back(t.size() > 2 ? unesc(t[2]) : "");
        } else if (t[0] == "obj") {
            Obj o;
            if (t.size() < 3 || !kindFromName(t[1], o.kind)) { err = "objeto invalido"; return false; }
            o.name = t[2];
            o.pos = {F(3), F(4), F(5)};
            o.scale = {t.size() > 6 ? F(6) : 1.f, t.size() > 7 ? F(7) : 1.f, t.size() > 8 ? F(8) : 1.f};
            o.yaw = F(9);
            for (int k = 0; k < 3; k++) o.color[k] = t.size() > (size_t)(10 + k) ? F(10 + k) : 1.f;
            if (t.size() > 13 && t[13] != "-") o.tex = t[13];
            if (t.size() > 14) o.solid = F(14) != 0;
            if (t.size() > 15) o.visible = F(15) != 0;
            if (t.size() > 16) o.spin = F(16) != 0;
            if (t.size() > 17 && t[17] != "-") o.model = t[17];
            s.objs.push_back(o);
        } else if (t[0] == "bg") {
            if (s.objs.empty()) { err = "'bg' sin objeto"; return false; }
            s.objs.back().bg = true;
        } else if (t[0] == "fx") {
            if (s.objs.empty()) { err = "'fx' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.transp = F(1); o.bright = F(2); o.hue = F(3); o.layer = (int)F(4);
        } else if (t[0] == "ai2") {
            if (s.objs.empty()) { err = "'ai2' sin objeto"; return false; }
            s.objs.back().ai.face = (int)F(1);
        } else if (t[0] == "vid") {
            if (s.objs.empty()) { err = "'vid' sin objeto"; return false; }
            s.objs.back().video = t.size() > 1 ? unesc(t[1]) : "";
            s.objs.back().videoAuto = F(2) != 0; s.objs.back().videoLoop = F(3) != 0;
        } else if (t[0] == "gw") {
            if (s.objs.empty()) { err = "'gw' sin objeto"; return false; }
            s.objs.back().giveWeapon = t.size() > 1 ? unesc(t[1]) : "";
        } else if (t[0] == "flip") {
            if (s.objs.empty()) { err = "'flip' sin objeto"; return false; }
            s.objs.back().flipX = F(1) != 0; s.objs.back().flipY = F(2) != 0;
        } else if (t[0] == "ex") {
            if (s.objs.empty()) { err = "'ex' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.noColor = F(1) != 0; o.texTile = F(2) != 0; o.locked = F(3) != 0; o.metal = F(5) != 0;
            if (t.size() > 4) o.reflect = F(4) != 0;
        } else if (t[0] == "tilt") {
            if (s.objs.empty()) { err = "'tilt' sin objeto"; return false; }
            s.objs.back().pitch = F(1); s.objs.back().roll = F(2);
        } else if (t[0] == "rig") {
            if (s.objs.empty()) { err = "'rig' sin objeto"; return false; }
            s.objs.back().rig = t.size() > 1 ? unesc(t[1]) : "";
            s.objs.back().clip = t.size() > 2 ? unesc(t[2]) : "";
        } else if (t[0] == "acl") {
            if (s.objs.empty()) { err = "'acl' sin objeto"; return false; }
            int k = (int)F(1);
            if (k < 0 || k >= kAnimCount) { err = "animacion invalida"; return false; }
            s.objs.back().ai.anim[k].clip = t.size() > 2 ? unesc(t[2]) : "";
        } else if (t[0] == "terrain") {
            if (s.objs.empty()) { err = "'terrain' sin objeto"; return false; }
            Obj& o = s.objs.back();
            int n = (int)F(1);
            if (n >= 2 && n <= 129) { o.tn = n; o.heights.assign((size_t)n * n, 0.f); }
        } else if (t[0] == "th") {
            if (s.objs.empty() || s.objs.back().tn < 2) { err = "'th' sin terreno"; return false; }
            Obj& o = s.objs.back();
            static thread_local size_t fill = 0;
            if (t.size() > 1 && t[1] == "@") { fill = (size_t)F(2); }
            for (size_t k = 3; k < t.size() && fill < o.heights.size(); k++) o.heights[fill++] = (float)std::atof(t[k].c_str());
        } else if (t[0] == "phys2") {
            if (s.objs.empty()) { err = "'phys2' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.pushable = F(1) != 0; o.bulletPush = F(2) != 0; o.gravScale = F(3); o.drag = std::max(0.f, F(4));
        } else if (t[0] == "auto5") {
            if (s.objs.empty()) { err = "'auto5' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.wander = F(1) != 0; o.wanderR = F(2); o.wanderSpd = F(3); o.routeOn = F(4) != 0; o.routeLoop = F(5) != 0; o.routePush = F(6) != 0;
            o.routeThrow = (int)F(7); o.routeSpd = F(8); o.routeAggr = F(9); o.actR = F(10); o.carMode = F(11) != 0; o.carHp = F(12); o.carTop = F(13);
            if (t.size() > 17) { o.routeLaps = std::max(0, std::min(50, (int)F(14))); o.frontOff = F(15); o.carCamD = std::max(1.f, F(16)); o.carCamH = F(17); }
        } else if (t[0] == "wheel") {
            if (!s.objs.empty() && t.size() > 7) { Obj& o = s.objs.back(); o.wheelOf = unesc(t[1]); o.wheelOff = {F(2), F(3), F(4)}; o.wheelAxle = (int)F(5); o.wheelR = std::max(0.01f, F(6)); o.wheelFront = F(7) != 0; }
        } else if (t[0] == "rag") {
            if (!s.objs.empty() && t.size() > 5) { Obj& o = s.objs.back(); o.ragOf = unesc(t[1]); o.ragOff = {F(2), F(3), F(4)}; o.ragR = std::max(0.01f, F(5)); o.ragDeath = t.size() > 6 && F(6) != 0; }
        } else if (t[0] == "mapobj") {
            if (!s.objs.empty()) { s.objs.back().mapPart = (int)F(1); }
        } else if (t[0] == "listm") {
            if (!s.objs.empty() && t.size() > 6) { Obj& o = s.objs.back(); o.listMode = true; o.listGap = F(1); o.listFade = F(2); o.listSpeed = std::max(0.5f, F(3)); o.listShow = std::max(0, std::min(60, (int)F(4))); o.listHoriz = F(5) != 0; o.listWrap = F(6) != 0; }
        } else if (t[0] == "goal") {
            if (!s.objs.empty() && t.size() > 1) { s.objs.back().goal = true; s.objs.back().goalScene = t[1] == "-" ? std::string() : unesc(t[1]); }
        } else if (t[0] == "act") {
            if (!s.objs.empty() && t.size() > 2) { int i = (int)F(1); if (i >= 0 && i < 7) s.objs.back().act[i] = unesc(t[2]); }
        } else if (t[0] == "hand") {
            if (!s.objs.empty() && t.size() > 9) { Obj& o = s.objs.back(); o.handItem = unesc(t[1]); o.handSide = F(2) != 0 ? 1 : 0; for (int k = 0; k < 3; k++) { o.hrot[k] = F(3 + k); o.hoff[k] = F(6 + k); } o.hscale = F(9) > 0.f ? F(9) : 1.f; }
        } else if (t[0] == "car2") {
            if (s.objs.empty()) { err = "'car2' sin objeto"; return false; }
            s.objs.back().carEnterD = std::max(0.1f, std::min(20.f, F(1)));
        } else if (t[0] == "vctl") {
            if (!s.objs.empty()) { s.objs.back().vctl = (int)F(1); s.objs.back().vctlSpd = std::max(10.f, F(2)); if (t.size() > 3) s.objs.back().jumpMode = std::max(0, std::min(3, (int)F(3))); if (t.size() > 4) s.objs.back().vctlJump = std::max(50.f, F(4)); }
        } else if (t[0] == "trail2") {
            if (!s.objs.empty()) { Obj& o = s.objs.back(); o.trail = F(1) != 0; o.trailStyle = (int)F(2); o.trailLife = std::max(0.1f, F(3)); o.trailCol[0] = F(4); o.trailCol[1] = F(5); o.trailCol[2] = F(6); o.routeFace = F(7) != 0; if (t.size() > 8) o.routeFaceOff = F(8); if (t.size() > 9) o.trailGap = std::max(0.5f, F(9)); if (t.size() > 10) o.trailScale = std::max(0.2f, F(10)); if (t.size() > 11) o.trailTransp = std::max(0.f, std::min(99.f, F(11))); if (t.size() > 12) o.trailSolid = F(12) != 0; }
        } else if (t[0] == "npcclone") {
            if (!s.objs.empty() && t.size() > 4) { Obj& o = s.objs.back(); o.cloneN = std::max(0, std::min(60, (int)F(1))); o.cloneRespawn = F(2) != 0; o.cloneTotal = std::max(0, std::min(500, (int)F(3))); o.cloneSpread = std::max(0.5f, F(4)); }
        } else if (t[0] == "rblur") {
            if (!s.objs.empty()) s.objs.back().reflBlur = std::max(0.f, std::min(1.f, F(1)));
        } else if (t[0] == "hmark") {
            if (!s.objs.empty()) s.objs.back().hitMark = F(1) != 0;
        } else if (t[0] == "snap") {
            if (!s.objs.empty()) s.objs.back().snapGround = F(1) != 0;
        } else if (t[0] == "route") {
            if (s.objs.empty()) { err = "'route' sin objeto"; return false; }
            for (size_t k = 1; k < t.size(); k++) s.objs.back().route.push_back((float)std::atof(t[k].c_str()));
        } else if (t[0] == "rmark") {
            if (!s.objs.empty() && t.size() > 7) { Obj& o = s.objs.back(); o.routeMark = F(1) != 0; o.routeMarkStyle = std::max(0, std::min(3, (int)F(2))); o.routeMarkCol[0] = F(3); o.routeMarkCol[1] = F(4); o.routeMarkCol[2] = F(5); o.routeMarkW = std::max(1.f, std::min(40.f, F(6))); o.routeMarkAhead = std::max(1, std::min(20, (int)F(7))); }
        } else if (t[0] == "routew") {
            if (s.objs.empty()) { err = "'routew' sin objeto"; return false; }
            s.objs.back().routeWaitMode = std::max(0, std::min(2, (int)F(1))); s.objs.back().routeWaitA = std::max(0.f, F(2)); s.objs.back().routeWaitB = std::max(0.f, F(3)); s.objs.back().routeDelay = t.size() > 4 ? std::max(0.f, F(4)) : 0.f;
        } else if (t[0] == "deform") {
            if (s.objs.empty()) { err = "'deform' sin objeto"; return false; }
            s.objs.back().deform = F(1) != 0; s.objs.back().deformAmt = std::max(0.05f, std::min(1.f, F(2)));
        } else if (t[0] == "phys") {
            if (s.objs.empty()) { err = "'phys' sin objeto"; return false; }
            Obj& o = s.objs.back();
            o.phys = t.size() > 1 && t[1] == "dynamic" ? Phys::Dynamic : t.size() > 1 && t[1] == "static" ? Phys::Static : Phys::None;
            o.mass = F(2); o.bounce = F(3); o.friction = F(4);
        } else if (t[0] == "look" || t[0] == "ltex" || t[0] == "snd" || t[0] == "lvar") {
            if (s.objs.empty()) { err = "'" + t[0] + "' sin objeto"; return false; }
            Obj& o = s.objs.back();
            std::string v = t.size() > 1 ? unesc(t[1]) : "";
            (t[0] == "ltex" ? o.lockTex : t[0] == "look" ? o.looks : t[0] == "snd" ? o.sounds : o.localVars).push_back(v);
        } else if (t[0] == "blk") {
            if (s.objs.empty()) { err = "'blk' sin objeto"; return false; }
            const OpInfo* oi = t.size() > 1 ? opInfoByKey(t[1]) : nullptr;
            if (!oi) { err = "bloque desconocido: " + (t.size() > 1 ? t[1] : std::string()); return false; }
            Block b;
            b.op = oi->op;
            b.t = t.size() > 2 ? unesc(t[2]) : "";
            for (int k = 0; k < 3; k++) b.f[k] = t.size() > (size_t)(3 + k) ? unesc(t[3 + k]) : "";
            s.objs.back().blocks.push_back(std::move(b));
        } else {
            err = "instruccion desconocida: " + t[0];
            return false;
        }
    }
    if (p.scenes.empty()) { err = "el proyecto no tiene escenas"; return false; }
    return true;
}

// ---------------------------------------------------------------- escritura
static std::string fmt(float v) {
    char b[48];
    snprintf(b, sizeof b, "%g", (double)v);
    return b;
}

static std::string noSpace(std::string s) {
    if (s.empty()) return "-";
    for (auto& c : s) if (c == ' ' || c == '\t') c = '_';
    return s;
}

std::string writeProject(const Project& p) {
    std::ostringstream o;
    o << "project " << noSpace(p.name) << '\n';
    if (p.hudDefault) {
        o << "hud default\n";
    } else {
        o << "hud custom\n";
        for (auto& b : p.hud)
            o << "button " << noSpace(b.label) << ' ' << fmt(b.x) << ' ' << fmt(b.y) << ' ' << fmt(b.r) << ' '
              << actName(b.act) << ' ' << fmt(b.color[0]) << ' ' << fmt(b.color[1]) << ' ' << fmt(b.color[2]) << '\n';
    }
    o << "weapon " << noSpace(p.weapon.tex) << ' ' << fmt(p.weapon.scale) << ' ' << fmt(p.weapon.ox) << ' '
      << fmt(p.weapon.oy) << ' ' << fmt(p.weapon.rate) << ' ' << fmt(p.weapon.range) << ' '
      << (p.weapon.enabled ? 1 : 0) << '\n';
    o << "weapon2 " << noSpace(p.weapon.model) << ' ' << noSpace(p.weapon.projTex) << ' ' << noSpace(p.weapon.projModel) << ' '
      << fmt(p.weapon.projSize) << ' ' << fmt(p.weapon.projSpeed) << ' ' << fmt(p.weapon.projColor[0]) << ' '
      << fmt(p.weapon.projColor[1]) << ' ' << fmt(p.weapon.projColor[2]) << ' ' << fmt(p.weapon.damage) << ' '
      << p.weapon.projShape << '\n';
    {
        const ExportCfg& e = p.exportCfg;
        o << "export " << esc(e.appName) << ' ' << esc(e.appId) << ' ' << esc(e.verName) << ' ' << e.verCode << ' ' << e.orient << ' ' << esc(e.icon)
          << ' ' << esc(e.exeName) << ' ' << esc(e.winTitle) << ' ' << (e.fullscreen ? 1 : 0) << ' ' << e.winW << ' ' << e.winH << ' ' << (e.hideVirtual ? 1 : 0) << '\n';
    }
    o << "controls " << p.resH;
    for (int i = 0; i < 12; i++) o << ' ' << (p.keys[i].empty() ? std::string("-") : p.keys[i]);
    o << '\n';
    auto wnew = [&](const char* tag, const Weapon& w) {
        o << tag << ' ' << w.type << ' ' << (w.startWith ? 1 : 0) << ' ' << w.magSize << ' ' << w.startAmmo << ' ' << (w.infinite ? 1 : 0) << ' '
          << fmt(w.recoilAmt) << ' ' << fmt(w.reloadTime) << ' ' << fmt(w.meleeRange) << ' ' << fmt(w.blast) << ' ' << fmt(w.fuse) << ' ' << esc(w.name) << '\n';
    };
    auto whand = [&](const char* tag, const Weapon& w) {
        if (!w.inHand) return;
        o << tag << ' ' << 1 << ' ' << w.handSide << ' ' << fmt(w.hrot[0]) << ' ' << fmt(w.hrot[1]) << ' ' << fmt(w.hrot[2]) << ' ' << fmt(w.hoff[0]) << ' ' << fmt(w.hoff[1]) << ' ' << fmt(w.hoff[2]) << ' ' << fmt(w.hscale) << '\n';
    };
    wnew("weapon3", p.weapon); whand("weapon4", p.weapon);
    for (auto& w : p.extraWeapons) {
        o << "xweapon " << noSpace(w.tex) << ' ' << fmt(w.scale) << ' ' << fmt(w.ox) << ' ' << fmt(w.oy) << ' ' << fmt(w.rate) << ' ' << fmt(w.range) << ' ' << (w.enabled ? 1 : 0) << '\n';
        o << "xweapon2 " << noSpace(w.model) << ' ' << noSpace(w.projTex) << ' ' << noSpace(w.projModel) << ' ' << fmt(w.projSize) << ' ' << fmt(w.projSpeed) << ' '
          << fmt(w.projColor[0]) << ' ' << fmt(w.projColor[1]) << ' ' << fmt(w.projColor[2]) << ' ' << fmt(w.damage) << ' ' << w.projShape << '\n';
        wnew("xweapon3", w); whand("xweapon4", w);
    }
    if (p.player.vehicle) o << "vehicle 1\n";
    if (p.player.fit || p.player.eyeH != 0.f || p.player.fpBody) o << "pfit " << (p.player.fit ? 1 : 0) << ' ' << fmt(p.player.eyeH) << ' ' << (p.player.fpBody ? 1 : 0) << '\n';
    if (p.boom.mode != 0 || !p.boom.frames.empty() || !p.boom.model.empty()) {
        o << "boom " << p.boom.mode << ' ' << fmt(p.boom.size) << ' ' << fmt(p.boom.time) << ' ' << (p.boom.model.empty() ? std::string("-") : noSpace(p.boom.model)) << '\n';
        for (auto& f : p.boom.frames) o << "boomf " << noSpace(f) << '\n';
    }
    o << "player2 " << (p.player.faceMove ? 1 : 0) << ' ' << fmt(p.player.shoulderDist) << ' ' << fmt(p.player.mox) << ' ' << fmt(p.player.moy) << ' ' << fmt(p.player.moz)
      << ' ' << fmt(p.player.myaw) << ' ' << fmt(p.player.mscale) << ' ' << fmt(p.player.shoulderH) << '\n';
    o << "paim " << fmt(p.player.fov) << ' ' << fmt(p.player.aimFov) << ' ' << fmt(p.player.aimSpeed) << ' ' << fmt(p.player.aimLook) << ' ' << fmt(p.player.aimMove)
      << ' ' << fmt(p.player.aimWx) << ' ' << fmt(p.player.aimWy) << ' ' << fmt(p.player.aimWz) << ' ' << fmt(p.player.aimRoll) << ' ' << (p.player.aimHold ? 1 : 0) << '\n';
    o << "player " << p.player.cam << ' ' << noSpace(p.player.model) << ' ' << fmt(p.player.speed) << ' ' << fmt(p.player.jump) << '\n';
    for (auto& cn : p.cines) {
        o << "cine " << noSpace(cn.name) << ' ' << fmt(cn.dur) << ' ' << cn.mode << ' ' << (cn.skip ? 1 : 0) << '\n';
        for (auto& k : cn.cam) o << "ck " << fmt(k.t) << ' ' << fmt(k.eye.x) << ' ' << fmt(k.eye.y) << ' ' << fmt(k.eye.z) << ' ' << fmt(k.yaw) << ' ' << fmt(k.pitch) << '\n';
        for (auto& tr : cn.tracks) {
            o << "ct " << noSpace(tr.obj) << '\n';
            for (auto& k : tr.keys) o << "ctk " << fmt(k.t) << ' ' << fmt(k.p.x) << ' ' << fmt(k.p.y) << ' ' << fmt(k.p.z) << ' ' << fmt(k.yaw) << '\n';
        }
    }
    o << "showvars " << (p.showVars ? 1 : 0) << '\n';
    if (p.quality != 1) o << "quality " << p.quality << '\n';
    if (p.player.flashlight) {
        const PlayerCfg& pc = p.player;
        o << "flash 1 " << (pc.flashOnStart ? 1 : 0) << ' ' << (pc.flashFlicker ? 1 : 0) << ' ' << fmt(pc.flashRange) << ' ' << fmt(pc.flashAngle) << ' ' << fmt(pc.flashInt)
          << ' ' << fmt(pc.flashCol[0]) << ' ' << fmt(pc.flashCol[1]) << ' ' << fmt(pc.flashCol[2]) << ' ' << esc(pc.flashTex) << '\n';
    }
    {
        const GameUi& u = p.ui;
        if (u.on) {
            bool bs[12] = {u.on, u.health, u.shield, u.ammo, u.slots, u.minimap, u.compass, u.speedo, u.timer, u.score, u.objective, u.hitmark};
            o << "ui";
            for (int k = 0; k < 12; k++) o << ' ' << (bs[k] ? 1 : 0);
            o << ' ' << (u.lowHp ? 1 : 0) << ' ' << u.crosshair << ' ' << fmt(u.vignette) << ' ' << u.grade
              << ' ' << fmt(u.accent[0]) << ' ' << fmt(u.accent[1]) << ' ' << fmt(u.accent[2]) << "\n";
        }
    }
    if (p.ui.on) o << "uimap " << p.ui.mapStyle << ' ' << fmt(p.ui.mapRange) << ' ' << fmt(p.ui.mapSize) << ' ' << (p.ui.mapRotate ? 1 : 0) << '\n';
    if (p.ui.on && p.ui.fight) o << "uifight 1 " << esc(p.ui.nameA) << ' ' << esc(p.ui.nameB) << '\n';
    if (p.gfxShadow || p.gfxSoft || p.gfxSpec > 0.f || p.gfxTone > 0.f || p.gfxEv != 0.f || p.gfxAniso != 1 || p.gfxPreset >= 0)
        o << "gfx " << p.gfxShadow << ' ' << p.gfxSoft << ' ' << fmt(p.gfxSpec) << ' ' << fmt(p.gfxTone) << ' ' << fmt(p.gfxEv) << ' ' << p.gfxAniso << ' ' << p.gfxPreset << '\n';
    if (p.keepAcrossScenes) o << "keepscenes 1\n";
    if (p.showFps) o << "showfps 1\n";
    if (p.spatial) o << "spatial 1 " << p.spatialR << "\n";
    { auto& q = p.perf; o << "perf2 " << q.lod << " " << q.dynRes << " " << q.dynTarget << " " << q.saver << " " << q.warm << " " << q.telem << " " << q.rt << "\n"; }
    { auto& q = p.perf; o << "perf " << q.cull << " " << q.distOn << " " << q.dist << " " << q.fpsOn << " " << q.fps << " " << q.partOn << " " << q.part << " " << q.lightOn << " " << q.light << " " << q.texOn << " " << q.tex << " " << q.aliveOn << " " << q.alive << " 0\n"; }
    if (p.btnStyle) o << "btnstyle " << p.btnStyle << '\n';
    if (p.gfxFilter) o << "filter " << p.gfxFilter << ' ' << fmt(p.gfxFilterAmt) << '\n';
    if (p.rtx) o << "rtx 1\n";
    if (p.gi > 0.f) o << "gi " << p.gi << "\n";
    if (p.mblur > 0.f) o << "mblur " << p.mblur << "\n";
    if (p.ctl2d) o << "ctl2d " << p.ctl2d << '\n';
    for (int k = 0; k < 8; k++) if (!p.snd[k].empty()) o << "snd " << k << ' ' << esc(p.snd[k]) << '\n';
    if (p.player.fixedMode || p.player.headBob) o << "player3 " << p.player.fixedMode << ' ' << (p.player.headBob ? 1 : 0) << ' ' << fmt(p.player.bobAmt) << '\n';
    if (p.player.lockOn || p.player.sideView || p.player.swipe || p.player.runner || p.player.faceExtra) o << "player4 " << p.player.lockOn << ' ' << (p.player.sideView ? 1 : 0) << ' ' << (p.player.swipe ? 1 : 0) << ' ' << fmt(p.player.lockRange) << ' ' << (p.player.runner ? 1 : 0) << ' ' << fmt(p.player.laneW) << ' ' << p.player.faceExtra << '\n';
    for (auto& v : p.globalVars) o << "gvar " << esc(v) << '\n';

    for (auto& s : p.scenes) {
        o << "\nscene " << noSpace(s.name) << ' ' << (s.is3d ? "3d" : "2d") << (s.side25 ? " side" : "") << '\n';
        if (s.ctl2d >= 0) o << "ctl2ds " << s.ctl2d << '\n';
        o << "sky " << fmt(s.skyTop[0]) << ' ' << fmt(s.skyTop[1]) << ' ' << fmt(s.skyTop[2]) << ' '
          << fmt(s.skyBot[0]) << ' ' << fmt(s.skyBot[1]) << ' ' << fmt(s.skyBot[2]) << '\n';
        if (s.cloudStyle || s.cloudAmt != 0.5f || s.cloudWind != 1.f) o << "clouds " << s.cloudStyle << ' ' << esc(s.cloudTex.empty() ? std::string("-") : s.cloudTex) << ' ' << fmt(s.cloudAmt) << ' ' << fmt(s.cloudWind) << '\n';
        if (s.sunBody || s.sunSize != 1.f) o << "sunbody " << s.sunBody << ' ' << fmt(s.sunSize) << '\n';
        if (!s.flare) o << "noflare\n";
        if (s.skyStyle || !s.skyTex.empty()) o << "skystyle " << s.skyStyle << ' ' << esc(s.skyTex.empty() ? std::string("-") : s.skyTex) << '\n';
        o << "sun " << fmt(s.sunDir.x) << ' ' << fmt(s.sunDir.y) << ' ' << fmt(s.sunDir.z) << ' '
          << fmt(s.sun[0]) << ' ' << fmt(s.sun[1]) << ' ' << fmt(s.sun[2]) << '\n';
        o << "env " << fmt(s.ambient) << ' ' << fmt(s.fog) << '\n';
        if (s.tone || s.atmo)
            o << "atmo " << s.tone << ' ' << s.atmo << ' ' << fmt(s.atmoAmt) << ' ' << fmt(s.atmoCol[0]) << ' ' << fmt(s.atmoCol[1]) << ' ' << fmt(s.atmoCol[2]) << '\n';
        if (std::fabs(s.shadowAmt - 1.f) > 1e-3f) o << "shade " << fmt(s.shadowAmt) << '\n';
        if (s.drawDist > 0.f) o << "drawdist " << fmt(s.drawDist) << '\n';
        if (s.simDist > 0.f) o << "simdist " << fmt(s.simDist) << '\n';
        if (s.atmoStyle || s.fogMode)
            o << "atmo2 " << s.atmoStyle << ' ' << s.fogMode << ' ' << fmt(s.fogCol[0]) << ' ' << fmt(s.fogCol[1]) << ' ' << fmt(s.fogCol[2]) << '\n';
        if (s.sea && s.seaStyle) o << "seastyle " << s.seaStyle << '\n';
        if (s.map2auto) o << "map2auto 1 " << fmt(s.map2autoSpd) << '\n';
        if (s.map2on) o << "map2 1 " << s.map2jump << ' ' << fmt(s.map2x) << ' ' << fmt(s.map2y) << '\n';
        if (s.limMode) o << "limit " << s.limMode << ' ' << fmt(s.limR) << ' ' << fmt(s.limCx) << ' ' << fmt(s.limCz) << '\n';
        if (!s.blk.empty()) {
            bool any = false; for (uint8_t b : s.blk) if (b) { any = true; break; }
            if (any) {
                o << "zmask"; uint8_t cur = 0; size_t run = 0;
                for (uint8_t b : s.blk) { if (b != cur) { o << ' ' << run; cur = b; run = 0; } run++; }
                o << ' ' << run << '\n';
            }
        }
        for (auto& z : s.zones) {
            o << "zone " << z.who << ' ' << (z.only.empty() ? std::string("-") : noSpace(z.only));
            for (float v : z.pts) o << ' ' << fmt(v);
            o << '\n';
        }
        if (s.sea)
            o << "sea 1 " << fmt(s.seaY) << ' ' << fmt(s.seaAlpha) << ' ' << fmt(s.seaCol[0]) << ' ' << fmt(s.seaCol[1]) << ' ' << fmt(s.seaCol[2]) << '\n';
        for (auto& v : s.gnd) {
            o << "gndl " << v.preset << ' ' << fmt(v.scale) << ' ' << esc(v.name) << ' ' << esc(v.tex) << '\n';
            for (size_t k = 0; k + 3 < v.pts.size();) {
                o << "gndp";
                for (int n = 0; n < 50 && k + 3 < v.pts.size(); n++, k += 4)
                    for (int q = 0; q < 4; q++) o << ' ' << fmt(v.pts[k + q]);
                o << '\n';
            }
        }
        for (auto& v : s.veg) {
            o << "vegl " << v.style;
            for (int k = 0; k < 3; k++) o << ' ' << fmt(v.col[k]);
            for (int k = 0; k < 3; k++) o << ' ' << fmt(v.col2[k]);
            o << ' ' << fmt(v.h) << ' ' << fmt(v.w) << ' ' << fmt(v.sway) << ' ' << esc(v.name) << ' ' << esc(v.tex) << '\n';
            for (size_t k = 0; k + 4 < v.pts.size();) {
                o << "vegp";
                for (int n = 0; n < 40 && k + 4 < v.pts.size(); n++, k += 5)
                    for (int q = 0; q < 5; q++) o << ' ' << fmt(v.pts[k + q]);
                o << '\n';
            }
        }
        o << "start " << fmt(s.start.x) << ' ' << fmt(s.start.y) << ' ' << fmt(s.start.z) << '\n';
        for (auto& ov : s.overlays)
            o << "ovl " << noSpace(ov.tex) << ' ' << fmt(ov.x) << ' ' << fmt(ov.y) << ' ' << fmt(ov.w) << ' ' << fmt(ov.h) << ' ' << fmt(ov.alpha) << '\n';
        if (s.sfx.any())
            o << "sfx " << fmt(s.sfx.scan) << ' ' << fmt(s.sfx.noise) << ' ' << fmt(s.sfx.vignette) << ' ' << fmt(s.sfx.tint) << ' ' << fmt(s.sfx.track)
              << ' ' << fmt(s.sfx.tintC[0]) << ' ' << fmt(s.sfx.tintC[1]) << ' ' << fmt(s.sfx.tintC[2]) << ' ' << (s.sfx.rec ? 1 : 0) << '\n';
        o << "cam " << fmt(s.cam.x) << ' ' << fmt(s.cam.y) << ' ' << fmt(s.cam.z) << '\n';
        for (auto& ob : s.objs) {
            o << "obj " << kindName(ob.kind) << ' ' << noSpace(ob.name) << ' '
              << fmt(ob.pos.x) << ' ' << fmt(ob.pos.y) << ' ' << fmt(ob.pos.z) << ' '
              << fmt(ob.scale.x) << ' ' << fmt(ob.scale.y) << ' ' << fmt(ob.scale.z) << ' ' << fmt(ob.yaw) << ' '
              << fmt(ob.color[0]) << ' ' << fmt(ob.color[1]) << ' ' << fmt(ob.color[2]) << ' '
              << noSpace(ob.tex) << ' ' << (ob.solid ? 1 : 0) << ' ' << (ob.visible ? 1 : 0) << ' '
              << (ob.spin ? 1 : 0) << ' ' << noSpace(ob.model) << '\n';
            if (ob.pitch != 0.f || ob.roll != 0.f) o << "tilt " << fmt(ob.pitch) << ' ' << fmt(ob.roll) << '\n';
            if (ob.bg) o << "bg\n";
            o << "fx " << fmt(ob.transp) << ' ' << fmt(ob.bright) << ' ' << fmt(ob.hue) << ' ' << ob.layer << '\n';
            if (!ob.rig.empty() || !ob.clip.empty()) o << "rig " << esc(ob.rig) << ' ' << esc(ob.clip) << '\n';
            if (ob.tn >= 2 && ob.heights.size() == (size_t)ob.tn * ob.tn) {
                o << "terrain " << ob.tn << '\n';
                for (size_t k = 0; k < ob.heights.size(); k += 24) {
                    o << "th @ " << k;
                    for (size_t q = k; q < k + 24 && q < ob.heights.size(); q++) o << ' ' << std::round(ob.heights[q] * 100.f) / 100.f;
                    o << '\n';
                }
            }
            if (ob.video.size()) o << "vid " << esc(ob.video) << ' ' << (ob.videoAuto ? 1 : 0) << ' ' << (ob.videoLoop ? 1 : 0) << '\n';
            if (ob.giveWeapon.size()) o << "gw " << esc(ob.giveWeapon) << '\n';
            if (ob.flipX || ob.flipY) o << "flip " << (ob.flipX ? 1 : 0) << ' ' << (ob.flipY ? 1 : 0) << '\n';
            if (ob.noColor || ob.texTile || ob.locked || ob.reflect || ob.metal) o << "ex " << (ob.noColor ? 1 : 0) << ' ' << (ob.texTile ? 1 : 0) << ' ' << (ob.locked ? 1 : 0) << ' ' << (ob.reflect ? 1 : 0) << ' ' << (ob.metal ? 1 : 0) << '\n';
            if (ob.fx.on || !ob.fx.tex.empty()) {
                const FxCfg& f = ob.fx;
                o << "emit " << (f.on ? 1 : 0) << ' ' << f.kind << ' ' << fmt(f.rate) << ' ' << fmt(f.life) << ' ' << fmt(f.size) << ' ' << fmt(f.speed) << ' '
                  << fmt(f.spread) << ' ' << fmt(f.gravity) << ' ' << fmt(f.grow) << ' ' << fmt(f.a0) << ' ' << (f.glow ? 1 : 0);
                for (int k = 0; k < 3; k++) o << ' ' << fmt(f.c0[k]);
                for (int k = 0; k < 3; k++) o << ' ' << fmt(f.c1[k]);
                o << ' ' << noSpace(f.tex) << '\n';
            }
            bool plAnim = false;
            {   // cualquier objeto (jugador, modelo, enemigo) guarda sus animaciones por acción
                plAnim = ob.ai.sprite;
                for (auto& as : ob.ai.anim) if (!as.frames.empty() || !as.clip.empty() || as.bob > 0 || as.sway > 0 || as.lunge > 0 || as.squash > 0) plAnim = true;
            }
            if (ob.ai.type != AiType::None || plAnim) {
                const AiCfg& a = ob.ai;
                o << "ai " << (a.type == AiType::Shooter ? "shooter" : a.type == AiType::Melee ? "melee" : "none") << ' ' << (a.sprite ? 1 : 0) << ' ' << fmt(a.hp) << ' '
                  << fmt(a.speed) << ' ' << fmt(a.sight) << ' ' << fmt(a.dmg) << ' ' << fmt(a.rate) << ' ' << fmt(a.reach) << ' '
                  << fmt(a.projSize) << ' ' << fmt(a.projSpeed) << ' ' << fmt(a.projColor[0]) << ' ' << fmt(a.projColor[1]) << ' '
                  << fmt(a.projColor[2]) << ' ' << noSpace(a.projTex) << ' ' << noSpace(a.projModel) << '\n';
                if (a.face) o << "ai2 " << a.face << '\n';
                if (a.bdir || a.blife > 0.f || !a.boff || !a.meleeTex.empty() || !a.bpaths.empty()) o << "ai3 " << a.bdir << ' ' << fmt(a.blife) << ' ' << (a.boff ? 1 : 0) << ' ' << esc(a.meleeTex) << ' ' << a.bpathMode << '\n';
                for (auto& pth : a.bpaths) { o << "bpath"; for (float v : pth) o << ' ' << fmt(v); o << '\n'; }
                for (int k = 0; k < kAnimCount; k++) if (a.anim[k].off) o << "acoff " << k << '\n';
                for (int k = 0; k < kAnimCount; k++) {
                    const AnimState& as = a.anim[k];
                    o << "ast " << k << ' ' << fmt(as.fps) << ' ' << fmt(as.bob) << ' ' << fmt(as.sway) << ' ' << fmt(as.lunge) << ' '
                      << fmt(as.squash) << '\n';
                    for (auto& f : as.frames) o << "afr " << k << ' ' << esc(f) << '\n';
                    if (!as.clip.empty()) o << "acl " << k << ' ' << esc(as.clip) << '\n';
                }
            }
            if (ob.pushable || ob.bulletPush || ob.gravScale != 1.f || ob.drag != 0.f)
                o << "phys2 " << (ob.pushable ? 1 : 0) << ' ' << (ob.bulletPush ? 1 : 0) << ' ' << fmt(ob.gravScale) << ' ' << fmt(ob.drag) << '\n';
            if (!ob.wheelOf.empty()) o << "wheel " << esc(ob.wheelOf) << ' ' << fmt(ob.wheelOff.x) << ' ' << fmt(ob.wheelOff.y) << ' ' << fmt(ob.wheelOff.z) << ' ' << ob.wheelAxle << ' ' << fmt(ob.wheelR) << ' ' << (ob.wheelFront ? 1 : 0) << '\n';
            if (!ob.ragOf.empty()) o << "rag " << esc(ob.ragOf) << ' ' << fmt(ob.ragOff.x) << ' ' << fmt(ob.ragOff.y) << ' ' << fmt(ob.ragOff.z) << ' ' << fmt(ob.ragR) << ' ' << (ob.ragDeath ? 1 : 0) << '\n';
            if (ob.mapPart) o << "mapobj " << ob.mapPart << '\n';
            if (ob.goal) o << "goal " << esc(ob.goalScene.empty() ? std::string("-") : ob.goalScene) << '\n';
            for (int k = 0; k < 7; k++) if (!ob.act[k].empty()) o << "act " << k << ' ' << esc(ob.act[k]) << '\n';
            if (!ob.handItem.empty()) o << "hand " << esc(ob.handItem) << ' ' << ob.handSide << ' ' << fmt(ob.hrot[0]) << ' ' << fmt(ob.hrot[1]) << ' ' << fmt(ob.hrot[2]) << ' ' << fmt(ob.hoff[0]) << ' ' << fmt(ob.hoff[1]) << ' ' << fmt(ob.hoff[2]) << ' ' << fmt(ob.hscale) << '\n';
            if (ob.vctl) o << "vctl " << ob.vctl << ' ' << fmt(ob.vctlSpd) << ' ' << ob.jumpMode << ' ' << fmt(ob.vctlJump) << '\n';
            if (ob.wander || ob.routeOn || ob.carMode || !ob.route.empty())
                o << "auto5 " << (ob.wander ? 1 : 0) << ' ' << fmt(ob.wanderR) << ' ' << fmt(ob.wanderSpd) << ' ' << (ob.routeOn ? 1 : 0) << ' ' << (ob.routeLoop ? 1 : 0) << ' '
                  << (ob.routePush ? 1 : 0) << ' ' << ob.routeThrow << ' ' << fmt(ob.routeSpd) << ' ' << fmt(ob.routeAggr) << ' ' << fmt(ob.actR) << ' '
                  << (ob.carMode ? 1 : 0) << ' ' << fmt(ob.carHp) << ' ' << fmt(ob.carTop) << ' ' << ob.routeLaps << ' ' << fmt(ob.frontOff) << ' ' << fmt(ob.carCamD) << ' ' << fmt(ob.carCamH) << '\n';
            if (ob.carMode && ob.carEnterD != 1.5f) o << "car2 " << fmt(ob.carEnterD) << '\n';
            if (ob.snapGround) o << "snap 1\n";
            if (ob.hitMark) o << "hmark 1\n";
            if (std::fabs(ob.reflBlur - 0.3f) > 1e-4f) o << "rblur " << fmt(ob.reflBlur) << '\n';
            if (ob.cloneN > 0) o << "npcclone " << ob.cloneN << ' ' << (ob.cloneRespawn ? 1 : 0) << ' ' << ob.cloneTotal << ' ' << fmt(ob.cloneSpread) << '\n';
            if (ob.trail || ob.routeFace || ob.routeFaceOff != 0.f || ob.trailGap != 28.f || ob.trailScale != 1.f || ob.trailTransp != 45.f || ob.trailSolid) o << "trail2 " << (ob.trail ? 1 : 0) << ' ' << ob.trailStyle << ' ' << fmt(ob.trailLife) << ' ' << fmt(ob.trailCol[0]) << ' ' << fmt(ob.trailCol[1]) << ' ' << fmt(ob.trailCol[2]) << ' ' << (ob.routeFace ? 1 : 0) << ' ' << fmt(ob.routeFaceOff) << ' ' << fmt(ob.trailGap) << ' ' << fmt(ob.trailScale) << ' ' << fmt(ob.trailTransp) << ' ' << (ob.trailSolid ? 1 : 0) << '\n';
            for (size_t k = 0; k < ob.route.size(); k += 16) {
                o << "route";
                for (size_t m = k; m < ob.route.size() && m < k + 16; m++) o << ' ' << fmt(ob.route[m]);
                o << '\n';
            }
            if (ob.routeMark) o << "rmark 1 " << ob.routeMarkStyle << ' ' << fmt(ob.routeMarkCol[0]) << ' ' << fmt(ob.routeMarkCol[1]) << ' ' << fmt(ob.routeMarkCol[2]) << ' ' << fmt(ob.routeMarkW) << ' ' << ob.routeMarkAhead << '\n';
            if (ob.routeWaitMode || ob.routeDelay > 0.f) o << "routew " << ob.routeWaitMode << ' ' << fmt(ob.routeWaitA) << ' ' << fmt(ob.routeWaitB) << ' ' << fmt(ob.routeDelay) << '\n';
            if (ob.deform) o << "deform 1 " << fmt(ob.deformAmt) << '\n';
            if (ob.phys != Phys::None)
                o << "phys " << (ob.phys == Phys::Dynamic ? "dynamic" : "static") << ' ' << fmt(ob.mass) << ' '
                  << fmt(ob.bounce) << ' ' << fmt(ob.friction) << '\n';
            for (auto& l : ob.looks) o << "look " << esc(l) << '\n';
            if (ob.listMode) o << "listm " << fmt(ob.listGap) << ' ' << fmt(ob.listFade) << ' ' << fmt(ob.listSpeed) << ' ' << ob.listShow << ' ' << (ob.listHoriz ? 1 : 0) << ' ' << (ob.listWrap ? 1 : 0) << '\n';
            for (auto& l : ob.lockTex) o << "ltex " << esc(l) << '\n';
            for (auto& l : ob.sounds) o << "snd " << esc(l) << '\n';
            for (auto& l : ob.localVars) o << "lvar " << esc(l) << '\n';
            for (auto& b : ob.blocks)
                o << "blk " << opInfo(b.op).key << ' ' << esc(b.t) << ' ' << esc(b.f[0]) << ' ' << esc(b.f[1]) << ' '
                  << esc(b.f[2]) << '\n';
        }
    }
    return o.str();
}

}  // namespace forge

namespace forge {

void terrainInit(Obj& o, int n) {
    n = std::max(2, std::min(129, n));
    o.tn = n;
    o.heights.assign((size_t)n * n, 0.f);
    o.terrVer++;
}

static float hAt(const Obj& o, int i, int j) {
    i = std::max(0, std::min(o.tn - 1, i));
    j = std::max(0, std::min(o.tn - 1, j));
    return o.heights[(size_t)j * o.tn + i];
}

float terrainSurface(const Obj& o, float x, float z) {
    if (o.tn < 2 || o.heights.size() != (size_t)o.tn * o.tn) return -1e9f;
    float u = (x - o.pos.x) / o.scale.x + 0.5f, v = (z - o.pos.z) / o.scale.z + 0.5f;
    if (u < 0.f || v < 0.f || u > 1.f || v > 1.f) return -1e9f;
    float gx = u * (o.tn - 1), gz = v * (o.tn - 1);
    int i = std::min(o.tn - 2, (int)gx), j = std::min(o.tn - 2, (int)gz);
    float fx = gx - i, fz = gz - j;
    float h = hAt(o, i, j) * (1 - fx) * (1 - fz) + hAt(o, i + 1, j) * fx * (1 - fz) + hAt(o, i, j + 1) * (1 - fx) * fz + hAt(o, i + 1, j + 1) * fx * fz;
    return o.pos.y + o.scale.y * 0.5f + h;
}

bool rayTerrain(const Obj& o, V3 e, V3 d, float maxT, float& t) {
    if (o.tn < 2) return false;
    float cell = std::min(o.scale.x, o.scale.z) / (float)(o.tn - 1);
    float step = std::max(0.05f, cell * 0.5f);
    float prevT = 0.f, prevD = 0.f;
    bool have = false;
    for (float s = 0.f; s <= maxT; s += step) {
        V3 p = e + d * s;
        float h = terrainSurface(o, p.x, p.z);
        if (h < -1e8f) { have = false; continue; }
        float diff = p.y - h;
        if (have && prevD > 0.f && diff <= 0.f) {  // cruzo la superficie: afina entre los dos pasos
            float a = prevT, b = s;
            for (int k = 0; k < 8; k++) {
                float m = (a + b) * 0.5f;
                V3 q = e + d * m;
                float hh = terrainSurface(o, q.x, q.z);
                if (hh > -1e8f && q.y - hh <= 0.f) b = m; else a = m;
            }
            t = b;
            return true;
        }
        if (!have && diff <= 0.f && s == 0.f) { t = 0.f; return true; }
        prevT = s; prevD = diff; have = true;
    }
    return false;
}

void terrainBrush(Obj& o, float wx, float wz, float radius, float k, int mode, float target) {
    if (o.tn < 2) return;
    float cx = (wx - o.pos.x) / o.scale.x + 0.5f, cz = (wz - o.pos.z) / o.scale.z + 0.5f;
    float rx = radius / o.scale.x * (o.tn - 1), rz = radius / o.scale.z * (o.tn - 1);
    int i0 = std::max(0, (int)std::floor(cx * (o.tn - 1) - rx)), i1 = std::min(o.tn - 1, (int)std::ceil(cx * (o.tn - 1) + rx));
    int j0 = std::max(0, (int)std::floor(cz * (o.tn - 1) - rz)), j1 = std::min(o.tn - 1, (int)std::ceil(cz * (o.tn - 1) + rz));
    std::vector<float> src = o.heights;
    for (int j = j0; j <= j1; j++)
        for (int i = i0; i <= i1; i++) {
            float x = o.pos.x + ((float)i / (o.tn - 1) - 0.5f) * o.scale.x, z = o.pos.z + ((float)j / (o.tn - 1) - 0.5f) * o.scale.z;
            float d = std::sqrt((x - wx) * (x - wx) + (z - wz) * (z - wz)) / std::max(0.01f, radius);
            if (d >= 1.f) continue;
            float w = 0.5f + 0.5f * std::cos(d * 3.14159265f);  // montaña redondeada
            float& h = o.heights[(size_t)j * o.tn + i];
            if (mode == 0) h += k * w;
            else if (mode == 1) h -= k * w;
            else if (mode == 2) h += (target - h) * std::min(1.f, w * 0.35f);
            else {
                float sum = 0; int c = 0;
                for (int dj = -1; dj <= 1; dj++) for (int di = -1; di <= 1; di++) {
                    int ii = i + di, jj = j + dj;
                    if (ii < 0 || jj < 0 || ii >= o.tn || jj >= o.tn) continue;
                    sum += src[(size_t)jj * o.tn + ii]; c++;
                }
                h += (sum / std::max(1, c) - h) * std::min(1.f, w * 0.6f);
            }
            h = std::max(-30.f, std::min(60.f, h));
        }
    o.terrVer++;
}

}  // namespace forge

// ---- v8: ambientacion, atmosfera y calidad
namespace forge {
const char* const kToneNames[3] = {"Por defecto", "Amarillento", "Azulado"};
const char* const kAtmoNames[6] = {"Ninguna", "Niebla", "Lluvia", "Tormenta de arena", "Nieve", "Personalizado"};
const char* const kWeaponTypeNames[4] = {"De fuego", "Cuerpo a cuerpo", "Arrojadiza", "Granada"};
const VoiceDef kVoices[10] = {
    {"Normal", 1.0f, 1.0f, 0}, {"Grave (hombre)", 0.7f, 0.95f, 1}, {"Aguda (mujer)", 1.35f, 1.0f, 2}, {"Niño", 1.8f, 1.1f, 3},
    {"Anciano", 0.6f, 0.75f, 1}, {"Robot", 0.5f, 0.85f, 4}, {"Monstruo", 0.3f, 0.7f, 0}, {"Ardilla", 2.0f, 1.5f, 2},
    {"Narrador", 0.85f, 0.85f, 1}, {"Susurro", 1.1f, 0.7f, 3}};
std::string speakCode(const std::string& voiceName) {
    const VoiceDef* v = &kVoices[0];
    for (auto& k : kVoices) if (voiceName == k.name) v = &k;
    char b[64];
    snprintf(b, sizeof b, "\x1e%.2f;%.2f;%d\x1f", v->pitch, v->rate, v->idx);
    return b;
}
const char* const kQualityNames[3] = {"Baja", "Media", "Alta"};
void toneTint(int tone, float out[3]) {  // tonos suaves, sin verde
    static const float T[3][3] = {{1.f, 1.f, 1.f}, {1.07f, 1.01f, 0.88f}, {0.90f, 0.97f, 1.08f}};
    tone = std::max(0, std::min(2, tone));
    for (int k = 0; k < 3; k++) out[k] = T[tone][k];
}
void atmoDefaults(int atmo, float col[3], float& amt) {
    static const float C[6][3] = {{0.8f, 0.85f, 0.9f}, {0.82f, 0.84f, 0.87f}, {0.55f, 0.6f, 0.68f},
                                  {0.78f, 0.62f, 0.38f}, {0.93f, 0.95f, 1.f}, {0.8f, 0.8f, 0.85f}};
    static const float A[6] = {0.f, 0.5f, 0.5f, 0.6f, 0.5f, 0.5f};
    atmo = std::max(0, std::min(5, atmo));
    for (int k = 0; k < 3; k++) col[k] = C[atmo][k];
    amt = A[atmo];
}
}  // namespace forge
