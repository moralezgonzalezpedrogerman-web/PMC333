#pragma once
#include "scene.h"
#include <utility>
#include <vector>

namespace forge {

// Niveles infinitos: el tramo que armaste a mano se vuelve a poner más adelante con los mismos objetos
// en otros lugares (otros carriles, otras distancias). Sirve para runners en 3D y para niveles 2D.
struct EndInfo {
    bool ok = false;
    int fc = 2, lc = 0;            // componente (0 x, 1 y, 2 z) hacia donde se avanza y la lateral
    float sgn = -1.f;              // signo del avance
    std::vector<int> obst;         // objetos que se reparten al azar (obstáculos, enemigos, monedas...)
    std::vector<int> tiles;        // objetos grandes (suelo, camino): se repiten tal cual, uno tras otro
    std::vector<float> lanes;      // posiciones laterales posibles
    float start = 0.f;             // inicio del tramo en el eje de avance (con signo)
    float len = 10.f;              // largo de un tramo
};

EndInfo endAnalyze(const Scene& s);
// Coloca un tramo nuevo: devuelve pares (objeto de origen, posición nueva). k = número de tramo (1, 2, 3...).
void endPlaceChunk(const Scene& s, const EndInfo& e, int k, unsigned& rng, std::vector<std::pair<int, V3>>& out);
// Para el editor: reparte otra vez, de una vez y para siempre, los objetos marcados dentro del tramo actual.
int endShuffleScene(Scene& s, unsigned seed);
float endProgress(const EndInfo& e, V3 p);   // cuánto avanzó algo en el eje de avance (con signo)

}  // namespace forge
