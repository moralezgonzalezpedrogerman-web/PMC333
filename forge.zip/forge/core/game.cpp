#include <random>
#include <cstring>
#include "game.h"
#include "stb_image.h"
#include "video.h"
#include "model.h"
#include <algorithm>
#include <cmath>
#include <array>
#include <ctime>
#include <cstdlib>
#include <functional>
#include <map>

namespace forge {

// Números al azar buenos (std::rand en Windows solo tiene 15 bits: las posiciones al azar quedaban en una rejilla amontonada).
static std::mt19937& gameRng() { static std::mt19937 r(std::random_device{}()); return r; }
static float frand() { return std::uniform_real_distribution<float>(0.f, 1.f)(gameRng()); }
static int irand(int n) { return n <= 1 ? 0 : std::uniform_int_distribution<int>(0, n - 1)(gameRng()); }
static const size_t kMaxObjs = 100000;   // antes 600: «por siempre crear clon» se detenía


// una acción «no existe» si se marcó «No reproducir» o si no tiene ninguna animación (así no se cae a la pose de reposo en T)
static bool animGone(const AnimState& as) {
    return as.off || (as.clip.empty() && as.frames.empty() && as.bob <= 0.f && as.sway <= 0.f && as.lunge <= 0.f && as.squash <= 0.f);
}

static const float kRad = 3.14159265f / 180.f;

static bool solidKind(Kind k) {
    return k == Kind::Cube || k == Kind::Floor || k == Kind::Wall || k == Kind::Model;
}

bool Game::hasHat(const Obj& o, Op hat) const {
    for (auto& b : o.blocks) if (b.op == hat) return true;
    return false;
}

V3 Game::forward() const {
    return {std::sin(yaw) * std::cos(pitch), std::sin(pitch), -std::cos(yaw) * std::cos(pitch)};
}

// ---------------------------------------------------------------- carga
static void compileObj(const std::vector<Block>& B, std::vector<int>& match, std::vector<int>& hats) {
    int n = (int)B.size();
    match.assign(n, n);
    hats.clear();
    struct S { int idx; Op op; };
    std::vector<S> st;
    for (int i = 0; i < n; i++) {
        Op op = B[i].op;
        if (isHat(op)) { hats.push_back(i); st.clear(); continue; }
        if (op == Op::Forever || op == Op::Repeat || op == Op::While || op == Op::RepeatUntil || op == Op::If || op == Op::RepeatEvery || op == Op::ForRange || op == Op::ForEach) st.push_back({i, op});
        else if (op == Op::Else) {
            if (!st.empty() && st.back().op == Op::If) { match[st.back().idx] = i; st.back() = {i, Op::Else}; }
        } else if (op == Op::EndIf) {
            if (!st.empty() && (st.back().op == Op::If || st.back().op == Op::Else)) { match[st.back().idx] = i; st.pop_back(); }
        } else if (op == Op::LoopEnd) {
            if (!st.empty() && (st.back().op == Op::Forever || st.back().op == Op::Repeat || st.back().op == Op::While || st.back().op == Op::RepeatUntil || st.back().op == Op::RepeatEvery || st.back().op == Op::ForRange || st.back().op == Op::ForEach)) {
                match[st.back().idx] = i;
                match[i] = st.back().idx;
                st.pop_back();
            }
        }
    }
}

void Game::resetVars() {
    timeScale_ = 1.f;
    vars.clear();
    lists_.clear();
    tilt_.clear();
    if (bgCamMode != 0) { bgCamMode = 0; camBgTex_.clear(); if (onCamera) onCamera(0); }
    for (auto& g : proj.globalVars) {  // vida y municion empiezan llenas
        std::string k = normName(g);
        vars[k] = k == "vida" ? 100.0 : k == "municion" ? 30.0 : 0.0;
    }
    if (proj.ui.on) {   // pantalla pro: variables listas
        if (!vars.count("vida")) vars["vida"] = 100.0;
        if (proj.ui.shield && !vars.count("escudo")) vars["escudo"] = 100.0;
        if (proj.ui.timer && !vars.count("tiempo")) vars["tiempo"] = 0.0;
        if (proj.ui.score && !vars.count("puntos")) vars["puntos"] = 0.0;
    }
    for (auto& kv : devVars) { std::string k = normName(kv.first); char* e = nullptr; double d = std::strtod(kv.second.c_str(), &e); vars[k] = (e && *e == 0 && !kv.second.empty()) ? Val(d) : Val::text(kv.second); }
}

int Game::spawnCloneAt(int src, const V3* pos, bool endGen) {
    if (src < 0 || src >= (int)sc->objs.size()) return -1;
    Obj c = sc->objs[src];
    c.clone = true;
    c.alive = true;
    c.endGen = endGen;
    if (pos) c.pos = *pos;
    if (c.name.size() < 5 || c.name.compare(c.name.size() - 5, 5, "_clon") != 0) c.name += "_clon";
    ObjState ns = st_[src];
    int idx = -1;
    for (size_t k = freeHint_; k < sc->objs.size(); k++)   // hueco de un clon ya borrado
        if (sc->objs[k].clone && !sc->objs[k].alive && !sc->objs[k].ghost && (int)k != src) { idx = (int)k; freeHint_ = k + 1; break; }
    if (idx < 0) freeHint_ = 0;
    if (idx >= 0) {
        runners_.erase(std::remove_if(runners_.begin(), runners_.end(), [&](const Runner& r) { return r.obj == idx; }), runners_.end());
        sc->objs[idx] = std::move(c);
        base_[idx] = base_[src]; near_[idx] = 0; moving_[idx] = 0; last_[idx] = sc->objs[idx].pos; cmp_[idx] = cmp_[src];
        st_[idx] = std::move(ns);
    } else {
        if (sc->objs.size() >= kMaxObjs) return -1;
        sc->objs.push_back(std::move(c));
        idx = (int)sc->objs.size() - 1;
        base_.push_back(base_[src]); near_.push_back(0); moving_.push_back(0);
        last_.push_back(sc->objs[idx].pos); cmp_.push_back(cmp_[src]); st_.push_back(std::move(ns));
    }
    st_[idx].hatState.assign(sc->objs[idx].blocks.size(), 0);
    fireHat(idx, Op::WhenCloneStart);
    return idx;
}

void Game::endlessTick() {
    if (!endRT_.on || !sc || !sc->endless) return;
    int pi = playerIndex(*sc);
    V3 ref = sc->is3d ? pos : (cam2Mode != 0 || pi < 0 ? V3{cam2x, cam2y, 0.f} : sc->objs[pi].pos);
    float u = endProgress(endRT_.info, ref);
    int guard = 0;
    while (guard++ < 4 && u + sc->endAhead >= endRT_.info.start + endRT_.info.len * endRT_.k) {
        std::vector<std::pair<int, V3>> out;
        endPlaceChunk(*sc, endRT_.info, endRT_.k, endRT_.rng, out);
        for (auto& pr : out) spawnCloneAt(pr.first, &pr.second, true);
        endRT_.k++;
    }
    for (auto& o : sc->objs)   // lo que quedó muy atrás se borra para no gastar memoria
        if (o.endGen && o.alive && endProgress(endRT_.info, o.pos) < u - sc->endBehind - endRT_.info.len) o.alive = false;
}

void Game::load(Project p) {
    proj = std::move(p);
    for (auto& sn : proj.scenes) ensurePlayer(sn);
    sc = nullptr;
    projs.clear();
    debris.clear();
    parts.clear();
    pendingClones_.clear();
    shakeT = 0;
    camMode = proj.player.cam;
    walkSpeed = proj.player.speed > 0 ? proj.player.speed : 4.5f;
    aiming = false; aimK = 0.f; fovDeg = proj.player.fov;
    jumpPow = proj.player.jump > 0 ? proj.player.jump : 7.f;
    hurtFlash = 0;
    resetVars();
    hitT = 0; crouchK_ = 0;
    carIdx = nearCar = -1; carSpeed_ = 0.f; carLean_ = 0.f; cineIdx_ = -1; prevCam_ = proj.player.cam;
    shown.clear(); texts.clear();
    runners_.clear();
    shootCd = recoil = flash = 0;
    initWeapons();
    gravX_ = 0; gravY_ = -10;
    volume = 100;
    if (!proj.scenes.empty()) enterScene(proj.scenes[0].name);
}

void Game::bindScene(int idx) {
    carIdx = nearCar = -1; cineIdx_ = -1; cineWaitRunner_ = -1;
    aiMode_ = 0;
    if (idx < 0 || idx >= (int)proj.scenes.size()) { sc = nullptr; return; }
    sc = &proj.scenes[idx];
}

void Game::enterScene(const std::string& name) {
    Scene* found = nullptr;
    for (auto& s : proj.scenes) if (s.name == name) { found = &s; break; }
    if (!found) return;
    if (sc && sc != found && !proj.keepAcrossScenes) {   // cada escena es independiente: música, sonidos y variables empiezan de cero
        if (onMusic) onMusic("", false);
        if (onStopSounds) onStopSounds();
        std::map<std::string, Val> keep;   // las variables globales de la app conservan su valor
        for (auto& g : proj.globalVars) { auto it = vars.find(normName(g)); if (it != vars.end()) keep[it->first] = it->second; }
        resetVars();
        for (auto& kv : keep) vars[kv.first] = kv.second;
        shown.clear(); texts.clear();
    }
    sc = found;
    booms.clear();
    if (carIdx >= 0) camMode = prevCam_;
    carIdx = nearCar = -1; carSpeed_ = 0.f; carLean_ = 0.f; carHpCur_ = 0.f; aiMode_ = 0;   // siempre se empieza fuera del auto, sin estado viejo
    runners_.clear();
    near_.assign(sc->objs.size(), 0);
    moving_.assign(sc->objs.size(), 0);
    last_.clear();
    for (auto& ob : sc->objs) last_.push_back(ob.pos);
    plMoving_ = plAir_ = false;
    base_.clear();
    cmp_.assign(sc->objs.size(), Compiled());
    st_.assign(sc->objs.size(), ObjState());
    for (size_t qi = 0; qi < sc->objs.size(); qi++) if (sc->objs[qi].routeOn && sc->objs[qi].routeDelay > 0.f) st_[qi].rwait = sc->objs[qi].routeDelay;   // espera inicial de la ruta
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if (!sc->is3d) {   // tamaño negativo (viejo truco para voltear) -> se convierte en «voltear»; así los bloques y toques siguen funcionando
            if (o.scale.x < 0.f) { o.scale.x = -o.scale.x; o.flipX = !o.flipX; }
            if (o.scale.y < 0.f) { o.scale.y = -o.scale.y; o.flipY = !o.flipY; }
        }
        base_.push_back(o.scale);
        compileObj(o.blocks, cmp_[i].match, cmp_[i].hats);
        st_[i].hatState.assign(o.blocks.size(), 0);
        if (!o.looks.empty()) {
            if (o.kind != Kind::Model && !o.looks[0].empty() && std::find(o.looks.begin(), o.looks.end(), o.tex) == o.looks.end()) o.tex = o.looks[0];   // manda la primera apariencia de la lista
            auto it = std::find(o.looks.begin(), o.looks.end(), o.tex);
            st_[i].look = it == o.looks.end() ? 0 : (int)(it - o.looks.begin());
        }
    }
    keep_.clear(); keepAll_ = false; keepExcept_.clear(); pushRules_.clear();
    worldFrozen_ = playerFrozen_ = false; flashOn_ = proj.player.flashlight && proj.player.flashOnStart;
    camRoll = camRollTarget = camRollTotal = bobPhase_ = bobAmp_ = bobRoll_ = 0.f;
    pos = sc->start;
    yaw = 0;
    int pi = playerIndex(*sc);
    if (pi >= 0) {
        pos = {sc->objs[pi].pos.x, sc->objs[pi].pos.y - 0.85f, sc->objs[pi].pos.z};
        yaw = sc->objs[pi].yaw * kRad;
    }
    bodyYaw = yaw;
    projs.clear();
    debris.clear();
    parts.clear();
    pendingClones_.clear();
    endRT_ = EndRT();
    vel = V3();
    pitch = 0;
    for (size_t i = 0; i < sc->objs.size(); i++) st_[i].hp = sc->objs[i].ai.hp;
    applyCam();
    cam2x = cam2y = 0.f; cam2Zoom = 100.f; cam2Mode = 0; cam2Target.clear();
    if (sc->endless) { endRT_.info = endAnalyze(*sc); endRT_.on = endRT_.info.ok; endRT_.rng = 2463534242u ^ (unsigned)(proj.scenes.size() * 977 + sc->objs.size()); }
    if (!sc->is3d && sc->map2on) {   // mapa 2D: el héroe y la cámara empiezan en la posición elegida
        int h = heroIdx();
        if (h >= 0) { sc->objs[h].pos.x = sc->map2x; sc->objs[h].pos.y = sc->map2y; }
        cam2x = sc->map2x; cam2y = sc->map2y;
    }
    for (size_t i = 0; i < sc->objs.size(); i++) fireHat((int)i, Op::WhenStart);
}

// ---------------------------------------------------------------- guiones
int Game::startScript(int obj, int hatIdx) {
    if (obj >= 0 && obj < (int)st_.size() && (st_[obj].pausedAll || std::find(st_[obj].pausedHats.begin(), st_[obj].pausedHats.end(), hatIdx) != st_[obj].pausedHats.end())) return -1;   // torre pausada
    for (auto& r : runners_)
        if (r.obj == obj && r.hat == hatIdx && !r.done) {  // reinicia el guion
            r.pc = hatIdx + 1; r.loops.clear(); r.wait = 0; r.gT = 0; r.gMode = 0; r.waitIds.clear();
            return r.id;
        }
    Runner r;
    r.id = nextId_++;
    r.obj = obj;
    r.hat = hatIdx;
    r.pc = hatIdx + 1;
    const auto& hats = cmp_[obj].hats;
    int total = (int)sc->objs[obj].blocks.size();
    r.end = total;
    for (int h : hats) if (h > hatIdx) { r.end = h; break; }
    runners_.push_back(std::move(r));
    return runners_.back().id;
}

void Game::fireHat(int obj, Op hat) {
    if (obj < 0 || obj >= (int)cmp_.size()) return;
    const auto& B = sc->objs[obj].blocks;
    for (int h : cmp_[obj].hats) if (B[h].op == hat) startScript(obj, h);
}

void Game::fireAll(Op hat) {
    if (!sc) return;
    for (size_t i = 0; i < sc->objs.size() && i < cmp_.size(); i++) fireHat((int)i, hat);
}

// Lanza los eventos que llevan un texto (boton, objeto que se mueve).
void Game::fireHatText(Op hat, const std::string& txt) {
    if (!sc) return;
    std::string k = normName(txt);
    for (size_t i = 0; i < sc->objs.size() && i < cmp_.size(); i++) {
        const auto& B = sc->objs[i].blocks;
        for (int h : cmp_[i].hats) if (B[h].op == hat && normName(B[h].t) == k) startScript((int)i, h);
    }
}

// Eventos nuevos: disparar, botones, movimiento de objetos y del jugador.
void Game::eventsV6(float dt, const Input& in) {
    (void)dt;
    for (auto& b : in.buttons) fireHatText(Op::WhenButton, b);
    int pi = playerIndex(*sc);
    // objetos que empiezan a moverse
    for (size_t i = 0; i < sc->objs.size() && i < last_.size() && i < moving_.size(); i++) {
        const Obj& o = sc->objs[i];
        V3 d = o.pos - last_[i];
        bool mv = o.alive && (std::fabs(d.x) + std::fabs(d.y) + std::fabs(d.z)) > (sc->is3d ? 0.004f : 0.3f);
        last_[i] = o.pos;
        if (mv && !moving_[i]) {
            if ((int)i != pi) {  // los que no tienen nombre: "este mismo objeto"
                const auto& B = o.blocks;
                for (int h : cmp_[i].hats) if (B[h].op == Op::WhenObjMoves && B[h].t.empty()) startScript((int)i, h);
            }
            for (size_t j = 0; j < sc->objs.size() && j < cmp_.size(); j++) {
                const auto& B = sc->objs[j].blocks;
                for (int h : cmp_[j].hats)
                    if (B[h].op == Op::WhenObjMoves && !B[h].t.empty() && normName(B[h].t) == normName(o.name)) startScript((int)j, h);
            }
        }
        moving_[i] = mv;
    }
    if (sc->is3d) {
        bool mv = std::fabs(vel.x) + std::fabs(vel.z) > 0.3f && ground;
        if (mv && !plMoving_) fireAll(Op::WhenPlayerMoves);
        plMoving_ = mv;
        bool air = !ground && vel.y > 0.5f;
        if (air && !plAir_) fireAll(Op::WhenPlayerJumps);
        plAir_ = air || (!ground && plAir_);
        if (ground) plAir_ = false;
    }
}

void Game::broadcast(const std::string& msg, std::vector<int>* ids) {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        const auto& B = sc->objs[i].blocks;
        for (int h : cmp_[i].hats)
            if (B[h].op == Op::WhenReceive && B[h].t == msg) {
                int id = startScript((int)i, h);
                if (ids) ids->push_back(id);
            }
    }
}

// Modo listado: lista de imágenes (apariencias) y cuál es la actual.
static bool listSeq(const Obj& o, int look, std::vector<std::string>& seq, int& cur) {
    seq.clear(); cur = 0;
    if (o.looks.empty()) return false;
    auto it = std::find(o.looks.begin(), o.looks.end(), o.tex);
    if (it == o.looks.end()) { if (!o.tex.empty()) seq.push_back(o.tex); seq.insert(seq.end(), o.looks.begin(), o.looks.end()); cur = 0; }
    else { seq = o.looks; cur = (int)(it - o.looks.begin()); (void)look; }
    return seq.size() > 1;
}

void Game::listEntries(int idx, std::vector<ListEnt>& out) const {
    out.clear();
    if (!sc || idx < 0 || idx >= (int)sc->objs.size()) return;
    const Obj& o = sc->objs[idx];
    std::vector<std::string> seq; int cur;
    if (!listSeq(o, 0, seq, cur)) return;
    int n = (int)seq.size();
    float pos = idx < (int)st_.size() && st_[idx].listInit ? st_[idx].listPos : (float)cur;
    float pitch = (o.listHoriz ? o.scale.x : o.scale.y) + o.listGap;
    int lo = (int)std::floor(pos) - o.listShow, hi = (int)std::ceil(pos) + o.listShow;
    for (int j = lo; j <= hi; j++) {
        int m = j;
        if (o.listWrap) m = ((j % n) + n) % n; else if (j < 0 || j >= n) continue;
        float d = (float)j - pos, ad = std::fabs(d);
        if (ad > o.listShow + 0.001f) continue;
        float a = 1.f - (1.f - o.listFade / 100.f) * std::min(1.f, ad);
        if (ad > o.listShow - 0.5f + 0.001f && o.listShow > 0) a *= std::max(0.f, (o.listShow + 0.5f - ad));   // la de la orilla entra/sale suavemente
        out.push_back({o.listHoriz ? d * pitch : -d * pitch, seq[m], a});
    }
    std::stable_sort(out.begin(), out.end(), [](const ListEnt& x, const ListEnt& y) { return std::fabs(x.off) > std::fabs(y.off); });   // la principal al final (arriba de todas)
}

int Game::findObj(const std::string& name) const {
    if (!sc) return -1;
    std::string k = normName(name);
    for (size_t i = 0; i < sc->objs.size(); i++) if (normName(sc->objs[i].name) == k) return (int)i;
    return -1;
}

// Rectangulo girado en el plano del suelo (3D: X,Z) o de la pantalla (2D: X,Y). (ax,ay) = eje local X girado.
struct Quad { float cx, cy, hx, hy, ax, ay; };
static Quad quadOf(const Obj& o, bool is3) {
    Quad q;
    q.cx = o.pos.x;
    q.hx = o.scale.x * .5f;
    if (is3) {
        float a = o.yaw * 0.0174532925f;
        q.cy = o.pos.z; q.hy = o.scale.z * .5f; q.ax = std::cos(a); q.ay = -std::sin(a);
    } else {
        float a = -(o.yaw - 90.f) * 0.0174532925f;
        q.cy = o.pos.y; q.hy = o.scale.y * .5f; q.ax = std::cos(a); q.ay = std::sin(a);
    }
    return q;
}
static bool quadsOverlap(const Quad& A, const Quad& B, float eps) {
    float ax[4][2] = {{A.ax, A.ay}, {-A.ay, A.ax}, {B.ax, B.ay}, {-B.ay, B.ax}};
    float dx = B.cx - A.cx, dy = B.cy - A.cy;
    for (auto& u : ax) {
        float rA = A.hx * std::fabs(u[0] * A.ax + u[1] * A.ay) + A.hy * std::fabs(-u[0] * A.ay + u[1] * A.ax);
        float rB = B.hx * std::fabs(u[0] * B.ax + u[1] * B.ay) + B.hy * std::fabs(-u[0] * B.ay + u[1] * B.ax);
        if (std::fabs(dx * u[0] + dy * u[1]) >= rA + rB - eps) return false;
    }
    return true;
}

void Game::effBox(const Obj& o, float& cx, float& cy, float& cz, float& hx, float& hy, float& hz) const {
    cx = o.pos.x; cy = o.pos.y; cz = o.pos.z; hx = o.scale.x * .5f; hy = o.scale.y * .5f; hz = o.scale.z * .5f;
    if (o.kind != Kind::Model || o.model.empty() || o.ai.type != AiType::None) return;
    modelBoxes(o.model);   // llena mbnd_
    auto it = mbnd_.find(o.model);
    if (it == mbnd_.end()) return;
    const auto& b = it->second;
    float ox = (b[0] + b[3]) * .5f * o.scale.x, oz = (b[2] + b[5]) * .5f * o.scale.z;
    float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
    cx = o.pos.x + c * ox + s * oz; cz = o.pos.z - s * ox + c * oz;
    cy = o.pos.y + (b[1] + b[4]) * .5f * o.scale.y;
    hx = (b[3] - b[0]) * .5f * o.scale.x; hy = (b[4] - b[1]) * .5f * o.scale.y; hz = (b[5] - b[2]) * .5f * o.scale.z;
}

std::array<float, 4> Game::spriteRect(const std::string& tex) const {
    auto it = sprr_.find(tex);
    if (it != sprr_.end()) return it->second;
    std::array<float, 4> r{0.5f, 0.5f, 1.f, 1.f};
    auto ta = proj.assets.find(tex);
    if (ta != proj.assets.end()) {
        int w = 0, h = 0, c = 0;
        stbi_set_flip_vertically_on_load(0);
        unsigned char* d = stbi_load_from_memory(ta->second.data(), (int)ta->second.size(), &w, &h, &c, 4);
        if (d) {
            int x0 = w, x1 = -1, y0 = h, y1 = -1;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    if (d[((size_t)y * w + x) * 4 + 3] > 40) { x0 = std::min(x0, x); x1 = std::max(x1, x); y0 = std::min(y0, y); y1 = std::max(y1, y); }
            if (x1 >= x0 && y1 >= y0) r = {((x0 + x1 + 1) * 0.5f) / w, ((y0 + y1 + 1) * 0.5f) / h, (float)(x1 - x0 + 1) / w, (float)(y1 - y0 + 1) / h};
            stbi_image_free(d);
        }
    }
    return sprr_[tex] = r;
}

bool Game::overlap(const Obj& a, const Obj& b) const {
    bool is3 = sc && sc->is3d;
    if (!is3) {
        auto q2 = [&](const Obj& o) {   // la caja se ajusta a lo que realmente se ve de la imagen (sin bordes transparentes)
            Quad q = quadOf(o, false);
            if (o.kind != Kind::Model && !o.tex.empty() && !o.bg) {
                auto r = spriteRect(o.tex);
                float ox = (r[0] - 0.5f) * o.scale.x, oy = (0.5f - r[1]) * o.scale.y;
                q.cx += q.ax * ox - q.ay * oy; q.cy += q.ay * ox + q.ax * oy;
                q.hx *= r[2]; q.hy *= r[3];
            }
            return q;
        };
        return quadsOverlap(q2(a), q2(b), 0.f);
    }
    float ax, ay, az, ahx, ahy, ahz, bx, by, bz, bhx, bhy, bhz;
    effBox(a, ax, ay, az, ahx, ahy, ahz); effBox(b, bx, by, bz, bhx, bhy, bhz);
    if (std::fabs(ay - by) >= ahy + bhy) return false;
    float ra = a.yaw * 0.0174532925f, rb = b.yaw * 0.0174532925f;
    Quad A{ax, az, ahx, ahz, std::cos(ra), -std::sin(ra)}, B{bx, bz, bhx, bhz, std::cos(rb), -std::sin(rb)};
    return quadsOverlap(A, B, 0.f);  // la colision gira con el objeto y sigue la forma real del modelo
}

// ---------------------------------------------------------------- variables y formulas
Val Game::getVar(const std::string& name, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        auto it = st_[obj].locals.find(k);
        if (it != st_[obj].locals.end()) return it->second;
    }
    auto it = vars.find(k);
    return it == vars.end() ? Val(0.0) : it->second;
}

void Game::setVar(const std::string& name, Val v, int obj) {
    std::string k = vkey(name);
    if (obj >= 0 && obj < (int)st_.size()) {
        for (auto& lv : sc->objs[obj].localVars)
            if (vkey(lv) == k) { st_[obj].locals[k] = v; return; }
    }
    vars[k] = v;
}

Val Game::eval(const std::string& f, int obj) {
    int prev = cur_;
    cur_ = obj;
    Val v = evalFormula(f, this);
    cur_ = prev;
    return v;
}

std::string Game::evalText(const std::string& f, int obj) {
    if (f.find('(') != std::string::npos) return eval(f, obj).txt();   // trae funciones: se evalúa como fórmula
    std::string out;
    size_t p = 0;
    while (p < f.size()) {
        if (f[p] == '"') {
            size_t q = f.find('"', p + 1);
            if (q != std::string::npos) {
                std::string nm = f.substr(p + 1, q - p - 1);
                int prev = cur_; cur_ = obj;
                Val v = getVar(nm, obj);
                cur_ = prev;
                out += v.txt();
                p = q + 1;
                continue;
            }
        }
        out += f[p++];
    }
    return out;
}

bool Game::lookup(const std::string& nameIn, const std::vector<Val>& a, Val& out) {
    bool quoted = !nameIn.empty() && nameIn[0] == '"';
    std::string n = quoted ? nameIn.substr(1) : nameIn;
    int o = cur_;
    Obj* ob = (sc && o >= 0 && o < (int)sc->objs.size()) ? &sc->objs[o] : nullptr;
    ObjState* os = (ob && o < (int)st_.size()) ? &st_[o] : nullptr;
    auto N = [&](size_t i) { return i < a.size() ? a[i].num() : 0.0; };
    auto S = [&](size_t i) { return i < a.size() ? a[i].txt() : std::string(); };

    if (quoted) {  // variable explicita
        out = getVar(n, o);
        return true;
    }
    if (n == "elemento de lista" || n == "largo de lista" || n == "lista contiene") {   // listas
        auto it = lists_.find(normName(S(0)));
        const std::vector<Val> empty;
        const std::vector<Val>& L = it != lists_.end() ? it->second : empty;
        if (n == "largo de lista") { out = (double)L.size(); return true; }
        if (n == "elemento de lista") { int k = (int)N(1); out = (k >= 1 && k <= (int)L.size()) ? L[k - 1] : Val(0.0); return true; }
        double hit = 0; std::string want = a.size() > 1 ? a[1].txt() : "";
        for (auto& v : L) if (v.txt() == want) { hit = 1; break; }
        out = hit; return true;
    }
    bool is3 = sc && sc->is3d;
    float sw = stageW(), sh = kView2DHeight;
    auto touchX = [&](int i) { return (in_.touch[i].x - 0.5f) * sw; };
    auto touchY = [&](int i) { return (0.5f - in_.touch[i].y) * sh; };
    auto nthTouch = [&](int k) {  // k = 1..: indice del k-esimo dedo actual
        int c = 0;
        for (int i = 0; i < 10; i++) if (in_.touch[i].down && ++c == k) return i;
        return -1;
    };
    auto objByArg = [&](size_t i) { return findObj(S(i)); };
    auto objPos = [&](int idx, V3& p) {
        if (idx >= 0) { p = sc->objs[idx].pos; return true; }
        return false;
    };

    // --- propiedades del objeto
    if (ob) {
        if (n == "get_object_name") { out = Val::text(ob->name); return true; }
        if (n == "direccion" || n == "direccion de la mirada") { out = ob->yaw; return true; }
        if (n == "transparencia") { out = ob->transp; return true; }
        if (n == "brillo") { out = ob->bright; return true; }
        if (n == "color") { out = ob->hue; return true; }
        if (n == "numero_fondo") { out = os->look + 1; return true; }
        if (n == "nombre_fondo") { out = Val::text(os->look < (int)ob->looks.size() ? ob->looks[os->look] : ""); return true; }
        if (n == "numero de fondos") { out = (double)ob->looks.size(); return true; }
        if (n == "posicion x") { out = ob->pos.x; return true; }
        if (n == "posicion y") { out = ob->pos.y; return true; }
        if (n == "tamano") { out = os->sizePct; return true; }
        if (n == "width") { out = ob->scale.x; return true; }
        if (n == "height") { out = ob->scale.y; return true; }
        if (n == "capa") { out = ob->layer; return true; }
        if (n == "velocidad x") { out = os->vel.x; return true; }
        if (n == "velocidad y") { out = os->vel.y; return true; }
        if (n == "velocidad angular") { out = os->spin; return true; }
        if (n == "tocar_objeto" || n == "touches_object_by_name") {
            int j = objByArg(0);
            out = (j >= 0 && j != o && ob->visible && sc->objs[j].alive && sc->objs[j].visible && overlap(*ob, sc->objs[j])) ? 1 : 0;
            return true;
        }
        if (n == "tocar_bordes") {
            out = (!is3 && (std::fabs(ob->pos.x) + ob->scale.x * .5f > sw * .5f || std::fabs(ob->pos.y) + ob->scale.y * .5f > sh * .5f)) ? 1 : 0;
            return true;
        }
        if (n == "tocar_dedos") {
            bool hit = false;
            if (!is3)
                for (int i = 0; i < 10; i++)
                    if (in_.touch[i].down && std::fabs(touchX(i) - ob->pos.x) <= ob->scale.x * .5f &&
                        std::fabs(touchY(i) - ob->pos.y) <= ob->scale.y * .5f) hit = true;
            out = hit ? 1 : 0;
            return true;
        }
        if (n == "toca el color" || n == "color toca el color") { out = 0; return true; }
    }

    // --- dispositivo
    if (n == "volumen") { out = volume; return true; }
    if (n == "stage width") { out = sw; return true; }
    if (n == "stage height") { out = sh; return true; }
    if (n == "micro volume" || n == "micro frequency") { out = 0; return true; }
    if (n == "local server ip") { out = Val::text(""); return true; }
    if (n == "local server port") { out = 0; return true; }
    if (n == "battery percentage") { out = dev.battery; return true; }
    if (n == "connected to internet") { out = dev.online; return true; }
    if (n == "cpu architecture") { out = Val::text("arm64"); return true; }
    if (n == "fps") { out = fps_; return true; }
    if (n == "clipboard_text") { out = Val::text(dev.clipboard); return true; }
    if (n == "keyboard_height") { out = dev.keyboardH; return true; }
    if (n == "color a x y" || n == "color es igual a color con % tolerancia") { out = 0; return true; }
    if (n == "acceleracion x") { out = dev.accel[0]; return true; }
    if (n == "acceleracion y") { out = dev.accel[1]; return true; }
    if (n == "acceleracion_z") { out = dev.accel[2]; return true; }
    if (n == "inclinacion x") { out = std::atan2(dev.accel[0], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "inclinacion y") { out = std::atan2(dev.accel[1], dev.accel[2] == 0 ? 9.8f : dev.accel[2]) / kRad; return true; }
    if (n == "giro x") { out = dev.gyro[0]; return true; }
    if (n == "giro y") { out = dev.gyro[1]; return true; }
    if (n == "giro z") { out = dev.gyro[2]; return true; }
    if (n == "direccion_compass") { out = dev.compass; return true; }
    if (n == "latitud") { out = dev.lat; return true; }
    if (n == "longitud") { out = dev.lon; return true; }
    if (n == "precision_localizacion") { out = dev.acc; return true; }
    if (n == "altitud") { out = dev.alt; return true; }
    if (n == "idioma del usuario") { out = Val::text(dev.lang); return true; }

    // --- toques
    if (n == "toque pantalla x" || n == "toque pantalla y" || n == "pantalla_tocada") {
        int i = a.empty() ? -1 : (int)N(0) - 1;
        if (a.empty()) { for (int k = 9; k >= 0; k--) if (in_.touch[k].down) { i = k; break; } }
        if (n == "pantalla_tocada") out = (i >= 0 && i < 10 && in_.touch[i].down) ? 1 : 0;
        else if (i < 0 || i > 9) out = 0;
        else out = n == "toque pantalla x" ? touchX(i) : touchY(i);
        return true;
    }
    if (n == "ultimo_indice_de_toque_pantalla") { int last = 0; for (int k = 0; k < 10; k++) if (in_.touch[k].down) last = k + 1; out = last; return true; }
    if (n == "numero de toques actuales") { int c = 0; for (auto& t : in_.touch) c += t.down; out = c; return true; }
    if (n == "indice del toque actual") { out = nthTouch((int)N(0)) + 1; return true; }

    // --- fecha y hora
    if (n == "cronometro") { out = time; return true; }
    if (n == "ano" || n == "mes" || n == "dia" || n == "dia de la semana" || n == "hora" || n == "minuto" || n == "segundo") {
        std::time_t t = std::time(nullptr);
        std::tm* tm = std::localtime(&t);
        out = n == "ano" ? tm->tm_year + 1900 : n == "mes" ? tm->tm_mon + 1 : n == "dia" ? tm->tm_mday
              : n == "dia de la semana" ? (tm->tm_wday == 0 ? 7 : tm->tm_wday) : n == "hora" ? tm->tm_hour
              : n == "minuto" ? tm->tm_min : tm->tm_sec;
        return true;
    }

    // --- propiedades de OTRO objeto (se elige por nombre; en 2D y 3D)
    if (a.size() >= 1 && (n == "posicion x de" || n == "posicion y de" || n == "posicion z de" || n == "tamano de" || n == "direccion de" ||
                          n == "ancho de" || n == "alto de" || n == "capa de" || n == "transparencia de")) {
        std::string ks = normName(S(0));
        if (sc && sc->is3d && (ks == "jugador" || ks == "player")) {
            out = n == "posicion x de" ? pos.x : n == "posicion y de" ? pos.y : n == "posicion z de" ? pos.z : 0.0;
            return true;
        }
        int j = objByArg(0);
        if (j < 0) { out = 0; return true; }
        const Obj& t = sc->objs[j];
        if (n == "posicion x de") out = t.pos.x; else if (n == "posicion y de") out = t.pos.y; else if (n == "posicion z de") out = t.pos.z;
        else if (n == "tamano de") out = st_[j].sizePct; else if (n == "direccion de") out = t.yaw;
        else if (n == "ancho de") out = t.scale.x; else if (n == "alto de") out = t.scale.y;
        else if (n == "capa de") out = t.layer; else out = t.transp;
        return true;
    }
    if (a.size() >= 2 && n == "distancia entre") {
        V3 p, q;
        if (objPos(objByArg(0), p) && objPos(objByArg(1), q)) out = (sc && sc->is3d) ? len(p - q) : std::sqrt((p.x - q.x) * (p.x - q.x) + (p.y - q.y) * (p.y - q.y)); else out = 0;
        return true;
    }

    // --- 3D
    if (n == "distancia al jugador") {
        out = (sc && sc->is3d && ob) ? len(V3{ob->pos.x - pos.x, ob->pos.y - (pos.y + 0.85f), ob->pos.z - pos.z}) : 0.0;
        return true;
    }
    if (n == "delta-time") { out = 1.0 / std::max(1.f, fps_); return true; }
    if (n.compare(0, 3, "3d ") == 0 && a.size() >= 1) {
        std::string what = n.substr(3);
        if (what == "distance between") {
            V3 p, q;
            if (objPos(objByArg(0), p) && objPos(objByArg(1), q)) out = len(p - q); else out = 0;
            return true;
        }
        int j = objByArg(0);
        if (j < 0) { out = 0; return true; }
        const Obj& t = sc->objs[j];
        if (what == "position x") out = t.pos.x; else if (what == "position y") out = t.pos.y; else if (what == "position z") out = t.pos.z;
        else if (what == "rotation y") out = t.yaw; else if (what == "rotation x" || what == "rotation z") out = 0;
        else if (what == "scale x") out = t.scale.x; else if (what == "scale y") out = t.scale.y; else if (what == "scale z") out = t.scale.z;
        else if (what == "velocity x") out = st_[j].vel.x; else if (what == "velocity y") out = st_[j].vel.y; else if (what == "velocity z") out = st_[j].vel.z;
        else return false;
        return true;
    }
    if (n == "object touches object") {
        int i = objByArg(0), j = objByArg(1);
        out = (i >= 0 && j >= 0 && overlap(sc->objs[i], sc->objs[j])) ? 1 : 0;
        return true;
    }
    if (n.compare(0, 7, "camera ") == 0) {
        std::string w = n.substr(7);
        V3 e = is3 ? eye() : V3(), f = is3 ? forward() : V3();
        if (w == "position x") out = e.x; else if (w == "position y") out = e.y; else if (w == "position z") out = e.z;
        else if (w == "direction x") out = f.x; else if (w == "direction y") out = f.y; else if (w == "direction z") out = f.z;
        else if (w == "rotation x") out = pitch / kRad; else if (w == "rotation y") out = yaw / kRad; else if (w == "rotation z") out = 0;
        else return false;
        return true;
    }

    // --- variables sin comillas
    std::string k = vkey(n);
    if (a.empty()) {
        if (os && os->locals.count(k)) { out = os->locals[k]; return true; }
        auto it = vars.find(k);
        if (it != vars.end()) { out = it->second; return true; }
        if (ob) for (auto& lv : ob->localVars) if (vkey(lv) == k) { out = 0; return true; }
    }
    return false;
}

// ---------------------------------------------------------------- mundo 3D
// Colision que sigue la forma del modelo: se marcan las celdas de una rejilla 16x16x16 que tocan la malla y se
// juntan en cajas; donde el modelo esta vacio (huecos, puertas, techos abiertos) no hay colision.
void Game::bodyDims(float& hw, float& h) const {
    hw = 0.3f; h = 1.7f;
    const std::string& mn = proj.player.model;
    if (mn.empty() || !sc) return;
    int pi = playerIndex(*sc);
    if (pi < 0) return;
    modelBoxes(mn);
    auto it = mbnd_.find(mn);
    if (it == mbnd_.end()) return;
    const auto& b = it->second;
    V3 s0 = sc->objs[pi].scale;
    float ex = b[3] - b[0], ey = b[4] - b[1], ez = b[5] - b[2];
    float sx = s0.x, sy = s0.y, sz = s0.z;
    if (proj.player.fit) { float k = std::min(s0.x / std::max(0.001f, ex), std::min(s0.y / std::max(0.001f, ey), s0.z / std::max(0.001f, ez))); sx = sy = sz = k; }
    sx *= proj.player.mscale; sy *= proj.player.mscale; sz *= proj.player.mscale;
    hw = std::max(0.2f, std::min(2.5f, 0.5f * std::sqrt(std::max(0.01f, ex * sx * ez * sz))));
    h = std::max(0.6f, std::min(8.f, ey * sy));
}

const std::vector<Game::CBox>& Game::modelBoxes(const std::string& name) const {
    auto it = mcol_.find(name);
    if (it != mcol_.end()) return it->second;
    std::vector<CBox>& out = mcol_[name];
    auto a = proj.assets.find(name);
    ModelData md;
    if (a == proj.assets.end() || !modelRead(a->second.data(), a->second.size(), md)) return out;
    {   // límites exactos de la malla (la física los usa para que el modelo no flote)
        std::array<float, 6> bb = {1e30f, 1e30f, 1e30f, -1e30f, -1e30f, -1e30f};
        for (size_t t = 0; t < md.idx.size(); t++) {
            const float* p = &md.v[md.idx[t] * 8];
            for (int c = 0; c < 3; c++) { bb[c] = std::min(bb[c], p[c]); bb[3 + c] = std::max(bb[3 + c], p[c]); }
        }
        if (bb[3] > bb[0] && bb[4] > bb[1] && bb[5] > bb[2]) mbnd_[name] = bb;
    }
    // Imagen de la textura: las partes transparentes NO cuentan para la colisión.
    std::vector<unsigned char> tpx; int tw = 0, th = 0;
    if (!md.tex.empty()) {
        auto ta = proj.assets.find(md.tex);
        if (ta != proj.assets.end()) {
            int c = 0; stbi_set_flip_vertically_on_load(0);
            unsigned char* d = stbi_load_from_memory(ta->second.data(), (int)ta->second.size(), &tw, &th, &c, 4);
            if (d) { tpx.assign(d, d + (size_t)tw * th * 4); stbi_image_free(d); }
        }
    }
    auto opaqueAt = [&](float u, float v) {
        if (tpx.empty()) return true;
        u -= std::floor(u); v -= std::floor(v);
        int x = std::min(tw - 1, (int)(u * tw)), y = std::min(th - 1, (int)((1.f - v) * th));
        return tpx[((size_t)y * tw + x) * 4 + 3] >= 80;
    };
    Ramp& rp = mramp_[name];
    rp.G = 96; rp.c.assign((size_t)rp.G * rp.G, std::vector<float>());
    auto rcell = [&](float v) { return std::max(0, std::min(rp.G - 1, (int)std::floor((v + 0.5f) * rp.G))); };
    const int N = 64;
    std::vector<char> occ((size_t)N * N * N, 0);
    auto cell = [&](float v) { return std::max(0, std::min(N - 1, (int)std::floor((v + 0.5f) * N))); };
    const float cs = 1.f / N;
    for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
        const float* P[3] = {&md.v[md.idx[t] * 8], &md.v[md.idx[t + 1] * 8], &md.v[md.idx[t + 2] * 8]};
        float e = 0;
        for (int k = 0; k < 3; k++) {
            const float *p0 = P[k], *p1 = P[(k + 1) % 3];
            e = std::max(e, std::max(std::fabs(p0[0] - p1[0]), std::max(std::fabs(p0[1] - p1[1]), std::fabs(p0[2] - p1[2]))));
        }
        int n = std::max(1, std::min(160, (int)std::ceil(e / (cs * 0.5f))));
        const bool walk = (P[0][4] + P[1][4] + P[2][4]) / 3.f > 0.5f;
        for (int i = 0; i <= n; i++)
            for (int j = 0; i + j <= n; j++) {
                float u = (float)i / n, v = (float)j / n, w = 1.f - u - v;
                float x = P[0][0] * w + P[1][0] * u + P[2][0] * v, y = P[0][1] * w + P[1][1] * u + P[2][1] * v,
                      z = P[0][2] * w + P[1][2] * u + P[2][2] * v;
                if (!tpx.empty() && !opaqueAt(P[0][6] * w + P[1][6] * u + P[2][6] * v, P[0][7] * w + P[1][7] * u + P[2][7] * v)) continue;
                occ[((size_t)cell(y) * N + cell(z)) * N + cell(x)] = 1;
                if (walk) {
                    auto& L = rp.c[(size_t)rcell(z) * rp.G + rcell(x)];
                    bool dup = false; for (float q : L) if (std::fabs(q - y) < 0.004f) { dup = true; break; }
                    if (!dup && L.size() < 8) L.push_back(y);
                }
            }
    }
    // Se juntan las celdas en cajas grandes (primero a lo largo de X, luego Z, luego Y): las casas huecas
    // quedan con paredes finas y el interior libre.
    struct R { int x0, x1, z0, z1, y0, y1; };
    std::vector<R> done;
    std::map<std::array<int, 4>, R> openY;
    for (int y = 0; y < N; y++) {
        std::vector<R> rowRects;
        std::vector<R> open;
        for (int z = 0; z < N; z++) {
            std::vector<R> next;
            int x = 0;
            while (x < N) {
                if (!occ[((size_t)y * N + z) * N + x]) { x++; continue; }
                int x1 = x;
                while (x1 < N && occ[((size_t)y * N + z) * N + x1]) x1++;
                bool ext = false;
                for (auto it = open.begin(); it != open.end(); ++it)
                    if (it->x0 == x && it->x1 == x1) { R r = *it; r.z1 = z + 1; next.push_back(r); open.erase(it); ext = true; break; }
                if (!ext) next.push_back({x, x1, z, z + 1, y, y + 1});
                x = x1;
            }
            for (auto& r : open) rowRects.push_back(r);
            open.swap(next);
        }
        for (auto& r : open) rowRects.push_back(r);
        std::map<std::array<int, 4>, R> nextY;
        for (auto& r : rowRects) {
            std::array<int, 4> k{r.x0, r.x1, r.z0, r.z1};
            auto it = openY.find(k);
            if (it != openY.end()) { R q = it->second; q.y1 = y + 1; nextY[k] = q; openY.erase(it); }
            else nextY[k] = r;
        }
        for (auto& kv : openY) done.push_back(kv.second);
        openY.swap(nextY);
    }
    for (auto& kv : openY) done.push_back(kv.second);
    for (auto& r : done)
        out.push_back({(r.x0 + r.x1) * 0.5f * cs - 0.5f, (r.y0 + r.y1) * 0.5f * cs - 0.5f, (r.z0 + r.z1) * 0.5f * cs - 0.5f,
                       (r.x1 - r.x0) * cs * 0.5f, (r.y1 - r.y0) * cs * 0.5f, (r.z1 - r.z0) * cs * 0.5f});
    return out;
}

float Game::tiltSurfaceY(const Obj& o, float x, float z, float yMax) const {
    if ((o.kind != Kind::Cube && o.kind != Kind::Wall) || (std::fabs(o.pitch) < 1.f && std::fabs(o.roll) < 1.f)) return -1e9f;
    M4 m = modelMatTilt(o.pos, o.yaw, o.pitch, o.roll, V3{1, 1, 1});
    V3 ex{m.m[0], m.m[1], m.m[2]}, ey{m.m[4], m.m[5], m.m[6]}, ez{m.m[8], m.m[9], m.m[10]};
    if (ey.y < 0.34f) return -1e9f;   // más empinado de ~70°: es pared, no rampa
    float hx = o.scale.x * .5f, hy = o.scale.y * .5f, hz = o.scale.z * .5f;
    V3 tc{o.pos.x + ey.x * hy, o.pos.y + ey.y * hy, o.pos.z + ey.z * hy};
    float y = tc.y - (ey.x * (x - tc.x) + ey.z * (z - tc.z)) / ey.y;
    V3 d{x - tc.x, y - tc.y, z - tc.z};
    if (std::fabs(d.x * ex.x + d.y * ex.y + d.z * ex.z) > hx || std::fabs(d.x * ez.x + d.y * ez.y + d.z * ez.z) > hz) return -1e9f;
    return y <= yMax ? y : -1e9f;
}

float Game::modelSurfaceY(const Obj& o, float x, float z, float yMax) const {
    if (o.kind != Kind::Model || o.model.empty()) return -1e9f;
    modelBoxes(o.model);
    auto it = mramp_.find(o.model);
    if (it == mramp_.end() || it->second.G == 0) return -1e9f;
    const Ramp& R = it->second;
    float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
    float dx = x - o.pos.x, dz = z - o.pos.z;
    float lx = (c * dx - s * dz) / std::max(1e-4f, o.scale.x), lz = (s * dx + c * dz) / std::max(1e-4f, o.scale.z);
    if (lx < -0.5f || lx > 0.5f || lz < -0.5f || lz > 0.5f) return -1e9f;
    int ix = std::max(0, std::min(R.G - 1, (int)std::floor((lx + 0.5f) * R.G))), iz = std::max(0, std::min(R.G - 1, (int)std::floor((lz + 0.5f) * R.G)));
    float ym = (yMax - o.pos.y) / std::max(1e-4f, o.scale.y), best = -1e9f;
    for (float q : R.c[(size_t)iz * R.G + ix]) if (q <= ym && q > best) best = q;
    return best < -1e8f ? -1e9f : o.pos.y + best * o.scale.y;
}

bool Game::rayObj(const Obj& o, V3 e, V3 d, float& t) const {
    if (o.kind == Kind::Floor && o.tn >= 2) return rayTerrain(o, e, d, 400.f, t);
    float tb;
    if (!rayBoxYaw(e, d, o.pos, o.scale * .5f, o.yaw, tb)) return false;  // primero la caja entera
    if (o.kind != Kind::Model || o.model.empty()) { t = tb; return true; }
    const auto& boxes = modelBoxes(o.model);
    if (boxes.empty()) { t = tb; return true; }
    float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
    V3 oo{e.x - o.pos.x, e.y - o.pos.y, e.z - o.pos.z};
    V3 lo{(c * oo.x - s * oo.z) / o.scale.x, oo.y / o.scale.y, (s * oo.x + c * oo.z) / o.scale.z};
    V3 ld{(c * d.x - s * d.z) / o.scale.x, d.y / o.scale.y, (s * d.x + c * d.z) / o.scale.z};
    float best = 1e30f;
    for (auto& b : boxes) {
        float tt;
        if (rayBox(lo, ld, V3{b.cx, b.cy, b.cz}, V3{b.hx, b.hy, b.hz}, tt) && tt < best) best = tt;
    }
    if (best >= 1e29f) return false;
    t = best;
    return true;
}

bool Game::blocked(V3 p) const { return blockedBox(p, 0.3f, 1.7f, -1); }

float Game::groundAt(V3 p, float hw) const {
    float best = -1e9f;
    for (auto& o : sc->objs) {
        if (!o.alive || !o.visible || o.kind != Kind::Floor || o.tn < 2 || !o.solid) continue;
        static const float S[5][2] = {{0, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
        for (auto& q : S) best = std::max(best, terrainSurface(o, p.x + q[0] * hw, p.z + q[1] * hw));
    }
    return best;
}

// v11.5: límites del mapa y zonas prohibidas. who: 1 jugador, 2 enemigos/NPC, 4 autos con ruta.
bool Game::limitBlocks(float x, float z, int skip) const {
    if (!sc || !sc->is3d) return false;
    const Scene& S = *sc;
    int who = 1;
    std::string nm;
    if (skip >= 0 && skip < (int)S.objs.size()) {
        const Obj& o = S.objs[skip];
        who = o.routeOn ? 4 : 2;
        nm = o.name;
    }
    if (S.blkAt(x, z)) return true;
    if (S.limMode == 1 && (x - S.limCx) * (x - S.limCx) + (z - S.limCz) * (z - S.limCz) > S.limR * S.limR) return true;
    if (S.limMode == 2 && (std::fabs(x - S.limCx) > S.limR || std::fabs(z - S.limCz) > S.limR)) return true;
    for (auto& zn : S.zones) {
        if (!zn.only.empty()) { if (normName(zn.only) != normName(nm) && !(skip < 0 && (normName(zn.only) == "jugador" || normName(zn.only) == "player"))) continue; }
        else if (!(zn.who & who)) continue;
        bool in = false;
        size_t n = zn.pts.size() / 2;
        for (size_t a = 0, b = n - 1; a < n; b = a++) {
            float xa = zn.pts[a * 2], za = zn.pts[a * 2 + 1], xb = zn.pts[b * 2], zb = zn.pts[b * 2 + 1];
            if ((za > z) != (zb > z) && x < (xb - xa) * (z - za) / (zb - za) + xa) in = !in;
        }
        if (in) return true;
    }
    return false;
}

bool Game::movBlocked(const Obj& o, V3 np, float hw, int skip) const {
    float cx, cy, cz, hx, hy, hz; effBox(o, cx, cy, cz, hx, hy, hz);
    float feet = cy - hy + 0.25f, h = std::max(0.2f, hy * 2.f - 0.25f);
    return blockedBox(V3{np.x, feet, np.z}, hw, h, skip);
}
bool Game::blockedBox(V3 p, float hw, float h, int skip, float stepTol) const {
    const float eps = 1e-4f;
    if (sc && sc->is3d && (sc->limMode || !sc->zones.empty() || !sc->blk.empty())) {
        static const float K[5][2] = {{0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
        for (auto& k : K) if (limitBlocks(p.x + k[0] * hw, p.z + k[1] * hw, skip)) return true;
    }
    for (int oi = 0; oi < (int)sc->objs.size(); oi++) {
        const Obj& o = sc->objs[oi];
        if (oi == skip || !o.alive || !o.visible || !o.solid || !solidKind(o.kind)) continue;
        if (o.kind == Kind::Floor && o.tn >= 2) {  // suelo deformable: bloquea lo que quede por debajo de la superficie
            float m = -1e9f;
            static const float S[5][2] = {{0, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
            for (auto& q : S) m = std::max(m, terrainSurface(o, p.x + q[0] * hw, p.z + q[1] * hw));
            if (m > -1e8f && p.y < m - eps - stepTol && p.y + h > o.pos.y - o.scale.y * .5f + eps) return true;
            continue;
        }
        if (o.kind != Kind::Model && (std::fabs(o.pitch) >= 1.f || std::fabs(o.roll) >= 1.f)) {   // rampa de cubo/pared inclinado: se sube caminando; debajo y a los lados no hay choque
            float hs = -1e9f;
            static const float K5[5][2] = {{0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            for (auto& k : K5) hs = std::max(hs, tiltSurfaceY(o, p.x + k[0] * hw, p.z + k[1] * hw, 1e9f));
            if (hs > -1e8f) {
                float ey = std::max(0.34f, std::cos(std::acos(std::max(-1.f, std::min(1.f, std::cos(o.pitch * 0.0174532925f) * std::cos(o.roll * 0.0174532925f))))));
                float thick = o.scale.y / ey;
                if (p.y + stepTol + 0.02f >= hs || p.y + h <= hs - thick) continue;   // encima (apoyado) o debajo
                return true;
            }
            if (std::fabs(o.pitch) < 80.f && std::fabs(o.roll) < 80.f) continue;   // sin cara de rampa bajo el cuerpo: no estorba
        }
        if (p.y + h <= o.pos.y - o.scale.y * .5f + eps || p.y >= o.pos.y + o.scale.y * .5f - eps) continue;
        Quad P{p.x, p.z, hw, hw, 1.f, 0.f};
        if (!quadsOverlap(P, quadOf(o, true), eps)) continue;
        if (o.kind == Kind::Model && !o.model.empty()) {  // la colision sigue la forma del modelo
            const auto& boxes = modelBoxes(o.model);
            if (!boxes.empty()) {
                float a = o.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
                bool hit = false;
                float hs = -1e9f;   // subida o bajada caminable bajo el cuerpo (centro y esquinas)
                {
                    static const float K5[5][2] = {{0, 0}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                    for (auto& k : K5) hs = std::max(hs, modelSurfaceY(o, p.x + k[0] * hw, p.z + k[1] * hw, p.y + stepTol + 0.02f));
                }
                bool onRamp = hs > -1e8f && p.y + stepTol + 0.02f >= hs;
                float rampMargin = 2.5f * o.scale.y / 64.f;
                for (auto& b : boxes) {
                    float bx = b.cx * o.scale.x, bz = b.cz * o.scale.z;
                    float by = o.pos.y + b.cy * o.scale.y, hy = b.hy * o.scale.y;
                    if (p.y + h <= by - hy + eps || p.y >= by + hy - eps) continue;
                    if (onRamp && by + hy <= hs + rampMargin) continue;   // los escalones de la rampa no estorban
                    Quad B{o.pos.x + c * bx + s * bz, o.pos.z - s * bx + c * bz, b.hx * o.scale.x, b.hz * o.scale.z, c, -s};
                    if (quadsOverlap(P, B, eps)) { hit = true; break; }
                }
                if (!hit) continue;
            }
        }
        return true;
    }
    return false;
}

void Game::tap3D() {
    V3 e = eye(), d = forward();
    float best = 4.f;
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenTap) || hasHat(o, Op::WhenInteract) || o.ai.type != AiType::None || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayObj(o, e, d, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0) { fireHat(hit, Op::WhenTap); fireHat(hit, Op::WhenInteract); forcePlayerAnim(kInteract, 0.8f); }
}

void Game::forcePlayerAnim(int k, float secs) {   // acción puntual del jugador (solo si tiene animación para ella)
    int pi = sc ? playerIndex(*sc) : -1;
    if (pi < 0 || pi >= (int)st_.size()) return;
    const AnimState& a = sc->objs[pi].ai.anim[k];
    if (a.clip.empty() && a.frames.empty()) return;
    ObjState& ps = st_[pi]; ps.anim = k; ps.animT = 0; ps.forceT = secs;
}

// ---- v10.3: deformación por impacto. Se empuja hacia adentro la malla cerca del punto de choque (limitado para que no se desarme).
void Game::dentObj(int i, V3 wp, V3 wd, float power) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size()) return;
    Obj& o = sc->objs[i];
    if (!o.deform || o.kind != Kind::Model || o.model.empty() || power <= 0.01f) return;
    ObjState& s = st_[i];
    auto mit = dentMd_.find(o.model);
    if (mit == dentMd_.end()) {
        ModelData md;
        auto a = proj.assets.find(o.model);
        if (a == proj.assets.end() || !modelRead(a->second.data(), a->second.size(), md)) md = ModelData();
        mit = dentMd_.emplace(o.model, std::move(md)).first;
    }
    const ModelData& md = mit->second;
    if (md.v.size() < 8) return;
    if (s.dentV.size() != md.v.size()) s.dentV = md.v;
    float a = o.yaw * 0.0174532925f, c = std::cos(a), sn = std::sin(a);
    auto toLocal = [&](V3 v) { return V3{(c * v.x - sn * v.z) / std::max(1e-4f, o.scale.x), v.y / std::max(1e-4f, o.scale.y), (sn * v.x + c * v.z) / std::max(1e-4f, o.scale.z)}; };
    V3 pl = toLocal(wp - o.pos), dl = norm(toLocal(wd));
    power = std::min(1.f, power);
    float R = 0.10f + 0.16f * power, depth = o.deformAmt * 0.20f * (0.4f + 0.6f * power), lim = o.deformAmt * 0.32f;
    bool any = false;
    for (size_t k = 0; k + 7 < md.v.size(); k += 8) {
        const float* r0 = &md.v[k];
        V3 rest{r0[0], r0[1], r0[2]}, nrm{r0[3], r0[4], r0[5]};
        V3 cur{s.dentV[k], s.dentV[k + 1], s.dentV[k + 2]};
        float d = len(rest - pl);
        if (d >= R || dot(nrm, dl) > 0.35f) continue;   // solo la cara que recibe el golpe
        float f = 1.f - d / R;
        f *= f;
        V3 nw = cur + dl * (depth * f);
        V3 tot = nw - rest;
        float tl = len(tot);
        if (tl > lim) nw = rest + tot * (lim / tl);
        s.dentV[k] = nw.x; s.dentV[k + 1] = nw.y; s.dentV[k + 2] = nw.z;
        any = true;
    }
    if (any) s.dentVer++;
}

void Game::damageObj(int i, float dmg) {
    Obj& o = sc->objs[i];
    ObjState& st = st_[i];
    if (st.noDmg > 0.f) return;   // bloque «Cancelar daño»
    if (o.ai.type != AiType::None || o.hitMark) hitT = 0.28f;   // la marca solo sale con enemigos y objetos elegidos
    if (o.ai.type != AiType::None && !st.dead) {
        st.hp -= dmg;
        st.hurtT = 0.35f;
        if (st.hp <= 0) {
            st.dead = true;
            st.deadT = 0;
            auto it = vars.find("puntos");
            if (it != vars.end()) it->second = Val(it->second.num() + (o.ai.type == AiType::Melee ? 25 : 10));
        }
    }
    fireHat(i, Op::WhenShot);
}

void Game::hurtPlayer(float d) {
    if (playerNoDmg_ > 0.f) return;   // bloque «Cancelar daño»
    if (carIdx >= 0 && sc && carIdx < (int)sc->objs.size()) {   // dentro de un auto: el auto recibe el daño
        carHpCur_ -= d;
        hurtFlash = 0.2f; snd(6);
        if (onVibrate) onVibrate(0.08f);
        if (carHpCur_ <= 0) exitCar(true);
        return;
    }
    auto sh = vars.find("escudo");   // v10.5: el escudo absorbe el daño primero
    if (sh != vars.end() && sh->second.num() > 0) {
        double have = sh->second.num(), take = std::min(have, (double)d);
        sh->second = Val(have - take);
        d -= (float)take;
    }
    auto it = vars.find("vida");
    if (d > 0) vars["vida"] = Val((it != vars.end() ? it->second.num() : 100.0) - d);
    hurtFlash = 0.35f;
    snd(6);
    int pi = sc ? playerIndex(*sc) : -1;
    if (pi >= 0 && pi < (int)st_.size()) st_[pi].hurtT = 0.4f;
    fireAll(Op::WhenPlayerHurt);
    if (onVibrate) onVibrate(0.08f);
}

void Game::spawnProj(V3 from, V3 dir, int owner) {
    float l = len(dir);
    if (l < 1e-5f) return;
    dir = dir * (1.f / l);
    Proj p;
    p.p = from;
    p.owner = owner;
    if (owner < 0) {
        const Weapon& w = curWeapon() ? *curWeapon() : proj.weapon;
        if (w.type == 2 || w.type == 3) { dir.y += 0.25f; dir = norm(dir); p.grav = 14.f; }
        if (w.type == 3) p.blast = std::max(0.5f, w.blast);
        p.v = dir * w.projSpeed;
        p.life = w.type == 3 ? std::max(0.3f, w.fuse) : std::max(0.3f, w.range / std::max(1.f, w.projSpeed));
        p.size = w.projSize; p.dmg = w.damage; p.shape = w.projShape;
        p.tex = w.projTex; p.model = w.projModel;
        for (int k = 0; k < 3; k++) p.col[k] = w.projColor[k];
    } else {
        const AiCfg& a = sc->objs[owner].ai;
        p.v = dir * a.projSpeed;
        p.life = 5.f;
        p.size = a.projSize; p.dmg = a.dmg;
        p.tex = a.projTex; p.model = a.projModel;
        p.shape = !a.projModel.empty() ? 2 : !a.projTex.empty() ? 1 : 0;
        for (int k = 0; k < 3; k++) p.col[k] = a.projColor[k];
    }
    if (projs.size() < 256) projs.push_back(std::move(p));
}

void Game::shoot3D() {
    if (side() && (curWeapon() ? curWeapon()->type : proj.weapon.type) == 1) {   // 2.5D: golpe cuerpo a cuerpo hacia donde mira
        const Weapon& W = curWeapon() ? *curWeapon() : proj.weapon;
        float reach = std::max(W.meleeRange, W.range);
        for (size_t i = 0; i < sc->objs.size(); i++) {
            auto& o = sc->objs[i];
            if (!o.alive || !o.visible) continue;
            if (!(hasHat(o, Op::WhenShot) || o.ai.type != AiType::None)) continue;
            float dx = (o.pos.x - pos.x) * sideDir_;
            if (dx < -0.3f || dx > reach + o.scale.x * 0.5f) continue;
            if (std::fabs(o.pos.y - pos.y) > 3.f) continue;
            damageObj((int)i, W.damage);
            if (o.phys == Phys::Dynamic && i < st_.size()) st_[i].vel = st_[i].vel + V3{sideDir_ * 3.f, 1.f, 0.f};
        }
        punchT_ = 0.22f;
        return;
    }
    V3 d = forward();
    V3 e = camMode == 0 ? eye() : V3{pos.x, pos.y + 1.4f, pos.z};
    const Weapon& W = curWeapon() ? *curWeapon() : proj.weapon;
    if (W.type != 1 && W.projSpeed > 0.5f) {  // proyectil visible
        spawnProj(e + d * 0.5f, d, -1);
        return;
    }
    float best = W.type == 1 ? W.meleeRange : W.range;  // instantaneo / golpe
    int hit = -1;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        if (!(hasHat(o, Op::WhenShot) || o.ai.type != AiType::None || (o.solid && solidKind(o.kind)))) continue;
        float t;
        if (rayObj(o, e, d, t) && t < best) { best = t; hit = (int)i; }
    }
    if (hit >= 0 && sc->objs[hit].bulletPush && sc->objs[hit].phys == Phys::Dynamic) st_[hit].vel = st_[hit].vel + d * (W.damage * 0.25f / std::max(0.2f, sc->objs[hit].mass));
    if (hit >= 0) { damageObj(hit, W.damage); dentObj(hit, e + d * best, d, W.type == 1 ? 0.8f : 0.55f); }
}

void Game::updateProjs(float dt) {
    for (size_t k = 0; k < projs.size();) {
        Proj& p = projs[k];
        if (p.grav > 0 && !p.rest) p.v.y -= p.grav * dt;
        V3 step = p.v * dt;
        float L = len(step);
        bool dead = false;
        if (L > 1e-6f) {
            V3 d = step * (1.f / L);
            float best = L;
            int hit = -1;
            bool hitPlayer = false;
            for (size_t i = 0; i < sc->objs.size(); i++) {
                const Obj& o = sc->objs[i];
                if ((int)i == p.owner || !o.alive || !o.visible || o.kind == Kind::Player || o.kind == Kind::Light) continue;
                bool wall = o.solid && solidKind(o.kind);
                bool target = p.owner < 0 && (hasHat(o, Op::WhenShot) || o.ai.type != AiType::None);
                if (o.ai.type != AiType::None && (st_[i].dead || p.owner >= 0)) { if (!wall) continue; }
                if (!wall && !target) continue;
                float t;
                if (rayObj(o, p.p, d, t) && t < best) { best = t; hit = (int)i; }
            }
            if (p.owner >= 0) {  // proyectil enemigo: toca al jugador
                V3 c{pos.x, pos.y + 0.9f, pos.z}, w = c - p.p;
                float proj_t = std::max(0.f, std::min(L, w.x * d.x + w.y * d.y + w.z * d.z));
                V3 q = p.p + d * proj_t, dq = c - q;
                float dist = std::sqrt(dq.x * dq.x + (dq.y * dq.y) * 0.25f + dq.z * dq.z);
                if (dist < 0.5f + p.size && proj_t <= best) { hitPlayer = true; best = proj_t; }
            }
            if (hitPlayer) { hurtPlayer(p.dmg); dead = true; }
            else if (hit >= 0 && p.blast > 0) { p.p = p.p + d * std::max(0.f, best - 0.15f); p.v = V3{0, 0, 0}; p.rest = true; }
            else if (hit >= 0) { if (sc->objs[hit].bulletPush && sc->objs[hit].phys == Phys::Dynamic) st_[hit].vel = st_[hit].vel + d * (p.dmg * 0.25f / std::max(0.2f, sc->objs[hit].mass)); damageObj(hit, p.dmg); dentObj(hit, p.p + d * best, d, std::min(1.f, 0.35f + p.dmg * 0.04f)); dead = true; }
            else p.p = p.p + step;
        }
        p.life -= dt;
        if (p.life <= 0) dead = true;
        if (p.blast > 0 && p.life <= 0) explode(p);
        if (dead) projs.erase(projs.begin() + k);
        else k++;
    }
}

static bool hasAnimCfg(const Obj& o) {
    for (int k = 0; k < kAnimCount; k++) {
        const AnimState& a = o.ai.anim[k];
        if (!a.frames.empty() || !a.clip.empty() || a.bob != 0.f || a.sway != 0.f || a.lunge != 0.f) return true;
    }
    return false;
}

void Game::updateAI(float dt) {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        AiCfg& a = o.ai;
        if (a.type == AiType::None && o.kind != Kind::Player && o.alive && i < st_.size() && hasAnimCfg(o)) {   // objeto decorativo con animaciones
            ObjState& s = st_[i];
            s.animT += dt;
            s.forceT = std::max(0.f, s.forceT - dt);
            if (s.forceT <= 0 && s.anim != kIdle) { s.anim = kIdle; s.animT = 0; }
            continue;
        }
        if (a.type == AiType::None || !o.alive) continue;
        ObjState& s = st_[i];
        s.animT += dt;
        s.hurtT = std::max(0.f, s.hurtT - dt);
        s.atkCd = std::max(0.f, s.atkCd - dt);
        s.atkT = std::max(0.f, s.atkT - dt);
        s.shootT = std::max(0.f, s.shootT - dt);
        s.forceT = std::max(0.f, s.forceT - dt);
        if (s.dead) {
            s.deadT += dt;
            s.anim = (!a.anim[kDie].clip.empty() || !a.anim[kDie].frames.empty()) ? kDie : kHurt;
            o.transp = std::min(100.f, s.deadT / 0.8f * 100.f);
            if (s.deadT > 0.8f) o.alive = false;
            continue;
        }
        float dx = pos.x - o.pos.x, dz = pos.z - o.pos.z, d = std::sqrt(dx * dx + dz * dz);
        int tgt = -1;  // v10: contra quien pelea (-1 = el jugador)
        bool ignorePlayer = false;
        if (aiMode_ != 0) {
            float best = aiMode_ == 1 ? d : 1e9f;
            ignorePlayer = aiMode_ == 2;
            for (size_t j = 0; j < sc->objs.size(); j++) {
                if (j == i) continue;
                const Obj& q = sc->objs[j];
                if (q.ai.type == AiType::None || !q.alive || (j < st_.size() && st_[j].dead)) continue;
                float ex = q.pos.x - o.pos.x, ez = q.pos.z - o.pos.z, ed = std::sqrt(ex * ex + ez * ez);
                if (ed < best) { best = ed; tgt = (int)j; dx = ex; dz = ez; d = ed; }
            }
        }
        bool sees = d < a.sight && !(ignorePlayer && tgt < 0);
        int want = kIdle;
        if (sees) {
            if (a.face == 0) o.yaw = std::atan2(dx, -dz) / kRad;
            float stopAt = a.type == AiType::Melee ? a.reach * 0.8f : 7.f;
            if (d > stopAt) {
                float stp = std::min(a.speed * dt, d - stopAt);
                float feet = o.pos.y - o.scale.y * .5f;
                float hw = 0.3f * std::max(o.scale.x, o.scale.z) + 0.1f;
                V3 np = {o.pos.x + dx / d * stp, feet, o.pos.z};
                if (!blockedBox(np, hw, o.scale.y, (int)i)) o.pos.x = np.x;
                np = {o.pos.x, feet, o.pos.z + dz / d * stp};
                if (!blockedBox(np, hw, o.scale.y, (int)i)) o.pos.z = np.z;
                want = (a.speed >= 4.f && (!a.anim[kRun].clip.empty() || !a.anim[kRun].frames.empty())) ? kRun : kWalk;
            }
            if (s.atkCd <= 0) {
                if (tgt >= 0 && ((a.type == AiType::Melee && d <= a.reach) || (a.type == AiType::Shooter && d <= a.sight))) {
                    damageObj(tgt, a.dmg);
                    dentObj(tgt, sc->objs[tgt].pos, norm(sc->objs[tgt].pos - o.pos), std::min(1.f, a.dmg * 0.08f));
                    s.atkCd = a.rate; s.atkT = 0.35f;
                    if (a.type == AiType::Shooter) s.shootT = 0.35f;
                } else if (tgt >= 0) {
                } else if (a.type == AiType::Melee && d <= a.reach) {
                    hurtPlayer(a.dmg);
                    s.atkCd = a.rate; s.atkT = 0.35f;
                } else if (a.type == AiType::Shooter && d <= a.sight) {
                    V3 from{o.pos.x, o.pos.y + o.scale.y * 0.2f, o.pos.z};
                    spawnProj(from, V3{pos.x - from.x, pos.y + 1.2f - from.y, pos.z - from.z}, (int)i);
                    s.atkCd = a.rate; s.atkT = 0.35f;
                }
            }
        }
        if (s.forceT > 0) want = s.anim;
        else if (s.hurtT > 0) want = kHurt;
        else if (s.atkT > 0) want = (s.shootT > 0 && (!a.anim[kShoot].clip.empty() || !a.anim[kShoot].frames.empty())) ? kShoot : kAttack;
        if (want != kIdle && animGone(a.anim[want])) want = s.anim;   // «No reproducir esta animación»
        if (want != s.anim) { s.anim = want; s.animT = 0; }
    }
}

void Game::breakApart(int i, int n) {
    Obj& o = sc->objs[i];
    bool is3 = sc->is3d;
    int per = std::max(1, (int)std::ceil(std::cbrt((double)n)));
    float sz = is3 ? std::min(o.scale.x, std::min(o.scale.y, o.scale.z)) / per : std::min(o.scale.x, o.scale.y) / per;
    auto rnd = []() { return frand(); };
    for (int k = 0; k < n && debris.size() < 200; k++) {
        Debris d;
        d.is3 = is3;
        d.p = o.pos + V3{(rnd() - .5f) * o.scale.x * .8f, (rnd() - .5f) * o.scale.y * .8f, is3 ? (rnd() - .5f) * o.scale.z * .8f : 0.f};
        float sp = is3 ? 3.f : 300.f;
        d.v = V3{(rnd() - .5f) * sp, rnd() * sp * 0.9f, is3 ? (rnd() - .5f) * sp : 0.f};
        d.size = std::max(is3 ? 0.06f : 6.f, sz * (0.6f + rnd() * 0.5f));
        d.ground = o.pos.y - o.scale.y * .5f;
        d.life = 2.0f + rnd();
        d.spin = (rnd() - .5f) * 720.f;
        for (int c = 0; c < 3; c++) d.col[c] = o.color[c];
        d.tex = o.tex;
        debris.push_back(std::move(d));
    }
    o.alive = false;
}

void Game::emitParticles(int i, int n) {
    Obj& o = sc->objs[i];
    const FxCfg& f = o.fx;
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    auto rnd = []() { return frand(); };
    for (int k = 0; k < n && (int)parts.size() < (proj.perf.partOn ? std::max(10, proj.perf.part) : 900); k++) {
        Part p;
        p.is3 = is3;
        p.p = o.pos;
        if (is3) p.p.y += o.scale.y * 0.4f;
        float sp = f.spread * ps;
        p.v = V3{(rnd() - .5f) * 2.f * sp, f.speed * ps * (0.7f + rnd() * 0.6f), is3 ? (rnd() - .5f) * 2.f * sp : 0.f};
        p.max = p.life = std::max(0.1f, f.life * (0.75f + rnd() * 0.5f));
        p.size = f.size * ps * (0.7f + rnd() * 0.6f);
        p.grow = f.grow; p.grav = f.gravity * ps; p.a0 = f.a0; p.glow = f.glow; p.tex = f.tex;
        for (int c = 0; c < 3; c++) { p.c0[c] = f.c0[c]; p.c1[c] = f.c1[c]; }
        parts.push_back(std::move(p));
    }
}

void Game::updateParts(float dt) {
    for (auto& b : booms) b.t += dt;
    booms.erase(std::remove_if(booms.begin(), booms.end(), [](const BoomFx& b) { return b.t >= b.max; }), booms.end());
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.fx.on || !o.alive || !o.visible) continue;
        st_[i].fxAcc += o.fx.rate * dt;
        int n = (int)st_[i].fxAcc;
        st_[i].fxAcc -= n;
        if (n > 0) emitParticles((int)i, std::min(n, 20));
    }
    for (size_t k = 0; k < parts.size();) {
        Part& p = parts[k];
        p.life -= dt;
        p.v.y -= p.grav * dt;  // gravedad positiva = cae, negativa = sube
        p.p = p.p + p.v * dt;
        if (p.life <= 0) parts.erase(parts.begin() + k);
        else k++;
    }
}

void Game::updateDebris(float dt) {
    for (size_t k = 0; k < debris.size();) {
        Debris& d = debris[k];
        d.life -= dt;
        d.ang += d.spin * dt;
        if (d.is3) {
            d.v.y -= 20.f * dt;
            d.p = d.p + d.v * dt;
            if (d.p.y < d.ground + d.size * .5f) {
                d.p.y = d.ground + d.size * .5f;
                d.v.y = std::fabs(d.v.y) > 1.5f ? -d.v.y * 0.3f : 0.f;
                d.v.x *= 0.6f; d.v.z *= 0.6f; d.spin *= 0.5f;
            }
        } else {
            d.v.y += gravY_ * 100.f * dt;
            d.p = d.p + d.v * dt;
        }
        if (d.life <= 0) debris.erase(debris.begin() + k);
        else k++;
    }
}

Game::ObjVis Game::vis(int i) const {
    ObjVis v;
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size()) return v;
    const Obj& o = sc->objs[i];
    const ObjState& s = st_[i];
    if (o.ai.type == AiType::None && o.kind != Kind::Player && !hasAnimCfg(o)) return v;
    v.billboard = o.ai.sprite;
    const AnimState& a = o.ai.anim[s.anim];
    if (!a.frames.empty()) {
        int k = (int)std::floor(s.animT * std::max(0.5f, a.fps)) % (int)a.frames.size();
        const std::string& f = a.frames[k];
        if (f.size() > 5 && f.substr(f.size() - 5) == ".fmdl") v.model = f;
        else v.tex = f;
    }
    float t = s.animT;
    v.bob = std::sin(t * 8.f) * a.bob;
    v.sway = std::sin(t * 6.f) * a.sway;
    v.lunge = std::sin(t * 10.f) * a.lunge;
    v.squash = 1.f + std::sin(t * 10.f) * a.squash * 0.2f;
    v.clip = a.clip;
    return v;
}

void Game::applyCam() {
    if (!sc) return;
    V3 head{pos.x, pos.y + 1.6f, pos.z};
    if (camMode == kShoulder) {
        V3 f = forward(), r{std::cos(yaw), 0, std::sin(yaw)};
        // modelos grandes (carros, camiones...): la cámara se aleja y sube en proporción para que siempre se vea el modelo
        float mk = 1.f;
        { int pi = playerIndex(*sc); if (pi >= 0 && carIdx < 0) mk = std::max(1.f, std::min(6.f, sc->objs[pi].scale.y / 1.9f)); }
        if (mk > 1.f) head.y = pos.y + 1.6f * mk;
        float sd = std::max(0.8f, proj.player.shoulderDist) * mk;
        V3 want = head - f * sd + r * (0.25f * sd) + V3{0, proj.player.shoulderH * mk, 0};
        if (carIdx >= 0 && carIdx < (int)sc->objs.size()) {   // conduciendo: distancia y altura propias de este auto
            const Obj& co = sc->objs[carIdx];
            want = head - f * std::max(1.5f, co.carCamD) + V3{0, co.carCamH, 0};
        } else if (proj.player.vehicle) want = head - f * sd + V3{0, 0.9f + sd * 0.12f + (proj.player.shoulderH - 0.3f), 0};   // coche: cámara centrada y más alta
        V3 dir = want - head;
        float L = len(dir), best = L;
        V3 dn = dir * (1.f / L);
        for (auto& o : sc->objs) {
            if (!o.alive || !o.visible || !o.solid || !solidKind(o.kind)) continue;
            float t;
            if (rayObj(o, head, dn, t) && t < best) best = t;
        }
        camEye = head + dn * std::max(0.4f, std::min(L, best - 0.2f));
        camFwd = f;
    } else if (camMode == kFixed) {
        int fm = proj.player.fixedMode;
        camEye = sc->cam;
        if (side()) {   // 2.5D: camara de lado, siempre mirando a lo largo de -Z y siguiendo la accion
            float cx = pos.x;
            if (lockIdx_ >= 0 && lockIdx_ < (int)sc->objs.size() && sc->objs[lockIdx_].alive) cx = (pos.x + sc->objs[lockIdx_].pos.x) * 0.5f;
            float dist = std::max(6.f, std::fabs(sc->cam.z - sc->start.z));
            camEye = V3{cx, std::max(2.f, sc->cam.y), sc->start.z + dist};
            V3 d = V3{cx, pos.y + 1.1f, sc->start.z} - camEye;
            camFwd = norm(d);
        }
        V3 tgt{pos.x, pos.y + 1.2f, pos.z};
        if (side()) {
        } else if (fm == 1) {  // se mueve junto al jugador, mantiene la distancia y la direccion
            V3 s0{sc->start.x, sc->start.y + 1.2f, sc->start.z};
            camEye = sc->cam + (tgt - s0);
            V3 d0 = s0 - sc->cam;
            camFwd = len(d0) > 1e-4f ? norm(d0) : V3{0, 0, -1};
        } else if (fm == 2) {  // totalmente fija: mira siempre hacia donde empieza el jugador
            V3 d0 = V3{sc->start.x, sc->start.y + 1.2f, sc->start.z} - camEye;
            camFwd = len(d0) > 1e-4f ? norm(d0) : V3{0, 0, -1};
        } else {
            V3 d = tgt - camEye;
            camFwd = len(d) > 1e-4f ? norm(d) : V3{0, 0, -1};
        }
    } else {
        camEye = head + V3{0.f, proj.player.eyeH, 0.f};
        camFwd = forward();
        if (proj.player.headBob) {  // balanceo al caminar
            float sp = std::sqrt(vel.x * vel.x + vel.z * vel.z);
            bool walking = sp > 0.5f && std::fabs(vel.y) < 0.5f;
            bobAmp_ += ((walking ? 1.f : 0.f) - bobAmp_) * std::min(1.f, dt_ * 8.f);
            if (walking) bobPhase_ += dt_ * (5.5f + sp * 0.5f);
            float a = bobAmp_ * proj.player.bobAmt;
            V3 rg{std::cos(yaw), 0, std::sin(yaw)};
            camEye.y += std::sin(bobPhase_ * 2.f) * 0.045f * a;
            camEye = camEye + rg * (std::cos(bobPhase_) * 0.03f * a);
            bobRoll_ = std::cos(bobPhase_) * 0.012f * a;
        } else bobRoll_ = 0.f;
    }
    camRoll += (camRollTarget - camRoll) * std::min(1.f, dt_ * 6.f);
    camRollTotal = camRoll + (camMode == kFirstPerson ? bobRoll_ : 0.f);
}

void Game::snd(int slot) {
    static const char* def[8] = {"paso", "salto", "aterrizaje", "disparo", "recarga", "golpe", "dano", "explosion"};
    if (!onSound || slot < 0 || slot > 7) return;
    onSound(proj.snd[slot].empty() ? def[slot] : proj.snd[slot]);
}

// 2D: mantiene dentro de la pantalla a los objetos que lo pidieron.
// Reglas de empuje: el objeto "empujado" se aparta por el lado de menor penetración del que lo toca.
void Game::pushTick() {
    if (!sc || pushRules_.empty()) return;
    const bool is3 = sc->is3d;
    for (auto& r : pushRules_) {
        if (r.self < 0 || r.self >= (int)sc->objs.size()) continue;
        Obj& me = sc->objs[r.self];
        if (!me.alive || !me.visible) continue;
        std::string k = normName(r.other);
        bool otherIsPlayer = is3 && (k == "jugador" || k == "player");
        int j = otherIsPlayer ? -1 : findObj(r.other);
        if (!otherIsPlayer && (j < 0 || j == r.self)) continue;
        V3 op, os;
        if (otherIsPlayer) { op = V3{pos.x, pos.y + 0.85f, pos.z}; os = V3{0.6f, 1.7f, 0.6f}; }
        else { Obj& q = sc->objs[j]; if (!q.alive || !q.visible) continue; op = q.pos; os = q.scale; }
        float dx = me.pos.x - op.x, pxl = (me.scale.x + os.x) * 0.5f - std::fabs(dx);
        float d2 = is3 ? me.pos.z - op.z : me.pos.y - op.y;
        float pz = is3 ? (me.scale.z + os.z) * 0.5f - std::fabs(d2) : (me.scale.y + os.y) * 0.5f - std::fabs(d2);
        if (pxl <= 0.f || pz <= 0.f) continue;
        if (is3 && std::fabs(me.pos.y - op.y) >= (me.scale.y + os.y) * 0.5f) continue;
        bool alongX = pxl < pz;
        float amt = alongX ? pxl : pz;
        float sgn = (alongX ? dx : d2) >= 0.f ? 1.f : -1.f;
        // quién se mueve: "este objeto" (selfPushed) o el otro
        float s2 = r.selfPushed ? sgn : -sgn;
        if (r.selfPushed) {
            if (alongX) me.pos.x += s2 * amt; else if (is3) me.pos.z += s2 * amt; else me.pos.y += s2 * amt;
            if (r.self < (int)st_.size() && me.phys == Phys::Dynamic) { if (alongX) st_[r.self].vel.x += s2 * 0.5f * (is3 ? 1.f : 100.f); }
        } else if (otherIsPlayer) {
            if (alongX) pos.x += s2 * amt; else pos.z += s2 * amt;
        } else {
            Obj& q = sc->objs[j];
            if (alongX) q.pos.x += s2 * amt; else if (is3) q.pos.z += s2 * amt; else q.pos.y += s2 * amt;
            if (j < (int)st_.size() && q.phys == Phys::Dynamic) { if (alongX) st_[j].vel.x += s2 * 0.5f * (is3 ? 1.f : 100.f); }
        }
    }
}

void Game::keepTick() {
    if (!sc || sc->is3d || (!keepAll_ && keep_.empty())) return;
    if (keep_.size() < sc->objs.size()) keep_.resize(sc->objs.size(), 0);
    float hw = stageW() * 0.5f, hh = kView2DHeight * 0.5f;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive || o.bg || o.kind == Kind::Light) continue;
        bool on = keep_[i] != 0;
        if (!on && keepAll_) {
            on = true;
            for (auto& e : keepExcept_) if (e == o.name) { on = false; break; }
        }
        if (!on) continue;
        float ex = std::min(o.scale.x * 0.5f, hw), ey = std::min(o.scale.y * 0.5f, hh);
        int mask = keep_[i] ? keep_[i] : 15;
        if (mask & 1) o.pos.x = std::max(-hw + ex, o.pos.x);
        if (mask & 2) o.pos.x = std::min(hw - ex, o.pos.x);
        if (mask & 4) o.pos.y = std::min(hh - ey, o.pos.y);
        if (mask & 8) o.pos.y = std::max(-hh + ey, o.pos.y);
    }
}

void Game::tap2D(float x, float y) {
    float wx = (x - .5f) * view2W() + cam2x, wy = (.5f - y) * view2H() + cam2y;
    int best = -1, bestLayer = -1000000;
    for (int i = 0; i < (int)sc->objs.size(); i++) {
        auto& o = sc->objs[i];
        if (!o.alive || !o.visible) continue;
        float ra = -(o.yaw - 90.f) * 0.0174532925f, cs = std::cos(ra), sn = std::sin(ra);
        float ddx = wx - o.pos.x, ddy = wy - o.pos.y;
        float lx = cs * ddx + sn * ddy, ly = -sn * ddx + cs * ddy;  // el toque se mide girado con el objeto
        if (!o.bg && !(std::fabs(lx) <= o.scale.x * .5f && std::fabs(ly) <= o.scale.y * .5f)) continue;
        int layer = o.bg ? -1000000 + 1 : o.layer;
        if (layer >= bestLayer && (hasHat(o, Op::WhenTap) || hasHat(o, Op::WhenInteract))) { best = i; bestLayer = layer; }
    }
    if (best >= 0) { fireHat(best, Op::WhenTap); fireHat(best, Op::WhenInteract); }
}

// ---------------------------------------------------------------- fisica sencilla
void Game::physBlast(V3 at, float radius, float power, int except) {
    float ps = sc->is3d ? 1.f : 100.f;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if ((int)i == except || !o.alive || o.phys != Phys::Dynamic || i >= st_.size()) continue;
        V3 d = o.pos - at;
        if (!sc->is3d) d.z = 0;
        float dist = len(d), R = radius * (sc->is3d ? 1.f : 100.f);
        if (dist >= R) continue;
        V3 dir = dist > 1e-4f ? d * (1.f / dist) : V3{0, 1, 0};
        if (sc->is3d) dir.y += 0.35f;   // un poco hacia arriba
        float k = power * ps * (1.f - dist / R) / std::max(0.2f, o.mass);
        st_[i].vel = st_[i].vel + dir * k;
    }
}

// El jugador empuja los objetos físicos "empujables" al caminar contra ellos.
void Game::pushByPlayer(float dt) {
    if (!sc->is3d) return;
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive || !o.pushable || o.phys != Phys::Dynamic) continue;
        V3 d = o.pos - V3{pos.x, pos.y + 0.85f, pos.z};
        if (std::fabs(d.x) < o.scale.x * .5f + 0.45f && std::fabs(d.z) < o.scale.z * .5f + 0.45f && std::fabs(d.y) < o.scale.y * .5f + 0.85f) {
            float l = std::sqrt(d.x * d.x + d.z * d.z);
            if (l < 1e-3f) continue;
            float sp = 3.2f / std::sqrt(std::max(0.3f, o.mass));
            st_[i].vel.x += d.x / l * sp * dt * 12.f;
            st_[i].vel.z += d.z / l * sp * dt * 12.f;
        }
    }
}

void Game::physics(float dt) {
    pushByPlayer(dt);
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        ObjState& s = st_[i];
        if (!o.alive) continue;
        if (worldFrozen_ && o.kind != Kind::Player) continue;
        if (o.phys == Phys::Dynamic) {
            if (asleep((int)i)) continue;
            s.grounded = false;
            s.vel.x += gravX_ * ps * dt * o.gravScale;
            s.vel.y += gravY_ * ps * dt * o.gravScale;
            if (o.drag > 0.f) { float k = std::max(0.f, 1.f - o.drag * dt); s.vel.x *= k; s.vel.z *= k; if (!is3 || gravY_ == 0) s.vel.y *= k; else s.vel.y *= (1.f - o.drag * 0.3f * dt); }
            if (is3) {   // si quedó metido en el suelo u otro objeto (al colocarlo), se sube poco a poco para no quedarse trabado
                float ocx, ocy, ocz, ohx, ohy, ohz;
                effBox(o, ocx, ocy, ocz, ohx, ohy, ohz);
                for (size_t j = 0; j < sc->objs.size(); j++) {
                    if (j == i) continue;
                    const Obj& q = sc->objs[j];
                    if (!q.alive || !q.visible || !q.solid || !solidKind(q.kind) || q.phys == Phys::Dynamic || (q.kind == Kind::Floor && q.tn >= 2)) continue;
                    float qcx, qcy, qcz, qhx, qhy, qhz;
                    effBox(q, qcx, qcy, qcz, qhx, qhy, qhz);
                    if (qcy >= ocy || !overlap(o, q)) continue;
                    float pen = (qcy + qhy) - (ocy - ohy);   // cuánto está metido
                    if (pen > 0.f && pen < ohy * 1.2f + 0.5f) { o.pos.y += std::min(pen, 3.f * dt + 0.02f); s.vel.y = std::max(s.vel.y, 0.f); }
                    break;
                }
            }
            for (int axis = 0; axis < (is3 ? 3 : 2); axis++) {
                float* p = axis == 0 ? &o.pos.x : axis == 1 ? &o.pos.y : &o.pos.z;
                float* v = axis == 0 ? &s.vel.x : axis == 1 ? &s.vel.y : &s.vel.z;
                float old = *p;
                *p += *v * dt;
                for (size_t j = 0; j < sc->objs.size(); j++) {
                    if (j == i) continue;
                    const Obj& q = sc->objs[j];
                    bool solidWorld = is3 && q.solid && solidKind(q.kind);
                    if (!q.alive || !q.visible || (q.phys == Phys::None && !solidWorld)) continue;
                    if (is3 && q.kind == Kind::Floor && q.tn >= 2) continue;   // el suelo deformable se resuelve aparte (sigue sus lomas)
                    if (!is3 && (q.mapPart == 1 || q.goal || (q.mapPart == 2 && !q.solid))) continue;   // fondo del mapa y Meta no son paredes
                    if (!overlap(o, q)) continue;
                    if (axis == 1 && *v * (gravY_ < 0 ? 1.f : -1.f) <= 0.f) s.grounded = true;   // apoyado
                    *p = old;
                    {   // choque fuerte: abolla a los dos objetos (si tienen la opción)
                        float sp = std::fabs(*v) / ps;
                        if (sp > 3.f && (o.deform || q.deform)) {
                            float pw = std::min(1.f, (sp - 3.f) / 12.f);
                            V3 mid = (o.pos + q.pos) * 0.5f, dirA = norm(q.pos - o.pos);
                            dentObj((int)i, mid, dirA, pw);
                            dentObj((int)j, mid, dirA * -1.f, pw);
                        }
                    }
                    float e = (o.bounce + q.bounce) * 0.5f;
                    if (q.phys == Phys::Dynamic && j < st_.size()) {   // dos objetos dinámicos: se reparten el impulso según su masa
                        float* v2 = axis == 0 ? &st_[j].vel.x : axis == 1 ? &st_[j].vel.y : &st_[j].vel.z;
                        float m1 = std::max(0.05f, o.mass), m2 = std::max(0.05f, q.mass), a1 = *v, a2 = *v2;
                        *v = ((m1 - e * m2) * a1 + (1.f + e) * m2 * a2) / (m1 + m2);
                        *v2 = ((m2 - e * m1) * a2 + (1.f + e) * m1 * a1) / (m1 + m2);
                        float fr2 = std::min(1.f, (o.friction + q.friction) * 0.5f) * dt * 10.f;
                        if (axis == 1) { s.vel.x *= (1.f - fr2); s.vel.z *= (1.f - fr2); } else s.vel.y *= (1.f - fr2);
                        break;
                    }
                    *v = -*v * e;
                    if (std::fabs(*v) < 2.f * ps * 0.05f) *v = 0;
                    float fr = std::min(1.f, (o.friction + q.friction) * 0.5f) * dt * 10.f;
                    if (axis == 1) { s.vel.x *= (1.f - fr); s.vel.z *= (1.f - fr); }
                    else s.vel.y *= (1.f - fr);
                    break;
                }
            }
            if (is3) {   // suelo deformable (montañas): el objeto se apoya sobre la superficie real
                float cx, cy, cz, hx, hy, hz;
                effBox(o, cx, cy, cz, hx, hy, hz);
                for (auto& q : sc->objs) {
                    if (!q.alive || !q.visible || !q.solid || q.kind != Kind::Floor || q.tn < 2) continue;
                    static const float S[9][2] = {{0, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}, {1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                    float m = -1e9f;
                    for (auto& k : S) m = std::max(m, terrainSurface(q, cx + k[0] * hx * 0.9f, cz + k[1] * hz * 0.9f));
                    float bottom = cy - hy;
                    if (m > -1e8f && bottom < m && cy + hy > q.pos.y - q.scale.y * 0.5f) {
                        o.pos.y += m - bottom;
                        if (s.vel.y < 0) s.vel.y = std::fabs(s.vel.y) * o.bounce > 1.5f ? -s.vel.y * o.bounce : 0.f;
                        float fr = std::min(1.f, (o.friction + 0.3f)) * dt * 6.f;
                        s.vel.x *= (1.f - fr); s.vel.z *= (1.f - fr);
                        effBox(o, cx, cy, cz, hx, hy, hz);
                    }
                }
            }
            if (!is3 && o.pos.y < -50000) o.alive = false;
        }
        if (s.spin != 0) o.yaw += s.spin * dt;
    }
}

// v11.5: altura del suelo (o de lo que haya debajo) donde se apoyaría el objeto 'i'.
float Game::supportY(int i) const {
    const Obj& o = sc->objs[i];
    float cx, cy, cz, hx, hy, hz;
    effBox(o, cx, cy, cz, hx, hy, hz);
    float best = -1e9f, top = cy + hy;
    for (int j = 0; j < (int)sc->objs.size(); j++) {
        const Obj& q = sc->objs[j];
        if (j == i || !q.alive || !q.visible || !q.solid || !solidKind(q.kind)) continue;
        if (q.kind == Kind::Floor && q.tn >= 2) {
            float m = terrainSurface(q, o.pos.x, o.pos.z);
            if (m > -1e8f && m <= top + 0.6f) best = std::max(best, m);
            continue;
        }
        if (q.kind == Kind::Model && !q.model.empty()) {   // modelo con subidas/bajadas: se apoya en la superficie real
            float m = modelSurfaceY(q, o.pos.x, o.pos.z, top + 0.3f);
            if (m > -1e8f) { best = std::max(best, m); continue; }
        }
        if (q.kind != Kind::Model && (std::fabs(q.pitch) >= 1.f || std::fabs(q.roll) >= 1.f)) {
            float m = tiltSurfaceY(q, o.pos.x, o.pos.z, top + 0.3f);
            if (m > -1e8f) best = std::max(best, m);
            continue;
        }
        float qx, qy, qz, qhx, qhy, qhz;
        effBox(q, qx, qy, qz, qhx, qhy, qhz);
        float a = q.yaw * 0.0174532925f, c = std::cos(a), s = std::sin(a);
        float dx = o.pos.x - qx, dz = o.pos.z - qz, lx = c * dx - s * dz, lz = s * dx + c * dz;
        if (std::fabs(lx) > qhx || std::fabs(lz) > qhz) continue;
        float t = qy + qhy;
        if (t <= top + 0.3f) best = std::max(best, t);
    }
    return best;
}

void Game::enterCar(int i) {
    if (!sc || !sc->is3d || carIdx >= 0 || i < 0 || i >= (int)sc->objs.size()) return;
    Obj& o = sc->objs[i];
    carIdx = i; carHpCur_ = std::max(1.f, o.carHp);
    prevCam_ = camMode; carSolid_ = o.solid;
    o.solid = false; o.routeOn = false; o.wander = false;
    if (o.phys == Phys::Dynamic) st_[i].vel = V3{0, 0, 0};
    pos = V3{o.pos.x, pos.y, o.pos.z};
    yaw = bodyYaw = (-o.yaw - o.frontOff) * 0.0174532925f;   // el modelo se dibuja girado +yaw: el rumbo real es -yaw-frente
    carSpeed_ = 0.f;
    if (camMode == kFirstPerson || camMode == kFixed) camMode = kShoulder;
    nearCar = -1;
}

void Game::exitCar(bool destroyed) {
    if (carIdx < 0 || !sc || carIdx >= (int)sc->objs.size()) { carIdx = -1; return; }
    Obj& o = sc->objs[carIdx];
    o.solid = carSolid_;
    camMode = prevCam_;
    V3 r{std::cos(bodyYaw), 0, std::sin(bodyYaw)};
    if (destroyed) {
        o.alive = false;
        if (o.kind == Kind::Model) { breakApart(carIdx, 10); }
        snd(6);
    } else {
        for (float side : {2.4f, -2.4f, 3.6f}) {   // baja por un lado que esté libre
            V3 np{pos.x + r.x * side, pos.y, pos.z + r.z * side};
            if (!blockedBox(np, 0.3f, 1.7f, carIdx)) { pos = np; break; }
        }
    }
    carIdx = -1; carSpeed_ = 0.f; vel = V3{0, 0, 0};
}

// v11.5: NPC que deambulan y autos que siguen una ruta. Solo se mueven si el jugador está cerca (rendimiento).
// v11.5: cinemáticas. La cámara sigue los puntos grabados (o la cabeza del jugador) y los objetos siguen sus rutas en el tiempo.
void Game::startCine(const std::string& name) {
    std::string k = normName(name);
    for (size_t i = 0; i < proj.cines.size(); i++) if (normName(proj.cines[i].name) == k) { cineIdx_ = (int)i; cineT_ = 0.f; return; }
    cineIdx_ = -1;
}

void Game::stopCine() {
    if (cineIdx_ < 0) return;
    cineIdx_ = -1;
    if (sc && sc->is3d) applyCam();
}

static float lerpAng(float a, float b, float t) { float d = std::fmod(b - a + 540.f, 360.f) - 180.f; return a + d * t; }

void Game::cineTick(float dt) {
    if (cineIdx_ < 0 || cineIdx_ >= (int)proj.cines.size() || !sc) { cineIdx_ = -1; return; }
    const Cine& C = proj.cines[cineIdx_];
    cineT_ += dt;
    float t = std::min(cineT_, C.dur);
    for (auto& tr : C.tracks) {   // objetos (y el jugador) siguen su ruta
        if (tr.keys.empty()) continue;
        size_t b = 0;
        while (b < tr.keys.size() && tr.keys[b].t < t) b++;
        CineTrackKey k = tr.keys[std::min(b, tr.keys.size() - 1)];
        if (b > 0 && b < tr.keys.size()) {
            const CineTrackKey &p = tr.keys[b - 1], &q = tr.keys[b];
            float f = (t - p.t) / std::max(1e-4f, q.t - p.t);
            k.p = p.p + (q.p - p.p) * f; k.yaw = lerpAng(p.yaw, q.yaw, f);
        }
        std::string nk = normName(tr.obj);
        bool isPlayer = nk == "jugador" || nk == "player";
        for (size_t i = 0; i < sc->objs.size(); i++) {
            Obj& o = sc->objs[i];
            if (!o.alive) continue;
            if (isPlayer ? o.kind == Kind::Player : normName(o.name) == nk) {
                o.pos = k.p; o.yaw = k.yaw;
                if (o.kind == Kind::Player || isPlayer) { pos = V3{k.p.x, k.p.y - o.scale.y * 0.5f, k.p.z}; bodyYaw = yaw = k.yaw * 0.0174532925f; vel = V3{0, 0, 0}; }
                if (o.phys == Phys::Dynamic && i < st_.size()) st_[i].vel = V3{0, 0, 0};
                break;
            }
        }
    }
    if (sc->is3d) {
        if (C.mode == 1) {   // primera persona del jugador
            camEye = V3{pos.x, pos.y + 1.6f, pos.z};
            camFwd = V3{std::sin(bodyYaw), 0.f, -std::cos(bodyYaw)};
        } else if (!C.cam.empty()) {   // cámara libre: curva suave por los puntos grabados
            size_t n = C.cam.size(), b = 0;
            while (b < n && C.cam[b].t < t) b++;
            CineKey k = C.cam[std::min(b, n - 1)];
            if (b > 0 && b < n) {
                const CineKey &p1 = C.cam[b - 1], &p2 = C.cam[b];
                const CineKey &p0 = C.cam[b >= 2 ? b - 2 : b - 1], &p3 = C.cam[b + 1 < n ? b + 1 : b];
                float f = (t - p1.t) / std::max(1e-4f, p2.t - p1.t), f2 = f * f, f3 = f2 * f;
                auto cr = [&](float a, float bb, float c, float d) { return 0.5f * ((2.f * bb) + (-a + c) * f + (2.f * a - 5.f * bb + 4.f * c - d) * f2 + (-a + 3.f * bb - 3.f * c + d) * f3); };
                k.eye = V3{cr(p0.eye.x, p1.eye.x, p2.eye.x, p3.eye.x), cr(p0.eye.y, p1.eye.y, p2.eye.y, p3.eye.y), cr(p0.eye.z, p1.eye.z, p2.eye.z, p3.eye.z)};
                k.yaw = lerpAng(p1.yaw, p2.yaw, f); k.pitch = p1.pitch + (p2.pitch - p1.pitch) * f;
            }
            float yr = k.yaw * 0.0174532925f, pr = k.pitch * 0.0174532925f;
            camEye = k.eye;
            camFwd = V3{std::sin(yr) * std::cos(pr), std::sin(pr), -std::cos(yr) * std::cos(pr)};
        }
    }
    if (cineT_ >= C.dur) stopCine();
}

// v11.5: 2D — objetos que siguen una ruta dibujada con lápiz y dejan una estela de copias de colores que se desvanece.
static float routeWaitFor(const Obj& o) {
    if (o.routeWaitMode == 1) return std::max(0.f, o.routeWaitA);
    if (o.routeWaitMode == 2) { float a = std::max(0.f, std::min(o.routeWaitA, o.routeWaitB)), b = std::max(o.routeWaitA, o.routeWaitB); return a + (b - a) * (frand()); }
    return 0.f;
}

void Game::routeTick2D(float dt) {
    int n0 = (int)sc->objs.size();
    int alive = 0;
    std::vector<std::pair<Obj, int>> pend;
    for (int i = 0; i < n0; i++) if (sc->objs[i].ghost && sc->objs[i].alive) alive++;
    auto trailStep = [&](Obj& o, ObjState& s, int i) {   // estela: una copia cada cierta distancia, sea cual sea la forma de moverse
            float mdx = o.pos.x - s.tx, mdy = o.pos.y - s.tz;
            if (!s.homed) { s.homed = true; s.tx = o.pos.x; s.tz = o.pos.y; }
            else if (mdx * mdx + mdy * mdy > o.trailGap * o.trailGap && alive < 600) {   // una copia cada cierta distancia recorrida
                s.tx = o.pos.x; s.tz = o.pos.y; alive++;
                s.hx += 37.f;   // avanza el color del arcoíris
                Obj c = o;
                c.ghost = c.clone = true; c.ghostOwner = i; c.alive = c.visible = true; c.blocks.clear(); c.routeOn = c.wander = c.trail = false;
                if (o.trailSolid) {   // opción: la copia reacciona a choques como parte del objeto (solo guiones «Al chocar con»)
                    const auto& cm = cmp_[i];
                    for (size_t hi2 = 0; hi2 < cm.hats.size(); hi2++) {
                        int h = cm.hats[hi2], e2 = hi2 + 1 < cm.hats.size() ? cm.hats[hi2 + 1] : (int)o.blocks.size();
                        if (o.blocks[h].op == Op::WhenCollide) c.blocks.insert(c.blocks.end(), o.blocks.begin() + h, o.blocks.begin() + e2);
                    }
                }
                c.phys = Phys::None; c.solid = false; c.name += "_estela"; c.layer = o.layer; c.pushable = false;
                c.ai.type = AiType::None; c.looks.clear(); c.vctl = 0; c.wander = false; c.scale = V3{o.scale.x * o.trailScale, o.scale.y * o.trailScale, o.scale.z * o.trailScale};
                c.noColor = false; c.transp = o.trailTransp; c.video.clear(); c.fx = FxCfg(); c.fx.rate = 0.f;
                float col[3] = {o.trailCol[0], o.trailCol[1], o.trailCol[2]};
                if (o.trailStyle == 0) {   // arcoíris
                    float hh = std::fmod(s.hx, 360.f) / 60.f; int hi = (int)hh; float f = hh - hi;
                    float q[6][3] = {{1, f, 0}, {1 - f, 1, 0}, {0, 1, f}, {0, 1 - f, 1}, {f, 0, 1}, {1, 0, 1 - f}};
                    for (int m = 0; m < 3; m++) col[m] = q[hi % 6][m];
                } else if (o.trailStyle == 2) { col[0] = col[1] = col[2] = 1.f; }
                for (int m = 0; m < 3; m++) c.color[m] = col[m];
                pend.push_back({std::move(c), i});
            }
            };
    for (int i = 0; i < n0 && i < (int)st_.size(); i++) {
        Obj& o = sc->objs[i];
        ObjState& s = st_[i];
        if (!o.alive) continue;
        if (o.ghost) {   // la copia se desvanece
            s.lap += dt;
            if (o.ghostOwner >= 0 && o.ghostOwner < n0 && sc->objs[o.ghostOwner].alive) { o.layer = sc->objs[o.ghostOwner].layer; o.bg = sc->objs[o.ghostOwner].bg; }   // siempre en la capa del dueño
            float k = std::min(1.f, s.lap / std::max(0.05f, s.wt));
            o.transp = o.trailTransp + (100.f - o.trailTransp) * k;
            if (o.trailSolid && !o.solid) {   // se vuelve sólida cuando el dueño ya se alejó (para no atorarlo)
                int ow = (int)s.tz;
                if (ow >= 0 && ow < n0 && sc->objs[ow].alive) {
                    float ddx = sc->objs[ow].pos.x - o.pos.x, ddy = sc->objs[ow].pos.y - o.pos.y, rr = std::max(o.scale.x, o.scale.y);
                    if (ddx * ddx + ddy * ddy > rr * rr) { o.solid = true; o.phys = Phys::Static; }
                }
            }
            o.scale = base_[i] * (1.f - 0.35f * k);
            if (s.lap >= s.wt) { o.alive = false; o.visible = false; }
            continue;
        }
        if (!o.routeOn || o.route.size() < 4 || o.bg || s.rpause) { if (o.trail && !o.bg) trailStep(o, s, i); continue; }
        int n = (int)o.route.size() / 2;
        if (s.wp < 0 || s.wp >= n) {
            float bd = 1e30f; s.wp = 0;
            for (int k = 0; k < n; k++) { float dx = o.route[k * 2] - o.pos.x, dy = o.route[k * 2 + 1] - o.pos.y; if (dx * dx + dy * dy < bd) { bd = dx * dx + dy * dy; s.wp = k; } }
        }
        if (s.rwait > 0.f) { s.rwait -= dt; continue; }   // esperando al terminar la vuelta
        float step = o.routeSpd * dt;
        while (step > 0.f) {
            float tx = o.route[s.wp * 2], ty = o.route[s.wp * 2 + 1], dx = tx - o.pos.x, dy = ty - o.pos.y, d = std::sqrt(dx * dx + dy * dy);
            if (d <= step) {
                o.pos.x = tx; o.pos.y = ty; step -= d;
                if (s.wp + 1 >= n) {
                    s.laps++;
                    if (!o.routeLoop || (o.routeLaps > 0 && s.laps >= o.routeLaps)) { o.routeOn = false; break; }
                    s.rwait = routeWaitFor(o);
                }
                s.wp = (s.wp + 1) % n;
                if (s.rwait > 0.f) break;
                if (d < 1e-4f && step < 1e-4f) break;
            } else {
                o.pos.x += dx / d * step; o.pos.y += dy / d * step; step = 0.f;
                if (o.routeFace) o.yaw = std::atan2(dx, dy) / 0.0174532925f + o.routeFaceOff;   // 2D: 0 arriba, 90 derecha
            }
        }
        if (o.trail) trailStep(o, s, i);
    }
    for (auto& pr : pend) {   // las copias se crean al final para no invalidar referencias
        int slot = -1;
        for (int k = 0; k < n0; k++) if (sc->objs[k].ghost && !sc->objs[k].alive) { slot = k; break; }
        if (slot < 0 && (int)sc->objs.size() < kMaxObjs) {
            sc->objs.push_back(Obj());
            base_.push_back(V3{}); near_.push_back(0); moving_.push_back(0); last_.push_back(V3{});
            cmp_.push_back(Compiled()); st_.push_back(ObjState());
            slot = (int)sc->objs.size() - 1;
        }
        if (slot < 0) continue;
        base_[slot] = base_[pr.second] * sc->objs[pr.second].trailScale;
        float life = sc->objs[pr.second].trailLife;
        sc->objs[slot] = std::move(pr.first);
        st_[slot] = ObjState();
        st_[slot].wt = life;
        st_[slot].tz = sc->objs[slot].trailSolid ? (float)sc->objs[slot].ghostOwner : -1.f;
        if (!sc->objs[slot].blocks.empty()) compileObj(sc->objs[slot].blocks, cmp_[slot].match, cmp_[slot].hats);
        cmp_[slot] = Compiled();
        last_[slot] = sc->objs[slot].pos;
    }
}

// Sonido que viene de un objeto: más lejos = más bajo, y se oye más por el lado donde está (si el proyecto lo activa).
void Game::soundAt(const std::string& n, int self) {
    if (proj.spatial && onSound3 && sc && sc->is3d && self >= 0 && self < (int)sc->objs.size()) {
        const Obj& o = sc->objs[self];
        V3 d{o.pos.x - pos.x, 0.f, o.pos.z - pos.z};
        float dist = std::sqrt(d.x * d.x + d.z * d.z), R = std::max(2.f, proj.spatialR);
        float vol = dist >= R ? 0.f : std::pow(1.f - dist / R, 1.5f);
        V3 f = norm(V3{camFwd.x, 0.f, camFwd.z}), rt = norm(cross(f, V3{0, 1, 0}));
        float pan = dist > 0.01f ? (d.x * rt.x + d.z * rt.z) / dist * std::min(1.f, dist / 3.f) : 0.f;
        if (vol > 0.002f) onSound3(n, vol, pan);
        return;
    }
    if (onSound) onSound(n);
}

void Game::spawnNpcClone(int src) {
    if (src < 0 || src >= (int)sc->objs.size() || sc->objs.size() >= kMaxObjs) return;
    if (proj.perf.aliveOn) { int n = 0; for (auto& q : sc->objs) if (q.clone && q.alive) n++; if (n >= std::max(1, proj.perf.alive)) return; }
    Obj c = sc->objs[src];
    ObjState ns = st_[src];
    c.clone = true; c.alive = true; c.visible = true; c.cloneN = 0; c.cloneRespawn = false; c.name += "_clon";
    float ang = frand() * 6.2831853f, rr = std::sqrt(frand()) * sc->objs[src].cloneSpread;
    V3 hp = ns.homed ? V3{ns.hx, sc->objs[src].pos.y, ns.hz} : sc->objs[src].pos;
    c.pos.x = hp.x + std::cos(ang) * rr; c.pos.z = hp.z + std::sin(ang) * rr;
    if (!sc->is3d) { c.pos.y = sc->objs[src].pos.y + std::sin(ang) * rr; c.pos.z = sc->objs[src].pos.z; c.pos.x = hp.x + std::cos(ang) * rr; }
    ns.origin = src; ns.spawned = 0; ns.dead = false; ns.deadT = 0; ns.hp = c.ai.hp; ns.homed = false; ns.snapped = false; ns.wt = 0.f;
    ns.hatState.clear();
    sc->objs.push_back(std::move(c));
    int idx = (int)sc->objs.size() - 1;
    base_.push_back(base_[src]); near_.push_back(0); moving_.push_back(0); last_.push_back(sc->objs[idx].pos); cmp_.push_back(cmp_[src]);
    st_.push_back(std::move(ns));
    st_[idx].hatState.assign(sc->objs[idx].blocks.size(), 0);
    st_[src].spawned++;
}

void Game::npcCloneTick(float dt) {
    int n0 = (int)sc->objs.size();
    for (int i = 0; i < n0 && i < (int)st_.size(); i++) {
        const Obj& o = sc->objs[i];
        if (o.clone || !o.alive || o.cloneN <= 0) continue;
        ObjState& s = st_[i];
        s.spT += dt;
        if (s.origin != -2 && s.spT >= 0.05f) {   // primera tanda
            s.origin = -2;
            for (int k = 0; k < o.cloneN; k++) spawnNpcClone(i);
            continue;
        }
        if (!o.cloneRespawn || s.spT < 0.5f) continue;
        s.spT = 0.f;
        int total = o.cloneTotal > 0 ? o.cloneTotal : o.cloneN;
        int alive = 0;
        for (int j = 0; j < (int)sc->objs.size(); j++) if (st_[j].origin == i && sc->objs[j].alive && !st_[j].dead) alive++;
        if (alive < o.cloneN && s.spawned < total) spawnNpcClone(i);
    }
}

// Enemigos 2D: tipo Disparo (lanza balas hacia la dirección elegida) o Cuerpo a cuerpo (camina hacia el héroe y golpea).
void Game::enemy2dTick(float dt) {
    int h = heroIdx();
    if (h < 0 || h >= (int)st_.size()) return;
    const Obj& hero = sc->objs[h];
    const size_t n = sc->objs.size();
    for (size_t i = 0; i < n && i < st_.size(); i++) {
        Obj& o = sc->objs[i]; AiCfg& a = o.ai; ObjState& s = st_[i];
        if (!o.alive || !o.visible || a.type == AiType::None || o.bullet || (int)i == h) continue;   // oculto = como si no estuviera
        if (!s.homed) { s.homed = true; s.hp = a.hp; s.face = hero.pos.x >= o.pos.x ? 1.f : -1.f; }
        if (s.dead) continue;
        s.shoot2 = std::max(0.f, s.shoot2 - dt); s.melee2 = std::max(0.f, s.melee2 - dt); s.atkCd = std::max(0.f, s.atkCd - dt); s.atkT = std::max(0.f, s.atkT - dt);
        // el héroe golpea (ataque cuerpo a cuerpo) a los enemigos cercanos
        if (st_[h].heroAtk > 0.f && s.hurtT <= 0.f && std::fabs(hero.pos.x - o.pos.x) < 130.f + o.scale.x * 0.5f && std::fabs(hero.pos.y - o.pos.y) < 120.f) {
            damageObj((int)i, 1.f);
            if (s.hp <= 0.f) { s.dead = true; o.alive = false; auto it = vars.find("puntos"); if (it != vars.end()) it->second = Val((double)(it->second.num() + 10)); continue; }
        }
        s.hurtT = std::max(0.f, s.hurtT - dt);
        float dx = hero.pos.x - o.pos.x, dy = hero.pos.y - o.pos.y, d = std::sqrt(dx * dx + dy * dy);
        bool see = d <= a.sight * 100.f && hero.visible;   // si el héroe está oculto, no lo ven
        bool moving = false;
        if (see) {
            s.face = dx >= 0 ? 1.f : -1.f;
            if (a.type == AiType::Melee) {
                float reach = a.reach * 100.f + (o.scale.x + hero.scale.x) * 0.5f;
                if (std::fabs(dx) > reach * 0.8f) { o.pos.x += s.face * a.speed * 100.f * dt; moving = true; }
                else if (std::fabs(dy) < 150.f && s.atkCd <= 0.f) {
                    s.atkCd = std::max(0.2f, a.rate); s.atkT = 0.3f;
                    hurtPlayer(a.dmg);
                    if (!a.meleeTex.empty() && pendingObjs_.size() < 8) {   // dibujo del golpe, del lado donde pega
                        Obj f; f.name = "golpe"; f.kind = Kind::Cube; f.tex = a.meleeTex; f.noColor = true; f.solid = false; f.clone = true;
                        f.scale = V3{o.scale.x * 0.8f, o.scale.y * 0.8f, 1.f}; f.pos = V3{o.pos.x + s.face * o.scale.x * 0.7f, o.pos.y, o.pos.z}; f.layer = o.layer + 1;
                        f.yaw = 90.f; f.bullet = true; f.bvel = V3{0, 0, 0}; f.bLife = 0.25f; f.bOff = true;
                        pendingObjs_.push_back(f);
                    }
                }
            } else if (a.type == AiType::Shooter && s.shoot2 <= 0.f && pendingObjs_.size() < 8) {
                s.shoot2 = std::max(0.1f, a.rate); s.atkT = 0.3f;
                V3 dir{s.face, 0, 0};
                switch (a.bdir) { case 1: dir = V3{1, 0, 0}; break; case 2: dir = V3{-1, 0, 0}; break; case 3: dir = V3{0, 1, 0}; break; case 4: dir = V3{0, -1, 0}; break; default: break; }
                Obj b; b.name = "bala"; b.kind = Kind::Cube; b.tex = a.projTex; b.noColor = !a.projTex.empty(); b.solid = false; b.clone = true;
                for (int k = 0; k < 3; k++) b.color[k] = a.projColor[k];
                float sz = std::max(10.f, a.projSize * 100.f);
                b.scale = V3{sz, sz, 1.f}; b.pos = V3{o.pos.x + dir.x * o.scale.x * 0.6f, o.pos.y + dir.y * o.scale.y * 0.6f, o.pos.z}; b.layer = o.layer + 1; b.yaw = 90.f;
                b.bullet = true; b.bvel = dir * (a.projSpeed * 40.f); b.bLife = a.blife; b.bOff = a.boff; b.bDmg = a.dmg;
                if (!a.bpaths.empty()) {   // ruta dibujada: en orden o al azar
                    size_t pi = a.bpathMode == 1 ? (size_t)irand((int)a.bpaths.size()) : (size_t)(s.spawned++ % (int)a.bpaths.size());
                    b.bpath = a.bpaths[pi];
                    if (a.bdir == 0 && s.face < 0) for (size_t q = 0; q + 1 < b.bpath.size(); q += 2) b.bpath[q] = -b.bpath[q];   // si mira a la izquierda, la ruta se refleja
                    b.bstart = o.pos; b.bseg = 0; b.bspd = a.projSpeed * 40.f; b.pos = o.pos; b.bvel = V3{0, 0, 0};
                }
                pendingObjs_.push_back(b);
            }
        }
        // dibujo según lo que hace (mismas imágenes por acción que el héroe)
        bool any = false; for (auto& im : o.act) if (!im.empty()) any = true;
        if (any) {
            if (!s.baseSet) { s.baseTex = o.tex; s.baseSet = true; }
            bool r = s.face > 0; const std::string* pick = nullptr;
            auto tryA = [&](int k) { if (!pick && !o.act[k].empty()) pick = &o.act[k]; };
            if (s.atkT > 0.f) tryA(r ? 6 : 5);
            if (std::fabs(s.vel.y) > 30.f) tryA(r ? 4 : 3);
            if (moving) tryA(r ? 2 : 1);
            tryA(0);
            o.tex = pick ? *pick : s.baseTex;
        }
    }
}

// Balas y golpes en línea recta: se mueven solos, desaparecen por tiempo o al salir de la pantalla y dañan al héroe.
void Game::bulletTick(float dt) {
    int h = heroIdx();
    const float hw = stageW() * 0.5f + 120.f, hh = kView2DHeight * 0.5f + 120.f;
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive || !o.bullet) continue;
        if (!o.bpath.empty()) {   // sigue su ruta punto por punto
            float left = o.bspd * dt;
            while (left > 0.f && o.bseg * 2 + 1 < o.bpath.size()) {
                V3 tg{o.bstart.x + o.bpath[o.bseg * 2], o.bstart.y + o.bpath[o.bseg * 2 + 1], o.pos.z};
                float ddx = tg.x - o.pos.x, ddy = tg.y - o.pos.y, dd = std::sqrt(ddx * ddx + ddy * ddy);
                if (dd <= left) { o.pos = tg; left -= dd; o.bseg++; }
                else { o.pos.x += ddx / dd * left; o.pos.y += ddy / dd * left; left = 0.f; }
            }
            if (o.bseg * 2 + 1 >= o.bpath.size()) { o.alive = false; continue; }   // terminó la ruta
        } else o.pos = o.pos + o.bvel * dt;
        o.bAge += dt;
        if (o.bLife > 0.f && o.bAge >= o.bLife) { o.alive = false; continue; }
        if (o.bOff && (std::fabs(o.pos.x - cam2x) > hw || std::fabs(o.pos.y - cam2y) > hh)) { o.alive = false; continue; }
        if (o.bDmg > 0.f && h >= 0 && h != (int)i) {
            const Obj& he = sc->objs[h];
            if (he.visible && o.visible && std::fabs(o.pos.x - he.pos.x) < (o.scale.x + he.scale.x) * 0.45f && std::fabs(o.pos.y - he.pos.y) < (o.scale.y + he.scale.y) * 0.45f) { hurtPlayer(o.bDmg); o.alive = false; }
        }
    }
}

void Game::fixVctlTick(float dt) {
    // Movimiento por controles virtuales (2D).
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        auto& s = st_[i]; Obj& o = sc->objs[i];
        if (!sc->is3d && o.vctl > 0 && o.alive && !o.ghost && o.kind != Kind::Player) {
            auto held = [&](const char* n) { return std::find(in_.buttons.begin(), in_.buttons.end(), std::string(n)) != in_.buttons.end(); };
            float mx = in_.moveX + (held("Derecha") ? 1.f : 0.f) - (held("Izquierda") ? 1.f : 0.f);
            float my = in_.moveY + (held("Arriba") ? 1.f : 0.f) - (held("Abajo") ? 1.f : 0.f);
            mx = std::max(-1.f, std::min(1.f, mx)); my = std::max(-1.f, std::min(1.f, my));
            bool air = o.vctl == 2 && o.phys != Phys::None && !s.grounded;
            if (std::fabs(mx) > 0.15f) s.face = mx > 0 ? 1.f : -1.f;
            bool atk = in_.shoot || held("B");
            for (auto& bn : in_.buttons) { std::string lb = normName(bn); if (lb.find("atac") != std::string::npos || lb.find("ataq") != std::string::npos || lb.find("golpe") != std::string::npos || lb.find("dispar") != std::string::npos || lb.find("pegar") != std::string::npos) atk = true; }
            if (atk) s.heroAtk = 0.3f; else s.heroAtk = std::max(0.f, s.heroAtk - dt);
            bool any = false; for (auto& a : o.act) if (!a.empty()) any = true;
            if (any) {
                if (!s.baseSet) { s.baseTex = o.tex; s.baseSet = true; }
                bool r = s.face > 0, mv = std::fabs(mx) > 0.15f || (o.vctl == 1 && std::fabs(my) > 0.15f);
                const std::string* pick = nullptr;
                auto tryA = [&](int k) { if (!pick && !o.act[k].empty()) pick = &o.act[k]; };
                if (s.heroAtk > 0) { tryA(r ? 6 : 5); }
                if (air) tryA(r ? 4 : 3);
                if (mv) tryA(r ? 2 : 1);
                tryA(0);
                o.tex = pick ? *pick : s.baseTex;
            }
            float autoX = 0.f, spd = o.vctlSpd;
            if (sc->map2auto) {   // caminata automática: con física corre solo y tú saltas; sin física avanza solo y mueves la nave por la pantalla
                if (o.vctl == 2 && o.phys != Phys::None) { mx = 1.f; spd = sc->map2autoSpd; s.face = 1.f; }
                else autoX = sc->map2autoSpd * dt;
            }
            if (o.vctl == 1 || o.phys == Phys::None) { o.pos.x += mx * spd * dt + autoX; o.pos.y += my * spd * dt; }
            else {   // con física: la palanca/flechas mueven de lado; A / Arriba / salto saltan
                s.vel.x = mx * spd;
                const bool pr = held("A") || held("Saltar") || held("Arriba") || in_.jump;
                const bool edge = pr && !s.jPrev;
                s.jPrev = pr;
                if (s.grounded) { s.jAir = 0; s.fuel = 1.f; }
                const float jp = o.vctlJump;
                if (o.jumpMode == 3) {   // propulsor: se mantiene el botón para subir mientras haya combustible
                    if (edge && s.grounded) s.vel.y = jp;
                    else if (pr && s.fuel > 0.f && !s.grounded) { s.vel.y = std::min(jp * 0.8f, s.vel.y + jp * 3.f * dt); s.fuel -= dt / 1.6f; }
                } else if (edge) {
                    int maxAir = o.jumpMode;   // 0 = un salto, 1 = doble, 2 = triple
                    if (s.grounded) { s.vel.y = jp; snd(1); }
                    else if (s.jAir < maxAir) { s.jAir++; s.vel.y = jp * 0.9f; snd(1); }
                }
            }
        }
    }
}

int Game::heroIdx() const {
    if (!sc || sc->is3d) return -1;
    for (size_t i = 0; i < sc->objs.size(); i++) if (sc->objs[i].vctl > 0 && sc->objs[i].alive && !sc->objs[i].mapPart) return (int)i;
    for (size_t i = 0; i < sc->objs.size(); i++) { std::string n = normName(sc->objs[i].name); if (sc->objs[i].alive && (n == "jugador" || n == "player")) return (int)i; }
    return -1;
}

// Mapa 2D: la cámara sigue al héroe, el héroe no sale del mapa, y la Meta cambia de escena.
void Game::mapTick(float dt) {
    if (!sc || sc->is3d) return;
    int h = heroIdx();
    if (h >= 0 && h < (int)st_.size()) {
        Obj& o = sc->objs[h]; auto& s = st_[h];
        if (sc->map2on) {
            std::vector<const Obj*> rs;
            for (auto& m : sc->objs) if (m.mapPart == 1 && m.alive) rs.push_back(&m);
            if (!rs.empty() && s.hHas) {
                auto inside = [&](float x, float y) {
                    float ex = o.scale.x * 0.45f, ey = o.scale.y * 0.45f;
                    const float cx[4] = {x - ex, x + ex, x - ex, x + ex}, cy[4] = {y - ey, y - ey, y + ey, y + ey};
                    for (int k = 0; k < 4; k++) {
                        bool ok = false;
                        for (auto* m : rs) if (std::fabs(cx[k] - m->pos.x) <= m->scale.x * 0.5f && std::fabs(cy[k] - m->pos.y) <= m->scale.y * 0.5f) { ok = true; break; }
                        if (!ok) return false;
                    }
                    return true;
                };
                if (!inside(o.pos.x, o.pos.y)) {
                    if (inside(s.hPrev.x, o.pos.y)) { o.pos.x = s.hPrev.x; s.vel.x = 0; }
                    else if (inside(o.pos.x, s.hPrev.y)) { o.pos.y = s.hPrev.y; s.vel.y = 0; }
                    else { o.pos.x = s.hPrev.x; o.pos.y = s.hPrev.y; s.vel.x = s.vel.y = 0; }
                }
            }
            s.hPrev = o.pos; s.hHas = true;
            cam2x = o.pos.x;
            cam2y = (o.vctl == 2 && sc->map2jump == 0) ? sc->map2y : o.pos.y;   // salto real: la cámara no sube; si no, sigue al héroe
        }
        for (auto& m : sc->objs) {   // Meta
            if (!m.goal || !m.alive || m.goalScene.empty()) continue;
            if (overlap(m, o)) { for (auto& sn : proj.scenes) if (sn.name == m.goalScene) { pending_ = m.goalScene; break; } break; }
        }
    }
}

// Llantas de un auto: siguen al auto, giran al avanzar o retroceder y las de adelante giran al dar vuelta.
void Game::wheelTick(float dt) {
    if (!sc || !sc->is3d) return;
    const float K = 0.0174532925f;
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& w = sc->objs[i];
        if (w.wheelOf.empty()) continue;
        auto& s = st_[i];
        if (s.wCar < 0 || s.wCar >= (int)sc->objs.size() || sc->objs[s.wCar].name != w.wheelOf) { s.wCar = findObj(w.wheelOf); s.wHas = false; }
        if (s.wCar < 0) continue;
        if (s.wCar == playerIndex(*sc)) {   // llantas del jugador en modo auto: siguen al cuerpo del jugador (no es un objeto que se mueva solo)
            const PlayerCfg& pc = proj.player;
            w.visible = camMode != kFirstPerson && carIdx < 0;
            float yawD = 180.f - bodyYaw / K + pc.myaw;
            float ya = yawD * K, cs = std::cos(ya), sn = std::sin(ya);
            V3 lo{w.wheelOff.x * w.scale.x, w.wheelOff.y * w.scale.y, w.wheelOff.z * w.scale.z};
            V3 rgtB{std::cos(bodyYaw), 0, std::sin(bodyYaw)}, fwdB{std::sin(bodyYaw), 0, -std::cos(bodyYaw)};
            V3 base = pos + rgtB * pc.mox + fwdB * pc.moz;
            w.pos = V3{base.x + cs * lo.x + sn * lo.z, base.y + pc.moy + lo.y, base.z - sn * lo.x + cs * lo.z};
            if (s.wHas) {
                V3 d = pos - s.wPrev;
                float fwd = d.x * fwdB.x + d.z * fwdB.z;
                if (std::fabs(fwd) < 5.f) s.wAng += fwd / std::max(0.02f, w.wheelR) / K;
            }
            s.wPrev = pos; s.wHas = true;
            s.wAng = std::fmod(s.wAng, 360.f);
            float steer = w.wheelFront ? carLean_ * 25.f : 0.f;
            w.yaw = yawD - steer;
            if (w.wheelAxle == 0) { w.pitch = s.wAng; w.roll = 0.f; }
            else { w.roll = s.wAng; w.pitch = 0.f; }
            continue;
        }
        const Obj& c = sc->objs[s.wCar];
        if (!c.alive) { w.visible = false; continue; }
        w.visible = c.visible;
        float ya = c.yaw * K, cs = std::cos(ya), sn = std::sin(ya);
        V3 lo{w.wheelOff.x * c.scale.x, w.wheelOff.y * c.scale.y, w.wheelOff.z * c.scale.z};
        w.pos = V3{c.pos.x + cs * lo.x + sn * lo.z, c.pos.y + lo.y, c.pos.z - sn * lo.x + cs * lo.z};
        w.scale = c.scale;
        float fo = c.frontOff * K;
        float flx = -std::sin(fo), flz = -std::cos(fo);           // hacia dónde mira el frente en el modelo
        float h = (-c.yaw - c.frontOff) * K;                      // rumbo del auto en el mundo
        if (s.wHas) {
            V3 d = c.pos - s.wPrev;
            float fwd = d.x * std::sin(h) + d.z * (-std::cos(h));
            if (std::fabs(fwd) < 5.f) s.wAng += fwd / std::max(0.02f, w.wheelR) / K;
        }
        s.wPrev = c.pos; s.wHas = true;
        s.wAng = std::fmod(s.wAng, 360.f);
        float steer = (w.wheelFront && s.wCar == carIdx) ? carLean_ * 25.f : 0.f;
        w.yaw = c.yaw - steer;
        if (w.wheelAxle == 0) { w.pitch = flz * s.wAng; w.roll = 0.f; }
        else { w.roll = -flx * s.wAng; w.pitch = 0.f; }
    }
}

// Ragdoll: los pedazos siguen al objeto (ocultos) hasta que se activa; entonces caen, rebotan y ruedan.
bool Game::asleep(int i) const {
    if (!sc || !sc->is3d || sc->simDist <= 0.f) return false;
    const Obj& o = sc->objs[i];
    if (o.kind == Kind::Player || o.kind == Kind::Floor || o.bullet || i == carIdx || !o.wheelOf.empty() || !o.ragOf.empty()) return false;
    float dx = o.pos.x - pos.x, dz = o.pos.z - pos.z, lim = sc->simDist + std::max(o.scale.x, o.scale.z);
    return dx * dx + dz * dz > lim * lim;
}

void Game::ragActivate(int parent) {
    if (!sc || parent < 0 || parent >= (int)sc->objs.size()) return;
    const std::string nm = sc->objs[parent].name;
    auto rnd = [&]() { ragSeed_ = ragSeed_ * 1664525u + 1013904223u; return ((ragSeed_ >> 8) & 0xFFFF) / 65535.f * 2.f - 1.f; };
    bool any = false;
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& w = sc->objs[i];
        if (w.ragOf != nm || st_[i].ragOn) continue;
        auto& s = st_[i];
        s.ragOn = true; any = true;
        s.rv = V3{rnd() * 2.5f, 2.f + std::fabs(rnd()) * 3.f, rnd() * 2.5f};
        s.rw = V3{rnd() * 360.f, rnd() * 360.f, rnd() * 360.f};
        w.visible = true;
    }
    if (any) { sc->objs[parent].visible = false; sc->objs[parent].solid = false; }
}

void Game::ragTick(float dt) {
    if (!sc || !sc->is3d) return;
    const float K = 0.0174532925f;
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& w = sc->objs[i];
        if (w.ragOf.empty()) continue;
        auto& s = st_[i];
        int par = findObj(w.ragOf);
        if (par < 0) continue;
        if (!s.ragOn) {
            const Obj& c = sc->objs[par];
            if (!c.alive && w.ragDeath) { ragActivate(par); if (!s.ragOn) continue; }
            else {
                w.visible = false;   // mientras el objeto está entero, los pedazos no se ven
                float ya = c.yaw * K, cs = std::cos(ya), sn = std::sin(ya);
                V3 lo{w.ragOff.x * c.scale.x, w.ragOff.y * c.scale.y, w.ragOff.z * c.scale.z};
                w.pos = V3{c.pos.x + cs * lo.x + sn * lo.z, c.pos.y + lo.y, c.pos.z - sn * lo.x + cs * lo.z};
                w.scale = c.scale; w.yaw = c.yaw; w.pitch = c.pitch; w.roll = c.roll;
                continue;
            }
        }
        // pedazo suelto: gravedad, suelo, fricción
        s.rv.y -= 20.f * dt;
        w.pos = w.pos + s.rv * dt;
        w.yaw += s.rw.y * dt; w.pitch += s.rw.x * dt; w.roll += s.rw.z * dt;
        float sy = supportY((int)i);
        if (sy > -1e8f && w.pos.y - w.ragR < sy) {
            w.pos.y = sy + w.ragR;
            s.rv.y = s.rv.y < -1.5f ? -s.rv.y * 0.25f : 0.f;
            float f = std::exp(-7.f * dt); s.rv.x *= f; s.rv.z *= f;
            float g = std::exp(-5.f * dt); s.rw = s.rw * g;
        } else if (w.pos.y < -200.f) { s.rv = V3{0, 0, 0}; s.rw = V3{0, 0, 0}; }
    }
}

void Game::autoTick(float dt) {
    if (!sc) return;
    if (penScene_ != sc) { pen_.clear(); penScene_ = sc; hasCp = false; scareT = blackT = 0.f; darkK = 1.f; fear = 0.f; }
    if (scareT > 0.f) scareT -= dt;
    if (blackT > 0.f) {   // apagón: parpadea al apagarse y al volver
        blackT -= dt;
        float ph = blackTot - blackT;
        bool flick = (ph < 0.9f || blackT < 1.0f) && ((int)(time * 18.f) % 3 == 0);
        darkK = flick ? 0.55f : 0.03f;
    } else darkK += (1.f - darkK) * std::min(1.f, dt * 3.f);
    if (!sc->is3d) for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {   // lápiz: una línea por cada tramo que se mueve
        ObjState& q = st_[i]; const Obj& o = sc->objs[i];
        if (!q.penDown || !o.alive) { q.penHas = false; continue; }
        if (!q.penHas) { q.penHas = true; q.penX = o.pos.x; q.penY = o.pos.y; continue; }
        float dx = o.pos.x - q.penX, dy = o.pos.y - q.penY;
        if (dx * dx + dy * dy < 0.25f) continue;
        if (pen_.size() >= 30000) pen_.erase(pen_.begin(), pen_.begin() + 15000);
        pen_.push_back({q.penX, q.penY, o.pos.x, o.pos.y, q.penW, q.penR, q.penG, q.penB});
        q.penX = o.pos.x; q.penY = o.pos.y;
    }
    if (!sc->is3d) for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {   // modo listado: la lista se desliza hacia la apariencia actual
        const Obj& o = sc->objs[i];
        if (!o.listMode) continue;
        std::vector<std::string> seq; int cur;
        if (!listSeq(o, 0, seq, cur)) continue;
        ObjState& q = st_[i];
        int n = (int)seq.size();
        if (!q.listInit) { q.listInit = true; q.listPos = (float)cur; continue; }
        float d = (float)cur - q.listPos;
        if (o.listWrap) d -= (float)n * std::round(d / (float)n);
        q.listPos += d * (1.f - std::exp(-o.listSpeed * dt));
        if (std::fabs((float)cur - q.listPos) < 0.003f || (o.listWrap && std::fabs(d) < 0.003f)) q.listPos = (float)cur;
        if (o.listWrap) { while (q.listPos >= (float)n) q.listPos -= (float)n; while (q.listPos < 0.f) q.listPos += (float)n; }
    }
    npcCloneTick(dt);
    fixVctlTick(dt);
    if (!sc->is3d) { enemy2dTick(dt); bulletTick(dt); }
    playerNoDmg_ = std::max(0.f, playerNoDmg_ - dt);
    for (auto& q : st_) if (q.noDmg > 0.f) q.noDmg = std::max(0.f, q.noDmg - dt);
    if (!sc->is3d) { routeTick2D(dt); return; }
    // auto cercano para el botón «Conducir»
    nearCar = -1;
    if (carIdx >= 0 && carIdx < (int)sc->objs.size()) {   // el auto sigue al jugador
        Obj& o = sc->objs[carIdx];
        o.pos.x = pos.x; o.pos.z = pos.z;
        o.yaw = -(bodyYaw / 0.0174532925f + carLean_ * 14.f + o.frontOff);   // al girar el auto se ve rotar un poco hacia ese lado
        o.roll = carLean_ * 3.f;
    } else {
        float best = 1e9f;
        for (size_t i = 0; i < sc->objs.size(); i++) {
            const Obj& o = sc->objs[i];
            if (!o.alive || !o.visible || !o.carMode) continue;
            float d = std::sqrt((o.pos.x - pos.x) * (o.pos.x - pos.x) + (o.pos.z - pos.z) * (o.pos.z - pos.z)) - std::max(o.scale.x, o.scale.z) * 0.4f;
            if (d < o.carEnterD && d < best) { best = d; nearCar = (int)i; }
        }
    }
    auto yawOf = [](float dx, float dz) { return std::atan2(dx, -dz) / 0.0174532925f; };
    auto turn = [](float cur, float want, float maxd) {
        float d = std::fmod(want - cur + 540.f, 360.f) - 180.f;
        d = std::max(-maxd, std::min(maxd, d));
        return cur + d;
    };
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
        Obj& o = sc->objs[i];
        ObjState& s = st_[i];
        if (o.snapGround && !s.snapped && o.alive) {   // se apoya en el suelo (o montaña) que tiene debajo
            s.snapped = true;
            float sy = supportY((int)i);
            if (sy > -1e8f) { float cx, cy, cz, hx, hy, hz; effBox(o, cx, cy, cz, hx, hy, hz); o.pos.y += sy - (cy - hy); }
        }
        if (!o.alive || (!o.wander && !o.routeOn) || (int)i == carIdx || s.dead) continue;
        if (!s.homed) { s.homed = true; s.hx = s.tx = o.pos.x; s.hz = s.tz = o.pos.z; s.wt = 0.f; }
        float pdx = o.pos.x - pos.x, pdz = o.pos.z - pos.z;
        if (pdx * pdx + pdz * pdz > o.actR * o.actR) continue;   // lejos del jugador: quieto
        float hw = std::max(0.3f, std::min(o.scale.x, o.scale.z) * 0.4f);
        if (o.routeOn && s.rpause) { s.spd = 0.f; continue; }
        if (o.routeOn && s.rwait > 0.f) { s.rwait -= dt_; s.spd = 0.f; continue; }
        if (o.routeOn && o.route.size() >= 4) {
            int n = (int)o.route.size() / 2;
            if (s.wp < 0 || s.wp >= n) {   // empieza por el punto más cercano
                float bd = 1e30f; s.wp = 0;
                for (int k = 0; k < n; k++) { float d = (o.route[k * 2] - o.pos.x) * (o.route[k * 2] - o.pos.x) + (o.route[k * 2 + 1] - o.pos.z) * (o.route[k * 2 + 1] - o.pos.z); if (d < bd) { bd = d; s.wp = k; } }
            }
            float tx = o.route[s.wp * 2], tz = o.route[s.wp * 2 + 1];
            float dx = tx - o.pos.x, dz = tz - o.pos.z, d = std::sqrt(dx * dx + dz * dz);
            if (d < 3.f + s.spd * 0.08f) {   // llegó al punto: sigue con el siguiente; al cerrar el circuito cuenta una vuelta
                bool wrapped = s.wp + 1 >= n;
                if (wrapped && !o.routeLoop) { s.laps++; if (o.routeLaps > 0 && s.laps >= o.routeLaps) { o.routeOn = false; s.spd = 0; continue; } }
                s.wp = (s.wp + 1) % n;
                if (wrapped && o.routeLoop) { s.laps++; if (o.routeLaps > 0 && s.laps >= o.routeLaps) { o.routeOn = false; s.spd = 0; continue; } s.rwait = routeWaitFor(o); }
                if (wrapped && !o.routeLoop) { /* sin circuito: vuelve a empezar desde el primer punto */ }
                continue;
            }
            // "ganas de ganar": acelera más si el jugador va delante; baja la velocidad en las curvas cerradas
            float pd = std::sqrt(pdx * pdx + pdz * pdz);
            float target = o.routeSpd * (pd > 12.f ? 1.f + o.routeAggr * 0.15f : 1.f);
            float hdg = -o.yaw - o.frontOff;
            float wantH = yawOf(dx, dz);
            float dh = std::fabs(std::fmod(wantH - hdg + 540.f, 360.f) - 180.f);
            target *= std::max(0.35f, 1.f - dh / 140.f);
            s.spd += std::max(-30.f * dt, std::min(10.f * dt + o.routeAggr * 6.f * dt, target - s.spd));   // arranca y frena poco a poco
            float turnRate = 90.f + 150.f * std::min(1.f, s.spd / 12.f);
            hdg = turn(hdg, wantH, turnRate * dt);
            o.yaw = -(hdg + o.frontOff);
            float a = hdg * 0.0174532925f;
            V3 np{o.pos.x + std::sin(a) * s.spd * dt, o.pos.y, o.pos.z - std::cos(a) * s.spd * dt};
            if (!movBlocked(o, np, hw, (int)i)) { o.pos.x = np.x; o.pos.z = np.z; }
            else s.spd *= 0.5f;
            if (o.routePush) {   // empuja a quien tenga delante (jugador o rivales)
                float fx = std::sin(a), fz = -std::cos(a);
                for (size_t j = 0; j < sc->objs.size(); j++) {
                    if (j == i || (int)j == carIdx) continue;
                    Obj& q = sc->objs[j];
                    if (!q.alive || !q.routeOn) continue;
                    float ex = q.pos.x - o.pos.x, ez = q.pos.z - o.pos.z, ed = std::sqrt(ex * ex + ez * ez);
                    if (ed < 2.4f && ed > 0.01f && ex * fx + ez * fz > 0) { q.pos.x += ex / ed * 4.f * dt; q.pos.z += ez / ed * 4.f * dt; }
                }
                if (pd < 2.6f && pd > 0.01f && (-pdx) * fx + (-pdz) * fz > 0) {
                    V3 np2{pos.x - pdx / pd * 5.f * dt, pos.y, pos.z - pdz / pd * 5.f * dt};
                    if (!blockedBox(np2, 0.3f, 1.7f, carIdx)) pos = np2;
                    if (carIdx >= 0) carSpeed_ *= (1.f - 0.6f * dt);
                }
            }
            if (o.routeThrow > 0) {   // lanza cosas al más cercano (o al jugador)
                s.thrCd -= dt;
                if (s.thrCd <= 0) {
                    V3 tgt = pos; float bd = pd; bool ok = pd < 26.f;
                    if (o.routeThrow == 1) {
                        for (size_t j = 0; j < sc->objs.size(); j++) {
                            if (j == i) continue;
                            const Obj& q = sc->objs[j];
                            if (!q.alive || !q.routeOn) continue;
                            float d2 = std::sqrt((q.pos.x - o.pos.x) * (q.pos.x - o.pos.x) + (q.pos.z - o.pos.z) * (q.pos.z - o.pos.z));
                            if (d2 < bd) { bd = d2; tgt = q.pos; ok = d2 < 26.f; }
                        }
                    }
                    s.thrCd = 3.5f - o.routeAggr * 2.f + frand() * 1.5f;
                    if (ok) spawnProj(V3{o.pos.x, o.pos.y + o.scale.y * 0.4f, o.pos.z}, V3{tgt.x - o.pos.x, 0.3f, tgt.z - o.pos.z}, (int)i);
                }
            }
            continue;
        }
        if (o.wander) {
            if (s.wt > 0.f) { s.wt -= dt; continue; }
            float dx = s.tx - o.pos.x, dz = s.tz - o.pos.z, d = std::sqrt(dx * dx + dz * dz);
            if (d < 0.4f) {   // llegó: espera un poco y elige otro destino dentro del radio
                float ang = frand() * 6.2831853f, rr = frand() * o.wanderR;
                s.tx = s.hx + std::cos(ang) * rr; s.tz = s.hz + std::sin(ang) * rr;
                s.wt = frand() * 2.f;
                continue;
            }
            o.yaw = -(turn(-o.yaw - o.frontOff, yawOf(dx, dz), 360.f * dt) + o.frontOff);
            float stp = std::min(d, o.wanderSpd * dt);
            V3 np{o.pos.x + dx / d * stp, o.pos.y, o.pos.z + dz / d * stp};
            if (movBlocked(o, np, hw, (int)i)) { s.tx = o.pos.x; s.tz = o.pos.z; s.wt = 0.5f; }   // chocó: espera y elige otro
            else { o.pos.x = np.x; o.pos.z = np.z; }
        }
    }
}

bool Game::collisionOff(int i) {
    if (i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size()) return false;
    Obj& o = sc->objs[i];
    if (st_[i].solidBlk < 0) {
        st_[i].solidBlk = 0;
        for (auto& b : o.blocks) if (b.op == Op::SetSolid) { st_[i].solidBlk = 1; break; }
    }
    return st_[i].solidBlk == 1 && !o.solid;
}

void Game::checkConditions() {
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        if (!o.alive) continue;
        if (asleep((int)i)) continue;
        for (int h : cmp_[i].hats) {
            const Block& b = o.blocks[h];
            if (b.op == Op::WhenTrue) {
                bool now = eval(b.f[0], (int)i).truthy();
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            } else if (b.op == Op::WhenCollide) {
                bool now = false;
                std::string k = normName(b.t);
                if (collisionOff(i)) { st_[i].hatState[h] = false; continue; }   // colisión apagada con el bloque: no choca
                if (sc->is3d && (k == "jugador" || k == "player")) {
                    V3 d = o.pos - V3{pos.x, pos.y + 0.85f, pos.z};
                    now = std::fabs(d.x) < o.scale.x * .5f + 0.3f && std::fabs(d.y) < o.scale.y * .5f + 0.85f &&
                          std::fabs(d.z) < o.scale.z * .5f + 0.3f;
                } else {
                    // se prueban TODOS los objetos con ese nombre que sigan vivos (clones, copias...) y, en 2D, también «el jugador»;
                    // antes solo se miraba el primero de la lista (aunque estuviera borrado) y a veces no se detectaba
                    int hero2 = (!sc->is3d && (k == "jugador" || k == "player" || k == "heroe")) ? heroIdx() : -1;
                    for (size_t j = 0; j < sc->objs.size() && !now; j++) {
                        if ((int)j == (int)i) continue;
                        const Obj& q = sc->objs[j];
                        if (!q.alive || !q.visible || !o.visible || collisionOff((int)j)) continue;
                        if (!((int)j == hero2 || normName(q.name) == k)) continue;
                        now = overlap(o, q);
                        if (!now && !sc->is3d && st_[i].havePrev && st_[j].havePrev) {   // objetos muy rápidos: también se prueba a medio camino (no se «saltan» al otro)
                            Obj a = o, c = q;
                            a.pos = (st_[i].prevP + o.pos) * 0.5f; c.pos = (st_[j].prevP + q.pos) * 0.5f;
                            now = overlap(a, c);
                        }
                    }
                }
                if (now && !st_[i].hatState[h]) startScript((int)i, h);
                st_[i].hatState[h] = now;
            }
        }
    }
    for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) { st_[i].prevP = sc->objs[i].pos; st_[i].havePrev = true; }
}

// ---------------------------------------------------------------- bucle principal
void Game::update(float dt, const Input& inRaw, float aspect) {
    Input in = inRaw;
    if (cineIdx_ >= 0) {   // durante una cinemática el jugador no controla nada (tocar la pantalla la salta)
        if (in.tap && cineIdx_ < (int)proj.cines.size() && proj.cines[cineIdx_].skip) stopCine();
        in.moveX = in.moveY = in.lookX = in.lookY = 0; in.jump = in.shoot = in.reload = in.nextWeapon = false; in.tap = false; in.buttons.clear();
    }
    if (playerFrozen_) { in.moveX = in.moveY = in.lookX = in.lookY = 0; in.jump = in.shoot = in.reload = in.nextWeapon = false; }
    for (auto& bn : in.buttons) if (bn == "Apuntar" || bn == "apuntar") in.aim = true;   // un botón de pantalla llamado «Apuntar» (mantener presionado) también apunta
    if (playerFrozen_ || cineIdx_ >= 0) { in.aim = false; }
    {   // apuntar con la mira: se acerca suave y se mira/camina más lento
        bool want = aiming || (in.aim && proj.player.aimHold);
        aimK += ((want ? 1.f : 0.f) - aimK) * std::min(1.f, dt * std::max(1.f, proj.player.aimSpeed));
        if (!want && aimK < 0.01f) aimK = 0.f;
        if (aimK > 0.001f) { float k = 1.f + (proj.player.aimLook - 1.f) * aimK; in.lookX *= k; in.lookY *= k; }
    }
    if (in.flash && proj.player.flashlight && !playerFrozen_) { flashOn_ = !flashOn_; if (onSound) onSound("linterna"); }
    dt_ = std::max(0.001f, std::min(0.1f, dt * timeScale_));
    dt = dt_;
    videoTick();
    for (auto& tk : tilt_) {   // mover al inclinar el teléfono
        if (tk.first < 0 || tk.first >= (int)sc->objs.size() || tk.second == 0.f) continue;
        Obj& to = sc->objs[tk.first];
        if (!to.alive) continue;
        float ax = std::max(-1.f, std::min(1.f, -dev.accel[0] / 9.8f)), ay = std::max(-1.f, std::min(1.f, -dev.accel[1] / 9.8f));
        if (std::fabs(ax) < 0.08f) ax = 0.f;
        if (std::fabs(ay) < 0.08f) ay = 0.f;
        if (sc->is3d) { to.pos.x += ax * tk.second * 0.02f * dt; to.pos.z -= ay * tk.second * 0.02f * dt; }
        else { to.pos.x += ax * tk.second * dt; to.pos.y += ay * tk.second * dt; }
    }
    pushTick();
    keepTick();
    if (aspect > 0.1f) aspect_ = aspect;
    if (net_.active()) {   // v10.7: multijugador local
        netTime_ += dt;
        net_.tick(netTime_, pos.x, pos.y, pos.z, bodyYaw, sc ? sc->name : "");
        for (auto& m : net_.takeMsgs()) broadcast(m, nullptr);
        for (auto& kv : net_.takeVars()) { std::string k = normName(kv.first); vars[k] = Val(std::atof(kv.second.c_str())); netLast_[k] = vars[k].txt(); }
        vars["jugadores"] = (double)net_.peers().size() + 1.0;
        vars["soyhost"] = net_.isHost() ? 1.0 : 0.0;
        if (net_.joined() > 0) broadcast("jugador_conectado", nullptr);
        if (net_.left() > 0) broadcast("jugador_desconectado", nullptr);
        for (auto& k : netShared_) {
            auto it = vars.find(k); if (it == vars.end()) continue;
            std::string cur = it->second.txt();
            if (netLast_[k] != cur) { net_.sendVar(k, cur); netLast_[k] = cur; }
        }
    }
    if (sc && sc->is3d) { vars["jugadorx"] = pos.x; vars["jugadory"] = pos.y; vars["jugadorz"] = pos.z; }   // v10.7: posicion del jugador para los bloques
    if (proj.player.runner && sc && sc->is3d && !playerFrozen_) {   // corredor infinito
        auto has = [&](const char* n) { return std::find(in.buttons.begin(), in.buttons.end(), std::string(n)) != in.buttons.end(); };
        bool l = has("Deslizar izquierda") || in.moveX < -0.6f, r = has("Deslizar derecha") || in.moveX > 0.6f;
        if (l && !laneL_) lane_ = std::max(-1, lane_ - 1);
        if (r && !laneR_) lane_ = std::min(1, lane_ + 1);
        laneL_ = l; laneR_ = r;
        if (has("Deslizar arriba") || has("Arriba")) in.jump = true;
        if (has("Deslizar abajo") || has("Abajo")) slideT_ = 0.7f;
        if (slideT_ > 0) { in.crouch = true; slideT_ -= dt; }
        in.moveY = 1.f;
        in.moveX = std::max(-1.f, std::min(1.f, (lane_ * proj.player.laneW - pos.x) * 4.f));
        in.lookX = 0; in.lookY = 0; yaw = 0;
    }
    if (side() && in.moveY > 0.6f) in.jump = true;   // 2.5D: palanca arriba = saltar
    if (proj.player.swipe) {   // v10.7: deslizar el dedo = botones virtuales
        const TouchPt& t0 = in.touch[0];
        if (t0.down && !swDown_) { swDown_ = true; swDone_ = false; swX_ = t0.x; swY_ = t0.y; }
        else if (t0.down && swDown_ && !swDone_) {
            float dx = t0.x - swX_, dy = t0.y - swY_;
            if (std::fabs(dx) > 0.07f || std::fabs(dy) > 0.07f) {
                in.buttons.push_back(std::fabs(dx) > std::fabs(dy) ? (dx > 0 ? "Deslizar derecha" : "Deslizar izquierda") : (dy > 0 ? "Deslizar abajo" : "Deslizar arriba"));
                swDone_ = true;
            }
        }
        if (!t0.down) swDown_ = false;
    }
    if (proj.ui.on && proj.ui.fight && sc) {   // v10.7: vida del rival (el enemigo vivo mas cercano) en la variable "vidaRival"
        double best = 1e18, pct = 0; bool any = false;
        for (size_t i = 0; i < sc->objs.size() && i < st_.size(); i++) {
            const Obj& o = sc->objs[i];
            if (o.ai.type == AiType::None || !o.alive || st_[i].dead) continue;
            double d = (o.pos.x - pos.x) * (o.pos.x - pos.x) + (o.pos.z - pos.z) * (o.pos.z - pos.z);
            if (d < best) { best = d; pct = 100.0 * std::max(0.f, st_[i].hp) / std::max(0.1f, o.ai.hp); any = true; }
        }
        vars["vidaRival"] = any ? pct : 0.0;
    }
    in_ = in;
    for (auto& bn : in.buttons) {   // v11.5: botones «Conducir» / «Bajar»
        if (bn == "Conducir" && nearCar >= 0) enterCar(nearCar);
        else if (bn == "Bajar" && carIdx >= 0) exitCar(false);
    }
    for (auto& kv : texts) kv.second.cur = evalText(kv.second.expr, kv.second.self);
    if (!pending_.empty()) {
        std::string n = pending_;
        pending_.clear();
        enterScene(n);
    }
    if (!sc) return;
    dt = std::min(dt, 0.05f);
    if (dt > 0) fps_ = fps_ * 0.9f + (1.f / dt) * 0.1f;
    time += dt;
    if (sayT > 0) sayT -= dt;

    if (sc->is3d && sc->side25 && camMode != kFixed) camMode = kFixed;
    if (sc->is3d) {
        const bool vehNow = (proj.player.vehicle || carIdx >= 0) && camMode != kFixed && camMode != kFirstPerson;
        if (camMode != kFixed) {
            if (!vehNow) {   // conduciendo, arrastrar la pantalla NO gira la cámara: solo giran los botones
                yaw += in.lookX;
                pitch = std::max(-1.5f, std::min(1.5f, pitch - in.lookY));
            }
            if (targetOn_) aimAtTarget(dt);
        } else {
            pitch = 0;
        }
        V3 f{std::sin(yaw), 0, -std::cos(yaw)}, r{std::cos(yaw), 0, std::sin(yaw)};
        if (camMode == kFixed) {  // se camina segun lo que ve la camara
            float fl = std::sqrt(camFwd.x * camFwd.x + camFwd.z * camFwd.z);
            if (fl > 1e-4f) { f = {camFwd.x / fl, 0, camFwd.z / fl}; r = {-f.z, 0, f.x}; }
        }
        bool veh = (proj.player.vehicle || carIdx >= 0) && camMode != kFixed && camMode != kFirstPerson;
        V3 w;
        if (veh) {   // modo vehículo: acelerar, frenar y girar (la cámara va detrás y gira con el carro)
            auto held = [&](const char* n) { return std::find(in.buttons.begin(), in.buttons.end(), std::string(n)) != in.buttons.end(); };
            float steer = in.moveX + (held("Derecha") ? 1.f : 0.f) - (held("Izquierda") ? 1.f : 0.f);
            float gas = (held("Acelerar") || in.moveY > 0.3f) ? 1.f : 0.f, brake = (held("Frenar") || in.moveY < -0.3f) ? 1.f : 0.f;
            float top = carIdx >= 0 ? std::max(2.f, sc->objs[carIdx].carTop) : std::max(2.f, walkSpeed);
            if (gas > 0) carSpeed_ += (top * 1.1f) * dt * (1.f - std::max(0.f, carSpeed_) / (top * 1.15f)) * 1.6f;
            if (brake > 0) carSpeed_ -= (carSpeed_ > 0 ? 2.2f : 0.8f) * top * dt;
            if (!gas && !brake) carSpeed_ -= std::min(std::fabs(carSpeed_), top * 0.35f * dt) * (carSpeed_ > 0 ? 1.f : -1.f);
            carSpeed_ = std::max(-top * 0.35f, std::min(top, carSpeed_));
            float grip = std::min(1.f, std::fabs(carSpeed_) / (top * 0.25f));
            if (gas <= 0 && brake <= 0) grip = 0.f;   // parado o sin pisar el pedal, el auto no gira (ni la cámara)
            {   float tl = std::max(-1.f, std::min(1.f, steer)) * std::min(1.f, std::fabs(carSpeed_) / (top * 0.15f)) * (carSpeed_ >= 0 ? 1.f : -1.f);
                carLean_ += (tl - carLean_) * std::min(1.f, dt * 7.f); }
            yaw += std::max(-1.f, std::min(1.f, steer)) * 1.9f * dt * grip * (carSpeed_ >= 0 ? 1.f : -1.f);
            pitch = 0.2f;
            f = V3{std::sin(yaw), 0, -std::cos(yaw)};
            w = f * (carSpeed_ / std::max(0.01f, carIdx >= 0 ? top : walkSpeed));
        } else {
            carSpeed_ = 0.f; carLean_ = 0.f;
            w = f * in.moveY + r * in.moveX;
        }
        if (side() && !veh) { w = V3{1.f, 0.f, 0.f} * in.moveX; if (in.moveX > 0.2f) sideDir_ = 1.f; else if (in.moveX < -0.2f) sideDir_ = -1.f; }   // 2.5D: solo se camina de lado (eje X del mundo)
        float l = len(w);
        if (l > 1 && !proj.player.runner) w = w * (1.f / l);
        if (camMode == kFixed && l > 0.1f) yaw = std::atan2(w.x, -w.z);
        bool lockedNow = false;
        if (!veh && proj.player.lockOn > 0 && (proj.player.lockOn == 2 || in.shoot || in.tap)) {   // v10.7: fijar al enemigo
            int bi = -1; float bd = proj.player.lockRange * proj.player.lockRange;
            for (int i = 0; i < (int)sc->objs.size(); i++) {
                const Obj& o = sc->objs[i];
                if (!o.alive || !o.visible || o.ai.type == AiType::None) continue;
                float d = (o.pos.x - pos.x) * (o.pos.x - pos.x) + (o.pos.z - pos.z) * (o.pos.z - pos.z);
                if (i == lockIdx_) d *= 0.6f;   // prefiere seguir con el mismo
                if (d < bd) { bd = d; bi = i; }
            }
            lockIdx_ = bi;
            if (bi >= 0) {
                const Obj& o = sc->objs[bi];
                float ty = std::atan2(o.pos.x - pos.x, -(o.pos.z - pos.z));
                if (side()) { sideDir_ = (o.pos.x - pos.x) >= 0 ? 1.f : -1.f; ty = sideDir_ * 1.5707963f; }
                float dy = ty - yaw;
                while (dy > 3.14159f) dy -= 6.28318f;
                while (dy < -3.14159f) dy += 6.28318f;
                float k = std::min(1.f, dt * 14.f);
                if (camMode == kShoulder || camMode == kFixed) { yaw += dy * k; lockedNow = true; }
                if (camMode == kShoulder) { /* la camara sigue el yaw */ }
            }
        } else lockIdx_ = -1;
        if (proj.player.faceMove && !veh && camMode != kFirstPerson && camMode != kFixed) {
            if (l > 0.1f) {
                float ty = std::atan2(w.x, -w.z), dy = ty - bodyYaw;
                while (dy > 3.14159f) dy -= 6.28318f;
                while (dy < -3.14159f) dy += 6.28318f;
                bodyYaw += dy * std::min(1.f, dt * 12.f);
            }
        } else bodyYaw = yaw;
        if (!veh && !lockedNow && proj.player.faceExtra == 2 && camMode != kFirstPerson && camMode != kFixed) {   // mira al contrario de donde camina
            if (l > 0.1f) {
                float ty = std::atan2(-w.x, w.z), dy = ty - bodyYaw;
                while (dy > 3.14159f) dy -= 6.28318f;
                while (dy < -3.14159f) dy += 6.28318f;
                bodyYaw += dy * std::min(1.f, dt * 12.f);
            }
        } else if (!veh && !lockedNow && proj.player.faceExtra == 3) bodyYaw = yaw + 3.14159265f;   // siempre mira hacia atras
        if (lockedNow) bodyYaw = yaw;
        if (side() && !veh) { yaw = bodyYaw = sideDir_ * 1.5707963f; lockedNow = true; }   // 2.5D: mira hacia donde va / hacia el rival
        punchT_ = std::max(0.f, punchT_ - dt);
        if (veh) bodyYaw = yaw;
        float spdK = 1.f;
        if (!veh) {
            crouchK_ += ((in.crouch ? 1.f : 0.f) - crouchK_) * std::min(1.f, dt * 10.f);
            spdK = in.crouch ? 0.5f : (in.sprint && in.moveY > 0.2f ? 1.6f : 1.f);
            if (aimK > 0.f) { spdK *= 1.f + (proj.player.aimMove - 1.f) * aimK; if (spdK > 1.f) spdK = 1.f; }
            sprintT_ = spdK > 1.f;
        }
        vel.x = w.x * walkSpeed * spdK;
        vel.z = w.z * walkSpeed * spdK;
        vel.y -= 20.f * dt;
        if (in.jump && ground) { vel.y = jumpPow; snd(1); }
        {   // pasos y aterrizaje
            float sp = std::sqrt(vel.x * vel.x + vel.z * vel.z);
            if (ground && sp > 0.6f) { stepAcc_ += sp * dt; if (stepAcc_ > 2.1f) { stepAcc_ = 0.f; snd(0); } }
            else if (!ground) stepAcc_ = 1.4f;
            if (ground && !wasGround_ && lastVelY_ < -6.f) snd(2);
            wasGround_ = ground;
            lastVelY_ = vel.y;
        }

        V3 p = pos;
        {
            float hw = veh ? 1.0f : 0.3f, bh = veh ? 1.2f : 1.7f;
            if (!veh) bodyDims(hw, bh);
            bool hit = false;
            p.x += vel.x * dt; if (blockedBox(p, hw, bh, -1, 0.55f)) { p.x = pos.x; hit = true; }
            p.z += vel.z * dt; if (blockedBox(p, hw, bh, -1, 0.55f)) { p.z = pos.z; hit = true; }
            if (veh && hit) { if (std::fabs(carSpeed_) > walkSpeed * 0.4f) { snd(5); shakeT = std::max(shakeT, 0.25f); shakeAmp = std::max(shakeAmp, 0.12f); } carSpeed_ *= -0.25f; }
        }
        {   // suelo deformable: sube y baja laderas suaves pegado al terreno
            float gy = groundAt(p, 0.2f);
            if (gy > -1e8f) {
                if (gy > p.y && gy - p.y <= 0.6f) { p.y = gy; if (vel.y < 0) vel.y = 0; }
                else if (ground && vel.y <= 0 && gy < p.y && p.y - gy <= 0.35f) p.y = gy;
            }
        }
        {   // modelos con subidas y bajadas: el jugador sigue la superficie real
            float gy = -1e9f;
            for (auto& mo : sc->objs) {
                if (!mo.alive || !mo.visible || !mo.solid) continue;
                if (mo.kind == Kind::Model && !mo.model.empty()) gy = std::max(gy, modelSurfaceY(mo, p.x, p.z, p.y + 0.6f));
                else if (mo.kind == Kind::Cube || mo.kind == Kind::Wall) gy = std::max(gy, tiltSurfaceY(mo, p.x, p.z, p.y + 0.6f));   // rampa de cubo inclinado
            }
            if (gy > -1e8f) {
                if (gy > p.y && gy - p.y <= 0.6f) { p.y = gy; if (vel.y < 0) vel.y = 0; }
                else if (ground && vel.y <= 0 && gy < p.y && p.y - gy <= 0.35f) p.y = gy;
            }
        }
        V3 q = p;
        q.y += vel.y * dt;
        ground = false;
        if (blocked(q)) { if (vel.y < 0) ground = true; vel.y = 0; }
        else p.y = q.y;
        if (side()) p.z = sc->start.z;   // 2.5D: todo pasa en un solo plano
        pos = p;
        if (pos.y < -60) { pos = sc->start; vel = V3(); }
        hurtFlash = std::max(0.f, hurtFlash - dt);
        hitT = std::max(0.f, hitT - dt);
        if (proj.ui.on && proj.ui.timer && !worldFrozen_) vars["tiempo"] = Val(vars["tiempo"].num() + dt);   // el reloj cuenta hacia arriba
        {   // animacion del jugador (quieto, caminar, atacar, recibir dano)
            int pi2 = playerIndex(*sc);
            if (pi2 >= 0 && pi2 < (int)st_.size()) {
                ObjState& ps = st_[pi2];
                ps.animT += dt;
                ps.atkT = std::max(0.f, ps.atkT - dt);
                ps.hurtT = std::max(0.f, ps.hurtT - dt);
                ps.forceT = std::max(0.f, ps.forceT - dt);
                const AiCfg& pa = sc->objs[pi2].ai;
                auto has = [&](int k) { return !pa.anim[k].off && (!pa.anim[k].clip.empty() || !pa.anim[k].frames.empty()); };
                auto pick = [&](int k, int fb) { return has(k) ? k : fb; };   // si no hay animación para esa acción, usa la parecida
                const Weapon* cw = curWeapon();
                bool gun = cw && cw->type == 0;
                bool moving = std::fabs(vel.x) + std::fabs(vel.z) > 0.3f;
                int want = kIdle;
                if (moving) {
                    V3 f = forward(); float vf = vel.x * f.x + vel.z * f.z, vr = vel.x * std::cos(yaw) + vel.z * std::sin(yaw);
                    want = kWalk;
                    if (std::fabs(vr) > std::fabs(vf) * 1.2f) want = pick(vr > 0 ? kStrafeR : kStrafeL, kWalk);
                    else if (vf < -0.3f) want = pick(kBack, kWalk);
                    else if (sprintT_) want = pick(kRun, kWalk);
                } else if (gun) want = pick(kAim, kIdle);
                if (!ground) want = pick(kJump, want);
                if (sc->sea && pos.y + 0.9f < sc->seaY) want = pick(kSwim, want);
                if (crouchK_ > 0.5f) want = pick(kCrouch, want);
                if (reloadT_ > 0) want = pick(kReload, want);
                if (ps.atkT > 0) want = !gun ? kAttack : (moving && has(kShootWalk)) ? kShootWalk : pick(kShoot, kAttack);
                if (ps.hurtT > 0) want = kHurt;
                { auto vi = vars.find("vida"); if (vi != vars.end() && vi->second.num() <= 0) want = pick(kDie, kHurt); }
                if (ps.forceT > 0) want = ps.anim;
                if (want != kIdle && animGone(pa.anim[want])) want = ps.anim;   // «No reproducir esta animación»: se queda con la que ya tenía
                if (want != ps.anim) { ps.anim = want; ps.animT = 0; }
            }
        }
        if (!worldFrozen_) { updateAI(dt); updateProjs(dt); }
        applyCam();

        for (size_t i = 0; i < sc->objs.size(); i++) {  // "Cuando el jugador se acerque"
            auto& o = sc->objs[i];
            if (!o.alive || !hasHat(o, Op::WhenNear)) continue;
            float dx = o.pos.x - pos.x, dz = o.pos.z - pos.z, dy = o.pos.y - (pos.y + 1.f);
            bool isNear = std::sqrt(dx * dx + dz * dz) < 1.2f + .5f * std::max(o.scale.x, o.scale.z) && std::fabs(dy) < 3.f;
            if (isNear && !near_[i]) fireHat((int)i, Op::WhenNear);
            near_[i] = isNear;
        }
        if (in.tap) tap3D();

        shootCd = std::max(0.f, shootCd - dt);
        recoil = std::max(0.f, recoil - dt * 6.f);
        flash = std::max(0.f, flash - dt);
        weaponTick(dt, in);
    } else if (in.tap) {
        tap2D(in.tapX, in.tapY);
    }
    if (in.tap) fireAll(Op::WhenScreenTap);
    {   // deslizar el dedo: de dónde a dónde (se decide al soltar)
        const TouchPt& t0 = in.touch[0];
        if (t0.down && !swpDown_) { swpDown_ = true; swpX_ = t0.x; swpY_ = t0.y; swpT_ = 0.f; }
        else if (t0.down) swpT_ += dt;
        else if (swpDown_) {
            swpDown_ = false;
            float dx = swpEx_ - swpX_, dy = swpEy_ - swpY_;
            float ax = std::fabs(dx), ay = std::fabs(dy);
            if (swpT_ < 1.2f && std::max(ax, ay) > 0.12f) {
                const char* d = ax > ay ? (dx > 0 ? "de izquierda a derecha" : "de derecha a izquierda") : (dy > 0 ? "de arriba hacia abajo" : "de abajo hacia arriba");
                fireHatText(Op::WhenSwipe, d);
            }
        }
        if (t0.down) { swpEx_ = t0.x; swpEy_ = t0.y; }
    }

    physics(dt);
    autoTick(dt);
    wheelTick(dt);
    ragTick(dt);
    mapTick(dt);
    checkConditions();
    for (size_t i = 0; i < runners_.size(); i++) {
        if (worldFrozen_) {  // congelado: solo siguen los guiones del jugador y los de toque/mensaje (para poder descongelar)
            const Runner& r = runners_[i];
            bool keepGoing = r.obj >= 0 && r.obj < (int)sc->objs.size() && (sc->objs[r.obj].kind == Kind::Player ||
                             (r.hat >= 0 && r.hat < (int)sc->objs[r.obj].blocks.size() && (sc->objs[r.obj].blocks[r.hat].op == Op::WhenTap || sc->objs[r.obj].blocks[r.hat].op == Op::WhenReceive)));
            if (!keepGoing) continue;
        }
        step(runners_[i], dt);
    }
    runners_.erase(std::remove_if(runners_.begin(), runners_.end(), [](const Runner& r) { return r.done; }), runners_.end());
    eventsV6(dt, in);
    // Clones pedidos durante este cuadro (se crean aqui para no invalidar referencias a los objetos)
    endlessTick();
    for (int src : pendingClones_) spawnCloneAt(src, nullptr);
    pendingClones_.clear();
    for (auto& po : pendingObjs_) {
        if (sc->objs.size() >= kMaxObjs) break;
        sc->objs.push_back(po);
        int idx = (int)sc->objs.size() - 1;
        base_.push_back(base_.empty() ? sc->objs[idx].pos : base_[0]);
        base_[idx] = sc->objs[idx].scale;
        near_.push_back(0); moving_.push_back(0); last_.push_back(sc->objs[idx].pos);
        cmp_.push_back(cmp_.empty() ? decltype(cmp_)::value_type() : cmp_[0]);
        st_.emplace_back();
        st_[idx].hatState.assign(sc->objs[idx].blocks.size(), 0);
    }
    pendingObjs_.clear();
    updateDebris(dt);
    if (!worldFrozen_) updateParts(dt);
    shakeT = std::max(0.f, shakeT - dt);
    if (cineIdx_ >= 0) cineTick(dt);
    if (!sc->is3d) {   // bloques de cámara 2D
        if (cam2Mode == 1) { cam2x = cam2mx; cam2y = cam2my; }
        else if (cam2Mode == 2) for (auto& q : sc->objs) if (q.alive && q.name == cam2Target) { cam2x = q.pos.x; cam2y = q.pos.y; break; }
    }
}

// ---------------------------------------------------------------- interprete de bloques
static float wrap360(float d) {
    d = std::fmod(d, 360.f);
    if (d > 180.f) d -= 360.f;
    if (d <= -180.f) d += 360.f;
    return d;
}

void Game::step(Runner& r, float dt) {
    Obj& o = sc->objs[r.obj];
    ObjState& s = st_[r.obj];
    const auto& B = o.blocks;
    const auto& M = cmp_[r.obj].match;
    int self = r.obj;
    if (s.pausedAll || std::find(s.pausedHats.begin(), s.pausedHats.end(), r.hat) != s.pausedHats.end()) return;   // torre pausada

    if (!r.waitIds.empty()) {
        r.waitIds.erase(std::remove_if(r.waitIds.begin(), r.waitIds.end(), [&](int id) {
            for (auto& q : runners_) if (q.id == id && !q.done) return false;
            return true;
        }), r.waitIds.end());
        if (!r.waitIds.empty()) return;
    }
    if (r.gT > 0) {
        r.gE += dt;
        float t = std::min(1.f, r.gE / r.gT);
        if (r.gMode == 0) o.pos = r.gFrom + (r.gTo - r.gFrom) * t;
        else {
            float v = r.gFrom.x + (r.gTo.x - r.gFrom.x) * t;
            if (r.gMode == 1) { s.sizePct = std::max(0.f, v); o.scale = base_[self] * (s.sizePct / 100.f); }
            else if (r.gMode == 2) o.transp = std::max(0.f, std::min(100.f, v));
            else o.yaw = wrap360(v);
        }
        if (r.gE < r.gT) return;
        r.gT = 0; r.gMode = 0;
    }
    if (r.wait > 0) {
        r.wait -= dt;
        if (r.wait > 0) return;
    }
    bool is3 = sc->is3d;
    int budget = 512;
    while (budget-- > 0) {
        if (r.pc >= r.end) { r.done = true; return; }
        int idx = r.pc;
        const Block& b = B[r.pc++];
        auto F = [&](int k) { return (float)num(b.f[k], self); };
        if (s.lookLock || s.lookLockSw) {   // aspecto bloqueado: los bloques que cambian la apariencia no hacen nada
            bool sw = b.op == Op::NextLook || b.op == Op::PrevLook || b.op == Op::SetLook;
            if (sw) continue;
            if (s.lookLock) switch (b.op) {
                case Op::PlayAnim: case Op::PlayClip: case Op::StopClip:
                case Op::SetWidth: case Op::SetHeight: case Op::ChangeWidth: case Op::ChangeHeight: case Op::SetHue: case Op::SetSize: case Op::ChangeSize:
                case Op::SetTransp: case Op::ChangeTransp: case Op::SetBright: case Op::ChangeBright: case Op::ClearFx: case Op::ChangeColor:
                case Op::GlideSize: case Op::GlideTransp: case Op::Show: case Op::Hide: case Op::SetFx: case Op::SetFxColor:
                    continue;
                default: break;
            }
        }
        switch (b.op) {
            // eventos: nunca se ejecutan dentro de un guion
            case Op::WhenStart: case Op::WhenTap: case Op::WhenReceive: case Op::WhenCollide: case Op::WhenTrue:
            case Op::WhenShot: case Op::WhenNear: case Op::WhenInteract: case Op::WhenCloneStart:
            case Op::WhenScreenTap: case Op::WhenSwipe: case Op::WhenLookUnlocked: case Op::WhenPlayerShoots: case Op::WhenButton: case Op::WhenObjMoves: case Op::WhenPlayerMoves: case Op::WhenPlayerHurt: case Op::WhenPlayerJumps: break;

            // control
            case Op::Wait: r.wait = std::max(0.f, F(0)); if (r.wait > 0) return; break;
            case Op::Broadcast: broadcast(b.t, nullptr); break;
            case Op::NetAuto: net_.start(proj.name, "Jugador"); break;
            case Op::NetHost: case Op::NetJoin: net_.start(proj.name + "/" + b.t, "Jugador"); break;
            case Op::NetSend: if (net_.active()) net_.sendMsg(b.t); break;
            case Op::NetShare: netShared_.insert(normName(b.t)); break;
            case Op::NetStop: net_.stop(); netShared_.clear(); vars["jugadores"] = 1.0; break;
            case Op::BroadcastWait: {
                std::vector<int> ids;
                broadcast(b.t, &ids);
                r.waitIds = ids;
                if (!ids.empty()) return;
                break;
            }
            case Op::StopTowers: {
                const std::string sel = normName(b.t);
                bool me = false;
                if (sel.find("menos") != std::string::npos) { for (auto& q : runners_) if (q.id != r.id) q.done = true; }
                else if (sel.find("todos los objetos") != std::string::npos) { for (auto& q : runners_) q.done = true; me = true; }
                else if (sel.find("objeto:") == 0 || sel.find("objetos:") == 0) {
                    std::string list = b.t.substr(b.t.find(':') + 1);
                    size_t a = 0;
                    while (a <= list.size()) {
                        size_t c = list.find(',', a); if (c == std::string::npos) c = list.size();
                        std::string nm = list.substr(a, c - a);
                        while (!nm.empty() && nm.front() == ' ') nm.erase(nm.begin());
                        while (!nm.empty() && nm.back() == ' ') nm.pop_back();
                        int j = nm.empty() ? -1 : findObj(nm);
                        if (j >= 0) { for (auto& q : runners_) if (q.obj == j) q.done = true; if (j == self) me = true; }
                        a = c + 1;
                    }
                } else { for (auto& q : runners_) if (q.obj == self) q.done = true; me = true; }   // este mismo objeto
                if (me) { r.done = true; return; }
                break;
            }
            case Op::GoRandom: if (!is3) { o.pos.x = (frand() - 0.5f) * view2W() + cam2x; o.pos.y = (frand() - 0.5f) * view2H() + cam2y; } break;
            case Op::GoTouch: if (!is3) { o.pos.x = cam2x + (in_.tapX - 0.5f) * view2W(); o.pos.y = cam2y + (0.5f - in_.tapY) * view2H(); } break;
            case Op::SayFor: { say = evalText(b.f[0], self); float secs = std::max(0.f, F(1)); sayT = secs; if (secs > 0.f) { r.wait = secs; return; } break; }
            case Op::SetLookNum: { int k = (int)F(0) - 1; if (k >= 0 && k < (int)o.looks.size()) { s.look = k; o.tex = o.looks[k]; } break; }
            case Op::CloneOf: { int j = findObj(b.t); if (j >= 0 && pendingClones_.size() < 8) pendingClones_.push_back(j); break; }
            case Op::NextScene: {
                for (size_t k = 0; k < proj.scenes.size(); k++) if (&proj.scenes[k] == sc) { pending_ = proj.scenes[(k + 1) % proj.scenes.size()].name; break; }
                r.done = true; return;
            }
            case Op::ResetVars: { for (auto& kv : vars) kv.second = Val(0.0); lists_.clear(); break; }
            case Op::PenDown: s.penDown = true; s.penHas = false; break;
            case Op::PenUp: s.penDown = false; s.penHas = false; break;
            case Op::PenSize: s.penW = std::max(0.5f, F(0)); break;
            case Op::PenColor: s.penR = std::max(0.f, std::min(255.f, F(0))) / 255.f; s.penG = std::max(0.f, std::min(255.f, F(1))) / 255.f; s.penB = std::max(0.f, std::min(255.f, F(2))) / 255.f; break;
            case Op::PenClear: pen_.clear(); break;
            case Op::PauseTower: case Op::ResumeTower: {
                const bool pause = b.op == Op::PauseTower;
                const std::string sel = normName(b.t);
                auto setAll = [&](ObjState& q) { q.pausedAll = pause; if (!pause) q.pausedHats.clear(); };
                if (sel.find("todos los objetos") != std::string::npos) { for (auto& q : st_) setAll(q); }
                else if ((sel.find("demas") != std::string::npos || sel.find("dem\xc3\xa1s") != std::string::npos)) {   // todas las demás de este objeto (menos la actual)
                    if (pause) { for (int h : cmp_[self].hats) if (h != r.hat && std::find(s.pausedHats.begin(), s.pausedHats.end(), h) == s.pausedHats.end()) s.pausedHats.push_back(h); }
                    else { s.pausedAll = false; s.pausedHats.clear(); }
                }
                else if (sel.find("todas") != std::string::npos) setAll(s);
                else {
                    int hat = r.hat;   // «Esta torre» o «Torre N»
                    size_t p = sel.find("torre ");
                    if (sel.find("esta") == std::string::npos && p != std::string::npos) {
                        int n = std::atoi(sel.c_str() + p + 6);
                        if (n >= 1 && n <= (int)cmp_[self].hats.size()) hat = cmp_[self].hats[n - 1]; else hat = -1;
                    }
                    if (hat >= 0) {
                        auto it = std::find(s.pausedHats.begin(), s.pausedHats.end(), hat);
                        if (pause && it == s.pausedHats.end()) s.pausedHats.push_back(hat);
                        if (!pause && it != s.pausedHats.end()) s.pausedHats.erase(it);
                    }
                }
                if (pause && (s.pausedAll || std::find(s.pausedHats.begin(), s.pausedHats.end(), r.hat) != s.pausedHats.end())) return;   // esta torre se detuvo aquí
                break;
            }
            case Op::LockLook: case Op::LockLookSw: {
                int t = self;
                if (!b.t.empty()) {   // textura elegida: se pone y queda fija
                    o.tex = b.t;
                    auto it = std::find(o.looks.begin(), o.looks.end(), b.t);
                    if (it != o.looks.end()) s.look = (int)(it - o.looks.begin());
                }
                bool onlySw = b.op == Op::LockLookSw;
                if (onlySw) st_[t].lookLockSw = true; else st_[t].lookLock = true;
                for (auto& q : runners_) {   // se detienen los «por siempre» que cambian el aspecto (y los deslizamientos de tamaño/transparencia)
                    if (q.obj != t || q.done || &q == &r) continue;
                    const auto& QB = sc->objs[t].blocks;
                    bool fe = false, lo = false;
                    for (int k = q.hat; k < q.end && k < (int)QB.size(); k++) {
                        Op po = QB[k].op;
                        if (po == Op::Forever) fe = true;
                        if (po == Op::NextLook || po == Op::PrevLook || po == Op::SetLook) lo = true;
                        if (!onlySw && (po == Op::PlayAnim || po == Op::SetWidth || po == Op::SetHeight || po == Op::ChangeWidth || po == Op::ChangeHeight || po == Op::SetHue || po == Op::SetSize || po == Op::ChangeSize || po == Op::SetTransp || po == Op::ChangeTransp || po == Op::SetBright || po == Op::ChangeBright || po == Op::ChangeColor || po == Op::GlideSize || po == Op::GlideTransp)) lo = true;
                    }
                    if (fe && lo) { q.done = true; auto& v = st_[t].lookStopped; if (std::find(v.begin(), v.end(), q.hat) == v.end()) v.push_back(q.hat); }
                    else if (!onlySw && (q.gMode == 1 || q.gMode == 2)) q.gT = 0;
                }
                break;
            }
            case Op::UnlockLook: case Op::UnlockLookSw: {
                int t = self;
                if (b.op == Op::UnlockLook) st_[t].lookLock = false; else st_[t].lookLockSw = false;
                fireHat(t, Op::WhenLookUnlocked);
                break;
            }
            case Op::ResumeLook: {
                int t = self;
                std::vector<int> v; v.swap(st_[t].lookStopped);
                for (int h : v) startScript(t, h);
                break;
            }
            case Op::Forever: r.loops.push_back({idx, -1}); break;
            case Op::Repeat: {
                int n = (int)F(0);
                if (n <= 0) r.pc = M[idx] + 1;
                else r.loops.push_back({idx, n});
                break;
            }
            case Op::RepeatEvery: {
                int n = (int)F(0);
                if (n <= 0) r.pc = M[idx] + 1;
                else { Loop lp{idx, n}; lp.iv = std::max(0.f, F(1)); r.loops.push_back(lp); }
                break;
            }
            case Op::ForRange: {
                double a0 = num(b.f[0], self), a1 = num(b.f[1], self);
                Loop lp{idx, -4}; lp.cur = a0; lp.to = a1; lp.step = a0 <= a1 ? 1 : -1;
                setVar(b.t, Val(a0), self);
                r.loops.push_back(lp);
                break;
            }
            case Op::ForEach: {
                auto it = lists_.find(normName(eval(b.f[0], self).txt()));
                if (it == lists_.end() || it->second.empty()) { r.pc = M[idx] + 1; break; }
                Loop lp{idx, -5}; lp.cur = 0;
                setVar(b.t, it->second[0], self);
                r.loops.push_back(lp);
                break;
            }
            case Op::While:
                if (eval(b.f[0], self).truthy()) r.loops.push_back({idx, -2}); else r.pc = M[idx] + 1;
                break;
            case Op::RepeatUntil:
                if (!eval(b.f[0], self).truthy()) r.loops.push_back({idx, -3}); else r.pc = M[idx] + 1;
                break;
            case Op::SetTarget: {
                std::string tk = normName(b.t);
                target_ = -1;
                targetKind_ = (tk.find("todas") != std::string::npos || tk.find("entidad") != std::string::npos) ? 3 : tk.find("monstruo") != std::string::npos ? 2 : tk.find("enemigo") != std::string::npos ? 1 : 0;
                if (targetKind_ == 0) { target_ = findObj(b.t); if (target_ < 0) targetKind_ = 1; }
                targetOn_ = true;
                break;
            }
            case Op::KeepOnScreen:
                if (self >= 0) {
                    if (keep_.size() < sc->objs.size()) keep_.resize(sc->objs.size(), 0);
                    std::string tk = normName(b.t);
                    int mask = 0;   // 1 izquierda, 2 derecha, 4 arriba, 8 abajo
                    if (tk.empty() || tk.find("todos") != std::string::npos) mask = 15;
                    else {
                        if (tk.find("izq") != std::string::npos) mask |= 1;
                        if (tk.find("der") != std::string::npos) mask |= 2;
                        if (tk.find("arr") != std::string::npos) mask |= 4;
                        if (tk.find("abaj") != std::string::npos) mask |= 8;
                        if (!mask) mask = 15;
                    }
                    keep_[self] = (char)mask;
                }
                break;
            case Op::PushedBy: case Op::PushOther:
                if (self >= 0 && !b.t.empty()) {
                    bool sp = b.op == Op::PushedBy;
                    bool dup = false;
                    for (auto& r : pushRules_) if (r.self == self && r.selfPushed == sp && normName(r.other) == normName(b.t)) dup = true;
                    if (!dup) pushRules_.push_back({self, b.t, sp});
                }
                break;
            case Op::AutoWander: if (self >= 0) { o.wander = F(0) != 0; if (b.f[1].size()) o.wanderR = std::max(0.5f, F(1)); st_[self].homed = false; } break;
            case Op::CamBack: case Op::CamFront: {
                int m = b.op == Op::CamBack ? 1 : 2;
                bgCamMode = m;
                if (onCamera) onCamera(m);
                if (sc && !sc->is3d)
                    for (auto& q : sc->objs) if (q.bg) { if (camBgTex_.empty() && q.tex != "::cam") camBgTex_ = q.tex; q.tex = "::cam"; q.noColor = true; q.flipX = (m == 2); break; }
                break;
            }
            case Op::CamOff: {
                bgCamMode = 0;
                if (onCamera) onCamera(0);
                if (sc) for (auto& q : sc->objs) if (q.bg && q.tex == "::cam") { q.tex = camBgTex_; q.flipX = false; camBgTex_.clear(); break; }
                break;
            }
            case Op::TiltMove: if (self >= 0) tilt_[self] = F(0); break;
            case Op::PlayRoute: if (self >= 0) { int L = std::max(0, (int)F(0)); o.routeOn = true; o.routeLaps = L; o.routeLoop = L != 1; st_[self].laps = 0; st_[self].spd = 0.f; st_[self].wp = -1; st_[self].rwait = o.routeDelay; st_[self].rpause = false; } break;
            case Op::AutoRoute: if (self >= 0) { o.routeOn = F(0) != 0; if (o.routeOn) { if (b.f[1].size()) { int L = std::max(0, (int)F(1)); o.routeLaps = L; o.routeLoop = L != 1; } st_[self].laps = 0; st_[self].spd = 0.f; st_[self].wp = -1; st_[self].rwait = o.routeDelay; st_[self].rpause = false; } } break;
            case Op::CarMode: if (self >= 0) o.carMode = F(0) != 0; break;
            case Op::PlayCine:
                if (cineIdx_ >= 0) { r.pc = idx; return; }   // sigue sonando: espera
                if (cineWaitRunner_ == r.id) { cineWaitRunner_ = -1; break; }   // ya terminó
                startCine(b.t);
                if (cineIdx_ >= 0) { cineWaitRunner_ = r.id; r.pc = idx; return; }
                break;
            case Op::StopCine: stopCine(); break;
            case Op::EnterCar: if (self >= 0) enterCar(self); break;
            case Op::ExitCar: exitCar(false); break;
            case Op::SolidWall:
                o.solid = true;
                if (o.phys == Phys::None) o.phys = Phys::Static;
                break;
            case Op::KeepAllOnScreen: {
                keepAll_ = true;
                keepExcept_.clear();
                if (!b.t.empty() && normName(b.t) != "(ninguno)" && normName(b.t) != "ninguno") keepExcept_.push_back(b.t);
                break;
            }
            case Op::AllowLeaveScreen: {
                std::string tk = normName(b.t);
                if (tk == "todos" || tk == "todas") { keepAll_ = false; keep_.assign(keep_.size(), 0); keepExcept_.clear(); break; }
                int j = (tk == "esteobjeto" || tk.empty()) ? self : findObj(b.t);
                if (j >= 0) {
                    if (keep_.size() < sc->objs.size()) keep_.resize(sc->objs.size(), 0);
                    keep_[j] = 0;
                    if (keepAll_) keepExcept_.push_back(sc->objs[j].name);
                }
                break;
            }
            case Op::ClearTarget: targetOn_ = false; target_ = -1; break;
            case Op::LoopEnd:
                if (!r.loops.empty()) {
                    Loop& l = r.loops.back();
                    if (l.remaining == -2 || l.remaining == -3) {
                        bool t = eval(B[l.start].f[0], self).truthy();
                        if (l.remaining == -2 ? t : !t) { r.pc = l.start + 1; return; }
                        r.loops.pop_back();
                        break;
                    }
                    if (l.remaining == -4) {
                        l.cur += l.step;
                        if (l.step > 0 ? l.cur <= l.to : l.cur >= l.to) { setVar(B[l.start].t, Val(l.cur), self); r.pc = l.start + 1; return; }
                        r.loops.pop_back();
                        break;
                    }
                    if (l.remaining == -5) {
                        auto it = lists_.find(normName(eval(B[l.start].f[0], self).txt()));
                        l.cur += 1;
                        if (it != lists_.end() && (size_t)l.cur < it->second.size()) { setVar(B[l.start].t, it->second[(size_t)l.cur], self); r.pc = l.start + 1; return; }
                        r.loops.pop_back();
                        break;
                    }
                    if (l.remaining == -1 || --l.remaining > 0) { r.pc = l.start + 1; if (l.iv > 0.f) r.wait = l.iv; return; }
                    r.loops.pop_back();
                }
                break;
            case Op::Note: break;
            case Op::If:
                if (!eval(b.f[0], self).truthy()) r.pc = M[idx] + 1;
                break;
            case Op::Else: r.pc = M[idx] + 1; break;
            case Op::EndIf: break;
            case Op::StartScene: pending_ = b.t; r.done = true; return;

            // movimiento
            case Op::PlaceAt: o.pos.x = F(0); o.pos.y = F(1); break;
            case Op::SetX: o.pos.x = F(0); break;
            case Op::SetY: o.pos.y = F(0); break;
            case Op::ChangeX: o.pos.x += F(0); break;
            case Op::ChangeY: o.pos.y += F(0); break;
            case Op::PlaceAt3: o.pos = {F(0), F(1), F(2)}; break;
            case Op::SetZ: o.pos.z = F(0); break;
            case Op::ChangeZ: o.pos.z += F(0); break;
            case Op::Move: {
                float st = F(0), a = o.yaw * kRad;
                o.pos.x += st * std::sin(a);
                if (is3) o.pos.z -= st * std::cos(a); else o.pos.y += st * std::cos(a);
                break;
            }
            case Op::TurnLeft: o.yaw = wrap360(o.yaw - F(0)); break;
            case Op::TurnRight: o.yaw = wrap360(o.yaw + F(0)); break;
            case Op::PointDir: o.yaw = wrap360(F(0)); break;
            case Op::SetSolid: o.solid = F(0) != 0; break;
            case Op::TeleportPlayer: pos = {F(0), F(1), F(2)}; vel = V3(); break;
            case Op::MoveToPlayer: {
                V3 d{pos.x - o.pos.x, 0, pos.z - o.pos.z};
                float l = std::sqrt(d.x * d.x + d.z * d.z);
                if (l > 1e-4f) { float st = std::min(F(0), l); o.pos.x += d.x / l * st; o.pos.z += d.z / l * st; }
                break;
            }
            case Op::PointTowards: {
                std::string tk = normName(b.t);
                if (is3 && (tk == "jugador" || tk == "player")) {
                    o.yaw = std::atan2(pos.x - o.pos.x, -(pos.z - o.pos.z)) / kRad;
                    break;
                }
                int j = findObj(b.t);
                if (j >= 0) {
                    V3 d = sc->objs[j].pos - o.pos;
                    o.yaw = std::atan2(d.x, is3 ? -d.z : d.y) / kRad;
                }
                break;
            }
            case Op::BounceEdge:
                if (!is3) {
                    float hw = stageW() * .5f, hh = kView2DHeight * .5f;
                    if (o.pos.x + o.scale.x * .5f > hw) { o.pos.x = hw - o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    else if (o.pos.x - o.scale.x * .5f < -hw) { o.pos.x = -hw + o.scale.x * .5f; o.yaw = wrap360(-o.yaw); }
                    if (o.pos.y + o.scale.y * .5f > hh) { o.pos.y = hh - o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                    else if (o.pos.y - o.scale.y * .5f < -hh) { o.pos.y = -hh + o.scale.y * .5f; o.yaw = wrap360(180.f - o.yaw); }
                }
                break;
            case Op::GlideTo: {
                float secs = F(0);
                V3 to{F(1), F(2), o.pos.z};
                if (secs <= 0) o.pos = to;
                else { r.gFrom = o.pos; r.gTo = to; r.gT = secs; r.gE = 0; return; }
                break;
            }
            case Op::GlideSize: case Op::GlideTransp: case Op::GlideTurn: {
                float secs = F(1);
                float to = F(0);
                float from = b.op == Op::GlideSize ? s.sizePct : b.op == Op::GlideTransp ? o.transp : o.yaw;
                if (b.op == Op::GlideTurn) to = from + F(0);
                if (secs <= 0) {
                    if (b.op == Op::GlideSize) { s.sizePct = std::max(0.f, to); o.scale = base_[self] * (s.sizePct / 100.f); }
                    else if (b.op == Op::GlideTransp) o.transp = std::max(0.f, std::min(100.f, to));
                    else o.yaw = wrap360(to);
                } else {
                    r.gMode = b.op == Op::GlideSize ? 1 : b.op == Op::GlideTransp ? 2 : 3;
                    r.gFrom = V3{from, 0, 0}; r.gTo = V3{to, 0, 0}; r.gT = secs; r.gE = 0; return;
                }
                break;
            }
            case Op::Cam2Zoom: cam2Zoom = std::max(10.f, std::min(1000.f, F(0))); break;
            case Op::Cam2Follow: cam2Target = b.t; cam2Mode = 2; break;
            case Op::Cam2Center: cam2mx = F(0); cam2my = F(1); cam2Mode = 1; break;
            case Op::Cam2Auto: cam2Zoom = 100.f; cam2Mode = 0; break;
            case Op::AimOn: aiming = true; break;
            case Op::AimOff: aiming = false; break;
            case Op::AimToggle: aiming = !aiming; break;
            case Op::SetFov: fovDeg = std::max(30.f, std::min(120.f, F(0))); break;
            case Op::RouteDelay: if (self >= 0) { o.routeDelay = std::max(0.f, F(0)); st_[self].rwait = o.routeDelay; } break;
            case Op::RouteRestart:
                if (self >= 0 && o.route.size() >= 4) {
                    o.routeOn = true; st_[self].laps = 0; st_[self].spd = 0.f; st_[self].wp = 0; st_[self].rpause = false; st_[self].rwait = o.routeDelay;
                    o.pos.x = o.route[0]; if (sc->is3d) o.pos.z = o.route[1]; else o.pos.y = o.route[1];
                }
                break;
            case Op::RoutePause: if (self >= 0) st_[self].rpause = true; break;
            case Op::Ragdoll: if (self >= 0) ragActivate(self); break;
            case Op::RouteResume: if (self >= 0) st_[self].rpause = false; break;
            case Op::GoBack: o.layer -= (int)F(0); break;
            case Op::GoFront: {
                int mx = o.layer;
                for (auto& q : sc->objs) if (!q.bg) mx = std::max(mx, q.layer);
                o.layer = mx + 1;
                break;
            }
            case Op::Vibrate: if (onVibrate) onVibrate(F(0)); break;
            case Op::PhysDynamic: o.phys = Phys::Dynamic; break;
            case Op::PhysStatic: o.phys = Phys::Static; break;
            case Op::PhysNone: o.phys = Phys::None; s.vel = V3(); break;
            case Op::SetForce: s.vel.x = F(0); s.vel.y = F(1); break;
            case Op::SpinLeft: s.spin = -F(0); break;
            case Op::SpinRight: s.spin = F(0); break;
            case Op::SetGravity: gravX_ = F(0); gravY_ = F(1); break;
            case Op::PhysImpulse: { float ps2 = sc->is3d ? 1.f : 100.f; s.vel.x += F(0) * ps2; s.vel.y += F(1) * ps2; if (sc->is3d) s.vel.z += F(2); break; }
            case Op::PhysBlast: physBlast(o.pos, std::max(0.1f, F(0)), F(1), self); break;
            case Op::SetDrag: o.drag = std::max(0.f, std::min(100.f, F(0))) / 10.f; break;
            case Op::SetGravScale: o.gravScale = F(0) / 100.f; break;
            case Op::SetPlayerYaw: yaw = F(0) * 0.0174532925f; bodyYaw = yaw; pitch = 0.f; break;
            case Op::SetPushable: o.pushable = o.bulletPush = F(0) != 0; break;
            case Op::SetMass: o.mass = std::max(0.f, F(0)); break;
            case Op::SetBounce: o.bounce = std::max(0.f, F(0) / 100.f); break;
            case Op::SetFriction: o.friction = std::max(0.f, F(0) / 100.f); break;

            // sonido
            case Op::StartSound: soundAt(b.t, self); break;
            case Op::StopSounds: if (onStopSounds) onStopSounds(); if (onMusic) onMusic("", false); break;
            case Op::SetVolume: volume = std::max(0.f, std::min(100.f, F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::ChangeVolume: volume = std::max(0.f, std::min(100.f, volume + F(0))); if (onVolume) onVolume(volume / 100.f); break;
            case Op::Speak: {
                std::string t = evalText(b.f[0], self);
                int words = 1;
                for (size_t k = 1; k < t.size(); k++) if (t[k] == ' ' && t[k - 1] != ' ') words++;
                say = t; sayT = std::max(3.f, 0.55f * (float)words);
                if (onSpeak) onSpeak(speakCode(b.t) + t);
                break;
            }
            case Op::Music: if (onMusic) onMusic(b.t, true); break;

            // apariencia
            case Op::NextLook:
                if (!o.looks.empty()) { s.look = (s.look + 1) % (int)o.looks.size(); o.tex = o.looks[s.look]; }
                break;
            case Op::PrevLook:
                if (!o.looks.empty()) { int n = (int)o.looks.size(); s.look = ((s.look - 1) % n + n) % n; o.tex = o.looks[s.look]; }
                break;
            case Op::SaveDevVar: {
                Val v = eval(b.f[0], self);
                setVar(b.t, v, self);
                devVars[vkey(b.t)] = v.txt();
                if (onDevSave) onDevSave(devVars);
                break;
            }
            case Op::ReadDevVar: {
                auto it = devVars.find(vkey(b.t));
                if (it != devVars.end()) { char* e = nullptr; double d = std::strtod(it->second.c_str(), &e); setVar(b.t, (e && *e == 0 && !it->second.empty()) ? Val(d) : Val::text(it->second), self); }
                break;
            }
            case Op::DelDevVar:
                devVars.erase(vkey(b.t)); setVar(b.t, Val(0.0), self);
                if (onDevSave) onDevSave(devVars);
                break;
            case Op::ShowText: { TextItem& t = texts[b.t]; t.expr = b.f[0]; t.x = F(1); t.y = F(2); t.size = 30.f; t.self = self; break; }
            case Op::HideText: texts.erase(b.t); break;
            case Op::SetLook: {
                auto it = std::find(o.looks.begin(), o.looks.end(), b.t);
                if (it != o.looks.end()) { s.look = (int)(it - o.looks.begin()); o.tex = *it; }
                break;
            }
            case Op::SetSize: s.sizePct = std::max(0.f, F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::ChangeSize: s.sizePct = std::max(0.f, s.sizePct + F(0)); o.scale = base_[self] * (s.sizePct / 100.f); break;
            case Op::Show: o.visible = true; break;
            case Op::Hide: o.visible = false; break;
            case Op::SetTransp: o.transp = std::max(0.f, std::min(100.f, F(0))); break;
            case Op::ChangeTransp: o.transp = std::max(0.f, std::min(100.f, o.transp + F(0))); break;
            case Op::SetBright: o.bright = std::max(0.f, F(0)); break;
            case Op::ChangeBright: o.bright = std::max(0.f, o.bright + F(0)); break;
            case Op::ClearFx: o.transp = 0; o.bright = 100; o.hue = 0; break;
            case Op::Flash: if (onFlash) onFlash(F(0) != 0); break;
            case Op::ChangeColor: o.hue = std::fmod(o.hue + F(0), 200.f); if (o.hue < 0) o.hue += 200.f; break;
            case Op::Say: say = evalText(b.f[0], self); sayT = 3.f; break;
            case Op::Destroy: o.alive = false; break;

            // datos
            case Op::SetVar: setVar(b.t, eval(b.f[0], self), self); break;
            case Op::ToggleVar: setVar(b.t, Val(getVar(b.t, self).num() != 0.0 ? 0.0 : 1.0), self); break;
            case Op::RandomVar: {
                int lo = (int)std::floor(F(0)), hi = (int)std::floor(F(1));
                if (hi < lo) std::swap(lo, hi);
                setVar(b.t, Val((double)(lo + (int)(std::uniform_int_distribution<long long>(0, (long long)hi - lo)(gameRng())))), self);
                break;
            }
            case Op::ClampVar: {
                double lo = F(0), hi = F(1);
                if (hi < lo) std::swap(lo, hi);
                setVar(b.t, Val(std::max(lo, std::min(hi, getVar(b.t, self).num()))), self);
                break;
            }
            case Op::SetColorRGB: for (int k = 0; k < 3; k++) o.color[k] = std::max(0.f, std::min(255.f, F(k))) / 255.f; o.noColor = false; break;
            case Op::SetLayer: o.layer = (int)F(0); break;
            case Op::SetSkyColor: {
                for (int k = 0; k < 3; k++) { float v = std::max(0.f, std::min(255.f, F(k))) / 255.f; sc->skyBot[k] = v; sc->skyTop[k] = v * 0.8f; }
                break;
            }
            case Op::MoveAway: {
                int j = findObj(b.t);
                if (j < 0) break;
                V3 d = o.pos - sc->objs[j].pos;
                if (!is3) d.z = 0;
                float l = len(d);
                if (l > 1e-4f) o.pos = o.pos + d * (F(0) / l);
                break;
            }
            case Op::SnapGrid: {
                float g = std::max(0.01f, F(0));
                o.pos.x = std::round(o.pos.x / g) * g;
                if (is3) o.pos.z = std::round(o.pos.z / g) * g; else o.pos.y = std::round(o.pos.y / g) * g;
                break;
            }
            case Op::SetTimeScale: timeScale_ = std::max(0.05f, std::min(4.f, F(0) / 100.f)); break;
            case Op::RestartScene: pending_ = sc->name; r.done = true; return;
            case Op::WaitFrames: r.wait = std::max(0.f, F(0)) / 60.f; if (r.wait > 0) return; break;
            case Op::HealPlayer: {
                double mx = 100.0;
                auto it = vars.find("vidamax"); if (it != vars.end() && it->second.num() > 0) mx = it->second.num();
                setVar("vida", Val(std::min(mx, getVar("vida", -1).num() + F(0))), -1);
                break;
            }
            case Op::RespawnPlayer: pos = hasCp ? cpPos : sc->start; vel = V3(); break;
            case Op::SetCheckpoint: hasCp = true; cpPos = pos; break;
            case Op::SetFear: fear = std::max(0.f, std::min(100.f, F(0))); break;
            case Op::Blackout: blackTot = blackT = std::max(0.2f, F(0)); if (onSound) onSound("linterna"); break;
            case Op::Jumpscare: scareT = 0.8f; shakeT = std::max(shakeT, 0.8f); shakeAmp = std::max(shakeAmp, 0.35f); if (!b.t.empty()) soundAt(b.t, self); break;
            case Op::ChangeVar: setVar(b.t, Val(getVar(b.t, self).num() + num(b.f[0], self)), self); break;
            case Op::ShowVar: shown[b.t] = {F(0), F(1)}; break;
            case Op::HideVar: shown.erase(b.t); break;
            case Op::PlaySoundWait: {
                soundAt(b.t, self);
                float len = soundLen ? soundLen(b.t) : 0.f;
                if (len > 0.f) { r.wait = len; return; }
                break;
            }
            case Op::SetCamera: {
                std::string k = normName(b.t);
                camMode = k.find("hombro") != std::string::npos ? kShoulder : k.find("fij") != std::string::npos ? kFixed : kFirstPerson;
                if (camMode != kFixed) yaw = bodyYaw;
                applyCam();
                break;
            }
            case Op::WaitUntil:
                if (!eval(b.f[0], self).truthy()) { r.pc = idx; return; }
                break;
            case Op::StopScript: r.done = true; return;
            case Op::StopOthers: for (auto& q : runners_) if (q.obj == self && q.id != r.id) q.done = true; break;
            case Op::SetWidth: o.scale.x = std::max(0.f, base_[self].x * F(0) / 100.f); break;
            case Op::SetHeight: o.scale.y = std::max(0.f, base_[self].y * F(0) / 100.f); break;
            case Op::ChangeWidth: o.scale.x = std::max(0.f, o.scale.x + base_[self].x * F(0) / 100.f); break;
            case Op::ChangeHeight: o.scale.y = std::max(0.f, o.scale.y + base_[self].y * F(0) / 100.f); break;
            case Op::SetHue: o.hue = std::fmod(F(0), 200.f); if (o.hue < 0) o.hue += 200.f; break;
            case Op::SetFxColor: for (int c = 0; c < 3; c++) o.fx.c0[c] = o.fx.c1[c] = std::max(0.f, std::min(255.f, F(c))) / 255.f; break;
            case Op::ListAdd: lists_[normName(b.t)].push_back(eval(b.f[0], self)); break;
            case Op::ListClear: lists_[normName(b.t)].clear(); break;
            case Op::ListRemove: { auto& L = lists_[normName(b.t)]; int k = (int)F(0); if (k >= 1 && k <= (int)L.size()) L.erase(L.begin() + (k - 1)); break; }
            case Op::ListInsert: { auto& L = lists_[normName(b.t)]; int k = std::max(1, std::min((int)L.size() + 1, (int)F(1))); L.insert(L.begin() + (k - 1), eval(b.f[0], self)); break; }
            case Op::ListReplace: { auto& L = lists_[normName(b.t)]; int k = (int)F(0); if (k >= 1 && k <= (int)L.size()) L[k - 1] = eval(b.f[1], self); break; }
            case Op::ShootPlayer:
                if (is3) {
                    V3 from{o.pos.x, o.pos.y + o.scale.y * 0.2f, o.pos.z};
                    spawnProj(from, V3{pos.x - from.x, pos.y + 1.2f - from.y, pos.z - from.z}, self);
                }
                break;
            case Op::HurtPlayer: hurtPlayer(F(0)); break;
            case Op::SetSpeed: walkSpeed = std::max(0.f, F(0)); break;
            case Op::SetJump: jumpPow = std::max(0.f, F(0)); break;
            case Op::PlayAnim: {
                std::string k = normName(b.t);
                int a = animFromName(k); if (a < 0) a = kCustom;
                s.anim = a; s.animT = 0; s.forceT = 1.0f;
                break;
            }
            case Op::MoveRandom: {
                float dist = F(0) * frand(), ang = 6.2831853f * frand();
                o.pos.x += dist * std::cos(ang);
                if (is3) o.pos.z += dist * std::sin(ang); else o.pos.y += dist * std::sin(ang);
                break;
            }
            case Op::GlideEnemy: {
                float best = 1e18f; int bi = -1;
                for (size_t q = 0; q < sc->objs.size(); q++) {
                    const Obj& e = sc->objs[q];
                    if ((int)q == self || !e.alive || e.ai.type == AiType::None || (q < st_.size() && st_[q].dead)) continue;
                    float d = (e.pos.x - o.pos.x) * (e.pos.x - o.pos.x) + (e.pos.y - o.pos.y) * (e.pos.y - o.pos.y) + (e.pos.z - o.pos.z) * (e.pos.z - o.pos.z);
                    if (d < best) { best = d; bi = (int)q; }
                }
                if (bi < 0) break;
                float secs = std::max(0.05f, F(0));
                r.gFrom = o.pos; r.gTo = V3{sc->objs[bi].pos.x, sc->objs[bi].pos.y, o.pos.z}; r.gT = secs; r.gE = 0; return;
            }
            case Op::CancelDamage: {
                float secs = std::max(0.f, F(0));
                int hi = heroIdx(); int pi = sc->is3d ? playerIndex(*sc) : -1;
                if (self == hi || self == pi) playerNoDmg_ = secs;
                s.noDmg = secs;
                break;
            }
            case Op::GoDir: {
                std::string d = normName(b.f[0].empty() ? "x" : b.f[0]);
                float sp = F(1); V3 v{0, 0, 0};
                if (d == "x") v.x = sp; else if (d == "-x") v.x = -sp; else if (d == "y") v.y = sp; else if (d == "-y") v.y = -sp;
                o.bullet = true; o.bvel = v; o.bAge = 0.f;
                break;
            }
            case Op::DespawnOffscreen: o.bOff = F(0) != 0; break;
            case Op::DespawnAfter: o.bLife = std::max(0.f, F(0)); break;
            case Op::CreateClone: if (pendingClones_.size() < 8) pendingClones_.push_back(self); break;
            case Op::DeleteClone: if (o.clone) { o.alive = false; r.done = true; return; } break;
            case Op::BreakApart: breakApart(self, std::max(1, std::min(40, (int)F(0)))); r.done = true; return;
            case Op::PlayClip: s.clip = b.t; break;
            case Op::StopClip: s.clip.clear(); s.curClip.clear(); break;
            case Op::PlayVideo: videoCmd(self, 0, b.t, 0); break;
            case Op::PauseVideo: videoCmd(self, 1, "", 0); break;
            case Op::ResumeVideo: videoCmd(self, 2, "", 0); break;
            case Op::LoopVideo: videoCmd(self, 3, "", 0); break;
            case Op::PlayVideoTimes: videoCmd(self, 4, "", (int)eval(b.f[0], self).num()); break;
            case Op::FlashOn: flashOn_ = true; break;
            case Op::FlashOff: flashOn_ = false; break;
            case Op::FlashToggle: flashOn_ = !flashOn_; if (onSound) onSound("linterna"); break;
            case Op::EnemiesFightAll: aiMode_ = 1; break;
            case Op::EnemiesFightEachOther: aiMode_ = 2; break;
            case Op::EnemiesAttackYou: aiMode_ = 0; break;
            case Op::FreezeWorld: worldFrozen_ = true; break;
            case Op::UnfreezeWorld: worldFrozen_ = false; break;
            case Op::FreezePlayer: playerFrozen_ = true; break;
            case Op::UnfreezePlayer: playerFrozen_ = false; break;
            case Op::TiltCamRight: camRollTarget = F(0) * 0.0174533f; break;
            case Op::TiltCamLeft: camRollTarget = -F(0) * 0.0174533f; break;
            case Op::LevelCam: camRollTarget = 0.f; break;
            case Op::RestartVideo: videoCmd(self, 5, "", 0); break;
            case Op::StopVideo: videoCmd(self, 6, "", 0); break;
            case Op::GoToPlayer: {
                V3 to = o.pos;
                if (is3) { to.x = pos.x; to.z = pos.z; }
                else {
                    int j = findObj("Jugador");
                    if (j >= 0) { to.x = sc->objs[j].pos.x; to.y = sc->objs[j].pos.y; }
                    else { to.x = (in_.tapX - 0.5f) * stageW(); to.y = (0.5f - in_.tapY) * kView2DHeight; }
                }
                float secs = F(0);
                if (secs <= 0) o.pos = to;
                else { r.gFrom = o.pos; r.gTo = to; r.gT = secs; r.gE = 0; return; }
                break;
            }
            case Op::GoToObject: {
                int j = findObj(b.t);
                if (j >= 0) { o.pos.x = sc->objs[j].pos.x; o.pos.y = sc->objs[j].pos.y; if (is3) o.pos.z = sc->objs[j].pos.z; }
                break;
            }
            case Op::MoveTowards: {
                int j = findObj(b.t);
                if (j < 0) break;
                V3 d = sc->objs[j].pos - o.pos;
                if (!is3) d.z = 0;
                float l = len(d);
                if (l > 1e-4f) { float st = std::min(F(0), l); o.pos = o.pos + d * (st / l); }
                break;
            }
            case Op::ShakeScreen: shakeT = std::max(shakeT, F(0)); shakeAmp = is3 ? 0.12f : 14.f; break;
            case Op::StopAll:
                for (auto& q : runners_) q.done = true;
                return;
            case Op::SetFx: o.fx.on = normName(b.t).find("apag") == std::string::npos; break;
            case Op::Explode: {
                float sz = std::max(0.5f, F(0));
                spawnBoom(o.pos, sz * 0.6f);
                physBlast(o.pos, sz, 8.f, self);
                snd(7); shakeT = 0.4f; shakeAmp = 0.12f; flash = 0.1f;
                float dpl = len(V3{pos.x, pos.y + 0.9f, pos.z} - o.pos);
                if (dpl < sz) hurtPlayer(std::max(0.5f, 3.f * (1.f - dpl / sz)));
                break;
            }
            case Op::BurstFx: emitParticles(self, std::max(1, std::min(200, (int)F(0)))); break;
            case Op::SetScreenFx: {
                std::string k = normName(b.t);
                int id = k.find("vhs") != std::string::npos ? 1 : k.find("video") != std::string::npos ? 2
                       : k.find("noct") != std::string::npos ? 3 : k.find("vieja") != std::string::npos ? 4 : 0;
                sfxPreset(sc->sfx, id);
                break;
            }
            case Op::Count: break;
        }
    }
}

}  // namespace forge

namespace forge {

// Busca el esqueleto de un objeto: el que eligio, o el primero guardado que pertenezca a ese modelo.
Game::RigRT* Game::rigRT(int i, const std::string& model, const std::string& wantClip) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || model.empty()) return nullptr;
    const Obj& o = sc->objs[i];
    std::string rn = o.rig;
    if (rn.empty()) {
        for (auto& a : proj.assets) {
            const std::string& n = a.first;
            if (n.size() > 6 && n.compare(n.size() - 6, 6, ".fanim") == 0) {
                // con varios archivos de animación para el mismo modelo se usa el que tiene la animación pedida
                auto it = rigs_.find(n + "|" + model);
                if (it != rigs_.end() && it->second.ok) { if (wantClip.empty() || rigFindClip(it->second.rig, wantClip) >= 0) { rn = n; break; } continue; }
                // se recuerda de qué modelo es cada archivo de animación y qué animaciones trae (leerlo cada cuadro era muy lento)
                static std::map<std::string, std::pair<size_t, std::pair<std::string, std::vector<std::string>>>> info;
                auto& e = info[n];
                if (e.first != a.second.size() || e.first == 0) {
                    e.first = a.second.size(); e.second.first.clear(); e.second.second.clear();
                    Rig r;
                    if (rigRead(std::string(a.second.begin(), a.second.end()), r)) { e.second.first = r.model; for (auto& c : r.clips) e.second.second.push_back(c.name); }
                }
                if (e.second.first == model && (wantClip.empty() || std::find(e.second.second.begin(), e.second.second.end(), wantClip) != e.second.second.end())) { rn = n; break; }
            }
        }
    }
    if (rn.empty()) return nullptr;
    std::string key = rn + "|" + model;
    auto it = rigs_.find(key);
    if (it != rigs_.end()) return it->second.ok ? &it->second : nullptr;
    RigRT& rt = rigs_[key];
    auto ra = proj.assets.find(rn), ma = proj.assets.find(model);
    ModelData md;
    if (ra == proj.assets.end() || ma == proj.assets.end() || !rigRead(std::string(ra->second.begin(), ra->second.end()), rt.rig) ||
        rt.rig.bones.empty() || !modelRead(ma->second.data(), ma->second.size(), md))
        return nullptr;
    rt.model = model;
    rt.rest = md.v;
    rt.idx = md.idx;
    rigComputeWeights(rt.rig, rt.rest, rt.w, &rt.idx);
    rt.ok = true;
    return &rt;
}

const Rig* Game::rigOf(int i, const std::string& model) const {
    RigRT* r = const_cast<Game*>(this)->rigRT(i, model);
    return r ? &r->rig : nullptr;
}

bool Game::boneLocal(int i, const std::string& model, int side, V3& out) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size() || model.empty()) return false;
    const Obj& o = sc->objs[i];
    ObjState& s = st_[i];
    std::string want = !s.clip.empty() ? s.clip : vis(i).clip;
    if (want.empty()) want = o.clip;
    RigRT* rt = rigRT(i, model, want);
    if (!rt) return false;
    int bi = -1;
    auto low = [](std::string x) { for (auto& c : x) c = (char)std::tolower((unsigned char)c); return x; };
    auto ends = [](const std::string& x, const char* e) { size_t n = std::strlen(e); return x.size() >= n && x.compare(x.size() - n, n, e) == 0; };
    for (size_t b = 0; b < rt->rig.bones.size() && bi < 0; b++) {
        std::string n = low(rt->rig.bones[b].name);
        if (n.find("mano") == std::string::npos && n.find("hand") == std::string::npos) continue;
        bool right = ends(n, "_d") || ends(n, "_r") || ends(n, ".r") || n.find("right") != std::string::npos || n.find("derech") != std::string::npos;
        bool left = ends(n, "_i") || ends(n, "_l") || ends(n, ".l") || n.find("left") != std::string::npos || n.find("izq") != std::string::npos;
        if ((side == 0 && right) || (side == 1 && left)) bi = (int)b;
    }
    if (bi < 0) return false;
    RigPose p;
    int ci = want.empty() ? -1 : rigFindClip(rt->rig, want);
    if (ci >= 0) p = rigSample(rt->rig, rt->rig.clips[ci], time - s.clipStart);
    else { p.rot.assign(rt->rig.bones.size(), Quat()); }
    std::vector<V3> js;
    rigJointPositions(rt->rig, p, js);
    if (bi >= (int)js.size()) return false;
    out = js[bi];
    return true;
}

bool Game::skinVerts(int i, const std::string& model, const std::vector<float>*& verts, const std::vector<uint32_t>*& idx, unsigned long long& sig) {
    if (!sc || i < 0 || i >= (int)sc->objs.size() || i >= (int)st_.size() || model.empty()) return false;
    const Obj& o = sc->objs[i];
    ObjState& s = st_[i];
    std::string want = !s.clip.empty() ? s.clip : vis(i).clip;
    if (want.empty()) want = o.clip;
    if (want.empty()) {
        if (s.dentV.empty()) return false;
        auto dm = dentMd_.find(model);
        if (dm == dentMd_.end() || dm->second.v.size() != s.dentV.size()) return false;
        verts = &s.dentV;
        idx = &dm->second.idx;
        sig = 0xDE000000ULL + (unsigned long long)s.dentVer * 7919ULL + (unsigned long long)i * 104729ULL + std::hash<std::string>()(model);
        return true;
    }
    RigRT* rt = rigRT(i, model, want);
    if (!rt) return false;
    int ci = rigFindClip(rt->rig, want);
    if (ci < 0) return false;
    if (s.curClip != want) { s.curClip = want; s.clipStart = time; }
    RigPose p = rigSample(rt->rig, rt->rig.clips[ci], time - s.clipStart);
    std::vector<float> mats;
    rigSkinMatrices(rt->rig, p, mats);
    rigSkin(rt->rest, rt->w, mats, rt->out);
    verts = &rt->out;
    idx = &rt->idx;
    sig = (unsigned long long)(time * 90.f) * 2654435761ULL + (unsigned long long)i * 40503ULL + std::hash<std::string>()(want + model);
    return true;
}

}  // namespace forge

// ---- v8: objetivo fijado (la mira sigue a un enemigo, monstruo u objeto)
namespace forge {
void Game::aimAtTarget(float dt) {
    int best = target_;
    if (best < 0 || best >= (int)sc->objs.size() || !sc->objs[best].alive) {
        best = -1;
        float bd = 1e9f;
        for (int i = 0; i < (int)sc->objs.size(); i++) {
            const Obj& o = sc->objs[i];
            if (!o.alive || !o.visible || o.ai.type == AiType::None) continue;
            if (targetKind_ == 1 && o.ai.type != AiType::Shooter) continue;
            if (targetKind_ == 2 && o.ai.type != AiType::Melee) continue;
            float d = (o.pos.x - pos.x) * (o.pos.x - pos.x) + (o.pos.z - pos.z) * (o.pos.z - pos.z);
            if (d < bd) { bd = d; best = i; }
        }
        if (targetKind_ != 0) target_ = best; else if (best < 0) return;
    }
    if (best < 0) return;
    const Obj& o = sc->objs[best];
    V3 e = camEye;
    V3 d{o.pos.x - e.x, o.pos.y + o.scale.y * 0.3f - e.y, o.pos.z - e.z};
    float ty = std::atan2(d.x, -d.z), l = std::sqrt(d.x * d.x + d.z * d.z), tp = std::atan2(d.y, std::max(l, 0.01f));
    float dy = ty - yaw;
    while (dy > 3.14159f) dy -= 6.28318f;
    while (dy < -3.14159f) dy += 6.28318f;
    float k = std::min(1.f, dt * 10.f);
    yaw += dy * k;
    pitch += (std::max(-1.5f, std::min(1.5f, tp)) - pitch) * k;
}
}  // namespace forge

// ---- v8: armas (tipos, municion, recarga, retroceso)
namespace forge {
void Game::initWeapons() {
    owned_.clear(); wMag_.clear(); wAmmo_.clear();
    int n = 1 + (int)proj.extraWeapons.size();
    wMag_.assign(n, 0); wAmmo_.assign(n, 0);
    curW_ = -1; reloadT_ = 0;
    for (int i = 0; i < n; i++) {
        const Weapon& w = weaponAt(i);
        wMag_[i] = w.magSize; wAmmo_[i] = w.startAmmo;
        if (w.startWith) { owned_.push_back(i); if (curW_ < 0) curW_ = i; }
    }
}
void Game::giveWeapon(const std::string& name) {
    std::string k = normName(name);
    for (int i = 0; i <= (int)proj.extraWeapons.size(); i++) {
        if (normName(weaponAt(i).name) != k) continue;
        if (std::find(owned_.begin(), owned_.end(), i) == owned_.end()) owned_.push_back(i);
        else wAmmo_[i] += weaponAt(i).startAmmo;
        curW_ = i;
        return;
    }
}
void Game::cycleWeapon() {
    if (owned_.size() < 2) return;
    auto it = std::find(owned_.begin(), owned_.end(), curW_);
    size_t k = it == owned_.end() ? 0 : (size_t)(it - owned_.begin() + 1) % owned_.size();
    curW_ = owned_[k];
    reloadT_ = 0;
    shootCd = 0.2f;
    forcePlayerAnim(kSwap, 0.6f);
}
void Game::startReload() {
    const Weapon* w = curWeapon();
    if (!w || w->type != 0 || w->infinite || w->magSize <= 0 || reloadT_ > 0) return;
    if (wMag_[curW_] >= w->magSize || wAmmo_[curW_] <= 0) return;
    reloadT_ = std::max(0.1f, w->reloadTime);
    snd(4);
}
void Game::spawnBoom(V3 at, float size) {
    size = std::max(0.3f, size);
    bool is3 = sc->is3d;
    float ps = is3 ? 1.f : 100.f;
    auto rnd = []() { return frand(); };
    if (proj.boom.mode == 0) {   // por defecto: bola de fuego, chispas y humo
        const int maxParts = proj.perf.partOn ? std::max(10, proj.perf.part) : 900;
        for (int k = 0; k < 46 && (int)parts.size() < maxParts; k++) {
            Part q; q.is3 = is3; q.p = at;
            float a = rnd() * 6.2831853f, e = (rnd() - 0.3f) * 1.4f, sp = size * (0.8f + rnd() * 2.2f) * ps;
            q.v = V3{std::cos(a) * std::cos(e) * sp, std::sin(e) * sp + size * 0.6f * ps, is3 ? std::sin(a) * std::cos(e) * sp : 0.f};
            bool smoke = k > 30;
            q.max = q.life = smoke ? 0.9f + rnd() * 0.6f : 0.35f + rnd() * 0.35f;
            q.size = size * (smoke ? 0.55f : 0.32f) * ps * (0.6f + rnd() * 0.8f);
            q.grow = smoke ? 1.6f : 0.8f; q.grav = smoke ? 0.f : -2.f * ps; q.a0 = smoke ? 0.5f : 1.f; q.glow = !smoke;
            if (smoke) { q.c0[0] = q.c0[1] = q.c0[2] = 0.25f; q.c1[0] = q.c1[1] = q.c1[2] = 0.1f; }
            else { q.c0[0] = 1.f; q.c0[1] = 0.85f; q.c0[2] = 0.3f; q.c1[0] = 0.9f; q.c1[1] = 0.2f; q.c1[2] = 0.f; }
            parts.push_back(std::move(q));
        }
    }
    BoomFx b; b.p = at; b.size = size * std::max(0.1f, proj.boom.size); b.max = std::max(0.1f, proj.boom.time); b.is3 = is3;
    if (proj.boom.mode == 0) { b.max = 0.35f; b.size = size * 1.4f; }
    booms.push_back(b);
    if (booms.size() > 24) booms.erase(booms.begin());
}
void Game::explode(const Proj& p) {
    snd(7);
    spawnBoom(p.p, std::max(1.f, p.blast * 0.6f));
    physBlast(p.p, p.blast, std::min(14.f, 4.f + p.dmg * 0.5f), -1);
    for (size_t i = 0; i < sc->objs.size(); i++) {
        const Obj& o = sc->objs[i];
        if (!o.alive || !o.visible || o.kind == Kind::Player || o.kind == Kind::Light) continue;
        if (!(hasHat(o, Op::WhenShot) || o.ai.type != AiType::None || o.deform)) continue;
        float d = len(o.pos - p.p);
        if (d < p.blast) {
            damageObj((int)i, std::max(0.5f, p.dmg * (1.f - d / p.blast)));
            V3 dirOut = sc->objs[i].pos - p.p;
            dentObj((int)i, p.p, norm(dirOut), std::min(1.f, 1.2f * (1.f - d / p.blast)));
        }
    }
    float dp = len(V3{pos.x, pos.y + 0.9f, pos.z} - p.p);
    if (dp < p.blast) hurtPlayer(std::max(0.5f, p.dmg * 0.5f * (1.f - dp / p.blast)));
    shakeT = 0.4f; shakeAmp = 0.15f;
    flash = 0.1f;
    if (onSound) onSound("explosion");
}
void Game::weaponTick(float dt, const Input& in) {
    // recoger armas del suelo
    for (auto& o : sc->objs) {
        if (!o.alive || o.giveWeapon.empty()) continue;
        float dx = o.pos.x - pos.x, dz = o.pos.z - pos.z;
        float rr = 0.9f + 0.5f * std::max(o.scale.x, o.scale.z);
        if (dx * dx + dz * dz < rr * rr && std::fabs(o.pos.y - pos.y) < 2.5f) {
            giveWeapon(o.giveWeapon);
            o.alive = false;
            if (onSound) onSound("recoger");
        }
    }
    if (kick_ > 0) { float rc = std::min(kick_, dt * 0.6f); pitch -= rc; kick_ -= rc; }
    if (in.nextWeapon) cycleWeapon();
    if (in.reload) startReload();
    const Weapon* w = curWeapon();
    if (reloadT_ > 0) {
        reloadT_ -= dt;
        if (reloadT_ <= 0 && w) {
            int need = w->magSize - wMag_[curW_], take = std::min(need, wAmmo_[curW_]);
            wMag_[curW_] += take; wAmmo_[curW_] -= take;
        }
    }
    if (w) {  // para mostrar con "mostrar variable": municion y reserva
        vars["municion"] = (double)(w->infinite ? 999 : w->magSize > 0 ? wMag_[curW_] : wAmmo_[curW_]);
        vars["reserva"] = (double)(w->infinite ? 999 : wAmmo_[curW_]);
    }
    if (!(in.shoot && shootCd <= 0 && w && w->enabled && reloadT_ <= 0)) return;
    if (!w->infinite && w->type != 1) {
        int& cnt = w->magSize > 0 ? wMag_[curW_] : wAmmo_[curW_];
        if (cnt <= 0) { if (w->magSize > 0) startReload(); shootCd = 0.25f; return; }
        cnt--;
        if (w->magSize > 0 && cnt == 0) startReload();
    }
    shootCd = w->rate;
    recoil = std::min(2.f, w->recoilAmt);
    flash = w->type == 0 ? 0.07f : 0.f;
    if (w->type == 0) { float k = 0.02f * w->recoilAmt; pitch = std::min(1.5f, pitch + k); kick_ += k; }
    if (w->type == 1) snd(5); else if (w->type == 0) snd(3); else if (onSound) onSound("lanzar");
    shoot3D();
    fireAll(Op::WhenPlayerShoots);
    int pi2 = playerIndex(*sc);
    if (pi2 >= 0 && pi2 < (int)st_.size()) st_[pi2].atkT = 0.3f;
}
}  // namespace forge

// ---- v8: video dentro de objetos
namespace forge {
void Game::videoCmd(int oi, int cmd, const std::string& asset, int times) {
    VideoApi& api = videoApi();
    if (!api.available() || !sc || oi < 0 || oi >= (int)sc->objs.size()) return;
    if (vid_.size() < sc->objs.size()) vid_.resize(sc->objs.size());
    Obj& o = sc->objs[oi];
    VidState& v = vid_[oi];
    if (!asset.empty() && asset != o.video) { o.video = asset; if (v.opened) { api.close(oi); v.opened = false; } }
    if (o.video.empty()) return;
    auto ensure = [&]() {
        if (v.opened && v.name == o.video) return true;
        auto a = proj.assets.find(o.video);
        if (a == proj.assets.end()) return false;
        v.opened = api.open(oi, o.video, a->second);
        v.name = o.video;
        return v.opened;
    };
    switch (cmd) {
        case 0: if (ensure()) { v.loop = 0; api.control(oi, 3, 0); api.control(oi, 0, 0); v.state = 1; v.started = true; } break;
        case 1: if (v.opened && v.state == 1) { api.control(oi, 1, 0); v.state = 2; } break;
        case 2: if (v.opened && v.state == 2) { api.control(oi, 0, 0); v.state = 1; } break;
        case 3: if (ensure()) { v.loop = -1; api.control(oi, 3, 0); api.control(oi, 0, 0); v.state = 1; v.started = true; } break;
        case 4: if (ensure()) { v.loop = std::max(1, times); api.control(oi, 3, 0); api.control(oi, 0, 0); v.state = 1; v.started = true; } break;
        case 5: if (ensure()) { api.control(oi, 3, 0); api.control(oi, 0, 0); v.state = 1; v.started = true; } break;
        case 6: if (v.opened) { api.control(oi, 2, 0); v.state = 0; } break;
    }
}

void Game::videoTick() {
    VideoApi& api = videoApi();
    if (!api.available() || !sc) return;
    if (vid_.size() < sc->objs.size()) vid_.resize(sc->objs.size());
    for (size_t i = 0; i < sc->objs.size(); i++) {
        Obj& o = sc->objs[i];
        VidState& v = vid_[i];
        if (o.video.empty()) continue;
        if (!v.started && o.videoAuto && v.state == 0) { videoCmd((int)i, o.videoLoop ? 3 : 0, "", 0); continue; }
        if (v.state == 1 && api.finished(i)) {
            if (v.loop == -1) { api.control(i, 3, 0); api.control(i, 0, 0); }
            else if (v.loop > 1) { v.loop--; api.control(i, 3, 0); api.control(i, 0, 0); }
            else { v.state = 0; v.loop = 0; }
        }
    }
}

bool Game::videoFrame(int oi, int& w, int& h, std::vector<uint8_t>& px) {
    VideoApi& api = videoApi();
    if (!api.available() || oi < 0 || oi >= (int)vid_.size() || !vid_[oi].opened) return false;
    return api.frame(oi, w, h, px);
}
}  // namespace forge
