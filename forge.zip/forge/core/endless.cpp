#include "endless.h"
#include <algorithm>
#include <cmath>
#include <set>

namespace forge {

static float rnd(unsigned& s) {   // xorshift: 0..1
    s ^= s << 13; s ^= s >> 17; s ^= s << 5;
    return (s & 0xFFFFFF) / 16777216.f;
}
static float comp(const V3& v, int c) { return c == 0 ? v.x : c == 1 ? v.y : v.z; }
static void setComp(V3& v, int c, float x) { (c == 0 ? v.x : c == 1 ? v.y : v.z) = x; }

float endProgress(const EndInfo& e, V3 p) { return e.sgn * comp(p, e.fc); }

EndInfo endAnalyze(const Scene& s) {
    EndInfo e;
    int d = std::max(0, std::min(3, s.endDir));
    if (s.is3d) { e.fc = d < 2 ? 2 : 0; e.lc = d < 2 ? 0 : 2; e.sgn = (d == 0 || d == 3) ? -1.f : 1.f; }
    else        { e.fc = d < 2 ? 0 : 1; e.lc = d < 2 ? 1 : 0; e.sgn = (d == 0 || d == 2) ? 1.f : -1.f; }
    std::set<std::string> pool(s.endPool.begin(), s.endPool.end());
    std::vector<int> all;
    for (size_t i = 0; i < s.objs.size(); i++) {
        const Obj& o = s.objs[i];
        if (!o.alive || o.clone || !pool.count(o.name)) continue;
        all.push_back((int)i);
    }
    if (all.empty()) return e;
    float lo = 1e30f, hi = -1e30f;
    auto ext = [&](const Obj& o) { return std::max(0.05f, std::fabs(comp(o.scale, e.fc))); };
    for (int i : all) {
        const Obj& o = s.objs[i];
        float u = e.sgn * comp(o.pos, e.fc), h = ext(o) * 0.5f;
        lo = std::min(lo, u - h); hi = std::max(hi, u + h);
    }
    float span = std::max(1.f, hi - lo);
    float tileLen = 0.f;
    for (int i : all) {
        const Obj& o = s.objs[i];
        bool tile = o.kind == Kind::Floor || ext(o) >= span * 0.6f;
        if (tile) { e.tiles.push_back(i); tileLen = std::max(tileLen, ext(o)); }
        else e.obst.push_back(i);
    }
    e.start = lo;
    e.len = tileLen > 0.f ? tileLen : span + span / std::max<size_t>(1, e.obst.size());
    e.lanes = s.endLanes;
    if (e.lanes.empty()) {   // sin carriles marcados: se usan los lugares laterales que ya tenían los objetos
        std::set<int> seen;
        for (int i : e.obst) { float l = comp(s.objs[i].pos, e.lc); if (seen.insert((int)std::lround(l * 20.f)).second) e.lanes.push_back(l); }
    }
    e.ok = !e.obst.empty() || !e.tiles.empty();
    return e;
}

void endPlaceChunk(const Scene& s, const EndInfo& e, int k, unsigned& rng, std::vector<std::pair<int, V3>>& out) {
    out.clear();
    if (!e.ok) return;
    for (int i : e.tiles) {   // suelo / camino: se corre justo un tramo por cada repetición
        V3 p = s.objs[i].pos;
        setComp(p, e.fc, comp(p, e.fc) + e.sgn * e.len * k);
        out.push_back({i, p});
    }
    size_t n = e.obst.size();
    if (!n) return;
    std::vector<int> perm = e.obst;   // qué objeto cae en cada lugar: se baraja
    for (size_t i = n; i > 1; i--) std::swap(perm[i - 1], perm[(size_t)(rnd(rng) * i) % i]);
    float slot = e.len / (float)n, dens = std::max(0.1f, std::min(1.f, s.endDensity));
    for (size_t i = 0; i < n; i++) {
        if (rnd(rng) > dens) continue;
        const Obj& src = s.objs[perm[i]];
        // posición de este lugar dentro del tramo (los lugares se reparten parejo) con un poco de variación
        float u = e.start + e.len * k + slot * ((float)i + 0.5f) + (rnd(rng) - 0.5f) * slot * std::max(0.f, std::min(1.f, s.endJit));
        float lat = e.lanes.empty() ? comp(src.pos, e.lc) : e.lanes[(size_t)(rnd(rng) * e.lanes.size()) % e.lanes.size()];
        V3 p = src.pos;
        setComp(p, e.fc, e.sgn * u);
        setComp(p, e.lc, lat);
        out.push_back({perm[i], p});
    }
}

int endShuffleScene(Scene& s, unsigned seed) {
    EndInfo e = endAnalyze(s);
    if (!e.ok || e.obst.empty()) return 0;
    unsigned rng = seed * 2654435761u + 12345u;
    if (!rng) rng = 1;
    Scene tmp = s; tmp.endDensity = 1.f;
    std::vector<std::pair<int, V3>> out;
    EndInfo e2 = e; e2.tiles.clear();
    endPlaceChunk(tmp, e2, 0, rng, out);   // tramo 0 = el mismo lugar del nivel original
    int n = 0;
    for (auto& pr : out) { s.objs[pr.first].pos = pr.second; n++; }
    return n;
}

}  // namespace forge
