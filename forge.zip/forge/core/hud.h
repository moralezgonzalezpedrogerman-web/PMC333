#pragma once
#include "game.h"
#include <vector>

struct ImDrawList;

namespace forge {

class Renderer;

// Botones tactiles (saltar, disparar...), arma en primera persona, joystick, texto y variables.
// Capa de la camara: imagenes fijas y efectos de pantalla (VHS, camara de video...). Se dibuja sobre todo.
void drawCameraLayer(ImDrawList* dl, const Game& g, Renderer* r, int w, int h);

class Hud {
public:
    std::vector<HudBtn> btns;  // los que estan activos (por defecto o los del proyecto)
    bool fix3 = false;   // 3D: palanca fija
    float fixX(int w) const { return jx_ * w; }
    float fixY(int h) const { return jy_ * h; }
    float fixR(int h) const { return jr_ * h; }
    struct Joy { bool active = false; float ox = 0, oy = 0, x = 0, y = 0; } joy;

    int mode = 0;   // 0 normal, 1 auto cerca (botón Conducir), 2 dentro de un auto
    void setup(const Project& p, int mode_ = 0);
    int ctl2d() const { return ctl2d_; }
    // Un dedo toca la pantalla: true si lo captura un boton (en escenas 3D).
    bool down(int id, float px, float py, int w, int h, bool is3d);
    void up(int id);
    void move(int id, float px, float py, int w, int h);  // palanca 2D
    void collect(Input& in);  // traduce botones presionados a entrada de juego
    void draw(ImDrawList* dl, const Game& g, Renderer* r, int w, int h, bool showButtons);

private:
    struct St { int ptr = -1; bool tapPending = false, pressed = false; };
    std::vector<St> st_;
    // v10: controles de escenas 2D (cruceta / palanca / plataformas), con los mismos nombres que usan los bloques "Cuando se presione el botón"
    struct B2 { std::string label; float x, y, r; float c[3]; int ptr = -1; };
    std::vector<B2> b2_;
    float jx_ = 0.17f, jy_ = 0.74f, jr_ = 0.16f;   // palanca (fracciones de la pantalla / del alto)
    int ctl2d_ = 0, stickPtr_ = -1;
    float stickX_ = 0, stickY_ = 0;  // desplazamiento de la palanca (-1..1)
};

}  // namespace forge
