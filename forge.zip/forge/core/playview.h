#pragma once
#include "audio.h"
#include "controls.h"
#include "game.h"
#include "hud.h"
#include <functional>

namespace forge {

class Renderer;

// Un juego en marcha: logica + dibujo + botones + audio. Lo usan los runtimes y el modo "Jugar" del editor.
class PlayView {
public:
    Game game;
    Hud hud;
    PlayControls ctl;
    Audio* audio = nullptr;
    bool showButtons = true;
    bool keys = false;       // v10.8: teclado / mouse / control segun el mapeo del proyecto (Windows)
    bool gamepad = false;    // v10.8: tambien el control (mapeo automatico)
    bool useRes = true;      // v10.8: aplicar la resolucion del proyecto (el editor no la usa)
    bool splash = false;     // juegos exportados: muestra primero la pantalla de inicio
    float splashT = -1.f;    // >= 0 mientras se muestra
    // Servicios del dispositivo (la plataforma los rellena; pueden quedar vacios)
    std::function<void(float)> onVibrate;
    std::function<void(const std::string&)> onSpeak;
    std::function<void(bool)> onFlash;
    std::function<void(int)> onCamera;                                   // 0 apagar, 1 cámara de atrás, 2 de adelante
    std::function<bool(int&, int&, std::vector<uint8_t>&)> camFrame;     // cuadro nuevo de la cámara (RGBA)
    std::function<bool(float*)> sensors;                                 // 7 números: aceleración x y z (orientada a la pantalla), brújula, giro x y z
    std::string devPath;     // archivo donde se guardan las variables del dispositivo (vacío = no se guardan)

    std::string telemPath;   // resumen de rendimiento de la partida (vacío = no se guarda)
    void flushTelemetry();   // escribe una línea con FPS medio, peor cuadro y cuántos cuadros fueron lentos
    void start(Project p);
    // Requiere un frame de ImGui activo (el HUD se dibuja con ImGui). r puede ser null en pruebas.
    void frame(Renderer* r, int w, int h, float dt, const Input* direct = nullptr);
private:
    const Scene* ctlSc_ = nullptr;
    float dynScale_ = 1.f, dtAvg_ = 1.f / 60.f, dynT_ = 0.f, upT_ = 0.f;
    const Scene* warmFor_ = nullptr;
    double tFrames_ = 0, tSum_ = 0, tWorst_ = 0, tTime_ = 0; long tSlow_ = 0, tN_ = 0;
};

}  // namespace forge
