package com.forge.maker;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Size;
import android.view.Surface;
import java.nio.ByteBuffer;
import java.util.Collections;

/**
 * Camara como FONDO del juego (sin abrir la app de camara). Camera2 + ImageReader (YUV) -> RGBA pequeño que el motor C++
 * pide con frame(). Devuelve los bytes con una cabecera de 8 bytes: ancho y alto (enteros, big-endian).
 */
public class CameraBridge {
    public static final int REQ_CAMERA = 4103;
    private final Activity act;
    private CameraDevice dev;
    private CameraCaptureSession sess;
    private ImageReader reader;
    private HandlerThread ht;
    private Handler h;
    private volatile byte[] frame;
    private volatile boolean fresh;
    private volatile int mode;          // 0 apagada, 1 atras, 2 adelante
    private int sensorOri;
    private int pendingMode = 0;

    public CameraBridge(Activity a) { act = a; }

    public synchronized void set(int m) {
        if (m == 0) { stop(); return; }
        if (Build.VERSION.SDK_INT >= 23 && act.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            pendingMode = m;
            act.requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        start(m);
    }

    public synchronized void onPermission(boolean granted) {
        int m = pendingMode;
        pendingMode = 0;
        if (granted && m != 0) start(m);
    }

    private void start(int m) {
        stop();
        mode = m;
        try {
            CameraManager cm = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            Size best = null;
            for (String cid : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(cid);
                Integer face = cc.get(CameraCharacteristics.LENS_FACING);
                if (face == null) continue;
                boolean wantFront = m == 2;
                if ((face == CameraCharacteristics.LENS_FACING_FRONT) != wantFront) continue;
                StreamConfigurationMap map = cc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
                if (map == null) continue;
                Size[] sizes = map.getOutputSizes(ImageFormat.YUV_420_888);
                if (sizes == null || sizes.length == 0) continue;
                for (Size s : sizes) {   // el tamaño más cercano a 640x480 sin pasarse mucho
                    if (s.getWidth() > 1280) continue;
                    if (best == null || Math.abs(s.getWidth() * s.getHeight() - 640 * 480) < Math.abs(best.getWidth() * best.getHeight() - 640 * 480)) best = s;
                }
                if (best == null) best = sizes[sizes.length - 1];
                Integer so = cc.get(CameraCharacteristics.SENSOR_ORIENTATION);
                sensorOri = so == null ? 90 : so;
                id = cid;
                break;
            }
            if (id == null || best == null) { mode = 0; return; }
            ht = new HandlerThread("forge-cam");
            ht.start();
            h = new Handler(ht.getLooper());
            final int rw = best.getWidth(), rh = best.getHeight();
            reader = ImageReader.newInstance(rw, rh, ImageFormat.YUV_420_888, 2);
            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img != null) convert(img);
                } catch (Throwable t) { /* se salta este cuadro */ }
                finally { if (img != null) img.close(); }
            }, h);
            cm.openCamera(id, new CameraDevice.StateCallback() {
                @Override public void onOpened(CameraDevice d) {
                    dev = d;
                    try {
                        d.createCaptureSession(Collections.singletonList(reader.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(CameraCaptureSession s) {
                                sess = s;
                                try {
                                    CaptureRequest.Builder b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                    b.addTarget(reader.getSurface());
                                    b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                                    s.setRepeatingRequest(b.build(), null, h);
                                } catch (Throwable t) { /* sin cámara */ }
                            }
                            @Override public void onConfigureFailed(CameraCaptureSession s) { }
                        }, h);
                    } catch (Throwable t) { /* sin cámara */ }
                }
                @Override public void onDisconnected(CameraDevice d) { d.close(); }
                @Override public void onError(CameraDevice d, int e) { d.close(); }
            }, h);
        } catch (SecurityException | CameraAccessException e) {
            mode = 0;
        } catch (Throwable t) {
            mode = 0;
        }
    }

    public synchronized void stop() {
        mode = 0;
        try { if (sess != null) sess.close(); } catch (Throwable t) { }
        try { if (dev != null) dev.close(); } catch (Throwable t) { }
        try { if (reader != null) reader.close(); } catch (Throwable t) { }
        try { if (ht != null) ht.quitSafely(); } catch (Throwable t) { }
        sess = null; dev = null; reader = null; ht = null; h = null;
        frame = null; fresh = false;
    }

    private void convert(Image img) {
        final int w = img.getWidth(), hh = img.getHeight();
        final int ow0 = w / 2, oh0 = hh / 2;   // se toma 1 de cada 2 pixeles: rápido y suficiente para un fondo
        Image.Plane[] pl = img.getPlanes();
        ByteBuffer yb = pl[0].getBuffer(), ub = pl[1].getBuffer(), vb = pl[2].getBuffer();
        final int ys = pl[0].getRowStride(), us = pl[1].getRowStride(), up = pl[1].getPixelStride(), vs = pl[2].getRowStride(), vp = pl[2].getPixelStride();
        int disp = 0;
        try {
            int r = act.getWindowManager().getDefaultDisplay().getRotation();
            disp = r == Surface.ROTATION_90 ? 90 : r == Surface.ROTATION_180 ? 180 : r == Surface.ROTATION_270 ? 270 : 0;
        } catch (Throwable t) { }
        int rot = mode == 2 ? (sensorOri + disp) % 360 : (sensorOri - disp + 360) % 360;
        final int ow = (rot == 90 || rot == 270) ? oh0 : ow0, oh = (rot == 90 || rot == 270) ? ow0 : oh0;
        byte[] out = new byte[8 + ow * oh * 4];
        out[0] = (byte) (ow >> 24); out[1] = (byte) (ow >> 16); out[2] = (byte) (ow >> 8); out[3] = (byte) ow;
        out[4] = (byte) (oh >> 24); out[5] = (byte) (oh >> 16); out[6] = (byte) (oh >> 8); out[7] = (byte) oh;
        int o = 8;
        for (int oy = 0; oy < oh; oy++) {
            for (int ox = 0; ox < ow; ox++) {
                int sx, sy;   // pixel de origen (en la rejilla reducida) según la rotación
                switch (rot) {
                    case 90: sx = oy; sy = ow - 1 - ox; sx = Math.min(ow0 - 1, sx); sy = Math.min(oh0 - 1, sy); break;
                    case 180: sx = ow0 - 1 - ox; sy = oh0 - 1 - oy; break;
                    case 270: sx = oh - 1 - oy; sy = ox; sx = Math.min(ow0 - 1, sx); sy = Math.min(oh0 - 1, sy); break;
                    default: sx = ox; sy = oy;
                }
                int px = sx * 2, py = sy * 2;
                int Y = yb.get(py * ys + px) & 0xFF;
                int U = (ub.get((py / 2) * us + (px / 2) * up) & 0xFF) - 128;
                int V = (vb.get((py / 2) * vs + (px / 2) * vp) & 0xFF) - 128;
                int R = Y + (int) (1.402f * V), G = Y - (int) (0.344f * U + 0.714f * V), B = Y + (int) (1.772f * U);
                out[o++] = (byte) (R < 0 ? 0 : R > 255 ? 255 : R);
                out[o++] = (byte) (G < 0 ? 0 : G > 255 ? 255 : G);
                out[o++] = (byte) (B < 0 ? 0 : B > 255 ? 255 : B);
                out[o++] = (byte) 255;
            }
        }
        frame = out;
        fresh = true;
    }

    /** Cuadro nuevo (8 bytes de cabecera + RGBA) o null si no hay uno nuevo. */
    public byte[] frame() {
        if (!fresh) return null;
        fresh = false;
        return frame;
    }
}
