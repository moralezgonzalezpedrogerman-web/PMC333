package com.forge.maker;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Pasa m4a/aac/ogg/opus/amr/3gp a WAV de 16 bits (con MediaCodec) para que el motor los pueda tocar. */
public final class AudioConvert {
    private AudioConvert() {}

    /** Devuelve los bytes de un WAV, o null si no se pudo. */
    public static byte[] toWav(File cacheDir, byte[] input, String name) {
        File tmp = null;
        MediaExtractor ex = null;
        MediaCodec codec = null;
        try {
            String ext = ".m4a";
            int dot = name.lastIndexOf('.');
            if (dot >= 0 && name.length() - dot < 8) ext = name.substring(dot);
            tmp = new File(cacheDir, "forge_audio_tmp" + ext);
            try (FileOutputStream fo = new FileOutputStream(tmp)) { fo.write(input); }

            ex = new MediaExtractor();
            ex.setDataSource(tmp.getAbsolutePath());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) return null;
            ex.selectTrack(track);
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();

            int channels = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT) ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            int rate = fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE) ? fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
            ByteArrayOutputStream pcm = new ByteArrayOutputStream(1 << 20);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inDone = false, outDone = false;
            long limit = 160L * 1024 * 1024;   // tope de seguridad
            while (!outDone) {
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        byte[] chunk = new byte[info.size];
                        ob.position(info.offset);
                        ob.get(chunk);
                        pcm.write(chunk, 0, chunk.length);
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                    if (pcm.size() > limit) break;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                }
            }
            byte[] data = pcm.toByteArray();
            if (data.length == 0) return null;
            ByteBuffer w = ByteBuffer.allocate(44 + data.length).order(ByteOrder.LITTLE_ENDIAN);
            w.put(new byte[]{'R', 'I', 'F', 'F'}).putInt(36 + data.length).put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
            w.putInt(16).putShort((short) 1).putShort((short) channels).putInt(rate)
             .putInt(rate * channels * 2).putShort((short) (channels * 2)).putShort((short) 16);
            w.put(new byte[]{'d', 'a', 't', 'a'}).putInt(data.length).put(data);
            return w.array();
        } catch (Throwable t) {
            return null;
        } finally {
            try { if (codec != null) { codec.stop(); codec.release(); } } catch (Throwable t) { }
            try { if (ex != null) ex.release(); } catch (Throwable t) { }
            if (tmp != null) tmp.delete();
        }
    }
}
