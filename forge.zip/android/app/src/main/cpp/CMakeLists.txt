cmake_minimum_required(VERSION 3.22)
project(forge CXX C)
set(CMAKE_CXX_STANDARD 17)

set(FORGE_ROOT ${CMAKE_CURRENT_SOURCE_DIR}/../../../../..)
set(FORGE_WITH_EDITOR ON)
include(${FORGE_ROOT}/cmake/deps.cmake)

set(GLUE ${ANDROID_NDK}/sources/android/native_app_glue)
file(GLOB CORE_SOURCES ${FORGE_ROOT}/core/*.cpp)
list(FILTER CORE_SOURCES EXCLUDE REGEX "gl_desktop\\.cpp$")  # en Android GL viene del sistema
file(GLOB EDITOR_SOURCES ${FORGE_ROOT}/editor/*.cpp)
set(IMGUI_SOURCES ${IMGUI_DIR}/imgui.cpp ${IMGUI_DIR}/imgui_draw.cpp ${IMGUI_DIR}/imgui_tables.cpp
    ${IMGUI_DIR}/imgui_widgets.cpp ${IMGUI_DIR}/misc/cpp/imgui_stdlib.cpp
    ${IMGUI_DIR}/backends/imgui_impl_android.cpp ${IMGUI_DIR}/backends/imgui_impl_opengl3.cpp)
set_source_files_properties(${UFBX_DIR}/ufbx.c PROPERTIES LANGUAGE C COMPILE_FLAGS "-O2")

add_library(forge SHARED android_main.cpp ${CORE_SOURCES} ${EDITOR_SOURCES} ${IMGUI_SOURCES}
            ${UFBX_DIR}/ufbx.c ${GLUE}/android_native_app_glue.c)
target_include_directories(forge PRIVATE ${FORGE_ROOT}/core ${FORGE_ROOT}/editor ${GLUE} ${STB_DIR}
    ${IMGUI_DIR} ${IMGUI_DIR}/backends ${MINIAUDIO_DIR} ${CGLTF_DIR} ${UFBX_DIR})
target_compile_definitions(forge PRIVATE FORGE_GLES=1 IMGUI_IMPL_OPENGL_ES3 IMGUI_DISABLE_DEMO_WINDOWS)
target_compile_options(forge PRIVATE -O2 -ffunction-sections -fdata-sections)
set(CMAKE_SHARED_LINKER_FLAGS "${CMAKE_SHARED_LINKER_FLAGS} -u ANativeActivity_onCreate -Wl,--gc-sections")
target_link_libraries(forge android log EGL GLESv3 OpenSLES dl)
