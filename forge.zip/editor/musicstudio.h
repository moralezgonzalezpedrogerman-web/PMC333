#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace forge {
// Estudio de música: secuenciador de 16 pasos con 6 pistas, y generador de efectos de sonido.
struct MusicSong {
    float bpm = 120.f;
    int scale = 1;       // 0 mayor, 1 menor, 2 frigia (oscura), 3 pentatónica, 4 blues
    int root = 0;        // semitonos sobre La
    int bars = 4;        // cuántas veces se repite el patrón en el archivo
    int inst[3] = {0, 0, 0};   // instrumento de melodía, acordes y bajo
    float vol[6] = {0.8f, 0.6f, 0.8f, 0.9f, 0.7f, 0.5f};
    float swing = 0.f;
    // melodía/acordes/bajo: grado de la escala (0..9) o -1 silencio. Percusión: 0/1
    int cell[6][16];
    MusicSong() { clear(); }
    void clear() { for (auto& r : cell) for (int& c : r) c = -1; }
};
extern const char* kGenreNames[8];
extern const char* kScaleNames[5];
extern const char* kInstNames[3][4];
const int kSfxCount = 24;
extern const char* kSfxNames[kSfxCount];
void musicPreset(MusicSong& s, int genre);
void musicRandom(MusicSong& s, unsigned seed);
std::vector<uint8_t> musicRender(const MusicSong& s);                         // WAV mono 22 kHz
std::vector<uint8_t> sfxRender(int kind, float pitch, float length, unsigned seed);
}
