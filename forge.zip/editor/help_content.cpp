// Generado a partir de la guía de ayuda (texto). Cada trozo es menor de 12 KB por el límite de MSVC.
#include "help.h"

namespace forge {

static const char* const kParts[] = {
R"HLP(
#Empieza aquí
###¿Qué es P-Maker? | Con P-Maker haces juegos como los de tu teléfono. Tú pones cosas, les dices qué hacer, y juegas.
- P-Maker es una caja de juguetes para hacer videojuegos. No necesitas saber programar.
- Un juego tiene escenas (como los niveles). Cada escena tiene objetos (un personaje, un árbol, una moneda...).
- A los objetos les das órdenes con bloques, como piezas de lego. Por ejemplo: "cuando me toquen, suena un sonido".
- Puedes hacer juegos en 2D (planos, como un dibujo) y en 3D (con profundidad, como un mundo).
- Cuando termines, toca JUGAR para probarlo y exportas un APK para instalarlo en tu teléfono.
###Hacer tu primer juego en 5 minutos | Vamos a crear un mundo 3D con un cubo y jugarlo.
- Abre P-Maker. En la pantalla de inicio escribe un nombre en el cuadro "Nombre del proyecto".
  @text|Nombre del proyecto: Mi juego
- Toca el mosaico verde "Nuevo vacío". Si quieres un ejemplo ya armado, toca "Nuevo con la demo".
  @btn|Nuevo vacío|g
- Verás la lista de escenas. Abre la primera escena tocándola.
- Toca el botón grande "Editar la escena (ver y colocar objetos)".
  @btn|Editar la escena (ver y colocar objetos)|b
- Arriba toca "Añadir" y luego "Cubo". Aparece un cubo en el mundo.
  @menu|Añadir|Cubo;Objetos de juego;Suelo;Pared;Item;Luz;Modelo 3D...|Cubo
- Toca "Añadir" y luego "Suelo" para tener donde pararte.
  @menu|Añadir|Cubo;Objetos de juego;Suelo;Pared;Item;Luz;Modelo 3D...|Suelo
- Toca el botón verde JUGAR. ¡Ya estás dentro de tu juego! Muévete con el círculo de la izquierda.
  @bar|JUGAR
###Las pantallas de P-Maker | Para no perderte, así se llama cada lugar.
- Inicio: aquí están tus juegos, las plantillas y la Ayuda. Es lo primero que ves.
  @text|Inicio: tus juegos y plantillas
- Lista de escenas: dentro de un juego, aquí ves todos los niveles.
- Pantalla de la escena: aquí están los objetos de la escena y el botón "Editar la escena".
- Pantalla del objeto: tiene pestañas Scripts (bloques), Apariencias, Sonidos, Animaciones y Videos.
  @tabs|Scripts;Apariencias;Sonidos;Animaciones;Videos|0
- Editor 3D: la pantalla grande donde pones cosas. Arriba tiene la barra con Añadir, Ventanas y JUGAR.
  @bar|Ventanas
###Guardar, abrir y cerrar | Para que no pierdas tu trabajo.
- P-Maker guarda cuando cierras el proyecto, pero es mejor guardar tú también.
- Toca el botón de menú (arriba a la derecha) y elige "Guardar". En el editor 3D usa "Proyecto" y luego "Guardar".
  @menu|Proyecto|Guardar;Ayuda: guías paso a paso;Exportar juego (APK, EXE, paquete)...;Cerrar proyecto|Guardar
- Para salir de tu juego elige "Cerrar proyecto". Volverás al inicio.
- Para volver a abrirlo, búscalo en "Tus juegos" y tócalo.
###Moverte con los dedos en el editor 3D | Tus dedos son tus herramientas.
- Un dedo arrastrando en un lugar vacío: gira la cámara para mirar alrededor.
  @view|none|none
- Dos dedos separándose o juntándose: acercas y alejas.
- Dos dedos moviéndose juntos: mueves la vista de lado.
- Tocar un objeto una vez: lo seleccionas (se pone un marco amarillo).
  @view|sel|tap
- Tocar un objeto dos veces rápido: se abren sus Propiedades.
- Con un objeto seleccionado, arrastra sobre él para moverlo.
  @view|sel|move
#Plantillas (juegos ya hechos)
###Usar una plantilla | Una plantilla es un juego que ya viene armado. Lo abres y lo cambias a tu gusto.
- En el Inicio baja hasta "Plantillas (juegos listos para modificar)".
- Toca la que te guste: Carreras, Terror, RPG, Peleas, Runner y más.
- Se crea tu propio juego con su nombre. Ábrelo desde "Tus juegos".
- Toca JUGAR para probarlo antes de cambiar nada.
- Después cambia lo que quieras: colores, enemigos, sonidos, bloques. Nada se rompe: la plantilla original queda guardada.
###Plantilla de Carreras | Conduces un carro por una pista con vueltas y tiempo.
- Abre la plantilla "Carreras" y toca JUGAR.
- Los botones azules mueven el carro a la Izquierda y a la Derecha. El verde Acelera y el rojo Frena.
  @car|
- Pasa por la meta para contar una vuelta y por el punto medio para que la vuelta cuente.
- Choca con conos para perder velocidad. Los turbos te dan empujón.
- Para cambiar la velocidad del carro: selecciona al Jugador, abre Propiedades y cambia su velocidad.
- Para poner tu propio carro: importa un modelo 3D (guía "Importar un modelo 3D") y ponlo en el objeto Jugador.
###Plantilla FNAF 2D y 3D | Sobrevives una noche cuidando la puerta y mirando las cámaras.
- Abre "FNAF 2D" o "FNAF 3D" desde las plantillas y toca JUGAR.
- Toca los botones de las puertas para cerrarlas o abrirlas. Cerrada gasta energía.
- Toca CAM1, CAM2, CAM3 para mirar otras salas. Vuelve con "Oficina".
- Si un animatrónico llega a tu puerta abierta, hay un susto y pierdes. Ciérrala a tiempo.
- La energía baja. Si llega a cero se apagan las luces. Resiste hasta que se acabe la noche.
- Para cambiar sustos y sonidos mira las guías de Sonido y de Bloques.
###Plantilla RPG con espada | Eres un caballero que explora una aldea, un bosque y unas ruinas.
- Abre "RPG" y toca JUGAR.
- Toca el botón de ataque para dar un espadazo. Los enemigos tienen vida y se caen al perderla.
- Habla con la gente tocándola o acercándote. Abre los cofres igual.
- Junta monedas para subir tus puntos. Al final hay un jefe orco.
- Cambia el arma en "Botones y arma", sección "Arma del jugador".
###Plantilla Plataformas 2D y 3D | Saltas por plataformas y juntas monedas.
- Abre la plantilla y toca JUGAR.
- En 2D usa izquierda, derecha y saltar. En 3D usa el círculo para moverte y el botón SALTAR.
- Cada moneda suma puntos. Si te caes, vuelves a empezar.
- Para agregar más plataformas copia una: mantén presionado el objeto y elige "Duplicar".
###Plantilla Peleas | Un luchador contra otro con puños.
- Abre "Peleas 3D" y toca JUGAR.
- Muévete cerca del otro luchador y toca el botón de golpe.
- Cada golpe quita vida. Gana el que deje al otro sin vida.
- Cambia los luchadores seleccionándolos y poniéndoles otro modelo en Propiedades.
###Plantillas casuales: Runner, Flappy, Frutas y Clicker | Juegos cortos de teléfono.
- Runner: toca la pantalla para saltar los obstáculos.
- Flappy: toca para volar y pasa entre los tubos sin chocar.
- Atrapa frutas: mueve la canasta a izquierda y derecha para atrapar lo que cae.
- Clicker: toca muchas veces para ganar puntos.
- Todos usan bloques. Abre un objeto y mira la pestaña Scripts para ver cómo funcionan.
#Juegos en 3D
##Poner cosas en el mundo
###Añadir objetos | Todo lo que ves se pone desde el menú Añadir.
- En el editor 3D toca "Añadir" arriba.
  @bar|Añadir
- Cubo: una caja. Suelo: donde caminas. Pared: un muro. Item: algo que se recoge. Luz: una lámpara.
  @menu|Añadir|Cubo;Objetos de juego;Suelo;Pared;Item;Luz;Modelo 3D...|Pared
- "Objetos de juego" trae enemigos, armas, llaves, puertas, interruptores, botiquines, teleports y fin de nivel.
- "Modelo 3D..." abre una ventana con tus modelos importados. Toca el que quieras.
- El objeto aparece frente a la cámara. Arrástralo para ponerlo en su lugar.
###Mover, girar y agrandar | Para dejar cada cosa donde quieres.
- Toca el objeto para seleccionarlo. Verás un marco amarillo.
  @view|sel|tap
- Arrástralo con un dedo para moverlo por el suelo.
- Toca dos veces para abrir Propiedades. Ahí hay Posición (X, Y, Z) y "Tamaño y giro".
  @list|Propiedades|Posición;Tamaño y giro;Apariencia;Física|Tamaño y giro
- Cambia los números tocando el cuadrito. Escribe y acepta.
- X es izquierda-derecha, Y es arriba-abajo y Z es adelante-atrás.
###Colores y texturas | Pinta tus objetos o ponles dibujos.
- Selecciona el objeto y abre Propiedades.
- En "Apariencia" toca el cuadro de color para elegir un color.
  @list|Propiedades|Posición;Tamaño y giro;Apariencia;Física|Apariencia
- Para ponerle un dibujo (textura) toca "Seleccionar una imagen..." y elige una imagen de tus archivos.
- Si no tienes imágenes, importa una en "Archivos" (guía "Importar imágenes").
- Una textura transparente deja pasar la luz y no hace sombra en esa parte.
###Copiar y borrar objetos | Para hacer muchos iguales.
- Abre la ventana "Objetos" desde Ventanas.
  @menu|Ventanas|Objetos;Propiedades;Mundo (cielo y luz);Botones y arma;Archivos|Objetos
- Mantén presionado el objeto que quieres.
- Elige "Duplicar" para una copia, "Renombrar" para cambiarle el nombre o "Eliminar" para borrarlo.
- Si borras sin querer, cierra el proyecto sin guardar y ábrelo de nuevo.
###Suelo, paredes y casas | Para armar un nivel.
- Añade un "Suelo" y estíralo en "Tamaño y giro" hasta que sea grande.
- Añade "Pared" y ponla de pie. Copia varias para hacer un cuarto.
- Deja un hueco para la puerta. Pon una puerta desde Añadir > Objetos de juego.
- Los modelos de casas importados se pueden recorrer por dentro porque su colisión sigue la forma.
##El mundo
###Cielo, sol y luces | Cambia el día y la noche.
- Abre Ventanas > "Mundo (cielo y luz)".
  @menu|Ventanas|Objetos;Propiedades;Mundo (cielo y luz);Botones y arma;Archivos|Mundo (cielo y luz)
- En "Cielo" elige los colores de arriba y de abajo.
- En "Sol y luz" mueve la fuerza del sol y su dirección. Más oscuro = noche.
- Para una lámpara usa Añadir > Luz y ponla donde quieras.
- Las sombras se ajustan de clara a oscura en la misma ventana.
###Clima, niebla y agua | Lluvia, nieve, tormenta de arena y mar.
- En la ventana del Mundo baja hasta "Clima y niebla del mundo".
- Elige niebla, lluvia, tormenta de arena, nieve o personalizado, y cuánta cantidad.
- La niebla de color gris da miedo, como en los juegos de terror.
- Más abajo, "Mar / agua (opcional)" pone un mar con su nivel.
###Terreno con montañas | Haz colinas con el dedo.
- Añade un "Suelo" grande y selecciónalo.
- En Propiedades busca "Terreno (montañas)" y elige Básico, Medio o Fino. Fino tiene más detalle pero pesa más.
- Activa "Modo esculpir" y arrastra el dedo sobre el suelo: sube la montaña.
- Con las opciones de esculpir también puedes bajar el suelo y hacer hoyos. Tu jugador camina sobre la forma nueva.
###Pasto y plantas | Pinta vegetación con el dedo.
- Abre Ventanas > "Mundo (cielo y luz)" y busca "Vegetación (pintar pasto con el dedo)".
- Elige el tipo de pasto, el color y la textura.
- Toca "+ Capa nueva de pasto" y pinta arrastrando por el suelo.
- Para pintar arena, roca o nieve usa "Pintar el suelo (lápiz de texturas)", que está en la misma ventana.
##El jugador
###Cámara del jugador | Primera persona, al hombro o fija.
- Toca el objeto verde "Jugador" en el mundo, o en la ventana Objetos.
- En Propiedades busca "Cámara del juego".
- Primera persona: ves por los ojos. Al hombro: ves al personaje por detrás. Fija: la cámara no se mueve.
- Al hombro puedes cambiar la distancia de la cámara.
- Hay opción de balanceo de cámara al caminar.
###Botones en pantalla | Disparar, saltar y más.
- Abre Ventanas > "Botones y arma".
  @menu|Ventanas|Objetos;Propiedades;Mundo (cielo y luz);Botones y arma;Archivos|Botones y arma
- En "Botones en pantalla (escenas 3D)" ves los botones del juego.
- Toca "+ Añadir botón" para uno nuevo. Elige su acción: saltar, disparar, interactuar, recargar, linterna, correr, agacharse y más.
- Arrastra el botón en la vista previa para moverlo. Cambia color y tamaño.
- Si lo dejas en blanco, el juego no tendrá botones.
  @hud|shoot;jump;stick

)HLP",
R"HLP(
###Armas y balas | Pistolas, espadas y granadas.
- En "Botones y arma" busca "Arma del jugador".
- Elige un dibujo o un modelo 3D para el arma y su proyectil.
- Cambia el daño, la velocidad de disparo, las balas por cargador y el retroceso.
- Con "+ Arma cuerpo a cuerpo", "+ Arma arrojadiza" o "+ Granada" agregas más armas.
- Elige si empiezas con ella o si hay que recogerla del suelo.
###Correr, agacharse y recargar | Para controles como los de Call of Duty.
- En "Botones y arma" abre "Pantalla del juego (HUD) lista para usar" y activa la casilla.
- Baja y toca "Agregar botones de móvil: Correr, Agacharse y Recargar".
- Aparecen tres botones. Muévelos si quieres.
  @hud|run;crouch;reload
- Mantén CORRER mientras avanzas: vas más rápido. Mantén AGACHAR: vas lento y la cámara baja.
###Linterna | Para la oscuridad.
- Selecciona al Jugador y abre Propiedades > "Linterna".
- Activa la linterna. Elige si empieza encendida.
- Cambia su alcance, ángulo, potencia y color.
- Con los bloques "Encender la linterna" y "Apagar la linterna" la controlas desde un script.
##Enemigos
###Poner un enemigo | Un monstruo que te persigue o dispara.
- Toca Añadir > Objetos de juego > Enemigo.
- Selecciónalo y abre Propiedades > "Enemigo o monstruo".
- Elige si dispara o pelea cuerpo a cuerpo, su vida, velocidad, qué tan lejos ve y su daño.
- Ponle un modelo 3D o imágenes por acción (caminar, atacar, quieto, daño).
- Si dispara, en "Proyectil del enemigo" cambias la bala.
###Bloques de enemigos | Que se peleen entre ellos.
- Abre el script de cualquier objeto.
- En la categoría Forge3D hay tres bloques: "Todos los enemigos te atacan", "se atacan entre sí, menos a ti" y "se atacan entre sí e incluso a ti".
- "Fijar objetivo" hace que los enemigos persigan a algo en especial.
- "Quitar objetivo" lo deja como estaba.
#Juegos en 2D
###Crear una escena 2D | Para juegos planos y menús.
- Dentro de tu proyecto, en la lista de escenas toca el botón de agregar y elige "Nueva escena 2D".
- Se crea con un fondo transparente. Toca el fondo para cambiarle la imagen.
- Toca "Objeto nuevo" para poner personajes, botones o decoraciones.
- Elige una imagen para cada objeto. Con bloques les das vida.
###Controles táctiles 2D | Flechas y botones en la pantalla.
- Abre el menú y entra a "Botones y arma".
- En "Controles en escenas 2D" elige: Cruceta, Palanca, Plataformas o Ninguno.
- Los botones mandan mensajes: Izquierda, Derecha, Arriba, Abajo, A y B.
- En tu objeto usa el bloque "Cuando se presione el botón Izquierda" y pon debajo "Incrementar X en -10".
- Con teclado en Windows también funcionan.
###Mover un personaje 2D | Con bloques.
- Abre tu personaje y la pestaña Scripts.
  @tabs|Scripts;Apariencias;Sonidos;Animaciones;Videos|0
- Pon "Cuando se presione el botón Derecha". Debajo "Incrementar X en 10".
  @blocks|e:Cuando se presione el botón Derecha;m:Incrementar X en 10|1
- Haz otro igual para Izquierda con -10.
- Para saltar usa "Incrementar Y en 15", espera un poco y "Incrementar Y en -15".
- Si no quieres que salga de la pantalla usa el bloque "No salir de la pantalla".
#Bloques (programar fácil)
##Lo básico
###¿Qué es un bloque? | Los bloques son órdenes con forma de pieza. Los unes y el objeto las obedece de arriba hacia abajo.
- Cada objeto tiene su propia pila de bloques en la pestaña Scripts.
- Un bloque amarillo de Eventos va primero: dice CUÁNDO pasa algo. Por ejemplo "Cuando pulse".
  @blocks|e:Cuando pulse;a:Reproducir sonido;m:Mover 10 pasos|0
- Los bloques de abajo dicen QUÉ hacer: moverse, sonar, cambiar de tamaño...
- Hay 7 colores o categorías: Eventos, Control, Movimiento, Sonido, Apariencia, Datos y Forge3D.
###Añadir un bloque | Paso a paso.
- Abre un objeto tocándolo en la lista de objetos de la escena.
- Entra a la pestaña Scripts.
  @tabs|Scripts;Apariencias;Sonidos;Animaciones;Videos|0
- Toca "+ Añadir bloque".
  @btn|+ Añadir bloque|g
- Elige una categoría. Si no sabes cuál, escribe en "Buscar bloque" una palabra, como "sonido" o "mover".
- Toca el bloque que quieras. Se pone al final de tu pila.
- Cambia sus números tocando el cuadrito del bloque.
###Cambiar números y textos | Los huecos de los bloques.
- Toca el hueco que quieres cambiar, por ejemplo el 10 de "Mover 10 pasos".
- Se abre el editor de fórmulas. Escribe un número o usa las fichas.
- Toca "Aceptar (guardar)" para guardar o "Cancelar" para dejarlo como estaba.
- Las funciones aparecen como fichas. Toca un cuadrito de la ficha para cambiar solo ese valor.
- Para borrar una función toca "Borrar": se quita la ficha completa.
###Copiar y borrar bloques | Ordena tu pila.
- Toca un bloque: aparece una explicación de lo que hace.
- Ahí mismo salen las opciones "Duplicar" (hace una copia) y "Eliminar" (lo quita).
- Si te equivocas de orden, elimina el bloque y agrégalo otra vez en el lugar correcto.
- Para probar, toca "Probar" o JUGAR.
###Variables | Cajitas que guardan números o palabras.
- Una variable es como una caja con nombre. Por ejemplo "puntos" guarda tu puntaje.
- En el editor de fórmulas toca "+ Crear variable nueva" y ponle nombre.
- Usa el bloque "Establezca una variable en" para darle un valor al inicio, por ejemplo 0.
  @blocks|e:Cuando empieza el programa;d:Establezca una variable puntos en 0|1
- Usa "Incrementar la variable" para sumar. Por ejemplo +1 cada vez que tocas una moneda.
- "Mostrar la variable" la pinta en la pantalla.
- Variables especiales: vida, escudo, municion, reserva, puntos, tiempo y objetivo. El HUD las usa.
###Mensajes entre objetos | Para que un objeto le avise a otro.
- Con "Difundir mensaje" un objeto grita una palabra, por ejemplo "abrir".
- En otro objeto pon "Cuando recibo abrir". Todo lo que esté debajo se hará.
  @blocks|e:Cuando recibo abrir;m:Incrementar Y en 3|0
- "Envía y espera" hace que el primero espere a que los demás terminen.
###Condiciones: si pasa, entonces | Para decidir.
- Usa "Si ... es verdadero entonces" de la categoría Control.
- En el hueco pon una comparación, por ejemplo vida < 20.
- Debajo pon lo que pasa. "De lo contrario" es para cuando no pasa.
  @blocks|c:Si vida < 20 es verdadero entonces;a:Decir ¡Cuidado!;c:De lo contrario;a:Decir Todo bien;c:Fin del si|0
- Cierra siempre con "Fin del si".
###Repetir cosas | Para no poner el mismo bloque muchas veces.
- "Repetir 10 veces" hace 10 veces lo que tiene dentro.
- "Para siempre" lo hace sin parar mientras juegas.
- "Mientras ... sea verdadero" repite hasta que deje de cumplirse.
- "Espera 1 segundos" hace una pausa.
- Cierra con "Fin del bucle".
  @blocks|c:Para siempre;m:Mover 2 pasos;c:Espera 1 segundos;c:Fin del bucle|0
##Ejemplos listos
###Moneda que suma puntos | Tocas o te acercas y ganas.
- Añade un Item (Añadir > Item) y llámalo "Moneda".
- En Scripts pon "Cuando se interactúe" (o "Cuando el jugador se acerque").
- Debajo pon "Incrementar la variable puntos en 1".
- Después "Iniciar sonido" con un sonido de moneda.
- Por último "Eliminar este objeto" para que desaparezca.
  @blocks|f:Cuando el jugador se acerque;d:Incrementar la variable puntos en 1;s:Iniciar sonido moneda;f:Eliminar este objeto|0
###Puerta con llave | Se abre solo si tienes la llave.
- Crea una variable "llave" y empiézala en 0.
- En la llave: "Cuando el jugador se acerque", pon la variable llave en 1 y "Eliminar este objeto".
- En la puerta: "Cuando se interactúe", "Si llave = 1 entonces", y debajo "Incrementar Y en 3" para subir la puerta.
- Con "De lo contrario" usa "Decir Necesitas la llave".
###Enemigo que te quita vida | Un trampa.
- Pon un objeto y ábrelo.
- "Cuando el jugador se acerque", "Quitar 10 de vida al jugador".
- Para que no te quite vida sin parar, pon "Espera 1 segundos" y repite con "Para siempre".
- La vida del jugador empieza en 100. La barra de vida del HUD baja sola.
###Cambiar de nivel | Pasar a otra escena.
- Crea otra escena con el botón de agregar en la lista de escenas.
- En un objeto (por ejemplo una puerta) pon "Cuando se interactúe".
- Debajo pon "Iniciar escena" y escribe el nombre de la otra escena.
- También puedes usar "Fin de nivel" desde Añadir > Objetos de juego.
###Marcador de puntos y reloj | Ver cuánto llevas.
- En Botones y arma activa "Pantalla del juego (HUD) lista para usar".
- Marca "Puntos" y "Reloj".
- Los puntos usan la variable "puntos". Suma con "Incrementar la variable puntos".
- El reloj cuenta solo hacia arriba en segundos.
#Animación
##Animar un modelo
###Qué es una animación | Hacer que algo camine o ataque.
- Un modelo 3D es como un muñeco de plástico: no se mueve solo.
- Le ponemos un esqueleto: puntos y palitos como los huesos.
- Movemos los huesos en poses (firme, pie izquierdo adelante...).
- El juego junta las poses y el muñeco camina.
  @skel|1
###Abrir el editor de animación | Aquí empieza todo.
- Abre el menú del proyecto y toca "Archivos (imágenes, sonidos, modelos)".
- Entra a la parte de Animaciones y toca "+ Nueva animación".
- También puedes entrar desde las Propiedades de un enemigo o del jugador, en "Animación con esqueleto".
- Se abre la ventana "Editor de animación" a pantalla completa. Tiene tres pestañas: Esqueleto, Poses y Animar.
  @tabs|Esqueleto;Poses;Animar|0
###Crear el esqueleto | Pestaña Esqueleto.
- Elige el modelo en "Modelo".
- Toca "Tipo FRENTE" si tu modelo está de frente con los brazos abiertos, o "Tipo LADO" si lo ves de lado. Se pone un esqueleto humano automático.
  @skel|0
- Ajusta: arrastra cada círculo blanco hasta su lugar (cabeza, manos, pies).
- Para más puntos, toca "Dibujar puntos y palos" y toca el lienzo.
- Con los botones Frente y Lado cambias la vista. "Cambiar ejes" e "Invertir" giran el modelo si se ve mal.
- Pellizca con dos dedos para acercar y alejar. Con un dedo en vacío mueves la vista.
###Hacer poses | Pestaña Poses.
- Toca la pestaña "Poses".
- Crea una pose y ponle nombre, por ejemplo "paso1".
- Arrastra un círculo del esqueleto para mover ese hueso. El modelo se dobla con él.
- Haz otra pose, "paso2", con la pierna contraria adelante.
- Guarda con "Guardar".
  @skel|1
###Armar la animación | Pestaña Animar.
- Toca "Animar" y luego "+ Nueva animación". Ponle nombre, por ejemplo "caminar".
- Agrega las poses en orden: paso1, paso2, paso1...
- Elige cuánto dura cada pose. Activa que se repita (ciclo) si es caminar.
- Toca reproducir para verla.
- Cuando te guste, toca "Guardar y cerrar".
###Poner la animación al enemigo o al jugador | Para que camine de verdad.
- Selecciona el enemigo o al Jugador y abre Propiedades.
- Busca "Animación con esqueleto".
- Elige el archivo de animación y luego, para cada estado, la animación que quieres: quieto, caminar, atacar, daño.
- Toca JUGAR. Al caminar debe mover los pies. En primera persona no ves tu cuerpo; usa cámara al hombro para verlo.
###Girar una animación | Si el modelo se mueve de lado o al revés.
- En la pestaña Animar busca "Dirección de la animación".
- Toca "Girar esta 90°" si sale de lado, o 180° si va al revés.
- "Girar TODAS" lo hace con todas las animaciones.
- Además puedes tocar "Cambiar ejes" o "Invertir" en la vista.

)HLP",
R"HLP(
##Animaciones de archivos
###Importar animaciones (Mixamo y más) | Archivos .fbx, .glb y .gltf.
- En el editor de animación, en la pestaña Animar, toca "Importar animaciones de un archivo...".
- Elige el archivo .fbx, .glb o .gltf. Sirven también los que no traen modelo ("sin piel").
- Si tu modelo ya tiene esqueleto, se unen los huesos por nombre: Hips con cadera, LeftArm con hombro_i, etc.
- Si no tiene esqueleto, se crea uno nuevo. Acomódalo en la pestaña Esqueleto.
- Si la animación sale de lado, mira la guía "Girar una animación".
###Animaciones que ya vienen | Sin hacer nada.
- Al crear un esqueleto humano automático ya hay animaciones listas: quieto, caminar, atacar, agachado, correr, apuntar, lanzar y cubrirse.
- Búscalas en la lista de la pestaña Animar.
###Animación con bloques | Moverlas desde un script.
- Usa "Reproducir animación de esqueleto" y escribe su nombre.
- "Detener animación de esqueleto" la para.
- Para cambiar la imagen de un objeto 2D usa "Cambiar apariencia a" o "Próxima apariencia".
#Sonido y música
###Importar sonidos | Tus propios audios.
- En la pantalla de un objeto entra a la pestaña Sonidos.
  @tabs|Scripts;Apariencias;Sonidos;Animaciones;Videos|2
- Toca "Importar sonido..." y elige un archivo mp3, wav u otro.
- Para usarlo, pon el bloque "Iniciar sonido" y elige su nombre.
- "Parar todos los sonidos" los calla.
- "Reproducir sonido o música y esperar a que termine" detiene los bloques hasta que acabe.
###Sonidos del juego | Pasos, salto, disparo.
- El juego ya trae sonidos de pasos, salto, aterrizaje, disparo, recarga, golpe, daño y explosión.
- Para cambiarlos, entra a Botones y arma o Mundo y busca "Sonidos del juego".
- Elige otro sonido de tus archivos para cada uno.
###Estudio de música y efectos | Crea tu música.
- Abre el menú del proyecto y toca "Estudio de música y efectos".
- Verás una cuadrícula. Elige el "Pincel de notas" y toca las casillas para poner notas.
- Toca reproducir para oírla. Haz bucles para que se repita.
- Guárdala. Aparece en tus sonidos para usarla con "Música en bucle".
###Música de fondo | Que suene siempre.
- Importa una música.
- En un objeto pon "Cuando empieza el programa".
- Debajo el bloque "Música en bucle" con el nombre de la música.
#Modelos e imágenes
###Importar un modelo 3D | Coches, personajes y casas.
- Abre "Archivos" y toca "Importar desde archivos...".
  @menu|Ventanas|Objetos;Propiedades;Mundo (cielo y luz);Botones y arma;Archivos|Archivos
- Elige un archivo .glb, .gltf, .fbx u .obj. También sirve un .zip que contenga uno (aunque tenga otro .zip adentro).
- Espera la pantalla de carga con su porcentaje. Los modelos grandes tardan.
- Para ponerlo en el mundo toca Añadir > "Modelo 3D..." y elige el tuyo.
- Si es un .blend, exporta primero a .glb desde Blender.
###Importar imágenes | Dibujos y texturas.
- Abre "Archivos" y toca "Importar desde archivos...".
- Elige imágenes png o jpg.
- En cualquier selector de imagen ahora aparecerá con su dibujito.
- Úsala como textura de un objeto, apariencia, fondo o arma.
###Editor de texturas | Dibuja tú mismo.
- Abre "Archivos" y la parte de imágenes.
- Elige "Dibujar textura" (editor grande con pestaña).
- Pinta con colores y pinceles, guarda y úsala en tus objetos.
###Importar un juego de Pocket Code | Trae tus juegos viejos.
- En el Inicio toca el mosaico "Importar proyecto (.pack, .zip, .rar)".
- Elige tu archivo .catrobat, .zip o .rar.
- Se crean las escenas con sus objetos y bloques.
- Si algo no se ve igual, revisa los tamaños. Las posiciones y movimientos ya se escalan solos.
#Efectos y gráficos
###Pantalla del juego (HUD) | Barras, mapa y brújula de juego profesional.
- Abre Ventanas > "Botones y arma".
- Busca "Pantalla del juego (HUD) lista para usar" y activa la casilla.
- Toca un estilo rápido: Disparos, Mundo abierto, Carreras o Aventura / terror.
  @hud|health;shield;ammo;slots;minimap
- O marca cada cosa: Barra de vida, escudo, munición, armas, minimapa, brújula, velocímetro, reloj, puntos, objetivo.
- Elige la mira (punto, cruz, círculo, cruz con hueco) y el estilo de color (Cine, Noche, Frío, Atardecer, Retro).
- El velocímetro es para el modo vehículo. El minimapa muestra enemigos rojos y objetos amarillos.
###Luz bonita y sombras | Que se vea mejor.
- En la ventana del Mundo baja a "Iluminación global y gráficos pro".
- Activa "Luz rebotada, oclusión y colores de cine" y sube o baja la intensidad.
- Las sombras salen de cada objeto. Las partes transparentes no hacen sombra.
- "Modo RTX" agrega reflejos y sombras suaves, pero pide más al teléfono.
###Desenfoque de movimiento | Cuando giras rápido.
- En la ventana del Mundo busca "Desenfoque de movimiento".
- Activa la casilla "Desenfocar la vista al mover la cámara".
- Ajusta la cantidad. Solo se ve al jugar.
###Partículas, humo y fuego | Efectos de cosas que salen.
- Selecciona el objeto y en Propiedades busca "Partículas (humo, fuego...)".
- Elige el tipo, el color y cuántas salen.
- Con el bloque "Lanzar partículas de golpe" las sueltas desde un script.
###Cámara con efecto de video | Aspecto de grabación.
- Abre Ventanas > "Mundo (cielo y luz)" y busca "Capa de la cámara (efectos e imágenes fijas)".
- Elige un efecto, por ejemplo VHS.
- Con "+ Añadir imagen fija" pones una imagen sobre la pantalla, como una mirilla o marco.
- También hay un bloque "Efecto de pantalla" para activarlo en un momento.
###Calidad para teléfonos lentos | Que no se trabe.
- Busca "Calidad general" y elige una más baja si va lento.
- Baja el desenfoque, el RTX y la luz global.
- Usa modelos con menos triángulos. Un coche de 90 mil triángulos pesa mucho.
#Física
###Física fácil | Que las cosas caigan y rueden.
- Selecciona un objeto y abre Propiedades > "Física".
- Activa la física dinámica. Ahora cae, rueda y choca.
- Puedes cambiar la masa, el rebote y la fricción.
- Si quieres que no se pueda empujar, desmarca la casilla de empujar.
###Explosiones y empujones | Con bloques.
- "Dar un empujón X, Y, Z" lanza el objeto en esa dirección.
- "Explosión de fuerza: radio y potencia" empuja a todos los objetos cercanos.
- "Resistencia del aire" y "Gravedad de este objeto" cambian cómo cae.
###Abollar y romper | Daños que se ven.
- Para romper, usa el bloque "Romper en N pedazos y desaparecer".
- Para abollar un modelo, activa la opción "Deformar" en sus Propiedades y elige cuánto.
- Los disparos y choques dejan marcas en la forma.
###Congelar el mundo | Para pausas y sustos.
- "Congelar todo menos al jugador" detiene a los enemigos y objetos.
- "Descongelar todo" los suelta.
- "Congelar al jugador" deja quieto al jugador mientras todo lo demás se mueve.
#Probar y exportar
###Probar tu juego | Siempre prueba antes de seguir.
- En el editor 3D toca JUGAR.
  @bar|JUGAR
- En las pantallas de escena y de objeto toca "Jugar" o "Probar".
- Para salir del juego usa el botón de salir o atrás.
- Prueba seguido: es más fácil arreglar un error chico que muchos juntos.
###Exportar un APK | Para instalarlo en tu teléfono.
- Abre el menú del proyecto y elige "Exportar juego (APK, EXE, paquete)...".
  @menu|Proyecto|Guardar;Ayuda: guías paso a paso;Exportar juego (APK, EXE, paquete)...;Cerrar proyecto|Exportar juego (APK, EXE, paquete)...
- Escribe el nombre del juego y el paquete (por ejemplo com.tunombre.mijuego).
- Elige un icono si quieres.
- Toca exportar y espera. El archivo APK queda listo para instalar.
- También puedes exportar un .exe para Windows o solo los archivos.
###Compartir tu proyecto | Un archivo .pack.
- Exporta como paquete (.pack) desde el mismo menú.
- Pasa el archivo a un amigo. Él lo abre con "Importar" en el Inicio.
###Si tu juego se cierra o se ve raro | Problemas comunes.
- Se ve oscuro: sube la luz en la ventana del Mundo.
- Se ve muy lento: baja la calidad, apaga RTX y usa modelos más ligeros.
- Un modelo sale muy grande o chico: cámbialo en "Tamaño y giro".
- Un objeto no se mueve: mira si está bloqueado y si el bloque Evento es el correcto.
- La animación sale de lado: mira la guía "Girar una animación".
- No pasa nada al tocar: revisa que tenga el evento "Cuando pulse" o "Cuando se interactúe".
- No compila en GitHub: manda las líneas que digan "error".
#Novedades v10.7: peleas, runner, ambiente y multijugador
###Hacer que el personaje apunte solo al enemigo | Fijar al enemigo al atacar.
- Selecciona el Jugador y abre sus propiedades (doble toque).
- Busca "Fijar al enemigo (apuntar solo)".
- "Al atacar": al pulsar atacar, el personaje gira hacia el enemigo más cercano.
- "Siempre": siempre mira al enemigo (como en las peleas).
- "Distancia para fijar" dice qué tan lejos busca.
###Hacer una pelea de lado (2.5D) | Como Street Fighter o Mortal Kombat.
- Abre la plantilla "Peleas 3D" (3D) o "Peleas 2D" (dibujos).
- En 3D se activa "Vista lateral 2.5D": solo caminas a izquierda y derecha, y la palanca arriba salta.
- Activa "Barras de pelea arriba" en la pantalla del juego: vida tuya y del rival, nombres y reloj.
- El rival usa la variable vidaRival (la pone el juego sola).
###Hacer un corredor infinito (Subway Surfers) | Tres carriles, trenes y monedas.
- Abre la plantilla "Runner infinito".
- El personaje corre solo. Desliza el dedo a la izquierda o derecha para cambiar de carril, arriba para saltar y abajo para agacharte.
- En tu propio juego activa "Corredor infinito de 3 carriles" en las propiedades del Jugador.
- Con bloques puedes leer jugadorx, jugadory y jugadorz (dónde está el jugador) para poner obstáculos delante.
###Cambiar el ambiente con un toque | Terror, noche, atardecer, nieve...
- Abre la ventana del Mundo.
- Busca "Ambientes listos (un toque)" y toca uno.
- Cambia el cielo, la luz, la niebla, el clima y los efectos de pantalla. Después ajusta lo que quieras.
###Multijugador local sin internet | Varios teléfonos en el mismo Wi-Fi o hotspot.
- Todos instalan el mismo juego. Conecta los teléfonos a la misma red Wi-Fi, o a la zona wifi (hotspot) de uno de ellos. No hace falta internet.
- En los bloques busca la categoría "Multijugador".
- Pon "Activar multijugador local (automático)" bajo "Cuando empiece". Los jugadores se ven entre sí solos.
- Las variables jugadores (cuántos hay) y soyhost (1 si eres el anfitrión) se llenan solas.
- "Enviar el mensaje ... a todos" hace que en los demás se ejecute "Cuando reciba el mensaje ...".
- "Compartir la variable ..." copia esa variable a todos (puntos, quién ganó...).
- Para salas con nombre usa "Crear partida local" y "Unirse a la partida local" con el mismo nombre.
- Bluetooth y juego por internet no están incluidos todavía.


)HLP",
R"HLP(
#Novedades v10.8: teclas, resolución y movimiento
###Jugar con WASD en Windows | Teclado y mouse como cualquier juego.
- Al presionar Jugar en Windows: W A S D mueven, Espacio salta, Shift corre, Ctrl se agacha, R recarga, Q cambia de arma, E interactúa, F linterna y el clic izquierdo dispara.
- Para cambiarlas: Proyecto > Controles > "Teclas y mouse" > Cambiar, y presiona la nueva tecla.
- Restaurar vuelve a la tecla por defecto. El control (gamepad) se mapea solo en el juego de Windows.
- En Android sigue la palanca y los botones en pantalla.
###Ocultar botones virtuales | Solo Windows.
- En el test (Jugar) hay una casilla "Ocultar botones virtuales".
- Al exportar el .exe existe la opción "Ocultar botones virtuales" (apagada por defecto). En la exportación de Android no existe.
###Resolución del juego | De 550p hasta 8K.
- Proyecto > "Resolución del juego". Por defecto es 1080p.
- Solo se aplica al jugar y en el juego exportado; el editor no cambia, para ir fluido.
###Mover objetos con las bolitas (gizmo) | Subir, bajar y de lado.
- Selecciona un objeto 3D: salen flechas con bolita rojas (X), verdes (Y, arriba/abajo) y azules (Z). Arrastra una para mover solo en ese eje.
###Zoom con la rueda y barras de desplazamiento | Solo Windows.
- La rueda del mouse acerca y aleja en la vista del editor.
- Los menús con scroll muestran su barra lateral en Windows.
###Hacia dónde mira el Jugador
- En las propiedades del Jugador: gira hacia donde camina, mira al frente, mira al contrario de donde camina, o siempre mira atrás.
)HLP",
R"HLP(
#Novedades v10.9: interfaz, escenas 2.5D y peleas
###Barra superior nueva | Botones redondeados sobre la escena.
- Arriba a la izquierda: volver a la escena, el menú Proyecto (carpeta) y el nombre de la escena (toca para cambiar de escena).
- Arriba a la derecha: Añadir, Ventanas y el botón verde JUGAR.
###Crear una escena 2.5D | Mundo 3D visto de lado.
- Toca el nombre de la escena > "Nueva escena 2.5D (de lado)".
- El jugador solo camina a izquierda y derecha y salta (joystick arriba = saltar). La cámara mira de lado y sigue la acción.
- Sirve para peleas, plataformas y runners con modelos 3D.
###Peleas 3D | Caminar, acercarse y golpear.
- Con la plantilla "Peleas 3D" el personaje camina de lado hacia el rival y siempre lo mira.
- Los botones Puño y Patada sacan un puño visible y le quitan vida al rival si está cerca.
###Plantillas 2D corregidas
- Los dibujos y textos de las plantillas 2D salían girados 90 grados; ya salen derechos.
)HLP",
R"HLP(
#Novedades v10.9b: modelos nuevos y estudio de música
###Modelos nuevos de la biblioteca | Estructuras, vehículos, armas, soldados y plantas.
- Estructuras: bodega, casa de palafito, rascacielos, torre de reloj, contenedor, tuberías, tanque de gas, silo y casa rural.
- Vehículos: sedán, pickup, camión, autobús, bulldozer, excavadora, avión, caza y dron.
- Armas: lanzacohetes, ametralladora, pistola y rifle de energía.
- Personas: soldado táctico, SWAT, zombi gordo y zombi obrero.
- Naturaleza: pino, palmera, arbusto, roca y roble.
- Agrégalos con Añadir > Modelo 3D o desde Archivos > Biblioteca.
###Estudio de música | Más fácil de usar.
- Ahora se ven los 16 pasos de cada pista sin cambiar de página.
- Al escuchar, un marco blanco recorre los pasos que suenan. Si editas mientras suena, se actualiza solo.
- Efectos: ahora hay 24 (Power-up, Daño, Curar, Puerta, Teletransporte, Alarma, Robot, Agua, Rugido, Espada, Clic, Error, Victoria, Game over, Motor, Trueno y los de antes).
)HLP",
R"HLP(
#Nuevo diseño de la interfaz (v10.9c)
###Menú lateral derecho | Guardar, Ayuda, Archivos, Música, Botones y arma, Mundo, Exportar y Cerrar proyecto.
- En la lista de escenas y en la pantalla de una escena hay una pestaña « » al borde derecho: tócala para abrir o cerrar el menú.
###Pantalla de la escena | Pestañas verticales Mundo y Objetos.
- Mundo: el suelo, las luces y el cielo. Objetos: todo lo demás, cada fila con su imagen, su nombre y cuántos bloques tiene.
###Editor de animación | Tres columnas.
- Herramientas a la izquierda, la lista de animaciones en el centro y el lienzo con sus botones a la derecha. Arriba: « VOLVER A ESCENA y Cerrar x.
)HLP",
R"HLP(
#Guías nuevas: aprende cada función
##Propiedades del objeto
###Las 4 pestañas de Propiedades | Todo lo de un objeto está en 4 pestañas grandes, sin salir del panel.
- Toca un objeto y abre "Propiedades". Arriba verás 4 botones grandes: Mover, Aspecto, Choque y Acciones.
  @tabs|Mover;Aspecto;Choque;Acciones|0
- Mover: dónde está (X, Y, Z), qué tan grande es y hacia dónde mira. También "Visible al empezar" y "Bloqueado".
  @list|Mover|Posición;Tamaño y giro;Visible al empezar;Bloqueado|Posición
- Aspecto: color, textura, modelo 3D, reflejos, metálico, video y partículas (humo, fuego).
  @tabs|Mover;Aspecto;Choque;Acciones|1
- Choque: si es sólido, si tiene física (cae, rebota) y si se abolla con los golpes.
  @tabs|Mover;Aspecto;Choque;Acciones|2
- Acciones: lo que HACE el objeto: enemigo, animaciones, autos, controles del jugador y objeto en la mano.
  @tabs|Mover;Aspecto;Choque;Acciones|3
- Los cambios se ven al instante en la escena: no hace falta salir para comprobar.
###El gizmo (flechas para mover y estirar) | Las 3 flechas de colores mueven; los cuadritos estiran.
- Toca un objeto: salen 3 flechas. Roja = X (izquierda/derecha), verde = Y (arriba/abajo), azul = Z (adelante/atrás).
  @view|sel|move
- Arrastra una flecha para mover solo en esa dirección. Los cuadritos blancos más lejos estiran en esa dirección.
- Los aros de girar vienen apagados para que no gires sin querer. Para usarlos: Propiedades > Mover > "Mostrar aros para girar".
- Si el gizmo no sale, mira si arriba dice "MODO PINTAR ACTIVO": toca "Salir del modo pintar".
  @btn|Salir del modo pintar|b
##El mundo
###Pintar el suelo | Arena, pasto, roca o tu propia textura donde quieras.
- En Mundo busca "Pintar suelo" y crea una capa. Elige la textura (arena, pasto, roca, nieve, tierra o una imagen tuya).
- Activa "Pintar el suelo" y pasa el dedo. Solo pinta donde SÍ hay suelo o terreno con colisión, no en el vacío.
  @text|Pintar el suelo (un dedo pinta, dos dedos mueven la cámara)
- "Borrar" quita pintura. "Tamaño del lápiz" cambia el grosor.
- Si se pone lento, usa capas con menos pinceladas (cada capa aguanta 4000).
###Zona prohibida con pincel | Pinta de rojo por dónde NO se puede pasar.
- En Mundo > Límites toca "Dibujar zona prohibida". Se abre el mapa visto desde arriba.
  @btn|Dibujar zona prohibida|b
- Herramienta Pincel: desliza el dedo por donde no quieres que pasen. Se pinta de rojo. Es UN solo objeto, sin importar cuánto pintes.
- Borrador: desliza para quitar. Rectángulo, Círculo y Polígono rellenan figuras. Deshacer vuelve atrás.
- "Grosor" cambia el tamaño del pincel y del borrador. Dos dedos hacen zoom y mueven el mapa.
  @menu|Herramienta|Pincel;Rectángulo;Círculo;Polígono;Borrador|Pincel
- Vale para el jugador, los enemigos y los autos. El mapa llega hasta 256 metros a cada lado del centro.
###Trazado de rayos y rendimiento | Gráficos más bonitos en Windows y versión liviana en el teléfono.
- Abre Rendimiento (en el menú del proyecto).
- "Trazado de rayos" (Windows): sombras y texturas al máximo. Es una aproximación, no ray tracing de verdad.
- "Simulación liviana" (Android): sombras más nítidas sin gastar mucha batería.
- Más opciones: bajar detalle de modelos lejanos, resolución dinámica, modo ahorro de batería y precarga.
  @list|Rendimiento|LOD;Resolución dinámica;Ahorro de batería;Precarga;Trazado de rayos|Trazado de rayos
##El jugador
###Colisión: el modelo como es | El jugador choca con el tamaño real de su modelo.
- Un carro choca como carro y una persona como persona. La caja de choque sale del ancho, fondo y alto del modelo.
- Para cambiar el tamaño: Propiedades del jugador > Mover > Ancho, Alto y Fondo. Con "Adaptar la colisión al modelo" se ajusta sola.
- Ya no se ve el cuadro amarillo encima del jugador si tiene modelo o dibujo.
###Cámara en primera persona y altura | Ver desde los ojos del personaje.
- Jugador > Acciones: elige Primera persona. "Altura de la cámara" sube o baja los ojos.
- En el editor se ve una marca cian a la altura de los ojos.
- "Ver el cuerpo del modelo" muestra el cuerpo del jugador en primera persona.
- Al hombro, la cámara se aleja sola si el modelo es grande (un carro, un camión).
###Arma en la mano | Pon el modelo del arma pegado a la mano.
- Abre el panel del Arma y activa "Ponerla en la mano del modelo del jugador".
- Gira y mueve el arma con los números hasta que parezca sujetada. Puedes cambiarlo para cada animación.
- Lo mismo para NPC y enemigos: Propiedades > Acciones > "Objeto en la mano".
##Animaciones por acción
###La lista de acciones | Elige qué animación hace en cada momento.
- Propiedades > Acciones > Animaciones. Verás una lista: Quieto, Caminar, Disparar, Apuntar, Agacharse, Recargar, Morir y más.
  @list|Animaciones|Quieto;Caminar;Disparar;Agacharse;Recargar;Morir|Recargar
- Toca cada una y elige la animación del modelo. Si dejas una vacía, usa la parecida (agacharse usa caminar).
- Con sprites (dibujos) en vez de animación de esqueleto, cada acción lleva sus imágenes que se alternan.
###Acción personalizada y mensajes | Activa cualquier animación con un bloque.
- Pon la animación en "Acción personalizada" (o en cualquier otra).
- Usa el bloque "Reproducir animación" con el nombre de la acción: recargar, morir, personalizada...
  @blocks|e:Cuando reciba el mensaje saludar;a:Reproducir animación personalizada|0
- Para que otro objeto dispare tu animación: "Difundir mensaje" en uno y "Cuando reciba el mensaje" en el otro.
- El jugador cambia solo entre quieto, caminar, correr, saltar, agacharse, recargar, nadar y caminar de lado o hacia atrás.
##Explosiones
###Bombas y explosiones | Humo, fuego y chispas, o tus propios dibujos y modelos.
- En el menú del proyecto abre "Explosión". Elige: por defecto, imágenes tuyas (sprites) o un modelo 3D.
- Para una bomba: pon el bloque "Explosión" en el objeto. Se activa con cualquier evento (tocar, recibir mensaje, tiempo).
  @blocks|e:Cuando me toquen;a:Explosión|0
- Las granadas del arma también explotan con tu efecto.
- Los modelos 3D de explosión crecen, giran y se desvanecen. No reproducen animación de esqueleto.
##Plantillas
###Plantillas con menú y final | Todas empiezan con Menú y terminan en Victoria o Derrota.
- Abre una plantilla: la primera escena es el Menú con el botón JUGAR.
  @btn|JUGAR|g
- Cuando ganas o pierdes pasas a "Victoria" o "Derrota", con "Jugar de nuevo" y "Menú".
- Cambia los textos y colores de esas escenas como cualquier otra.
- "Asedio zombi": shooter nocturno. Elimina a todos los zombis y vence al jefe.
)HLP",
R"HLP(
#Más guías: autos, 2D, mundo y juego completo
##Autos y vehículos
###Hacer un auto que se maneja | El jugador se sube, maneja y se baja.
- Añade un modelo de carro (Añadir > Modelo 3D > Carros). Toca el carro y abre Propiedades > Acciones.
  @tabs|Mover;Aspecto;Choque;Acciones|3
- Activa "Modo auto: el jugador puede conducirlo". Ajusta Vida del auto, Velocidad máxima y la cámara (distancia y altura).
- Al jugar, acércate: sale el botón «Conducir». Dentro, los botones cambian a Izquierda, Derecha, Acelerar, Frenar y Bajar.
  @hud|jump;shoot;stick
- Si el auto se destruye, sigues a pie.
###Llantas que giran | Que las ruedas giren de verdad al avanzar.
- En el auto, toca "Crear llantas...". Se abre una ventana con vistas de lado, del otro lado, de frente y de arriba.
- Arrastra el círculo sobre cada llanta. Con los botones - y + (o escribiendo el número) ajustas posición, tamaño y radio.
- "Recortar" separa la llanta del carro para que gire al avanzar. Se rellena sola la parte negra de la banda.
- Si el modelo se ve de lado o al revés, usa "Orientar el modelo" (siguiente guía).
###Orientar el modelo | Cuando el carro va de lado o hacia atrás.
- En Propiedades > Acciones busca "Hacia dónde mira el modelo". Elige la dirección correcta.
- Con "Ajuste fino del frente (grados)" lo afinas.
- El frente del modelo debe apuntar hacia donde avanza. Pruébalo con JUGAR.
##Juegos 2D
###Crear mapa 2D | Arma un nivel con bloques y un personaje.
- En una escena 2D abre "Crear mapa 2D". Elige piezas (suelo, bloques, enemigos, monedas, meta) y tócalas en la cuadrícula.
- Cada pieza del mapa se puede mover con el dedo en el mismo panel de edición, y tiene casilla "Bloquear" para que no se mueva por error.
- Los botones - y + cambian los valores, o toca el número para escribirlo.
- Tipo de cámara: salto real (la pantalla solo se mueve de lado) o que la pantalla suba y baje con el salto.
- La meta termina el nivel: úsala para pasar a Victoria.
###Saltos en 2D: uno, doble, triple o propulsor | Elige cómo salta tu héroe.
- Toca el personaje 2D y abre Propiedades. Pon "Movimiento por controles virtuales" en "Plataforma (con física)".
- Elige "Tipo de salto": Un solo salto, Doble salto, Triple salto o Propulsor (mantén el botón para volar).
  @list|Tipo de salto|Un solo salto;Doble salto;Triple salto;Propulsor|Doble salto
- Con "Velocidad del control" decides qué tan rápido corre.
##Cielo, agua y límites
###Cielo, sol, luna y nubes | Día, noche, atardecer y planetas.
- En Mundo busca Cielo. Elige un diseño (degradado, nubes, estrellas, atardecer...) o pon tu propia imagen.
- Astro: sol nítido, sol con rayos, luna, luna creciente, Saturno, Marte, Júpiter, gigante roja o Tierra. "Tamaño del astro" lo agranda.
- Nubes: actuales, realistas, con tu imagen, cúmulos, tormenta, cirros, estratos, caricatura o atardecer.
- "Ambientación (color del mundo)" cambia el tono de toda la escena de un toque (terror, noche, atardecer, nieve).
###Mar y agua | Un océano con varios estilos.
- En Mundo > Mar / agua (opcional) activa el mar. Elige el estilo: anime, realista, oscuro, cristal, tropical o pantano.
- Ajusta la altura del agua, su color y su transparencia.
- Si el jugador se hunde en el agua, usa la animación "Nadar" de la lista de acciones.
###Límites del mapa | Que nadie se salga.
- En Mundo > Límites elige: Sin límite, Círculo (radio) o Cuadro. "Centrar donde empieza el jugador" lo centra.
- Para esquinas y lugares raros, usa la zona prohibida con pincel.
##Biblioteca de modelos
###Modelos por categorías | Personajes, árboles, casas, carros, armas y más.
- Toca el campo "Modelo" y en el selector abre la pestaña "Por defecto" (los modelos que vienen con el sistema). Arriba hay chips: Todos, Personajes, Árboles y vegetación, Rocas, Casas y estructuras, Carros, Muebles, Electrodomésticos, Comida y bebida, Armas...
  @menu|Categoría|Todos;Personajes;Árboles y vegetación;Casas y estructuras;Carros;Armas|Carros
- Toca una categoría y solo salen los modelos de ese tipo. Toca uno para usarlo.
- Los modelos de la biblioteca ya tienen colisión con su forma real.
##Un juego completo
###Inicio, juego y final | La estructura de cualquier juego.
- Escena 1 "Menú": un fondo y un botón JUGAR con el bloque "Cuando pulse" > "Iniciar escena" (la del juego).
  @blocks|e:Cuando pulse;a:Iniciar escena Juego|0
- Escena 2 "Juego": el nivel. Aquí van los enemigos, el mapa y los objetivos.
- Escenas "Victoria" y "Derrota": un mensaje y dos botones: Jugar de nuevo y Menú.
- Las plantillas ya traen esta estructura: ábrelas y copia lo que necesites.
###Ganar y perder | Dos reglas que casi todo juego necesita.
- Perder: un objeto vacío con "Cuando vida <= 0 se convierta en verdadero", y después "Iniciar escena Derrota".
  @blocks|e:Cuando vida <= 0 se convierta en verdadero;a:Iniciar escena Derrota|0
- Ganar: "Cuando puntos >= 80 se convierta en verdadero" (o la cantidad que quieras) y "Iniciar escena Victoria".
- Los enemigos que derrotas suman puntos solos (más los cuerpo a cuerpo). Los botiquines suben la variable vida.
- Para mostrar vida y puntos en pantalla usa "Mostrar la variable".
###Variables vida y puntos | Los números de tu juego.
- "vida" empieza en 100 y baja cuando te dañan. "puntos" empieza en 0.
- Usa "Incrementar la variable" para sumar o restar. "Establezca una variable" fija un valor.
- Las variables se muestran con el bloque "Mostrar la variable".
##Rendimiento
###Que tu juego no se trabe | Opciones para teléfonos y Windows.
- Abre Rendimiento. Activa "Modelos pesados más simples al alejarse" y "Resolución dinámica" (baja sola si los FPS caen).
- "Modo ahorro de batería": 30 FPS y resolución máxima 80 %. "Precargar" evita tirones al empezar.
- Usa pocas pinceladas de suelo, poca vegetación y modelos ligeros en mapas grandes.
- "Distancia de dibujado" de la escena también ayuda en mapas enormes.
)HLP",
};

const char* helpContentText() {
    static std::string all;
    if (all.empty()) for (const char* p : kParts) all += p;
    return all.c_str();
}

}  // namespace forge
