// Editor de texturas: se dibuja pixel por pixel y se guarda como imagen PNG del proyecto.
#include "editor.h"
#include "renderer.h"
#include "imgui.h"
#include "wrapui.h"
#include "misc/cpp/imgui_stdlib.h"
#include "stb_image.h"
#include "stb_image_write.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

static void pngOutP(void* ctx, void* data, int n) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + n);
}

void Editor::openPaint(const std::string& existing) {
    paintOpen_ = true;
    paintUndo_.clear();
    paintRedo_.clear();
    paintTool_ = 0;
    bool loaded = false;
    if (!existing.empty()) {
        auto a = edit_.proj.assets.find(existing);
        if (a != edit_.proj.assets.end()) {
            int w, h, c;
            stbi_set_flip_vertically_on_load(0);
            unsigned char* d = stbi_load_from_memory(a->second.data(), (int)a->second.size(), &w, &h, &c, 4);
            if (d) {
                if (w <= 256 && h <= 256) {
                    paintW_ = w; paintH_ = h;
                    paintPx_.assign(d, d + (size_t)w * h * 4);
                    // se guarda como una NUEVA textura (la importada original no se toca)
                    std::string base = existing;
                    size_t dp = base.find_last_of('.');
                    if (dp != std::string::npos) base = base.substr(0, dp);
                    std::string n = base + "_editada.png";
                    for (int i = 2; edit_.proj.assets.count(n); i++) n = base + "_editada" + std::to_string(i) + ".png";
                    paintName_ = n;
                    loaded = true;
                } else {
                    toast("Esa imagen es muy grande para dibujarla aquí (máximo 256x256)");
                }
                stbi_image_free(d);
            }
        }
    }
    if (!loaded) {
        paintW_ = paintH_ = paintNewSize_;
        paintPx_.assign((size_t)paintW_ * paintH_ * 4, 0);
        std::string base = "dibujo";
        std::string n = base + ".png";
        for (int i = 2; edit_.proj.assets.count(n); i++) n = base + std::to_string(i) + ".png";
        paintName_ = n;
    }
}

// Guarda el lienzo como PNG en los archivos del proyecto.
bool Editor::paintSave() {
    std::string n = paintName_;
    if (n.empty()) n = "dibujo.png";
    if (n.size() < 4 || n.substr(n.size() - 4) != ".png") n += ".png";
    std::vector<uint8_t> png;
    if (!stbi_write_png_to_func(pngOutP, &png, paintW_, paintH_, 4, paintPx_.data(), paintW_ * 4)) { toast("No se pudo guardar el dibujo"); return false; }
    edit_.proj.assets[n] = std::move(png);
    assetDirty_.insert(n);
    paintName_ = n;
    if (rend_) rend_->forget(n);  // para que se vea el cambio en todos lados
    markDirty();
    toast("Textura guardada: " + n);
    return true;
}

void Editor::paintWin() {
    if (!paintOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    if (!wrapui::Begin("Dibujar textura", &paintOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB |
                                                          kNoSW | ImGuiWindowFlags_NoSavedSettings)) { ImGui::End(); return; }
    bool wide = w_ >= h_;
    wrapui::CloseBar(&paintOpen_);
    // herramientas en un panel que se desliza con el dedo; el lienzo ocupa todo el resto
    wrapui::BeginChild("##ptools", wide ? ImVec2(fs * 15.5f, 0) : ImVec2(0, h_ * 0.30f), true, kNoSB);
    dragScroll();
    auto pushUndo = [&]() {
        paintUndo_.push_back(paintPx_);
        if (paintUndo_.size() > 30) paintUndo_.erase(paintUndo_.begin());
        paintRedo_.clear();
    };
    textInput("##pname", "Nombre del archivo", paintName_, "nombre.png");

    // herramientas: filas de botones iguales (no se cortan)
    float sp0 = ImGui::GetStyle().ItemSpacing.x, fw = ImGui::GetContentRegionAvail().x;
    float c4 = (fw - sp0 * 3.f) / 4.f, c3 = (fw - sp0 * 2.f) / 3.f, bh0 = fs * 2.3f;
    static const char* tools[4] = {"Lápiz", "Borrador", "Cubeta", "Gotero"};
    for (int i = 0; i < 4; i++) {
        if (i) ImGui::SameLine();
        bool sel = paintTool_ == i;
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.62f, 0.55f, 1.f));
        if (wrapui::Button(tools[i], ImVec2(c4, bh0)) && tapped()) paintTool_ = i;
        if (sel) ImGui::PopStyleColor();
    }
    if (wrapui::Button("Deshacer", ImVec2(c3, bh0)) && tapped() && !paintUndo_.empty()) { paintRedo_.push_back(paintPx_); paintPx_ = paintUndo_.back(); paintUndo_.pop_back(); }
    ImGui::SameLine();
    if (wrapui::Button("Rehacer", ImVec2(c3, bh0)) && tapped() && !paintRedo_.empty()) { paintUndo_.push_back(paintPx_); paintPx_ = paintRedo_.back(); paintRedo_.pop_back(); }
    ImGui::SameLine();
    if (wrapui::Button("Limpiar", ImVec2(c3, bh0)) && tapped()) { pushUndo(); std::fill(paintPx_.begin(), paintPx_.end(), 0); }
    ImGui::SetNextItemWidth(fs * 8.f);
    wrapui::SliderInt("Grosor", &paintBrush_, 1, 8);
    wrapui::Checkbox("Simetría (espejo)", &paintSym_);

    // color: la primera casilla es "transparente" (sin color)
    wrapui::ColorEdit4("Color", paintCol_, ImGuiColorEditFlags_AlphaBar | ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_AlphaPreview);
    static const float pal[16][3] = {{0, 0, 0}, {1, 1, 1}, {0.5f, 0.5f, 0.5f}, {0.8f, 0.1f, 0.1f}, {1, 0.5f, 0.1f}, {1, 0.9f, 0.2f}, {0.2f, 0.7f, 0.2f}, {0.1f, 0.4f, 0.2f},
                                      {0.2f, 0.8f, 0.9f}, {0.2f, 0.4f, 0.9f}, {0.4f, 0.2f, 0.7f}, {0.9f, 0.4f, 0.8f}, {0.55f, 0.35f, 0.2f}, {0.8f, 0.65f, 0.45f}, {0.2f, 0.2f, 0.25f}, {0.85f, 0.85f, 0.9f}};
    if (wrapui::Button("Transparente", ImVec2(fw, bh0)) && tapped()) { paintCol_[3] = 0.f; }
    for (int i = 0; i < 16; i++) {
        ImGui::PushID(i);
        if (ImGui::ColorButton("##c", ImVec4(pal[i][0], pal[i][1], pal[i][2], 1.f), ImGuiColorEditFlags_NoTooltip, ImVec2(fs * 1.5f, fs * 1.5f))) {
            paintCol_[0] = pal[i][0]; paintCol_[1] = pal[i][1]; paintCol_[2] = pal[i][2]; paintCol_[3] = 1.f;
        }
        ImGui::PopID();
        if (i != 7 && i != 15) ImGui::SameLine();
    }

    // abrir una textura ya importada para modificarla (se guarda como una nueva)
    if (wrapui::Button("Abrir una textura importada", ImVec2(fw, bh0)) && tapped()) ImGui::OpenPopup("abrirtex");
    if (ImGui::BeginPopup("abrirtex")) {
        ImGui::TextWrapped("Elige una imagen. Lo que dibujes se guarda como una nueva; la original no cambia.");
        int shown = 0;
        for (auto& kv : edit_.proj.assets) {
            std::string low = kv.first;
            for (auto& ch : low) ch = (char)tolower((unsigned char)ch);
            auto ends2 = [&](const char* e) { size_t l = strlen(e); return low.size() > l && low.compare(low.size() - l, l, e) == 0; };
            if (!(ends2(".png") || ends2(".jpg") || ends2(".jpeg") || ends2(".bmp") || ends2(".tga"))) continue;
            shown++;
            if (wrapui::Button((kv.first.size() > 30 ? kv.first.substr(0, 28) + ".." : kv.first).c_str(), ImVec2(fs * 16.f, bh0)) && tapped()) { std::string pick = kv.first; ImGui::CloseCurrentPopup(); openPaint(pick); break; }
        }
        if (!shown) ImGui::TextDisabled("No hay imágenes importadas todavía.");
        ImGui::EndPopup();
    }

    // abajo: tamaño de lienzo nuevo, guardar
    if (wrapui::Button("Guardar textura", ImVec2(c3, bh0)) && tapped()) paintSave();
    ImGui::SameLine();
    if (wrapui::Button("Guardar y cerrar", ImVec2(c3, bh0)) && tapped() && paintSave()) paintOpen_ = false;
    ImGui::SameLine();
    if (wrapui::Button("Lienzo nuevo", ImVec2(c3, bh0)) && tapped()) ImGui::OpenPopup("nuevolienzo");
    if (ImGui::BeginPopup("nuevolienzo")) {
        ImGui::TextUnformatted("Tamaño del dibujo (píxeles):");
        for (int sz2 : {16, 32, 64, 128}) {
            if (wrapui::Button(std::to_string(sz2).c_str())) { paintNewSize_ = sz2; openPaint(""); ImGui::CloseCurrentPopup(); }
            ImGui::SameLine();
        }
        ImGui::NewLine();
        ImGui::EndPopup();
    }
    ImGui::EndChild();
    if (wide) ImGui::SameLine();

    // lienzo
    float avail = std::min(ImGui::GetContentRegionAvail().x, ImGui::GetContentRegionAvail().y - fs * 0.5f);
    float cell = std::max(2.f, std::floor(avail / std::max(paintW_, paintH_)));
    ImVec2 org = ImGui::GetCursorScreenPos(), sz(cell * paintW_, cell * paintH_);
    ImGui::InvisibleButton("##canvas", sz);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float chk = std::max(cell, 8.f);
    for (float y = 0; y < sz.y; y += chk)  // fondo de cuadros: lo transparente se ve
        for (float x = 0; x < sz.x; x += chk) {
            bool dark = (((int)(x / chk) + (int)(y / chk)) & 1) != 0;
            dl->AddRectFilled(ImVec2(org.x + x, org.y + y), ImVec2(org.x + std::min(sz.x, x + chk), org.y + std::min(sz.y, y + chk)),
                              dark ? IM_COL32(70, 74, 86, 255) : IM_COL32(100, 105, 120, 255));
        }
    for (int y = 0; y < paintH_; y++)
        for (int x = 0; x < paintW_; x++) {
            const uint8_t* p = &paintPx_[((size_t)y * paintW_ + x) * 4];
            if (!p[3]) continue;
            dl->AddRectFilled(ImVec2(org.x + x * cell, org.y + y * cell), ImVec2(org.x + (x + 1) * cell, org.y + (y + 1) * cell), IM_COL32(p[0], p[1], p[2], p[3]));
        }
    if (cell >= 6.f)
        for (int x = 0; x <= paintW_; x += (paintW_ > 32 ? 8 : 1)) dl->AddLine(ImVec2(org.x + x * cell, org.y), ImVec2(org.x + x * cell, org.y + sz.y), IM_COL32(0, 0, 0, 40));

    auto put = [&](int x, int y, bool erase) {
        for (int dy = 0; dy < paintBrush_; dy++)
            for (int dx = 0; dx < paintBrush_; dx++) {
                int xx = x + dx - paintBrush_ / 2, yy = y + dy - paintBrush_ / 2;
                for (int m = 0; m < (paintSym_ ? 2 : 1); m++) {
                    int px = m ? paintW_ - 1 - xx : xx;
                    if (px < 0 || yy < 0 || px >= paintW_ || yy >= paintH_) continue;
                    uint8_t* p = &paintPx_[((size_t)yy * paintW_ + px) * 4];
                    if (erase) { p[0] = p[1] = p[2] = p[3] = 0; }
                    else {
                        p[0] = (uint8_t)(paintCol_[0] * 255.f + 0.5f); p[1] = (uint8_t)(paintCol_[1] * 255.f + 0.5f);
                        p[2] = (uint8_t)(paintCol_[2] * 255.f + 0.5f); p[3] = (uint8_t)(paintCol_[3] * 255.f + 0.5f);
                    }
                }
            }
    };
    static int lx = -1, ly = -1;
    if (ImGui::IsItemActive()) {
        ImVec2 m = ImGui::GetIO().MousePos;
        int x = (int)std::floor((m.x - org.x) / cell), y = (int)std::floor((m.y - org.y) / cell);
        x = std::max(0, std::min(paintW_ - 1, x));
        y = std::max(0, std::min(paintH_ - 1, y));
        if (ImGui::IsMouseClicked(0)) { lx = ly = -1; if (paintTool_ != 3) pushUndo(); }
        if (paintTool_ == 0 || paintTool_ == 1) {
            int steps = lx < 0 ? 1 : std::max(std::abs(x - lx), std::abs(y - ly)) + 1;
            for (int s = 0; s < steps; s++) {  // une los puntos para que el trazo no quede roto
                int ix = lx < 0 ? x : lx + (x - lx) * s / std::max(1, steps - 1), iy = ly < 0 ? y : ly + (y - ly) * s / std::max(1, steps - 1);
                put(ix, iy, paintTool_ == 1);
            }
            lx = x; ly = y;
        } else if (paintTool_ == 3 && ImGui::IsMouseClicked(0)) {
            const uint8_t* p = &paintPx_[((size_t)y * paintW_ + x) * 4];
            for (int k = 0; k < 4; k++) paintCol_[k] = p[k] / 255.f;
            paintTool_ = 0;
        } else if (paintTool_ == 2 && ImGui::IsMouseClicked(0)) {  // cubeta: rellena la zona del mismo color
            uint8_t tgt[4], nw[4] = {(uint8_t)(paintCol_[0] * 255.f + 0.5f), (uint8_t)(paintCol_[1] * 255.f + 0.5f), (uint8_t)(paintCol_[2] * 255.f + 0.5f), (uint8_t)(paintCol_[3] * 255.f + 0.5f)};
            memcpy(tgt, &paintPx_[((size_t)y * paintW_ + x) * 4], 4);
            if (memcmp(tgt, nw, 4) != 0) {
                std::vector<std::pair<int, int>> st{{x, y}};
                while (!st.empty()) {
                    auto [cx, cy] = st.back();
                    st.pop_back();
                    if (cx < 0 || cy < 0 || cx >= paintW_ || cy >= paintH_) continue;
                    uint8_t* p = &paintPx_[((size_t)cy * paintW_ + cx) * 4];
                    if (memcmp(p, tgt, 4) != 0) continue;
                    memcpy(p, nw, 4);
                    st.push_back({cx + 1, cy}); st.push_back({cx - 1, cy}); st.push_back({cx, cy + 1}); st.push_back({cx, cy - 1});
                }
            }
        }
    } else {
        lx = ly = -1;
    }

    ImGui::End();
}

}  // namespace forge
