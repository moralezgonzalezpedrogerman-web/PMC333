// Ayuda dentro de la app: carpetas, subcarpetas y guías paso a paso con dibujos de dónde tocar.
#pragma once
#include <string>
#include <vector>
#include "imgui.h"

namespace forge {

struct HelpStep { std::string text, pic; };            // pic: dibujo ("tipo|dato|dato"), vacío = sin dibujo
struct HelpGuide { std::string title, intro; std::vector<HelpStep> steps; };
struct HelpFolder {
    std::string title;
    std::vector<HelpFolder> sub;
    std::vector<HelpGuide> guides;
};

const HelpFolder& helpRoot();   // se arma una sola vez a partir del texto de help_content.cpp
void helpDrawPic(ImDrawList* dl, ImVec2 org, ImVec2 size, const std::string& spec, float fs, double t);
const char* helpContentText();  // texto fuente (para pruebas)

}  // namespace forge
