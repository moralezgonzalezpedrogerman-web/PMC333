// «Crear mapa 2D»: un nivel largo (imagen o varios rectángulos) donde la cámara sigue al héroe y el héroe no sale del mapa.
#include "editor.h"
#include "renderer.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>

namespace forge {

namespace {
float gCx = 0.f, gCy = 0.f, gZoom = 0.2f;   // centro del mapa en pantalla y pixeles por unidad
int gTool = 0;                              // 0 mover/elegir, 1 poner el inicio
int gDrag = -1; bool gDragging = false, gMoved = false;
ImVec2 gLast, gPrev;
bool gFirst = true;
}

void Editor::openMap() {
    mapOpen_ = true; gFirst = true; gTool = 0; gDrag = -1;
}

bool Editor::mapWindow() {
    if (!mapOpen_ || !hasScene() || scene().is3d) { mapOpen_ = false; return false; }
    bool ch = false;
    Scene& S = scene();
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ds, ImGuiCond_Appearing);
    if (!ImGui::Begin("Crear mapa 2D", &mapOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) { ImGui::End(); return false; }
    const float fs = ImGui::GetFontSize();
    if (gFirst) {   // ajusta la vista a todo el mapa
        gFirst = false;
        float x0 = 1e9f, x1 = -1e9f, y0 = 1e9f, y1 = -1e9f; bool any = false;
        for (auto& o : S.objs) if (o.mapPart == 1) { any = true; x0 = std::min(x0, o.pos.x - o.scale.x * 0.5f); x1 = std::max(x1, o.pos.x + o.scale.x * 0.5f); y0 = std::min(y0, o.pos.y - o.scale.y * 0.5f); y1 = std::max(y1, o.pos.y + o.scale.y * 0.5f); }
        if (!any) { x0 = -600; x1 = 600; y0 = -400; y1 = 400; }
        gCx = (x0 + x1) * 0.5f; gCy = (y0 + y1) * 0.5f;
        gZoom = std::min(ds.x * 0.9f / std::max(100.f, x1 - x0), ds.y * 0.35f / std::max(100.f, y1 - y0));
    }
    ImGui::TextWrapped("Arma tu nivel: partes del mapa (imagen larga o varios rectángulos), objetos con colisión y la Meta. El héroe (objeto con «movimiento por controles virtuales») no sale del mapa y la pantalla lo sigue.");
    ch |= wrapui::Checkbox("Activar mapa: la pantalla sigue al personaje", &S.map2on);
    if (S.map2on) {
        static const char* jn[2] = {"Salto real (la pantalla solo se mueve de lado)", "La pantalla sube y baja con el salto (el personaje siempre al centro)"};
        if (ImGui::BeginCombo("Con física", jn[S.map2jump])) { for (int k = 0; k < 2; k++) if (ImGui::Selectable(jn[k], k == S.map2jump)) { S.map2jump = k; ch = true; } ImGui::EndCombo(); }
        ImGui::TextDisabled("Sin física, el personaje se mueve libre sin caer. Inicio: (%.0f, %.0f)", S.map2x, S.map2y);
    }
    {
        float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int per = aw > fs * 44.f ? 6 : 3; float bw = (aw - sp * (per - 1)) / per; int bi = 0;
        auto nb = [&](const char* t, bool on = false) { if (bi++ % per) ImGui::SameLine(); if (on) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.5f, 0.9f, 1.f)); bool r = wrapui::Button(t, ImVec2(bw, fs * 2.2f)); if (on) ImGui::PopStyleColor(); return r; };
        auto add = [&](int part) {
            addObject(Kind::Cube);
            if (Obj* o = selObj()) {
                o->mapPart = part; o->pos = V3{gCx, gCy, 0}; o->yaw = 90.f;
                if (part == 1) { o->scale = V3{1200, 600, 1}; o->layer = -50; o->solid = false; o->noColor = false; o->color[0] = 0.35f; o->color[1] = 0.45f; o->color[2] = 0.6f; o->name = uniqueName("ParteMapa"); }
                else { o->scale = V3{300, 60, 1}; o->solid = true; o->phys = Phys::Static; o->noColor = false; o->color[0] = 0.5f; o->color[1] = 0.33f; o->color[2] = 0.2f; o->name = uniqueName("Bloque"); }
            }
            ch = true;
        };
        if (nb("+ Parte del mapa")) add(1);
        if (nb("+ Objeto con colisión")) add(2);
        if (nb("+ Meta")) { addPreset(106); if (Obj* o = selObj()) { o->mapPart = 2; o->pos = V3{gCx, gCy, 0}; } ch = true; }
        if (nb("Poner inicio", gTool == 1)) gTool = gTool == 1 ? 0 : 1;
        if (nb("Ver todo")) gFirst = true;
        if (nb("Cerrar")) mapOpen_ = false;
    }
    Obj* so = (sel_ >= 0 && sel_ < (int)S.objs.size() && (S.objs[sel_].mapPart || S.objs[sel_].goal)) ? &S.objs[sel_] : nullptr;
    if (so) {
        ImGui::TextUnformatted(so->name.c_str());
        ImGui::SameLine();
        if (wrapui::Button("Borrar")) { S.objs.erase(S.objs.begin() + sel_); sel_ = -1; ch = true; so = nullptr; }
    }
    if (so) {
        ImGui::SameLine();
        if (wrapui::Button("Bloques / propiedades")) { int i = sel_; mapOpen_ = false; openObject(i); ImGui::End(); return ch; }
        ch |= ImGui::DragFloat("X", &so->pos.x, 5.f, -1e7f, 1e7f, "%.0f");
        ImGui::SameLine(); ch |= ImGui::DragFloat("Y", &so->pos.y, 5.f, -1e7f, 1e7f, "%.0f");
        ch |= ImGui::DragFloat("Ancho", &so->scale.x, 5.f, 1.f, 1e7f, "%.0f");
        ImGui::SameLine(); ch |= ImGui::DragFloat("Alto", &so->scale.y, 5.f, 1.f, 1e7f, "%.0f");
        ch |= assetCombo("Textura / imagen", so->tex, 0, "(sin imagen: color)");
        if (!so->tex.empty()) { so->noColor = false; }
        ch |= wrapui::ColorEdit3("Color", so->color);
        if (so->mapPart == 2 && !so->goal) ch |= wrapui::Checkbox("Con colisión (el héroe no lo atraviesa)", &so->solid);
    }
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(100.f, av.y - 4.f);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 c(org.x + av.x * 0.5f, org.y + av.y * 0.5f);
    auto toS = [&](float x, float y) { return ImVec2(c.x + (x - gCx) * gZoom, c.y - (y - gCy) * gZoom); };
    auto toW = [&](ImVec2 p) { return ImVec2(gCx + (p.x - c.x) / gZoom, gCy - (p.y - c.y) / gZoom); };
    dl->PushClipRect(org, ImVec2(org.x + av.x, org.y + av.y), true);
    dl->AddRectFilled(org, ImVec2(org.x + av.x, org.y + av.y), IM_COL32(24, 27, 36, 255));
    {   // cuadrícula cada 100 (o más si está lejos)
        float step = 100.f; while (step * gZoom < 18.f) step *= 5.f;
        ImVec2 w0 = toW(org), w1 = toW(ImVec2(org.x + av.x, org.y + av.y));
        for (float x = std::floor(w0.x / step) * step; x < w1.x; x += step) dl->AddLine(toS(x, w0.y), toS(x, w1.y), IM_COL32(255, 255, 255, 18));
        for (float y = std::floor(w1.y / step) * step; y < w0.y; y += step) dl->AddLine(toS(w0.x, y), toS(w1.x, y), IM_COL32(255, 255, 255, 18));
    }
    std::vector<int> order;
    for (int i = 0; i < (int)S.objs.size(); i++) if (S.objs[i].mapPart || S.objs[i].goal) order.push_back(i);
    std::stable_sort(order.begin(), order.end(), [&](int a, int b) { return S.objs[a].layer < S.objs[b].layer; });
    for (int i : order) {
        const Obj& q = S.objs[i];
        ImVec2 a = toS(q.pos.x - q.scale.x * 0.5f, q.pos.y + q.scale.y * 0.5f), b = toS(q.pos.x + q.scale.x * 0.5f, q.pos.y - q.scale.y * 0.5f);
        unsigned id = 0; int tw = 1, th = 1;
        if (rend_ && !q.tex.empty()) id = rend_->textureId(edit_, q.tex, &tw, &th);
        if (id) dl->AddImage((ImTextureID)(intptr_t)id, a, b, ImVec2(0, 1), ImVec2(1, 0));
        else dl->AddRectFilled(a, b, IM_COL32((int)(q.color[0] * 255), (int)(q.color[1] * 255), (int)(q.color[2] * 255), q.mapPart == 1 ? 255 : 220));
        dl->AddRect(a, b, i == sel_ ? IM_COL32(255, 220, 60, 255) : (q.mapPart == 1 ? IM_COL32(120, 200, 255, 255) : IM_COL32(255, 255, 255, 140)), 0.f, 0, i == sel_ ? 3.f : 1.5f);
        if (q.goal) dl->AddText(a, IM_COL32(255, 255, 255, 255), "META");
    }
    {   // inicio del nivel (posición del héroe y de la cámara)
        ImVec2 p = toS(S.map2x, S.map2y); float r = fs * 1.1f;
        dl->AddCircleFilled(p, r * 0.35f, IM_COL32(255, 80, 80, 255));
        dl->AddLine(ImVec2(p.x - r, p.y), ImVec2(p.x + r, p.y), IM_COL32(255, 80, 80, 255), 2.5f);
        dl->AddLine(ImVec2(p.x, p.y - r), ImVec2(p.x, p.y + r), IM_COL32(255, 80, 80, 255), 2.5f);
        dl->AddText(ImVec2(p.x + r, p.y - r), IM_COL32(255, 160, 160, 255), "Inicio");
        float hw = kView2DHeight * (ds.x / ds.y) * 0.5f, hh = kView2DHeight * 0.5f;   // lo que se ve en la pantalla del juego desde el inicio
        dl->AddRect(toS(S.map2x - hw, S.map2y + hh), toS(S.map2x + hw, S.map2y - hh), IM_COL32(255, 80, 80, 150), 0.f, 0, 1.5f);
    }
    dl->PopClipRect();
    ImGui::SetCursorScreenPos(org);
    ImGui::InvisibleButton("##mapcv", av);
    ImVec2 mp = ImGui::GetIO().MousePos;
    bool ok = std::isfinite(mp.x) && std::fabs(mp.x) < 1e6f && std::fabs(mp.y) < 1e6f;
    if (ImGui::IsItemActivated() && ok) {
        gDragging = true; gMoved = false; gLast = mp; gPrev = mp; gDrag = -1;
        ImVec2 w = toW(mp);
        for (int k = (int)order.size() - 1; k >= 0; k--) {   // el de más arriba
            const Obj& q = S.objs[order[k]];
            if (std::fabs(w.x - q.pos.x) <= q.scale.x * 0.5f && std::fabs(w.y - q.pos.y) <= q.scale.y * 0.5f) { gDrag = order[k]; break; }
        }
        if (gTool == 0 && gDrag >= 0) sel_ = gDrag;
    }
    if (ImGui::IsItemActive() && gDragging && ok) {
        ImVec2 d(mp.x - gPrev.x, mp.y - gPrev.y);
        if (std::fabs(mp.x - gLast.x) + std::fabs(mp.y - gLast.y) > 10.f) gMoved = true;
        if (gMoved && gTool == 0) {
            if (gDrag >= 0 && gDrag == sel_ && gDrag < (int)S.objs.size()) { S.objs[gDrag].pos.x += d.x / gZoom; S.objs[gDrag].pos.y -= d.y / gZoom; ch = true; }
            else { gCx -= d.x / gZoom; gCy += d.y / gZoom; }
        }
        gPrev = mp;
    }
    if (ImGui::IsItemDeactivated() && gDragging) {
        gDragging = false;
        if (!gMoved) {
            if (gTool == 1) { ImVec2 w = toW(gLast); S.map2x = std::round(w.x); S.map2y = std::round(w.y); S.map2on = true; gTool = 0; ch = true; }
            else if (gDrag < 0) sel_ = -1;
        }
    }
    // zoom con botones (acercar / alejar) sobre el mapa
    {
        ImGui::SetCursorScreenPos(ImVec2(org.x + 6, org.y + 6));
        if (wrapui::Button("+", ImVec2(fs * 2.4f, fs * 2.4f))) gZoom = std::min(4.f, gZoom * 1.35f);
        ImGui::SetCursorScreenPos(ImVec2(org.x + 6 + fs * 2.8f, org.y + 6));
        if (wrapui::Button("-", ImVec2(fs * 2.4f, fs * 2.4f))) gZoom = std::max(0.004f, gZoom / 1.35f);
    }
    if (ch) markDirty();
    ImGui::End();
    return ch;
}

}  // namespace forge
