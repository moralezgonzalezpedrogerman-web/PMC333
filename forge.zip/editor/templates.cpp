#include "templates.h"
#include "library.h"

namespace forge {

static Block B(Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
    Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
}
static Obj mk(Kind k, const char* name, V3 pos, V3 sc, float r, float g, float b, bool solid = true) {
    Obj o; o.kind = k; o.name = name; o.pos = pos; o.scale = sc; o.color[0] = r; o.color[1] = g; o.color[2] = b; o.solid = solid; return o;
}
static Obj model3(const char* name, const char* model, V3 pos, float size, float yaw = 0.f) {
    Obj o = mk(Kind::Model, name, pos, {size, size, size}, 1, 1, 1);
    o.model = model;
    o.yaw = yaw;
    o.pos.y = size * 0.5f + pos.y;
    return o;
}
static Obj enemy3(const char* name, const char* model, V3 pos, AiType t, float hp, float speed, float size = 1.9f) {
    Obj o = model3(name, model, pos, size);
    o.ai.type = t; o.ai.hp = hp; o.ai.speed = speed;
    return o;
}
static void texFloor(Obj& o, const char* tex) { o.tex = tex; o.texTile = true; }
static Scene base3(const char* nm, float size, float sky, const char* floorTex) {
    Scene s; s.name = nm;
    Obj fl = mk(Kind::Floor, "Suelo", {0, -0.1f, 0}, {size, 0.2f, size}, 1, 1, 1);
    if (floorTex) texFloor(fl, floorTex);
    Obj lt = mk(Kind::Light, "Luz", {0, 8, 0}, {size * 0.6f, 1, 1}, 1.f, 0.92f, 0.8f, false);
    s.objs = {fl, lt};
    s.start = {0, 0.05f, size * 0.4f};
    s.skyTop[0] = 0.25f * sky; s.skyTop[1] = 0.45f * sky; s.skyTop[2] = 0.8f * sky;
    return s;
}
static void walls(Scene& s, float h, float half, const char* tex) {
    const char* nm[4] = {"Pared N", "Pared S", "Pared E", "Pared O"};
    V3 pos[4] = {{0, h / 2, -half}, {0, h / 2, half}, {half, h / 2, 0}, {-half, h / 2, 0}};
    V3 sc[4] = {{half * 2, h, 0.5f}, {half * 2, h, 0.5f}, {0.5f, h, half * 2}, {0.5f, h, half * 2}};
    for (int i = 0; i < 4; i++) { Obj w = mk(Kind::Wall, nm[i], pos[i], sc[i], 1, 1, 1); texFloor(w, tex); s.objs.push_back(w); }
}
static Obj music(const char* snd) {
    Obj c = mk(Kind::Cube, "Música", {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
    c.noColor = true; c.visible = true;
    c.blocks = {B(Op::WhenStart), B(Op::Music, snd)};
    return c;
}
static Scene base2(const char* nm, float r, float g, float b) {
    Scene s; s.name = nm; s.is3d = false;
    Obj bg = mk(Kind::Cube, "Fondo", {0, 0, 0}, {1, 1, 1}, r, g, b, false);
    bg.bg = true;
    s.objs.push_back(bg);
    return s;
}
static Obj hero2(float x, float y, bool phys) {
    Obj o = mk(Kind::Cube, "Jugador", {x, y, 0}, {90, 90, 1}, 0.2f, 0.7f, 1.f);
    if (phys) o.phys = Phys::Dynamic;
    return o;
}
static Obj coin3(float x, float y, float z) {
    Obj o = model3("Moneda", "lib_moneda.fmdl", {x, y - 0.25f, z}, 0.7f);
    o.solid = false; o.spin = true;
    o.blocks = {B(Op::WhenInteract), B(Op::ChangeVar, "puntos", "1"), B(Op::Destroy)};
    return o;
}

static const TemplateInfo kInfo[] = {
    {"Shooter en primera persona (FPS)", "Arena con paredes y enemigos que disparan y atacan.", 0},
    {"Shooter 3D (cámara al hombro)", "Como un juego de disparos en tercera persona.", 1},
    {"Carreras", "Pista cerrada con muros, velocidad alta y cámara detrás.", 2},
    {"Plataformas 3D", "Plataformas flotantes y monedas para recoger.", 3},
    {"Plataformas 2D", "Corre y salta (controles táctiles y teclado).", 4},
    {"Shooter 2D arcade", "Nave que se mueve con cruceta y enemigos que patrullan.", 5},
    {"RPG de aventura", "Mundo abierto con personajes que hablan y monstruos.", 6},
    {"Hack and slash", "Espada y muchos enemigos cuerpo a cuerpo.", 7},
    {"Terror 2D estilo FNAF", "Oficina con puertas y un monstruo que acecha.", 8},
    {"Terror 3D estilo FNAF", "Pasillo oscuro con linterna y un monstruo lento.", 9},
};

int templateCount() { return (int)(sizeof(kInfo) / sizeof(kInfo[0])); }
const TemplateInfo& templateInfo(int id) { return kInfo[id < 0 ? 0 : id % templateCount()]; }

void buildTemplate(int id, Project& p) {
    p.globalVars = {"puntos"};
    Scene s;
    switch (id) {
    case 0: case 1: case 7: {
        s = base3("Nivel1", 40.f, 1.f, "lib_tex_concreto.png");
        walls(s, 4.f, 20.f, "lib_tex_ladrillo.png");
        for (int i = 0; i < 4; i++) s.objs.push_back(model3("Caja", i % 2 ? "lib_caja.fmdl" : "lib_barril.fmdl", {-8.f + i * 5.f, 0, -6.f}, 1.3f));
        s.objs.push_back(model3("Farola", "lib_farola.fmdl", {10, 0, 6}, 4.2f));
        int n = id == 7 ? 7 : 5;
        for (int i = 0; i < n; i++) {
            bool melee = (id == 7 || i % 2);
            s.objs.push_back(enemy3(melee ? (id == 7 ? "Zombi" : "Monstruo") : "Soldado enemigo", melee ? (id == 7 ? "lib_zombi.fmdl" : "lib_monstruo.fmdl") : "lib_soldado.fmdl",
                                    {-14.f + i * 5.f, 0, -14.f}, melee ? AiType::Melee : AiType::Shooter, id == 7 ? 4.f : 3.f, 2.2f, melee && id != 7 ? 2.6f : 1.9f));
        }
        s.objs.push_back(music(id == 7 ? "lib_musica_aventura.wav" : "lib_musica_accion.wav"));
        if (id == 0) { p.player.cam = kFirstPerson; p.weapon.model = "lib_pistola.fmdl"; }
        else { p.player.cam = kShoulder; p.player.shoulderDist = 3.2f; p.player.model = "lib_jugador.fmdl"; p.player.mscale = 1.9f; p.weapon.model = id == 7 ? "lib_espada.fmdl" : "lib_rifle.fmdl"; }
        if (id == 7) { p.weapon.type = 1; p.weapon.name = "Espada"; p.weapon.range = 2.5f; p.weapon.damage = 2.f; p.weapon.rate = 0.45f; }
        break; }
    case 2: {
        s = base3("Pista", 120.f, 1.f, "lib_tex_pasto.png");
        s.objs.push_back(mk(Kind::Floor, "Pista", {0, 0.02f, 0}, {100, 0.1f, 100}, 1, 1, 1));
        texFloor(s.objs.back(), "lib_tex_asfalto.png");
        walls(s, 1.2f, 50.f, "lib_tex_damero.png");
        Obj isla = mk(Kind::Wall, "Isla central", {0, 0.75f, 0}, {50, 1.5f, 30}, 1, 1, 1);
        texFloor(isla, "lib_tex_pasto.png");
        s.objs.push_back(isla);
        for (int i = 0; i < 6; i++) s.objs.push_back(model3("Árbol", "lib_arbol.fmdl", {-18.f + i * 7.f, 1.5f, i % 2 ? 6.f : -6.f}, 5.f));
        for (int i = 0; i < 4; i++) s.objs.push_back(model3("Barril", "lib_barril.fmdl", {-12.f + i * 8.f, 0, 40.f}, 1.2f));
        p.player.cam = kShoulder; p.player.speed = 16.f; p.player.shoulderDist = 8.f;
        p.player.model = "lib_carro.fmdl"; p.player.mscale = 4.2f; p.player.faceMove = true;
        Obj meta = mk(Kind::Cube, "Meta", {0, 0.1f, 40}, {12, 0.2f, 1.2f}, 1.f, 1.f, 1.f, false);
        texFloor(meta, "lib_tex_damero.png");
        meta.blocks = {B(Op::WhenNear), B(Op::Say, "", "'¡Vuelta completada!'")};
        s.objs.push_back(meta);
        s.objs.push_back(music("lib_musica_carrera.wav"));
        s.start = {0, 0.05f, 44};
        break; }
    case 3: {
        s = base3("Plataformas", 80.f, 1.f, "lib_tex_roca.png");
        for (int i = 0; i < 9; i++) {
            Obj pl = mk(Kind::Wall, "Plataforma", {(i % 3 - 1) * 4.f, 1.f + i * 1.3f, 24.f - i * 6.f}, {5, 0.5f, 5}, 1, 1, 1);
            texFloor(pl, i % 2 ? "lib_tex_madera.png" : "lib_tex_pasto.png");
            s.objs.push_back(pl);
            s.objs.push_back(coin3((i % 3 - 1) * 4.f, 2.6f + i * 1.3f, 24.f - i * 6.f));
        }
        s.objs.push_back(model3("Cofre final", "lib_cofre.fmdl", {0, 1.0f + 8 * 1.3f + 0.25f, 24.f - 8 * 6.f}, 1.2f));
        s.objs.push_back(music("lib_musica_aventura.wav"));
        p.player.cam = kShoulder; p.player.jump = 9.f; p.player.speed = 5.5f; p.player.model = "lib_jugador.fmdl"; p.player.mscale = 1.9f;
        s.start = {0, 0.05f, 30};
        break; }
    case 4: case 5: {
        bool plat = id == 4;
        s = base2("Nivel1", plat ? 0.45f : 0.05f, plat ? 0.7f : 0.06f, plat ? 0.95f : 0.18f);
        Obj hero = hero2(-300, plat ? -250 : -330, plat);
        hero.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen)};
        if (plat) {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "8"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-8"), B(Op::WhenButton, "A"), B(Op::SetForce, "", "0", "700")});
            s.objs.push_back(hero);
            Obj g = mk(Kind::Cube, "Suelo", {0, -420, 0}, {2400, 120, 1}, 1, 1, 1); g.tex = "lib_tex_pasto.png"; g.phys = Phys::Static; s.objs.push_back(g);
            for (int i = 0; i < 3; i++) { Obj pl = mk(Kind::Cube, "Plataforma", {-200.f + i * 260.f, -250.f + i * 110.f, 0}, {200, 36, 1}, 1, 1, 1); pl.tex = "lib_tex_madera.png"; pl.phys = Phys::Static; s.objs.push_back(pl); }
            p.ctl2d = 3;
        } else {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "10"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-10"), B(Op::WhenButton, "Arriba"), B(Op::ChangeY, "", "10"), B(Op::WhenButton, "Abajo"), B(Op::ChangeY, "", "-10")});
            s.objs.push_back(hero);
            for (int i = 0; i < 5; i++) {
                Obj e = mk(Kind::Cube, "Enemigo", {-400.f + i * 200.f, 300, 0}, {70, 70, 1}, 0.9f, 0.3f, 0.3f);
                e.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::Repeat, "", "40"), B(Op::ChangeX, "", i % 2 ? "6" : "-6"), B(Op::Wait, "", "0.02"), B(Op::LoopEnd), B(Op::ChangeY, "", "-30"), B(Op::LoopEnd)};
                s.objs.push_back(e);
            }
            p.ctl2d = 1;
        }
        s.objs.push_back(music(plat ? "lib_musica_aventura.wav" : "lib_musica_accion.wav"));
        break; }
    case 6: {
        s = base3("Aldea", 80.f, 1.f, "lib_tex_pasto.png");
        for (int i = 0; i < 4; i++) s.objs.push_back(model3("Casa", "lib_casa.fmdl", {-14.f + i * 9.f, 0, -10.f}, 6.5f));
        for (int i = 0; i < 8; i++) s.objs.push_back(model3("Árbol", "lib_arbol.fmdl", {-30.f + i * 8.f, 0, 22.f}, 5.f));
        Obj npc = model3("Aldeano", "lib_aldeano.fmdl", {3, 0, 4}, 1.9f);
        npc.blocks = {B(Op::WhenInteract), B(Op::Say, "", "'Hola viajero, cuidado con los monstruos del bosque.'")};
        s.objs.push_back(npc);
        s.objs.push_back(model3("Cofre", "lib_cofre.fmdl", {-6, 0, 6}, 1.1f));
        for (int i = 0; i < 3; i++) s.objs.push_back(enemy3("Monstruo", "lib_monstruo.fmdl", {-20.f + i * 6.f, 0, -28.f}, AiType::Melee, 3.f, 2.f, 2.6f));
        s.objs.push_back(music("lib_musica_aventura.wav"));
        p.player.cam = kShoulder; p.player.shoulderDist = 4.f; p.player.model = "lib_jugador.fmdl"; p.player.mscale = 1.9f;
        break; }
    case 8: {  // FNAF 2D: oficina oscura, dos puertas y un animatronico
        s = base2("Oficina", 0.06f, 0.07f, 0.1f);
        s.sfx.vignette = 0.9f; s.sfx.noise = 0.35f; s.sfx.scan = 0.4f; s.sfx.track = 0.3f;
        s.objs[0].tex = "lib_tex_papel_pared.png"; s.objs[0].noColor = false;
        p.globalVars = {"puertaI", "puertaD"};
        Obj ctl = mk(Kind::Cube, "Control", {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
        ctl.noColor = true;
        ctl.blocks = {B(Op::WhenStart), B(Op::SetVar, "puertaI", "0"), B(Op::SetVar, "puertaD", "0"), B(Op::Music, "lib_ambiente_terror.wav")};
        s.objs.push_back(ctl);
        Obj piso = mk(Kind::Cube, "Piso", {0, -420, 0}, {2400, 160, 1}, 1, 1, 1);
        piso.tex = "lib_tex_damero.png"; piso.layer = 1;
        s.objs.push_back(piso);
        for (int k = 0; k < 2; k++) {
            Obj d = mk(Kind::Cube, k ? "Puerta derecha" : "Puerta izquierda", {k ? 380.f : -380.f, 0, 0}, {170, 560, 1}, 1, 1, 1);
            d.tex = "lib_tex_metal.png"; d.layer = 3;
            const char* v = k ? "puertaD" : "puertaI";
            d.blocks = {B(Op::WhenTap), B(Op::SetVar, v, k ? "1 - puertaD" : "1 - puertaI"), B(Op::SetTransp, "", k ? "puertaD * 85" : "puertaI * 85")};
            s.objs.push_back(d);
        }
        Obj m = mk(Kind::Cube, "Animatrónico", {0, 60, 0}, {330, 400, 1}, 1, 1, 1);
        m.tex = "lib_spr_oso.png"; m.noColor = true; m.layer = 2; m.visible = false;
        m.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::Wait, "", "7"), B(Op::Show), B(Op::StartSound, "lib_susto.wav"), B(Op::Wait, "", "1.5"),
                    B(Op::If, "", "puertaI = 0"), B(Op::ShakeScreen, "", "1.5"), B(Op::Say, "", "'¡TE ATRAPÓ!'"), B(Op::Wait, "", "3"), B(Op::Else), B(Op::Say, "", "'Se fue...'"), B(Op::EndIf),
                    B(Op::Hide), B(Op::LoopEnd)};
        s.objs.push_back(m);
        Obj ojos = mk(Kind::Cube, "Ojos", {-380, 60, 0}, {120, 50, 1}, 1, 1, 1);
        ojos.tex = "lib_spr_ojos.png"; ojos.noColor = true; ojos.layer = 2;
        ojos.blocks = {B(Op::WhenStart), B(Op::Hide), B(Op::Forever), B(Op::Wait, "", "4"), B(Op::Show), B(Op::Wait, "", "0.4"), B(Op::Hide), B(Op::Wait, "", "0.15"), B(Op::Show), B(Op::Wait, "", "0.3"), B(Op::Hide), B(Op::LoopEnd)};
        s.objs.push_back(ojos);
        break; }
    case 9: default: {
        s = base3("Pizzería", 40.f, 0.05f, "lib_tex_damero.png");
        s.ambient = 0.07f; s.fog = 0.07f; s.atmo = 1; s.atmoAmt = 0.45f; s.atmoStyle = 1; s.fogMode = 1; s.shadowAmt = 1.4f;
        s.fogCol[0] = 0.04f; s.fogCol[1] = 0.05f; s.fogCol[2] = 0.07f;
        s.skyTop[0] = s.skyTop[1] = s.skyTop[2] = 0.02f; s.skyBot[0] = s.skyBot[1] = s.skyBot[2] = 0.03f;
        s.objs[1].color[0] = 0.5f; s.objs[1].color[1] = 0.5f; s.objs[1].color[2] = 0.75f;
        walls(s, 3.5f, 16.f, "lib_tex_papel_pared.png");
        for (int i = 0; i < 3; i++) s.objs.push_back(model3("Escritorio", "lib_escritorio.fmdl", {-8.f + i * 8.f, 0, -4.f}, 2.2f));
        s.objs.push_back(enemy3("Oso animatrónico", "lib_animatronico_oso.fmdl", {0, 0, -13}, AiType::Melee, 99.f, 1.2f, 3.0f));
        s.objs.push_back(enemy3("Conejo animatrónico", "lib_animatronico_conejo.fmdl", {-12, 0, -8}, AiType::Melee, 99.f, 0.9f, 3.0f));
        Obj fail = mk(Kind::Cube, "Luces", {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
        fail.noColor = true;
        fail.blocks = {B(Op::WhenStart), B(Op::Music, "lib_ambiente_terror.wav"), B(Op::Forever), B(Op::Wait, "", "9"), B(Op::ShakeScreen, "", "0.4"), B(Op::StartSound, "lib_rugido.wav"), B(Op::LoopEnd)};
        s.objs.push_back(fail);
        p.player.flashlight = true; p.player.flashOnStart = true; p.player.flashFlicker = true; p.player.flashRange = 28.f; p.player.flashInt = 2.2f;
        p.player.cam = kFirstPerson; p.player.speed = 3.2f; p.weapon.enabled = false;
        s.sfx.vignette = 0.6f; s.sfx.noise = 0.15f;
        s.start = {0, 0.05f, 13};
        break; }
    }
    p.scenes.push_back(s);
    // agrega a el proyecto todo lo que use de la biblioteca (modelos, texturas, sonidos)
    auto need = [&](const std::string& n) { if (n.compare(0, 4, "lib_") == 0) libraryAdd(n, p.assets); };
    need(p.player.model); need(p.weapon.model);
    for (auto& o : p.scenes[0].objs) {
        need(o.tex); need(o.model);
        for (auto& b : o.blocks) need(b.t);
    }
}

}  // namespace forge
