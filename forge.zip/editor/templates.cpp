#include "templates.h"

namespace forge {

static Block B(Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
    Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
}
static Obj mk(Kind k, const char* name, V3 pos, V3 sc, float r, float g, float b, bool solid = true) {
    Obj o; o.kind = k; o.name = name; o.pos = pos; o.scale = sc; o.color[0] = r; o.color[1] = g; o.color[2] = b; o.solid = solid; return o;
}
static Obj enemy3(const char* name, V3 pos, AiType t, float hp, float speed, float r, float g, float b) {
    Obj o = mk(Kind::Cube, name, pos, {0.9f, 1.8f, 0.9f}, r, g, b);
    o.ai.type = t; o.ai.hp = hp; o.ai.speed = speed;
    return o;
}
static Scene base3(const char* nm, float size, float sky) {
    Scene s; s.name = nm;
    Obj fl = mk(Kind::Floor, "Suelo", {0, -0.1f, 0}, {size, 0.2f, size}, 0.42f, 0.58f, 0.38f);
    Obj lt = mk(Kind::Light, "Luz", {0, 8, 0}, {size * 0.6f, 1, 1}, 1.f, 0.92f, 0.8f, false);
    s.objs = {fl, lt};
    s.start = {0, 0.05f, size * 0.4f};
    s.skyTop[0] = 0.25f * sky; s.skyTop[1] = 0.45f * sky; s.skyTop[2] = 0.8f * sky;
    return s;
}
static void walls(Scene& s, float h, float half, float r, float g, float b) {
    s.objs.push_back(mk(Kind::Wall, "Pared N", {0, h / 2, -half}, {half * 2, h, 0.5f}, r, g, b));
    s.objs.push_back(mk(Kind::Wall, "Pared S", {0, h / 2, half}, {half * 2, h, 0.5f}, r, g, b));
    s.objs.push_back(mk(Kind::Wall, "Pared E", {half, h / 2, 0}, {0.5f, h, half * 2}, r, g, b));
    s.objs.push_back(mk(Kind::Wall, "Pared O", {-half, h / 2, 0}, {0.5f, h, half * 2}, r, g, b));
}
static Scene base2(const char* nm, float r, float g, float b) {
    Scene s; s.name = nm; s.is3d = false;
    Obj bg = mk(Kind::Cube, "Fondo", {0, 0, 0}, {1, 1, 1}, r, g, b, false);
    bg.bg = true;
    s.objs.push_back(bg);
    return s;
}
static Obj hero2(float x, float y, bool phys) {
    Obj o = mk(Kind::Cube, "Jugador", {x, y, 0}, {90, 90, 1}, 0.2f, 0.7f, 1.f);
    if (phys) o.phys = Phys::Dynamic;
    return o;
}
static Obj coin3(float x, float y, float z) {
    Obj o = mk(Kind::Item, "Moneda", {x, y, z}, {0.5f, 0.5f, 0.5f}, 1.f, 0.85f, 0.2f, false);
    o.spin = true;
    o.blocks = {B(Op::WhenInteract), B(Op::ChangeVar, "puntos", "1"), B(Op::Destroy)};
    return o;
}

static const TemplateInfo kInfo[] = {
    {"Shooter en primera persona (FPS)", "Arena con paredes y enemigos que disparan y atacan.", 0},
    {"Shooter 3D (cámara al hombro)", "Como un juego de disparos en tercera persona.", 1},
    {"Carreras", "Pista cerrada con muros, velocidad alta y cámara detrás.", 2},
    {"Plataformas 3D", "Plataformas flotantes y monedas para recoger.", 3},
    {"Plataformas 2D", "Corre y salta (controles táctiles y teclado).", 4},
    {"Shooter 2D arcade", "Nave que se mueve con cruceta y enemigos que patrullan.", 5},
    {"RPG de aventura", "Mundo abierto con personajes que hablan y monstruos.", 6},
    {"Hack and slash", "Espada y muchos enemigos cuerpo a cuerpo.", 7},
    {"Terror 2D estilo FNAF", "Oficina con puertas y un monstruo que acecha.", 8},
    {"Terror 3D estilo FNAF", "Pasillo oscuro con linterna y un monstruo lento.", 9},
};

int templateCount() { return (int)(sizeof(kInfo) / sizeof(kInfo[0])); }
const TemplateInfo& templateInfo(int id) { return kInfo[id < 0 ? 0 : id % templateCount()]; }

void buildTemplate(int id, Project& p) {
    p.globalVars = {"puntos"};
    Scene s;
    switch (id) {
    case 0: case 1: case 7: {
        s = base3("Nivel1", 40.f, 1.f);
        walls(s, 4.f, 20.f, 0.55f, 0.55f, 0.6f);
        for (int i = 0; i < 4; i++) s.objs.push_back(mk(Kind::Cube, "Caja", {-8.f + i * 5.f, 0.6f, -6.f}, {1.2f, 1.2f, 1.2f}, 0.6f, 0.45f, 0.25f));
        int n = id == 7 ? 7 : 4;
        for (int i = 0; i < n; i++) {
            AiType t = (id == 7 || i % 2) ? AiType::Melee : AiType::Shooter;
            s.objs.push_back(enemy3(t == AiType::Melee ? "Monstruo" : "Soldado", {-14.f + i * 4.5f, 0.9f, -14.f}, t, id == 7 ? 4.f : 3.f, 2.2f, 0.8f, 0.25f, 0.25f));
        }
        if (id == 0) p.player.cam = kFirstPerson;
        else { p.player.cam = kShoulder; p.player.shoulderDist = 3.2f; }
        if (id == 7) { p.weapon.type = 1; p.weapon.name = "Espada"; p.weapon.range = 2.5f; p.weapon.damage = 2.f; p.weapon.rate = 0.45f; }
        break; }
    case 2: {
        s = base3("Pista", 120.f, 1.f);
        s.objs[0].color[0] = 0.25f; s.objs[0].color[1] = 0.27f; s.objs[0].color[2] = 0.3f;
        walls(s, 1.5f, 50.f, 0.9f, 0.2f, 0.2f);
        s.objs.push_back(mk(Kind::Wall, "Isla central", {0, 0.75f, 0}, {50, 1.5f, 30}, 0.35f, 0.6f, 0.3f));
        p.player.cam = kShoulder; p.player.speed = 16.f; p.player.shoulderDist = 5.5f;
        Obj meta = mk(Kind::Cube, "Meta", {0, 0.1f, 40}, {12, 0.2f, 1.2f}, 1.f, 1.f, 1.f, false);
        meta.blocks = {B(Op::WhenNear), B(Op::Say, "", "'¡Vuelta completada!'")};
        s.objs.push_back(meta);
        s.start = {0, 0.05f, 44};
        break; }
    case 3: {
        s = base3("Plataformas", 80.f, 1.f);
        s.objs[0].color[0] = 0.2f; s.objs[0].color[1] = 0.3f; s.objs[0].color[2] = 0.6f;
        for (int i = 0; i < 9; i++) {
            s.objs.push_back(mk(Kind::Wall, "Plataforma", {(i % 3 - 1) * 4.f, 1.f + i * 1.3f, 24.f - i * 6.f}, {5, 0.5f, 5}, 0.7f, 0.55f, 0.3f));
            s.objs.push_back(coin3((i % 3 - 1) * 4.f, 2.3f + i * 1.3f, 24.f - i * 6.f));
        }
        p.player.cam = kShoulder; p.player.jump = 9.f; p.player.speed = 5.5f;
        s.start = {0, 0.05f, 30};
        break; }
    case 4: case 5: {
        bool plat = id == 4;
        s = base2("Nivel1", plat ? 0.45f : 0.05f, plat ? 0.7f : 0.06f, plat ? 0.95f : 0.18f);
        Obj hero = hero2(-300, plat ? -250 : -330, plat);
        hero.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen)};
        if (plat) {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "8"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-8"), B(Op::WhenButton, "A"), B(Op::SetForce, "", "0", "700")});
            s.objs.push_back(hero);
            Obj g = mk(Kind::Cube, "Suelo", {0, -420, 0}, {2400, 120, 1}, 0.3f, 0.6f, 0.25f); g.phys = Phys::Static; s.objs.push_back(g);
            for (int i = 0; i < 3; i++) { Obj pl = mk(Kind::Cube, "Plataforma", {-200.f + i * 260.f, -250.f + i * 110.f, 0}, {200, 36, 1}, 0.6f, 0.4f, 0.2f); pl.phys = Phys::Static; s.objs.push_back(pl); }
            p.ctl2d = 3;
        } else {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "10"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-10"), B(Op::WhenButton, "Arriba"), B(Op::ChangeY, "", "10"), B(Op::WhenButton, "Abajo"), B(Op::ChangeY, "", "-10")});
            s.objs.push_back(hero);
            for (int i = 0; i < 5; i++) {
                Obj e = mk(Kind::Cube, "Enemigo", {-400.f + i * 200.f, 300, 0}, {70, 70, 1}, 0.9f, 0.3f, 0.3f);
                e.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::Repeat, "", "40"), B(Op::ChangeX, "", i % 2 ? "6" : "-6"), B(Op::Wait, "", "0.02"), B(Op::LoopEnd), B(Op::ChangeY, "", "-30"), B(Op::LoopEnd)};
                s.objs.push_back(e);
            }
            p.ctl2d = 1;
        }
        break; }
    case 6: {
        s = base3("Aldea", 80.f, 1.f);
        for (int i = 0; i < 4; i++) s.objs.push_back(mk(Kind::Cube, "Casa", {-14.f + i * 9.f, 2.f, -10.f}, {6, 4, 6}, 0.75f, 0.6f, 0.4f));
        Obj npc = mk(Kind::Cube, "Aldeano", {3, 0.9f, 4}, {0.9f, 1.8f, 0.9f}, 0.3f, 0.5f, 0.9f);
        npc.blocks = {B(Op::WhenInteract), B(Op::Say, "", "'Hola viajero, cuidado con los monstruos del bosque.'")};
        s.objs.push_back(npc);
        for (int i = 0; i < 3; i++) s.objs.push_back(enemy3("Monstruo", {-20.f + i * 6.f, 0.9f, -28.f}, AiType::Melee, 3.f, 2.f, 0.3f, 0.7f, 0.3f));
        p.player.cam = kShoulder; p.player.shoulderDist = 4.f;
        break; }
    case 8: {
        s = base2("Oficina", 0.06f, 0.07f, 0.1f);
        p.globalVars = {"puertaI", "puertaD"};
        Obj ctl = mk(Kind::Cube, "Control", {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
        ctl.noColor = true;
        ctl.blocks = {B(Op::WhenStart), B(Op::SetVar, "puertaI", "0"), B(Op::SetVar, "puertaD", "0"), B(Op::ShowVar, "puertaI", "-420", "440")};
        s.objs.push_back(ctl);
        for (int k = 0; k < 2; k++) {
            Obj d = mk(Kind::Cube, k ? "Puerta derecha" : "Puerta izquierda", {k ? 380.f : -380.f, 0, 0}, {160, 520, 1}, 0.3f, 0.3f, 0.35f);
            const char* v = k ? "puertaD" : "puertaI";
            d.blocks = {B(Op::WhenTap), B(Op::SetVar, v, k ? "1 - puertaD" : "1 - puertaI"), B(Op::SetTransp, "", k ? "puertaD * 70" : "puertaI * 70")};
            s.objs.push_back(d);
        }
        Obj m = mk(Kind::Cube, "Monstruo", {0, 100, 0}, {150, 220, 1}, 0.8f, 0.2f, 0.2f);
        m.layer = -1;
        m.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::Wait, "", "6"), B(Op::If, "", "puertaI = 0"), B(Op::ShakeScreen, "", "1.5"), B(Op::Say, "", "'¡TE ATRAPÓ!'"), B(Op::Else), B(Op::Say, "", "'Se fue...'"), B(Op::EndIf), B(Op::LoopEnd)};
        s.objs.push_back(m);
        break; }
    case 9: default: {
        s = base3("Pasillo", 40.f, 0.1f);
        s.ambient = 0.08f; s.fog = 0.06f; s.atmo = 1; s.atmoAmt = 0.4f; s.atmoStyle = 1; s.fogMode = 1;
        s.fogCol[0] = 0.05f; s.fogCol[1] = 0.06f; s.fogCol[2] = 0.08f;
        s.objs[1].color[0] = 0.25f; s.objs[1].color[1] = 0.25f; s.objs[1].color[2] = 0.35f;
        walls(s, 3.5f, 16.f, 0.3f, 0.3f, 0.34f);
        s.objs.push_back(enemy3("Monstruo", {0, 0.9f, -12}, AiType::Melee, 99.f, 1.1f, 0.5f, 0.1f, 0.1f));
        p.player.flashlight = true; p.player.flashOnStart = true; p.player.flashFlicker = true;
        p.player.cam = kFirstPerson; p.player.speed = 3.2f;
        s.start = {0, 0.05f, 13};
        break; }
    }
    p.scenes.push_back(s);
}

}  // namespace forge
