#include "templates.h"
#include "library.h"

namespace forge {

static Block B(Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
    Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
}
static Obj mk(Kind k, const char* name, V3 pos, V3 sc, float r, float g, float b, bool solid = true) {
    Obj o; o.kind = k; o.name = name; o.pos = pos; o.scale = sc; o.color[0] = r; o.color[1] = g; o.color[2] = b; o.solid = solid; return o;
}
static Obj model3(const char* name, const char* model, V3 pos, float size, float yaw = 0.f) {
    Obj o = mk(Kind::Model, name, pos, {size, size, size}, 1, 1, 1);
    o.model = model;
    o.yaw = yaw;
    o.pos.y = size * 0.5f + pos.y;
    return o;
}
static Obj model3h(const char* name, const char* model, V3 pos, float size, float hf, float yaw = 0.f) {
    Obj o = model3(name, model, {pos.x, 0, pos.z}, size, yaw);
    o.pos.y = size * hf * 0.5f + pos.y;
    return o;
}
static void playerObj(Scene& s, float size, float yawDeg = 0.f) {   // el cuerpo del jugador (tamaño uniforme: el modelo se ve con sus proporciones)
    Obj o = mk(Kind::Player, "Jugador", {s.start.x, s.start.y + 0.85f, s.start.z}, {size, size, size}, 0.2f, 1.f, 0.3f, false);
    o.yaw = yawDeg;
    s.objs.push_back(o);
}
static void hudBtn(Project& p, const char* label, float x, float y, float r, HudAct act, float cr, float cg, float cb) {
    HudBtn b; b.label = label; b.x = x; b.y = y; b.r = r; b.act = act; b.color[0] = cr; b.color[1] = cg; b.color[2] = cb;
    p.hud.push_back(b);
}
static Obj ctrl(const char* name, std::vector<Block> bl) {   // objeto invisible que solo tiene programación
    Obj c = mk(Kind::Cube, name, {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
    c.noColor = true;
    c.blocks = std::move(bl);
    return c;
}
static Obj enemy3(const char* name, const char* model, V3 pos, AiType t, float hp, float speed, float size = 1.9f) {
    Obj o = model3(name, model, pos, size);
    o.ai.type = t; o.ai.hp = hp; o.ai.speed = speed;
    return o;
}
static void texFloor(Obj& o, const char* tex) { o.tex = tex; o.texTile = true; }
static Scene base3(const char* nm, float size, float sky, const char* floorTex) {
    Scene s; s.name = nm;
    Obj fl = mk(Kind::Floor, "Suelo", {0, -0.1f, 0}, {size, 0.2f, size}, 1, 1, 1);
    if (floorTex) texFloor(fl, floorTex);
    Obj lt = mk(Kind::Light, "Luz", {0, 8, 0}, {size * 0.6f, 1, 1}, 1.f, 0.92f, 0.8f, false);
    s.objs = {fl, lt};
    s.start = {0, 0.05f, size * 0.4f};
    s.skyTop[0] = 0.25f * sky; s.skyTop[1] = 0.45f * sky; s.skyTop[2] = 0.8f * sky;
    return s;
}
static void walls(Scene& s, float h, float half, const char* tex) {
    const char* nm[4] = {"Pared N", "Pared S", "Pared E", "Pared O"};
    V3 pos[4] = {{0, h / 2, -half}, {0, h / 2, half}, {half, h / 2, 0}, {-half, h / 2, 0}};
    V3 sc[4] = {{half * 2, h, 0.5f}, {half * 2, h, 0.5f}, {0.5f, h, half * 2}, {0.5f, h, half * 2}};
    for (int i = 0; i < 4; i++) { Obj w = mk(Kind::Wall, nm[i], pos[i], sc[i], 1, 1, 1); texFloor(w, tex); s.objs.push_back(w); }
}
static Obj music(const char* snd) {
    Obj c = mk(Kind::Cube, "Música", {0, 0, 0}, {1, 1, 1}, 0, 0, 0, false);
    c.noColor = true; c.visible = true;
    c.blocks = {B(Op::WhenStart), B(Op::Music, snd)};
    return c;
}
static Scene base2(const char* nm, float r, float g, float b) {
    Scene s; s.name = nm; s.is3d = false;
    Obj bg = mk(Kind::Cube, "Fondo", {0, 0, 0}, {1, 1, 1}, r, g, b, false);
    bg.bg = true;
    s.objs.push_back(bg);
    return s;
}
static Obj hero2(float x, float y, bool phys) {
    Obj o = mk(Kind::Cube, "Jugador", {x, y, 0}, {90, 90, 1}, 0.2f, 0.7f, 1.f);
    if (phys) o.phys = Phys::Dynamic;
    return o;
}
static Obj coin3(float x, float y, float z) {
    Obj o = model3("Moneda", "lib_moneda.fmdl", {x, y - 0.25f, z}, 0.7f);
    o.solid = false; o.spin = true;
    o.blocks = {B(Op::WhenInteract), B(Op::ChangeVar, "puntos", "1"), B(Op::Destroy)};
    return o;
}


static const TemplateInfo kInfo[] = {
    {"Shooter en primera persona (FPS)", "Almacén con salas, coberturas, botiquines y enemigos que disparan.", 0},
    {"Shooter 3D (cámara al hombro)", "Base militar en tercera persona con soldados y monstruos.", 1},
    {"Carreras", "Circuito cerrado: botones izquierda, derecha, acelerar y frenar; vueltas y turbos.", 2},
    {"Plataformas 3D", "Plataformas flotantes, monedas y un cofre final.", 3},
    {"Plataformas 2D", "Corre y salta (controles táctiles y teclado).", 4},
    {"Shooter 2D arcade", "Nave que se mueve con cruceta y enemigos que patrullan.", 5},
    {"RPG de aventura", "Aldea, bosque y ruinas con espada, aldeanos, cofres y un jefe.", 6},
    {"Hack and slash", "Arena con espada y oleadas de zombis y esqueletos.", 7},
    {"Terror 2D estilo FNAF", "Oficina con puertas, 3 cámaras funcionales, energía, 6 AM y sustos.", 8},
    {"Terror 3D estilo FNAF", "Oficina 3D con puertas que se cierran, cámaras reales y sustos.", 9},
    {"Runner infinito (móvil)", "Toca la pantalla para saltar los obstáculos.", 10},
    {"Flappy (móvil)", "Toca para volar entre las tuberías.", 11},
    {"Atrapa frutas (móvil)", "Mueve la canasta y atrapa las frutas que caen.", 12},
    {"Clicker (móvil)", "Toca el botón, compra mejoras y consigue puntos solo.", 13},
    {"Peleas 3D", "Arena de combate con luchadores y un campeón.", 14},
};

int templateCount() { return (int)(sizeof(kInfo) / sizeof(kInfo[0])); }
const TemplateInfo& templateInfo(int id) { return kInfo[id < 0 ? 0 : id % templateCount()]; }

static const std::string kEnd = "";
static Obj pickup(const char* name, const char* model, V3 pos, const char* var, const char* amt, const char* msg, float size = 0.9f) {
    Obj o = model3(name, model, pos, size);
    o.solid = false; o.spin = true;
    o.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::ChangeVar, var, amt), B(Op::Say, "", msg), B(Op::StartSound, "lib_moneda.wav"), B(Op::Destroy)};
    return o;
}
static std::vector<Block> jumpscare(const char* sound = "lib_susto.wav") {   // el monstruo aparece frente a la cámara del jugador
    return {B(Op::FreezePlayer), B(Op::TeleportPlayer, "", "0", "0.05", "1.5"), B(Op::SetPlayerYaw, "", "0"), B(Op::PlaceAt3, "", "0", "1.5", "0.25"), B(Op::ShakeScreen, "", "2"),
            B(Op::StartSound, sound), B(Op::Wait, "", "2.5"), B(Op::Say, "", "'FIN DEL JUEGO'"), B(Op::Wait, "", "3"), B(Op::StartScene, "Oficina")};
}
static void wallSeg(Scene& s, float cx, float cz, float w, float d, float h, const char* tex) {
    Obj o = mk(Kind::Wall, "Pared", {cx, h / 2, cz}, {w, h, d}, 1, 1, 1);
    texFloor(o, tex);
    s.objs.push_back(o);
}
static void cuarto(Scene& s, float cx, float cz, float w, float d, float h, const char* floorTex, const char* wallTex) {   // piso + 4 paredes
    Obj f = mk(Kind::Floor, "Piso", {cx, -0.05f, cz}, {w, 0.2f, d}, 1, 1, 1);
    texFloor(f, floorTex);
    s.objs.push_back(f);
    wallSeg(s, cx, cz - d / 2, w, 0.4f, h, wallTex); wallSeg(s, cx, cz + d / 2, w, 0.4f, h, wallTex);
    wallSeg(s, cx - w / 2, cz, 0.4f, d, h, wallTex); wallSeg(s, cx + w / 2, cz, 0.4f, d, h, wallTex);
}
static Obj lamp(const char* name, V3 pos, float range, float r, float g, float b) {
    return mk(Kind::Light, name, pos, {range, 1, 1}, r, g, b, false);
}
static Obj tap2(const char* name, V3 pos, V3 sc, float r, float g, float b, const char* tex, std::vector<Block> bl) {
    Obj o = mk(Kind::Cube, name, pos, sc, r, g, b, false);
    if (tex && *tex) { o.tex = tex; o.noColor = true; }
    o.blocks = std::move(bl);
    return o;
}

void buildTemplate(int id, Project& p) {
    p.globalVars = {"puntos"};
    Scene s;
    switch (id) {
    case 0: case 1: case 7: case 14: {
        const bool fps = id == 0, hs = id == 7, fight = id == 14;
        s = base3(fight ? "Arena" : hs ? "Coliseo" : fps ? "Almacén" : "Base", fight ? 36.f : 56.f, 1.f, fight ? "lib_tex_arena.png" : "lib_tex_concreto.png");
        p.globalVars = {"puntos", "vida"};
        float half = fight ? 14.f : 24.f;
        walls(s, fight ? 3.f : 5.f, half, fight ? "lib_tex_roca.png" : "lib_tex_ladrillo.png");
        if (!fight) {   // salas interiores con puertas: dos muros con huecos y coberturas
            wallSeg(s, -10, -4, 14, 0.5f, 3.5f, "lib_tex_concreto.png"); wallSeg(s, 14, -4, 12, 0.5f, 3.5f, "lib_tex_concreto.png");
            wallSeg(s, 0, 9, 18, 0.5f, 3.5f, "lib_tex_concreto.png");
            s.objs.push_back(model3h("Mesa de trabajo", "lib_escritorio.fmdl", {-16, 0, 14}, 2.2f, 0.67f));
            for (int i = 0; i < 8; i++) s.objs.push_back(model3(i % 2 ? "Caja" : "Barril", i % 2 ? "lib_caja.fmdl" : "lib_barril.fmdl", {-18.f + i * 3.4f, 0, i % 2 ? -12.f : 4.f}, i % 2 ? 1.4f : 1.2f));
            s.objs.push_back(model3("Farola", "lib_farola.fmdl", {16, 0, 16}, 4.2f));
            s.objs.push_back(model3("Farola", "lib_farola.fmdl", {-16, 0, -16}, 4.2f));
            s.objs.push_back(pickup("Botiquín", "lib_cofre.fmdl", {-2, 0, 14}, "vida", "30", "'Botiquín: +30 de vida'", 0.9f));
            s.objs.push_back(pickup("Botiquín", "lib_cofre.fmdl", {18, 0, -12}, "vida", "30", "'Botiquín: +30 de vida'", 0.9f));
        } else {
            for (int i = 0; i < 4; i++) { float a = i * 1.5708f + 0.785f; s.objs.push_back(model3("Pilar", "lib_lapida.fmdl", {std::cos(a) * 9.f, 0, std::sin(a) * 9.f}, 2.2f)); }
            s.objs.push_back(pickup("Botiquín", "lib_cofre.fmdl", {0, 0, 10}, "vida", "40", "'Botiquín: +40 de vida'", 0.9f));
        }
        struct Spawn { const char* nm; const char* mdl; AiType t; float hp, sp, size; };
        std::vector<Spawn> en;
        if (fight) en = {{"Luchador", "lib_luchador2.fmdl", AiType::Melee, 4.f, 2.4f, 1.9f}, {"Luchador", "lib_luchador2.fmdl", AiType::Melee, 4.f, 2.6f, 1.9f}, {"Campeón", "lib_luchador2.fmdl", AiType::Melee, 14.f, 3.0f, 2.6f}};
        else if (hs) en = {{"Zombi", "lib_zombi.fmdl", AiType::Melee, 4.f, 2.2f, 1.9f}, {"Zombi", "lib_zombi.fmdl", AiType::Melee, 4.f, 2.0f, 1.9f}, {"Esqueleto", "lib_esqueleto.fmdl", AiType::Melee, 3.f, 2.8f, 1.9f},
                           {"Esqueleto", "lib_esqueleto.fmdl", AiType::Melee, 3.f, 2.8f, 1.9f}, {"Orco", "lib_orco.fmdl", AiType::Melee, 9.f, 2.0f, 2.8f}, {"Zombi", "lib_zombi.fmdl", AiType::Melee, 4.f, 2.3f, 1.9f}};
        else en = {{"Soldado enemigo", "lib_soldado.fmdl", AiType::Shooter, 3.f, 2.2f, 1.9f}, {"Soldado enemigo", "lib_soldado.fmdl", AiType::Shooter, 3.f, 2.2f, 1.9f}, {"Monstruo", "lib_monstruo.fmdl", AiType::Melee, 6.f, 2.4f, 2.6f},
                   {"Soldado enemigo", "lib_soldado.fmdl", AiType::Shooter, 3.f, 2.0f, 1.9f}, {"Monstruo", "lib_monstruo.fmdl", AiType::Melee, 6.f, 2.4f, 2.6f}, {"Soldado enemigo", "lib_soldado.fmdl", AiType::Shooter, 3.f, 2.2f, 1.9f}};
        for (size_t i = 0; i < en.size(); i++) {
            float ang = (float)i / en.size() * 6.2832f;
            float rr = fight ? 9.f : 14.f + (i % 2) * 4.f;
            s.objs.push_back(enemy3(en[i].nm, en[i].mdl, {std::sin(ang) * rr, 0, -std::fabs(std::cos(ang)) * rr}, en[i].t, en[i].hp, en[i].sp, en[i].size));
        }
        s.objs.push_back(music(fight ? "lib_musica_pelea.wav" : hs ? "lib_musica_aventura.wav" : "lib_musica_accion.wav"));
        Obj meta = mk(Kind::Cube, "Salida", {0, 0.05f, half - 2}, {3, 0.1f, 3}, 0.2f, 1.f, 0.4f, false);
        meta.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::Say, "", "'¡Nivel completado!'"), B(Op::StartSound, "lib_campana.wav"), B(Op::Wait, "", "4"), B(Op::StartScene, s.name.c_str())};
        s.objs.push_back(meta);
        s.start = {0, 0.05f, half - 6};
        if (fps) { p.player.cam = kFirstPerson; p.weapon.model = "lib_pistola.fmdl"; p.player.headBob = true; }
        else {
            p.player.cam = kShoulder; p.player.shoulderDist = 3.4f; p.player.model = fight ? "lib_luchador1.fmdl" : hs ? "lib_caballero.fmdl" : "lib_jugador.fmdl";
            playerObj(s, hs || fight ? 2.0f : 1.9f);
            p.weapon.model = hs ? "lib_espada2.fmdl" : "lib_rifle.fmdl";
        }
        if (hs) { p.weapon.type = 1; p.weapon.name = "Espada"; p.weapon.range = 2.7f; p.weapon.damage = 2.f; p.weapon.rate = 0.4f; p.weapon.scale = 0.9f; }
        if (fight) { p.weapon.type = 1; p.weapon.name = "Puños"; p.weapon.model = ""; p.weapon.range = 2.2f; p.weapon.damage = 1.5f; p.weapon.rate = 0.3f; }
        break; }
    case 2: {   // CARRERAS: circuito cerrado, botones Izquierda / Derecha / Acelerar / Frenar
        s = base3("Pista", 150.f, 1.f, "lib_tex_pasto.png");
        s.objs.push_back(mk(Kind::Floor, "Pista", {0, 0.02f, 0}, {124, 0.1f, 124}, 1, 1, 1));
        texFloor(s.objs.back(), "lib_tex_asfalto.png");
        walls(s, 1.6f, 62.f, "lib_tex_damero.png");
        Obj isla = mk(Kind::Wall, "Isla central", {0, 1.f, 0}, {66, 2.f, 66}, 1, 1, 1);
        texFloor(isla, "lib_tex_pasto.png");
        s.objs.push_back(isla);
        for (int i = 0; i < 12; i++) { float a = i * 0.5236f; s.objs.push_back(model3("Árbol", "lib_arbol.fmdl", {std::cos(a) * 20.f, 2.f, std::sin(a) * 20.f}, 6.f)); }
        for (int i = 0; i < 8; i++) { Obj l = mk(Kind::Cube, "Línea", {-30.f + i * 9.f, 0.09f, 46.f}, {4, 0.03f, 0.5f}, 1, 1, 1, false); s.objs.push_back(l); }
        const float conos[][2] = {{30, 40}, {44, 20}, {44, -22}, {20, -44}, {-26, -46}, {-44, -10}, {-46, 30}};
        for (auto& c : conos) {
            Obj o = model3("Cono", "lib_cono.fmdl", {c[0], 0, c[1]}, 1.4f);
            o.solid = false;
            o.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::SetSpeed, "", "7"), B(Op::StartSound, "lib_golpe.wav"), B(Op::ShakeScreen, "", "0.3"), B(Op::Wait, "", "1.6"), B(Op::SetSpeed, "", "22"), B(Op::Destroy)};
            s.objs.push_back(o);
        }
        const float turbos[][3] = {{8, 46, 0}, {47, 0, 1}, {0, -47, 0}, {-47, 4, 1}};
        for (auto& t : turbos) {
            Obj o = mk(Kind::Cube, "Turbo", {t[0], 0.12f, t[1]}, {t[2] ? 8.f : 5.f, 0.06f, t[2] ? 5.f : 8.f}, 1.f, 0.85f, 0.1f, false);
            o.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::SetSpeed, "", "36"), B(Op::StartSound, "lib_susto.wav"), B(Op::Wait, "", "2.2"), B(Op::SetSpeed, "", "22")};
            s.objs.push_back(o);
        }
        p.globalVars = {"vueltas", "tiempo", "punto"};
        Obj medio = mk(Kind::Cube, "Punto medio", {0, 0.1f, -46}, {3, 0.1f, 30}, 1, 1, 1, false);
        medio.noColor = true; medio.visible = true; medio.transp = 100;
        medio.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::SetVar, "punto", "1")};
        s.objs.push_back(medio);
        Obj meta = mk(Kind::Cube, "Meta", {-8, 0.12f, 46}, {2.5f, 0.1f, 30}, 1.f, 1.f, 1.f, false);
        texFloor(meta, "lib_tex_damero.png");
        meta.blocks = {B(Op::WhenCollide, "Jugador"), B(Op::If, "", "punto = 1"), B(Op::SetVar, "punto", "0"), B(Op::ChangeVar, "vueltas", "1"), B(Op::StartSound, "lib_campana.wav"),
                       B(Op::If, "", "vueltas >= 3"), B(Op::Say, "", "'¡CARRERA TERMINADA! Tiempo: ' + tiempo + ' s'"), B(Op::Wait, "", "6"), B(Op::StartScene, "Pista"), B(Op::Else), B(Op::Say, "", "'Vuelta ' + vueltas + ' de 3'"), B(Op::EndIf), B(Op::EndIf)};
        s.objs.push_back(meta);
        s.objs.push_back(ctrl("Cronómetro", {B(Op::WhenStart), B(Op::SetVar, "vueltas", "0"), B(Op::SetVar, "tiempo", "0"), B(Op::SetVar, "punto", "0"), B(Op::Forever), B(Op::Wait, "", "1"), B(Op::ChangeVar, "tiempo", "1"), B(Op::LoopEnd)}));
        s.objs.push_back(music("lib_musica_carrera.wav"));
        s.start = {0, 0.1f, 46};
        p.player.cam = kShoulder; p.player.speed = 22.f; p.player.shoulderDist = 8.5f; p.player.vehicle = true;
        p.player.model = "lib_carro2.fmdl"; p.player.faceMove = true;
        playerObj(s, 4.4f, 90.f);
        p.player.moy = -1.55f;
        p.weapon.enabled = false;
        p.hudDefault = false;
        hudBtn(p, "Izquierda", 0.10f, 0.78f, 0.10f, HudAct::Hold, 0.5f, 0.7f, 1.f);
        hudBtn(p, "Derecha", 0.29f, 0.78f, 0.10f, HudAct::Hold, 0.5f, 0.7f, 1.f);
        hudBtn(p, "Acelerar", 0.89f, 0.76f, 0.12f, HudAct::Hold, 0.3f, 1.f, 0.4f);
        hudBtn(p, "Frenar", 0.72f, 0.86f, 0.08f, HudAct::Hold, 1.f, 0.4f, 0.35f);
        p.showVars = true;
        break; }
    case 3: {
        s = base3("Plataformas", 80.f, 1.f, "lib_tex_roca.png");
        for (int i = 0; i < 9; i++) {
            Obj pl = mk(Kind::Wall, "Plataforma", {(i % 3 - 1) * 4.f, 1.f + i * 1.3f, 24.f - i * 6.f}, {5, 0.5f, 5}, 1, 1, 1);
            texFloor(pl, i % 2 ? "lib_tex_madera.png" : "lib_tex_pasto.png");
            s.objs.push_back(pl);
            s.objs.push_back(coin3((i % 3 - 1) * 4.f, 2.6f + i * 1.3f, 24.f - i * 6.f));
        }
        s.objs.push_back(model3("Cofre final", "lib_cofre.fmdl", {0, 1.0f + 8 * 1.3f + 0.25f, 24.f - 8 * 6.f}, 1.2f));
        s.objs.push_back(music("lib_musica_aventura.wav"));
        p.player.cam = kShoulder; p.player.jump = 9.f; p.player.speed = 5.5f; p.player.model = "lib_jugador.fmdl";
        s.start = {0, 0.05f, 30};
        playerObj(s, 1.9f);
        break; }
    case 4: case 5: {
        bool plat = id == 4;
        s = base2("Nivel1", plat ? 0.45f : 0.05f, plat ? 0.7f : 0.06f, plat ? 0.95f : 0.18f);
        Obj hero = hero2(-300, plat ? -250 : -330, plat);
        hero.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen)};
        if (plat) {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "8"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-8"), B(Op::WhenButton, "A"), B(Op::SetForce, "", "0", "700")});
            s.objs.push_back(hero);
            Obj g = mk(Kind::Cube, "Suelo", {0, -420, 0}, {2400, 120, 1}, 1, 1, 1); g.tex = "lib_tex_pasto.png"; g.phys = Phys::Static; s.objs.push_back(g);
            for (int i = 0; i < 3; i++) { Obj pl = mk(Kind::Cube, "Plataforma", {-200.f + i * 260.f, -250.f + i * 110.f, 0}, {200, 36, 1}, 1, 1, 1); pl.tex = "lib_tex_madera.png"; pl.phys = Phys::Static; s.objs.push_back(pl); }
            p.ctl2d = 3;
        } else {
            hero.blocks.insert(hero.blocks.end(), {B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "10"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-10"), B(Op::WhenButton, "Arriba"), B(Op::ChangeY, "", "10"), B(Op::WhenButton, "Abajo"), B(Op::ChangeY, "", "-10")});
            s.objs.push_back(hero);
            for (int i = 0; i < 5; i++) {
                Obj e = mk(Kind::Cube, "Enemigo", {-400.f + i * 200.f, 300, 0}, {70, 70, 1}, 0.9f, 0.3f, 0.3f);
                e.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::Repeat, "", "40"), B(Op::ChangeX, "", i % 2 ? "6" : "-6"), B(Op::Wait, "", "0.02"), B(Op::LoopEnd), B(Op::ChangeY, "", "-30"), B(Op::LoopEnd)};
                s.objs.push_back(e);
            }
            p.ctl2d = 1;
        }
        s.objs.push_back(music(plat ? "lib_musica_aventura.wav" : "lib_musica_accion.wav"));
        break; }
    case 6: {   // RPG: aldea al sur, bosque en medio, ruinas con jefe al norte
        s = base3("Reino", 120.f, 1.f, "lib_tex_pasto.png");
        p.globalVars = {"monedas", "vida", "pociones"};
        s.start = {0, 0.05f, 46};
        const char* ladr = "lib_tex_ladrillo.png";
        walls(s, 2.4f, 58.f, "lib_tex_roca.png");
        for (int i = 0; i < 5; i++) s.objs.push_back(model3h("Casa", "lib_casa.fmdl", {-24.f + i * 12.f, 0, 36.f}, 7.f, 0.65f, i % 2 ? 0.f : 10.f));
        s.objs.push_back(model3("Farola", "lib_farola.fmdl", {-4, 0, 40}, 4.2f)); s.objs.push_back(model3("Farola", "lib_farola.fmdl", {6, 0, 40}, 4.2f));
        for (int i = 0; i < 22; i++) { float x = -50.f + (i % 11) * 9.5f, z = i < 11 ? 8.f : -8.f; s.objs.push_back(model3("Árbol", "lib_arbol.fmdl", {x + (i % 3) * 1.4f, 0, z + (i % 4)}, 5.5f)); }
        Obj npc = model3("Anciano", "lib_aldeano.fmdl", {3, 0, 42}, 1.9f);
        npc.blocks = {B(Op::WhenInteract), B(Op::Say, "", "'Anciano: Un orco jefe vive en las ruinas del norte. ¡Derrótalo con tu espada!'")};
        s.objs.push_back(npc);
        Obj herrero = model3("Herrero", "lib_aldeano.fmdl", {-12, 0, 44}, 1.9f);
        herrero.blocks = {B(Op::WhenInteract), B(Op::If, "", "monedas >= 20"), B(Op::ChangeVar, "monedas", "-20"), B(Op::ChangeVar, "vida", "40"), B(Op::Say, "", "'Herrero: Te vendé una poción. +40 de vida.'"), B(Op::Else), B(Op::Say, "", "'Herrero: Una poción cuesta 20 monedas.'"), B(Op::EndIf)};
        s.objs.push_back(herrero);
        for (int i = 0; i < 3; i++) {
            Obj c = model3("Cofre", "lib_cofre.fmdl", {-20.f + i * 18.f, 0, 22.f}, 1.2f);
            c.blocks = {B(Op::WhenInteract), B(Op::ChangeVar, "monedas", "15"), B(Op::Say, "", "'¡Un cofre! +15 monedas'"), B(Op::StartSound, "lib_moneda.wav"), B(Op::Destroy)};
            s.objs.push_back(c);
        }
        for (int i = 0; i < 4; i++) s.objs.push_back(enemy3("Esqueleto", "lib_esqueleto.fmdl", {-16.f + i * 10.f, 0, -2.f}, AiType::Melee, 3.f, 2.3f, 1.9f));
        for (int i = 0; i < 3; i++) s.objs.push_back(enemy3("Orco", "lib_orco.fmdl", {-12.f + i * 12.f, 0, -26.f}, AiType::Melee, 7.f, 2.1f, 2.8f));
        // ruinas del jefe
        for (int i = 0; i < 6; i++) s.objs.push_back(model3("Columna", "lib_lapida.fmdl", {-15.f + i * 6.f, 0, -44.f}, 3.f));
        wallSeg(s, 0, -52, 40, 0.8f, 4.f, ladr);
        s.objs.push_back(enemy3("Orco jefe", "lib_orco.fmdl", {0, 0, -46.f}, AiType::Melee, 24.f, 2.4f, 4.8f));
        s.objs.push_back(pickup("Moneda", "lib_moneda.fmdl", {2, 0.5f, 30}, "monedas", "5", "'+5 monedas'", 0.7f));
        s.objs.push_back(pickup("Moneda", "lib_moneda.fmdl", {-6, 0.5f, 28}, "monedas", "5", "'+5 monedas'", 0.7f));
        s.objs.push_back(music("lib_musica_aventura.wav"));
        p.player.cam = kShoulder; p.player.shoulderDist = 4.4f; p.player.model = "lib_caballero.fmdl";
        playerObj(s, 2.0f);
        p.weapon.type = 1; p.weapon.name = "Espada"; p.weapon.model = "lib_espada2.fmdl"; p.weapon.scale = 0.9f; p.weapon.range = 2.7f; p.weapon.damage = 2.f; p.weapon.rate = 0.4f;
        p.showVars = true;
        break; }
    case 8: {   // FNAF 2D
        s = base2("Oficina", 0.06f, 0.07f, 0.1f);
        s.name = "Oficina";
        s.sfx.vignette = 0.9f; s.sfx.noise = 0.3f; s.sfx.scan = 0.35f; s.sfx.track = 0.2f;
        s.objs[0].tex = "lib_tex_papel_pared.png"; s.objs[0].noColor = false;
        p.globalVars = {"puertaI", "puertaD", "cam", "posOso", "posCon", "power", "hora", "seg"};
        s.objs.push_back(ctrl("Sistema", {B(Op::WhenStart), B(Op::SetVar, "puertaI", "0"), B(Op::SetVar, "puertaD", "0"), B(Op::SetVar, "cam", "0"), B(Op::SetVar, "posOso", "0"), B(Op::SetVar, "posCon", "0"),
            B(Op::SetVar, "power", "100"), B(Op::SetVar, "hora", "0"), B(Op::SetVar, "seg", "0"), B(Op::Music, "lib_ambiente_terror.wav"),
            B(Op::Forever), B(Op::Wait, "", "1"), B(Op::ChangeVar, "power", "-(0.14 + puertaI * 0.3 + puertaD * 0.3 + (cam > 0) * 0.2)"), B(Op::ChangeVar, "seg", "1"),
            B(Op::If, "", "seg >= 45"), B(Op::SetVar, "seg", "0"), B(Op::ChangeVar, "hora", "1"), B(Op::EndIf),
            B(Op::If, "", "hora >= 6"), B(Op::Broadcast, "victoria"), B(Op::StopScript), B(Op::EndIf),
            B(Op::If, "", "power <= 0"), B(Op::Broadcast, "apagon"), B(Op::StopScript), B(Op::EndIf), B(Op::LoopEnd)}));
        s.objs.push_back(ctrl("Mensajes", {B(Op::WhenReceive, "victoria"), B(Op::StartSound, "lib_campana.wav"), B(Op::Say, "", "'¡6 AM! ¡Sobreviviste la noche!'"), B(Op::Wait, "", "6"), B(Op::StartScene, "Oficina"),
            B(Op::WhenReceive, "apagon"), B(Op::SetVar, "puertaI", "0"), B(Op::SetVar, "puertaD", "0"), B(Op::SetVar, "cam", "0"), B(Op::Say, "", "'Se acabó la energía...'"), B(Op::Wait, "", "4"), B(Op::Broadcast, "susto_oso")}));
        Obj piso = mk(Kind::Cube, "Piso", {0, -420, 0}, {2400, 160, 1}, 1, 1, 1); piso.tex = "lib_tex_damero.png"; piso.layer = 1; s.objs.push_back(piso);
        Obj mesa = mk(Kind::Cube, "Escritorio", {0, -350, 0}, {900, 160, 1}, 1, 1, 1); mesa.tex = "lib_tex_madera.png"; mesa.layer = 4; s.objs.push_back(mesa);
        for (int k = 0; k < 2; k++) {
            const char* v = k ? "puertaD" : "puertaI";
            Obj d = tap2(k ? "Puerta derecha" : "Puerta izquierda", {k ? 640.f : -640.f, 20, 0}, {250, 700, 1}, 1, 1, 1, "lib_tex_metal.png",
                         {B(Op::WhenTap), B(Op::SetVar, v, k ? "1 - puertaD" : "1 - puertaI"), B(Op::SetTransp, "", k ? "(1 - puertaD) * 85" : "(1 - puertaI) * 85"), B(Op::StartSound, "lib_puerta.wav")});
            d.layer = 3; d.transp = 85;
            s.objs.push_back(d);
        }
        // pantalla de cámaras
        const char* feedTex[3] = {"lib_tex_madera.png", "lib_tex_ladrillo.png", "lib_tex_asfalto.png"};
        Obj marco = mk(Kind::Cube, "Marco del monitor", {0, 70, 0}, {1020, 640, 1}, 0.02f, 0.02f, 0.03f); marco.layer = 9;
        marco.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::If, "", "cam > 0"), B(Op::Show), B(Op::Else), B(Op::Hide), B(Op::EndIf), B(Op::Wait, "", "0.05"), B(Op::LoopEnd)};
        s.objs.push_back(marco);
        for (int c = 0; c < 3; c++) {
            Obj f = mk(Kind::Cube, "Cámara", {0, 70, 0}, {980, 600, 1}, 0.7f, 0.9f, 0.8f); f.tex = feedTex[c]; f.layer = 10; f.noColor = false;
            std::string cn = "cam = " + std::to_string(c + 1);
            f.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::If, "", cn.c_str()), B(Op::Show), B(Op::Else), B(Op::Hide), B(Op::EndIf), B(Op::Wait, "", "0.05"), B(Op::LoopEnd)};
            s.objs.push_back(f);
        }
        // animatrónicos: en las cámaras y en las puertas
        struct An { const char* nm; const char* spr; const char* pos; int hallCam; float doorX; const char* doorVar; const char* door; const char* scare; };
        An an[2] = {{"Oso", "lib_spr_oso.png", "posOso", 2, -520.f, "puertaI", "susto_oso", "susto_oso"}, {"Conejo", "lib_spr_conejo.png", "posCon", 3, 520.f, "puertaD", "susto_con", "susto_con"}};
        for (int a = 0; a < 2; a++) {
            std::string pv = an[a].pos, in0 = "cam = 1 y " + pv + " = 0", inH = "cam = " + std::to_string(an[a].hallCam) + " y " + pv + " = 1", atDoor = "cam = 0 y " + pv + " = 2";
            Obj feed = mk(Kind::Cube, std::string(an[a].nm).append(" en cámara").c_str(), {a ? 220.f : -220.f, 70, 0}, {300, 300, 1}, 1, 1, 1);
            feed.tex = an[a].spr; feed.noColor = true; feed.layer = 11; feed.visible = false;
            std::string cond = "(" + in0 + ") o (" + inH + ")";
            feed.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::If, "", cond.c_str()), B(Op::Show), B(Op::Else), B(Op::Hide), B(Op::EndIf), B(Op::Wait, "", "0.05"), B(Op::LoopEnd)};
            s.objs.push_back(feed);
            Obj door = mk(Kind::Cube, std::string(an[a].nm).append(" en la puerta").c_str(), {an[a].doorX, 40, 0}, {330, 330, 1}, 1, 1, 1);
            door.tex = an[a].spr; door.noColor = true; door.layer = 2; door.visible = false;
            door.blocks = {B(Op::WhenStart), B(Op::Forever), B(Op::If, "", atDoor.c_str()), B(Op::Show), B(Op::Else), B(Op::Hide), B(Op::EndIf), B(Op::Wait, "", "0.05"), B(Op::LoopEnd)};
            s.objs.push_back(door);
            std::string atD = pv + " = 2", dv = an[a].doorVar;
            std::string closed = dv + " = 1";
            Obj ai = ctrl(std::string("IA ").append(an[a].nm).c_str(), {B(Op::WhenStart), B(Op::Forever), B(Op::Wait, "", a ? "valor aleatorio desde hasta(7,11)" : "valor aleatorio desde hasta(6,10)"),
                B(Op::If, "", (pv + " < 2").c_str()), B(Op::ChangeVar, pv.c_str(), "1"), B(Op::StartSound, "lib_golpe.wav"), B(Op::EndIf), B(Op::LoopEnd),
                B(Op::WhenTrue, "", atD.c_str()), B(Op::Wait, "", "4"), B(Op::If, "", closed.c_str()), B(Op::SetVar, pv.c_str(), "0"), B(Op::StartSound, "lib_puerta.wav"), B(Op::Else), B(Op::Broadcast, an[a].scare), B(Op::EndIf)});
            s.objs.push_back(ai);
            Obj sc = mk(Kind::Cube, std::string("Susto ").append(an[a].nm).c_str(), {0, 0, 0}, {1500, 1000, 1}, 1, 1, 1);
            sc.tex = an[a].spr; sc.noColor = true; sc.layer = 30; sc.visible = false;
            sc.blocks = {B(Op::WhenReceive, an[a].scare), B(Op::Show), B(Op::StartSound, "lib_susto.wav"), B(Op::ShakeScreen, "", "2"), B(Op::Wait, "", "2.4"), B(Op::Say, "", "'FIN DEL JUEGO'"), B(Op::Wait, "", "3"), B(Op::StartScene, "Oficina")};
            s.objs.push_back(sc);
        }
        // botones de cámara
        for (int c = 0; c < 4; c++) {
            const char* nms[4] = {"CAM 1 Escenario", "CAM 2 Pasillo izq.", "CAM 3 Pasillo der.", "Cerrar cámaras"};
            std::string cn = std::to_string(c + 1);
            std::vector<Block> bl;
            if (c < 3) {
                std::string cond = "cam = " + cn;
                bl = {B(Op::WhenTap), B(Op::If, "", cond.c_str()), B(Op::SetVar, "cam", "0"), B(Op::Else), B(Op::SetVar, "cam", cn.c_str()), B(Op::Say, "", (std::string("'") + nms[c] + "'").c_str()), B(Op::StartSound, "lib_golpe.wav"), B(Op::EndIf)};
            } else bl = {B(Op::WhenTap), B(Op::SetVar, "cam", "0")};
            Obj b = tap2(nms[c], {-330.f + c * 220.f, -440, 0}, {190, 70, 1}, c < 3 ? 0.2f : 0.7f, c < 3 ? 0.55f : 0.2f, c < 3 ? 0.9f : 0.2f, "", bl);
            b.layer = 20;
            s.objs.push_back(b);
        }
        p.showVars = true;
        p.exportCfg.orient = 0;
        break; }
    case 9: default: {   // FNAF 3D
        s = base3("Oficina", 20.f, 0.05f, "lib_tex_damero.png");
        s.name = "Oficina";
        s.objs.clear();
        p.globalVars = {"puertaI", "puertaD", "power", "hora", "seg"};
        s.ambient = 0.09f; s.fog = 0.05f; s.atmo = 1; s.atmoAmt = 0.4f; s.atmoStyle = 1; s.fogMode = 1; s.shadowAmt = 1.3f;
        s.fogCol[0] = 0.03f; s.fogCol[1] = 0.04f; s.fogCol[2] = 0.06f;
        s.skyTop[0] = s.skyTop[1] = s.skyTop[2] = 0.015f; s.skyBot[0] = s.skyBot[1] = s.skyBot[2] = 0.02f;
        s.sfx.vignette = 0.55f; s.sfx.noise = 0.12f;
        const char* pw = "lib_tex_papel_pared.png";
        // oficina (techo incluido) con dos huecos de puerta a los lados
        { Obj f = mk(Kind::Floor, "Piso oficina", {0, -0.05f, 0}, {8, 0.2f, 8}, 1, 1, 1); texFloor(f, "lib_tex_damero.png"); s.objs.push_back(f); }
        { Obj t = mk(Kind::Wall, "Techo", {0, 3.1f, 0}, {8.4f, 0.2f, 8.4f}, 0.3f, 0.3f, 0.32f); s.objs.push_back(t); }
        wallSeg(s, 0, -4, 8.4f, 0.4f, 3.1f, pw); wallSeg(s, 0, 4, 8.4f, 0.4f, 3.1f, pw);
        for (int k = 0; k < 2; k++) { float x = k ? 4.f : -4.f; wallSeg(s, x, -2.6f, 0.4f, 2.8f, 3.1f, pw); wallSeg(s, x, 2.6f, 0.4f, 2.8f, 3.1f, pw); }
        s.objs.push_back(model3h("Escritorio", "lib_escritorio.fmdl", {0, 0, -2.7f}, 2.6f, 0.67f));
        s.objs.push_back(model3h("Monitor", "lib_monitor.fmdl", {0, 0.8f, -2.7f}, 0.9f, 0.94f));
        s.objs.push_back(model3("Barril", "lib_barril.fmdl", {-3.2f, 0, -3.2f}, 1.2f));
        s.objs.push_back(lamp("Luz oficina", {0, 2.6f, 0}, 9.f, 0.95f, 0.85f, 0.6f));
        // pasillos de las puertas
        for (int k = 0; k < 2; k++) {
            float sg = k ? 1.f : -1.f;
            wallSeg(s, sg * 9.f, -2.2f, 10.f, 0.4f, 3.1f, pw); wallSeg(s, sg * 9.f, 2.2f, 10.f, 0.4f, 3.1f, pw); wallSeg(s, sg * 14.2f, 0, 0.4f, 4.8f, 3.1f, pw);
            Obj f = mk(Kind::Floor, "Piso pasillo", {sg * 9.f, -0.05f, 0}, {10, 0.2f, 4.4f}, 1, 1, 1); texFloor(f, "lib_tex_concreto.png"); s.objs.push_back(f);
            s.objs.push_back(lamp("Luz pasillo", {sg * 9.f, 2.5f, 0}, 7.f, 0.9f, 0.3f, 0.25f));
            // puerta de seguridad (sube para abrir)
            std::string v = k ? "puertaD" : "puertaI";
            Obj d = model3(k ? "Puerta derecha" : "Puerta izquierda", "lib_puerta_metal.fmdl", {sg * 4.f, 0, 0}, 2.8f, 90.f);
            d.pos.y = 4.8f;
            std::string btn = k ? "Puerta der" : "Puerta izq";
            d.blocks = {B(Op::WhenButton, btn.c_str()), B(Op::If, "", (v + " = 0").c_str()), B(Op::SetVar, v.c_str(), "1"), B(Op::PlaceAt3, "", k ? "4" : "-4", "1.4", "0"),
                        B(Op::Else), B(Op::SetVar, v.c_str(), "0"), B(Op::PlaceAt3, "", k ? "4" : "-4", "4.8", "0"), B(Op::EndIf), B(Op::StartSound, "lib_puerta.wav"),
                        B(Op::WhenReceive, "apagon"), B(Op::SetVar, v.c_str(), "0"), B(Op::PlaceAt3, "", k ? "4" : "-4", "4.8", "0")};
            s.objs.push_back(d);
        }
        // salas de cámara lejanas
        cuarto(s, 40, 0, 12, 9, 3.4f, "lib_tex_damero.png", "lib_tex_ladrillo.png");
        { Obj st = mk(Kind::Wall, "Escenario", {40, 0.3f, -2.6f}, {8, 0.6f, 3}, 0.5f, 0.2f, 0.2f); texFloor(st, "lib_tex_madera.png"); s.objs.push_back(st); }
        s.objs.push_back(lamp("Luz cam1", {40, 3.0f, 0}, 11.f, 0.7f, 0.9f, 0.8f));
        cuarto(s, 70, 0, 4.4f, 14, 3.2f, "lib_tex_concreto.png", pw);
        s.objs.push_back(lamp("Luz cam2", {70, 2.8f, 0}, 9.f, 0.7f, 0.9f, 0.8f));
        cuarto(s, 100, 0, 4.4f, 14, 3.2f, "lib_tex_concreto.png", pw);
        s.objs.push_back(lamp("Luz cam3", {100, 2.8f, 0}, 9.f, 0.7f, 0.9f, 0.8f));
        s.objs.push_back(model3h("Cámara de seguridad", "lib_camara_seg.fmdl", {0, 2.7f, -3.8f}, 0.7f, 0.9f));
        // animatrónicos
        struct An { const char* nm; const char* mdl; float stageX; float hallX; float doorX; const char* vr; const char* sc; };
        An an[2] = {{"Oso animatrónico", "lib_animatronico_oso.fmdl", 37.f, 70.f, -7.2f, "puertaI", "susto_oso"}, {"Conejo animatrónico", "lib_animatronico_conejo.fmdl", 43.f, 100.f, 7.2f, "puertaD", "susto_con"}};
        for (int a = 0; a < 2; a++) {
            Obj o = model3(an[a].nm, an[a].mdl, {an[a].stageX, 0.6f, -2.6f}, 3.0f);
            o.solid = false; o.yaw = 0;
            std::string sx = std::to_string(an[a].stageX), hx = std::to_string(an[a].hallX), dx = std::to_string(an[a].doorX), cl = std::string(an[a].vr) + " = 1";
            std::vector<Block> bl = {B(Op::WhenStart), B(Op::Forever), B(Op::Wait, "", a ? "valor aleatorio desde hasta(8,13)" : "valor aleatorio desde hasta(7,11)"),
                B(Op::PlaceAt3, "", hx.c_str(), "1.5", "-2"), B(Op::StartSound, "lib_golpe.wav"), B(Op::Wait, "", "valor aleatorio desde hasta(6,10)"),
                B(Op::PlaceAt3, "", dx.c_str(), "1.5", "0"), B(Op::Wait, "", "4.5"), B(Op::If, "", cl.c_str()),
                B(Op::PlaceAt3, "", sx.c_str(), "2.1", "-2.6"), B(Op::StartSound, "lib_puerta.wav"), B(Op::Else)};
            auto js = jumpscare();
            bl.insert(bl.end(), js.begin(), js.end());
            bl.push_back(B(Op::EndIf)); bl.push_back(B(Op::LoopEnd));
            if (a == 0) {   // apagón: el oso viene a buscarte
                bl.push_back(B(Op::WhenReceive, "apagon")); bl.push_back(B(Op::Wait, "", "7"));
                auto js2 = jumpscare(); bl.insert(bl.end(), js2.begin(), js2.end());
            }
            o.blocks = bl;
            s.objs.push_back(o);
        }
        // cámaras (teletransportan la vista) y sistema
        std::vector<Block> sys = {B(Op::WhenStart), B(Op::SetVar, "puertaI", "0"), B(Op::SetVar, "puertaD", "0"), B(Op::SetVar, "power", "100"), B(Op::SetVar, "hora", "0"), B(Op::SetVar, "seg", "0"),
            B(Op::Music, "lib_ambiente_terror.wav"),
            B(Op::Forever), B(Op::Wait, "", "1"), B(Op::ChangeVar, "power", "-(0.14 + puertaI * 0.3 + puertaD * 0.3)"), B(Op::ChangeVar, "seg", "1"),
            B(Op::If, "", "seg >= 45"), B(Op::SetVar, "seg", "0"), B(Op::ChangeVar, "hora", "1"), B(Op::EndIf),
            B(Op::If, "", "hora >= 6"), B(Op::StartSound, "lib_campana.wav"), B(Op::Say, "", "'¡6 AM! ¡Sobreviviste la noche!'"), B(Op::Wait, "", "6"), B(Op::StartScene, "Oficina"), B(Op::EndIf),
            B(Op::If, "", "power <= 0"), B(Op::Broadcast, "apagon"), B(Op::Say, "", "'Se acabó la energía...'"), B(Op::StopScript), B(Op::EndIf), B(Op::LoopEnd)};
        const char* cx[3] = {"40", "70", "100"}; const char* cz[3] = {"3.6", "6", "6"}; const char* cn2[3] = {"CAM 1", "CAM 2", "CAM 3"}; const char* cb[3] = {"CAM1", "CAM2", "CAM3"};
        for (int c = 0; c < 3; c++) {
            sys.push_back(B(Op::WhenButton, cb[c])); sys.push_back(B(Op::FreezePlayer)); sys.push_back(B(Op::TeleportPlayer, "", cx[c], "0.05", cz[c])); sys.push_back(B(Op::SetPlayerYaw, "", "0"));
            sys.push_back(B(Op::SetScreenFx, "vhs")); sys.push_back(B(Op::Say, "", (std::string("'") + cn2[c] + "'").c_str())); sys.push_back(B(Op::StartSound, "lib_golpe.wav"));
        }
        sys.push_back(B(Op::WhenButton, "Oficina")); sys.push_back(B(Op::UnfreezePlayer)); sys.push_back(B(Op::TeleportPlayer, "", "0", "0.05", "1.5")); sys.push_back(B(Op::SetPlayerYaw, "", "0")); sys.push_back(B(Op::SetScreenFx, "normal"));
        s.objs.push_back(ctrl("Sistema", sys));
        p.player.cam = kFirstPerson; p.player.speed = 2.6f; p.weapon.enabled = false;
        p.player.flashlight = false;
        s.start = {0, 0.05f, 1.5f};
        p.hudDefault = false;
        hudBtn(p, "Puerta izq", 0.09f, 0.55f, 0.09f, HudAct::Script, 0.9f, 0.3f, 0.3f);
        hudBtn(p, "Puerta der", 0.91f, 0.55f, 0.09f, HudAct::Script, 0.9f, 0.3f, 0.3f);
        hudBtn(p, "CAM1", 0.34f, 0.1f, 0.06f, HudAct::Script, 0.3f, 0.7f, 1.f);
        hudBtn(p, "CAM2", 0.5f, 0.1f, 0.06f, HudAct::Script, 0.3f, 0.7f, 1.f);
        hudBtn(p, "CAM3", 0.66f, 0.1f, 0.06f, HudAct::Script, 0.3f, 0.7f, 1.f);
        hudBtn(p, "Oficina", 0.5f, 0.88f, 0.08f, HudAct::Script, 0.4f, 1.f, 0.5f);
        p.showVars = true;
        break; }
    case 10: {   // Runner infinito
        s = base2("Carrera", 0.45f, 0.75f, 0.95f);
        s.name = "Carrera";
        p.globalVars = {"puntos"};
        s.objs[0].blocks = {B(Op::WhenTap), B(Op::Broadcast, "saltar")};
        Obj sol = tap2("Sol", {620, 330, 0}, {170, 170, 1}, 1.f, 0.9f, 0.3f, "lib_spr_moneda.png", {}); sol.layer = 1; s.objs.push_back(sol);
        Obj g = mk(Kind::Cube, "Suelo", {0, -420, 0}, {2600, 140, 1}, 1, 1, 1); g.tex = "lib_tex_pasto.png"; g.phys = Phys::Static; g.layer = 2; s.objs.push_back(g);
        Obj hero = mk(Kind::Cube, "Corredor", {-420, -290, 0}, {90, 130, 1}, 0.25f, 0.55f, 1.f);
        hero.phys = Phys::Dynamic;
        hero.blocks = {B(Op::WhenReceive, "saltar"), B(Op::SetForce, "", "0", "640"), B(Op::StartSound, "lib_moneda.wav")};
        s.objs.push_back(hero);
        Obj ob = mk(Kind::Cube, "Obstáculo", {1250, -300, 0}, {80, 110, 1}, 0.9f, 0.35f, 0.15f); ob.tex = "lib_tex_ladrillo.png"; ob.noColor = false;
        ob.blocks = {B(Op::WhenStart), B(Op::Hide), B(Op::Forever), B(Op::Wait, "", "valor aleatorio desde hasta(1.1,2.2)"), B(Op::CreateClone), B(Op::LoopEnd),
                     B(Op::WhenCloneStart), B(Op::Show), B(Op::Repeat, "", "230"), B(Op::ChangeX, "", "-9"), B(Op::Wait, "", "0.016"), B(Op::LoopEnd), B(Op::DeleteClone),
                     B(Op::WhenCollide, "Corredor"), B(Op::StartSound, "lib_golpe.wav"), B(Op::ShakeScreen, "", "0.6"), B(Op::Say, "", "'¡Perdiste! Puntos: ' + puntos"), B(Op::Wait, "", "2"), B(Op::StartScene, "Carrera")};
        s.objs.push_back(ob);
        s.objs.push_back(ctrl("Puntaje", {B(Op::WhenStart), B(Op::SetVar, "puntos", "0"), B(Op::Forever), B(Op::Wait, "", "0.4"), B(Op::ChangeVar, "puntos", "1"), B(Op::LoopEnd)}));
        s.objs.push_back(music("lib_musica_casual.wav"));
        p.showVars = true;
        break; }
    case 11: {   // Flappy
        s = base2("Vuelo", 0.4f, 0.8f, 0.95f);
        s.name = "Vuelo";
        p.globalVars = {"puntos", "hueco"};
        s.objs[0].blocks = {B(Op::WhenTap), B(Op::Broadcast, "aletear")};
        Obj bird = mk(Kind::Cube, "Pájaro", {-130, 0, 0}, {80, 80, 1}, 1, 1, 1);
        bird.tex = "lib_spr_pajaro.png"; bird.noColor = true; bird.phys = Phys::Dynamic; bird.gravScale = 0.45f; bird.layer = 5;
        bird.blocks = {B(Op::WhenReceive, "aletear"), B(Op::SetForce, "", "0", "430"), B(Op::StartSound, "lib_espadazo.wav")};
        s.objs.push_back(bird);
        Obj suelo = mk(Kind::Cube, "Suelo", {0, -480, 0}, {900, 90, 1}, 0.45f, 0.3f, 0.12f); suelo.tex = "lib_tex_arena.png"; suelo.phys = Phys::Static; suelo.layer = 6;
        suelo.blocks = {B(Op::WhenCollide, "Pájaro"), B(Op::Broadcast, "perder")};
        s.objs.push_back(suelo);
        for (int k = 0; k < 2; k++) {
            Obj t = mk(Kind::Cube, k ? "Tubo arriba" : "Tubo abajo", {330, k ? 500 : -500, 0}, {110, 700, 1}, 1, 1, 1);
            t.tex = "lib_spr_tuberia.png"; t.noColor = true; t.layer = 3;
            t.blocks = {B(Op::WhenStart), B(Op::Hide),
                        B(Op::WhenCloneStart), B(Op::SetY, "", k ? "hueco + 490" : "hueco - 490"), B(Op::Show), B(Op::Repeat, "", "150"), B(Op::ChangeX, "", "-5"), B(Op::Wait, "", "0.016"), B(Op::LoopEnd), B(Op::DeleteClone),
                        B(Op::WhenCollide, "Pájaro"), B(Op::Broadcast, "perder")};
            s.objs.push_back(t);
        }
        s.objs.push_back(ctrl("Juego", {B(Op::WhenStart), B(Op::SetVar, "puntos", "0"), B(Op::Wait, "", "1.2"), B(Op::Forever), B(Op::SetVar, "hueco", "valor aleatorio desde hasta(-170,170)"),
                                        B(Op::Broadcast, "tubos"), B(Op::Wait, "", "0.05"), B(Op::ChangeVar, "puntos", "1"), B(Op::Wait, "", "1.7"), B(Op::LoopEnd),
                                        B(Op::WhenReceive, "perder"), B(Op::StartSound, "lib_golpe.wav"), B(Op::ShakeScreen, "", "0.6"), B(Op::Say, "", "'¡Chocaste! Puntos: ' + puntos"), B(Op::Wait, "", "2"), B(Op::StartScene, "Vuelo")}));
        for (auto& o : s.objs) if (o.name == "Tubo arriba" || o.name == "Tubo abajo") o.blocks.insert(o.blocks.begin(), B(Op::WhenReceive, "tubos")), o.blocks.insert(o.blocks.begin() + 1, B(Op::CreateClone));
        s.objs.push_back(music("lib_musica_casual.wav"));
        p.showVars = true;
        p.exportCfg.orient = 1;
        break; }
    case 12: {   // Atrapa frutas
        s = base2("Huerto", 0.5f, 0.85f, 0.95f);
        s.name = "Huerto";
        p.globalVars = {"puntos", "vidas"};
        Obj pasto = mk(Kind::Cube, "Pasto", {0, -470, 0}, {900, 140, 1}, 1, 1, 1); pasto.tex = "lib_tex_pasto.png"; pasto.layer = 1; s.objs.push_back(pasto);
        Obj cesta = mk(Kind::Cube, "Canasta", {0, -380, 0}, {170, 90, 1}, 0.8f, 0.55f, 0.3f); cesta.tex = "lib_tex_madera.png"; cesta.layer = 5;
        cesta.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen), B(Op::WhenButton, "Derecha"), B(Op::ChangeX, "", "13"), B(Op::WhenButton, "Izquierda"), B(Op::ChangeX, "", "-13"),
                        B(Op::WhenTrue, "", "vidas <= 0"), B(Op::Say, "", "'Fin del juego. Puntos: ' + puntos"), B(Op::Wait, "", "2.5"), B(Op::StartScene, "Huerto")};
        s.objs.push_back(cesta);
        Obj fr = mk(Kind::Cube, "Fruta", {0, 560, 0}, {90, 90, 1}, 1, 1, 1);
        fr.tex = "lib_spr_fruta.png"; fr.noColor = true; fr.layer = 4;
        fr.blocks = {B(Op::WhenStart), B(Op::Hide), B(Op::SetVar, "puntos", "0"), B(Op::SetVar, "vidas", "3"), B(Op::Forever), B(Op::Wait, "", "valor aleatorio desde hasta(0.6,1.2)"), B(Op::SetX, "", "valor aleatorio desde hasta(-220,220)"), B(Op::SetY, "", "560"), B(Op::CreateClone), B(Op::LoopEnd),
                     B(Op::WhenCloneStart), B(Op::Show), B(Op::Repeat, "", "125"), B(Op::ChangeY, "", "-9"), B(Op::Wait, "", "0.016"), B(Op::LoopEnd), B(Op::ChangeVar, "vidas", "-1"), B(Op::StartSound, "lib_golpe.wav"), B(Op::DeleteClone),
                     B(Op::WhenCollide, "Canasta"), B(Op::ChangeVar, "puntos", "1"), B(Op::StartSound, "lib_moneda.wav"), B(Op::DeleteClone)};
        s.objs.push_back(fr);
        s.objs.push_back(music("lib_musica_casual.wav"));
        p.ctl2d = 3;
        p.showVars = true;
        p.exportCfg.orient = 1;
        break; }
    case 13: {   // Clicker
        s = base2("Clicker", 0.2f, 0.25f, 0.45f);
        s.name = "Clicker";
        p.globalVars = {"puntos", "mejora", "auto"};
        s.objs.push_back(ctrl("Sistema", {B(Op::WhenStart), B(Op::SetVar, "puntos", "0"), B(Op::SetVar, "mejora", "1"), B(Op::SetVar, "auto", "0"), B(Op::Music, "lib_musica_casual.wav"),
                                          B(Op::Forever), B(Op::Wait, "", "1"), B(Op::ChangeVar, "puntos", "auto"), B(Op::LoopEnd)}));
        Obj big = tap2("Botón gigante", {0, 100, 0}, {420, 420, 1}, 1, 1, 1, "lib_spr_boton.png",
                       {B(Op::WhenTap), B(Op::ChangeVar, "puntos", "mejora"), B(Op::StartSound, "lib_moneda.wav"), B(Op::SetSize, "", "90"), B(Op::Wait, "", "0.06"), B(Op::SetSize, "", "100")});
        s.objs.push_back(big);
        Obj m1 = tap2("Mejora: más puntos por toque", {-120, -330, 0}, {230, 130, 1}, 0.3f, 0.8f, 0.4f, "",
                      {B(Op::WhenTap), B(Op::If, "", "puntos >= mejora * 25"), B(Op::ChangeVar, "puntos", "-(mejora * 25)"), B(Op::ChangeVar, "mejora", "1"), B(Op::StartSound, "lib_campana.wav"), B(Op::Say, "", "'¡Mejora! Ahora ganas ' + mejora + ' por toque'"),
                       B(Op::Else), B(Op::Say, "", "'Necesitas ' + (mejora * 25) + ' puntos'"), B(Op::EndIf)});
        s.objs.push_back(m1);
        Obj m2 = tap2("Mejora: puntos automáticos", {120, -330, 0}, {230, 130, 1}, 0.95f, 0.7f, 0.2f, "",
                      {B(Op::WhenTap), B(Op::If, "", "puntos >= (auto + 1) * 60"), B(Op::ChangeVar, "puntos", "-((auto + 1) * 60)"), B(Op::ChangeVar, "auto", "1"), B(Op::StartSound, "lib_campana.wav"), B(Op::Say, "", "'¡Ahora ganas ' + auto + ' por segundo!'"),
                       B(Op::Else), B(Op::Say, "", "'Necesitas ' + ((auto + 1) * 60) + ' puntos'"), B(Op::EndIf)});
        s.objs.push_back(m2);
        p.showVars = true;
        p.exportCfg.orient = 1;
        break; }
    }
    p.scenes.push_back(s);
    // agrega a el proyecto todo lo que use de la biblioteca (modelos, texturas, sonidos)
    auto need = [&](const std::string& n) { if (n.compare(0, 4, "lib_") == 0) libraryAdd(n, p.assets); };
    need(p.player.model); need(p.weapon.model);
    for (auto& o : p.scenes[0].objs) {
        need(o.tex); need(o.model);
        for (auto& b : o.blocks) need(b.t);
    }
}

}  // namespace forge
