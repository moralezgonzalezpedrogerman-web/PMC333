#pragma once
#include <string>
#include <vector>
#include "scene.h"
namespace forge {
// Biblioteca de P-Maker: modelos 3D, texturas y musica/sonidos hechos por codigo. Se agregan al proyecto al elegirlos.
struct LibItem { std::string name; int kind; };  // kind: 0 textura, 1 sonido, 2 modelo
const std::vector<LibItem>& libraryItems();
bool libraryHas(const std::string& name);
const char* voxLibName(int i);
int voxLibCount();
bool voxLibraryAdd(const std::string& name, Files& assets);
bool libraryAdd(const std::string& name, Files& assets);   // agrega el item (y lo que necesite) si falta
void libraryPrune(Files& assets, const std::string& projectText);  // quita lib_* que nadie usa (al exportar)
}
