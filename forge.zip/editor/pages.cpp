// Paginas del editor (como Pocket Code): Proyecto -> Escenas -> Escena -> Objeto (Scripts / Apariencias / Sonidos),
// editor de bloques con arrastrar y soltar, paleta de bloques por categorias y editor de formulas.
#include "editor.h"
#include "formula.h"
#include "fsutil.h"

#include "imgui.h"
#include "wrapui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <algorithm>
#include <cctype>
#include <cstring>
#include <cmath>
#include <cstdio>

namespace forge {

namespace {

ImVec4 catRGB(Cat c, float k = 1.f) {
    float r = .5f, g = .5f, b = .5f;
    switch (c) {
        case Cat::Eventos: r = .98f; g = .74f; b = .20f; break;
        case Cat::Control: r = .62f; g = .45f; b = .98f; break;
        case Cat::Movimiento: r = .20f; g = .72f; b = .98f; break;
        case Cat::Sonido: r = .98f; g = .40f; b = .66f; break;
        case Cat::Apariencia: r = .55f; g = .88f; b = .30f; break;
        case Cat::Datos: r = .99f; g = .50f; b = .38f; break;
        case Cat::Forge3D: r = .16f; g = .86f; b = .76f; break;
        case Cat::Multijugador: r = .95f; g = .35f; b = .55f; break;
    }
    return ImVec4(r * k, g * k, b * k, 1.f);
}
ImU32 col32(const ImVec4& v) { return ImGui::ColorConvertFloat4ToU32(v); }

std::string shorten(const std::string& s, size_t n = 22) {
    n *= 4;  // los textos largos continuan en el renglon de abajo
    if (s.size() <= n) return s;
    size_t k = n;
    while (k > 0 && ((unsigned char)s[k] & 0xC0) == 0x80) k--;  // no cortar un caracter UTF-8
    return s.substr(0, k) + "..";
}

struct Tok { int type; std::string s; };  // 0 palabra, 1 formula (s = "0".."2"), 2 texto {t}
std::vector<Tok> tokenize(const char* title) {
    std::vector<Tok> v;
    std::string w;
    auto flush = [&]() { if (!w.empty()) { v.push_back({0, w}); w.clear(); } };
    for (const char* p = title; *p; p++) {
        if (*p == ' ') { flush(); continue; }
        if (*p == '{') {
            flush();
            std::string k;
            p++;
            while (*p && *p != '}') k += *p++;
            if (k == "t") v.push_back({2, ""});
            else v.push_back({1, k});
            if (!*p) break;
            continue;
        }
        w += *p;
    }
    flush();
    return v;
}

std::string plainTitle(const OpInfo& in) {
    std::string out;
    for (auto& t : tokenize(in.title)) {
        if (!out.empty()) out += ' ';
        if (t.type == 0) out += t.s;
        else if (t.type == 2) out += in.t && *in.t ? in.t : "...";
        else {
            const char* f = t.s == "0" ? in.f0 : t.s == "1" ? in.f1 : in.f2;
            out += f && *f ? f : "0";
        }
    }
    return out;
}

struct PreviewEnv : FormulaEnv {
    bool lookup(const std::string&, const std::vector<Val>&, Val&) override { return false; }
};

bool gHandle = false;  // un asa de bloque esta pulsada (no desplazar la lista)

}  // namespace

namespace {
struct Preset { int id; const char* name; const char* sub; int group; };  // group: 0 diseno, 1 enemigos, 2 objetos, 3 puertas, 4 niveles
const Preset kPresets[] = {
    {0, "Cubo", "diseño", 0}, {1, "Suelo", "diseño", 0}, {2, "Pared", "diseño", 0}, {3, "Ítem", "decoración", 0},
    {4, "Luz", "lámpara", 0}, {5, "Modelo 3D", "importar", 0}, {25, "Inicio jugador", "dónde empieza", 0},
    {10, "Enemigo", "te persigue", 1}, {11, "Monstruo", "grande y fuerte", 1},
    {12, "Arma", "da munición", 2}, {13, "Munición", "+10 balas", 2}, {14, "Botiquín", "+25 vida", 2},
    {15, "Llave", "la recoges", 2}, {16, "Interruptor", "envía mensaje", 2}, {24, "Cartel", "muestra texto", 2},
    {17, "Puerta horiz.", "se abre al tocar", 3}, {18, "Puerta vert.", "se abre al tocar", 3},
    {19, "Destruible horiz.", "se rompe a tiros", 3}, {20, "Destruible vert.", "se rompe a tiros", 3},
    {21, "Fin de nivel", "cambia de escena", 4}, {22, "Teleport inicio", "te lleva al fin", 4}, {23, "Teleport fin", "destino", 4},
};
Block mkB(Op op, const char* t = "", const char* a = "", const char* b = "", const char* c = "") {
    Block k;
    k.op = op; k.t = t; k.f[0] = a; k.f[1] = b; k.f[2] = c;
    return k;
}
std::string num(float v) {
    char b[32];
    snprintf(b, sizeof b, "%.2f", v);
    std::string s = b;
    while (s.size() > 1 && s.back() == '0') s.pop_back();
    if (!s.empty() && s.back() == '.') s.pop_back();
    return s;
}
}  // namespace

// ---------------------------------------------------------------- bloques (logica)
bool Editor::blockRange(const std::vector<Block>& B, int i, int& end) {
    if (i < 0 || i >= (int)B.size()) return false;
    int k = opInfo(B[i].op).indent;
    if (k == 2) {
        end = i + 1;
        while (end < (int)B.size() && opInfo(B[end].op).indent != 2) end++;
        return true;
    }
    if (k == 1) {
        int d = 0;
        for (int j = i; j < (int)B.size(); j++) {
            int q = opInfo(B[j].op).indent;
            if (q == 1) d++;
            else if (q == -1 && --d == 0) { end = j + 1; return true; }
        }
        end = (int)B.size();
        return true;
    }
    if (k == 0) { end = i + 1; return true; }
    return false;  // cierres y "de lo contrario" no se mueven solos
}

bool Editor::moveRange(std::vector<Block>& B, int from, int to) {
    int e;
    if (!blockRange(B, from, e)) return false;
    if (to < 0 || to > (int)B.size() || (to >= from && to <= e)) return false;
    std::vector<Block> g(B.begin() + from, B.begin() + e);
    B.erase(B.begin() + from, B.begin() + e);
    int t = to > from ? to - (e - from) : to;
    B.insert(B.begin() + t, g.begin(), g.end());
    return true;
}

int Editor::addBlock(Obj& o, Op op) {
    auto make = [](Op x) {
        const OpInfo& in = opInfo(x);
        Block b;
        b.op = x;
        b.t = in.t ? in.t : "";
        b.f[0] = in.f0 ? in.f0 : "";
        b.f[1] = in.f1 ? in.f1 : "";
        b.f[2] = in.f2 ? in.f2 : "";
        return b;
    };
    if (o.blocks.empty() && !isHat(op)) o.blocks.push_back(make(Op::WhenStart));
    int idx = (int)o.blocks.size();
    o.blocks.push_back(make(op));
    if (op == Op::If) {
        o.blocks.push_back(make(Op::Else));
        o.blocks.push_back(make(Op::EndIf));
    } else if (op == Op::Repeat || op == Op::Forever || op == Op::While || op == Op::RepeatUntil) {
        o.blocks.push_back(make(Op::LoopEnd));
    }
    markDirty();
    return idx;
}

// ---------------------------------------------------------------- ayudantes de pagina
bool Editor::tapped() const { return dragAcc_ < ImGui::GetFontSize() * 0.6f; }

void Editor::dragScroll() {
    bool skip = gHandle;
    gHandle = false;
    float fs = ImGui::GetFontSize();
    if (ImGui::GetDragDropPayload()) {  // al arrastrar un bloque, desplazar cerca de los bordes
        ImVec2 m = ImGui::GetIO().MousePos, p = ImGui::GetWindowPos(), s = ImGui::GetWindowSize();
        if (m.x >= p.x && m.x <= p.x + s.x) {
            if (m.y < p.y + fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() - fs * 0.6f);
            else if (m.y > p.y + s.y - fs * 2.5f) ImGui::SetScrollY(ImGui::GetScrollY() + fs * 0.6f);
        }
        return;
    }
    static ImGuiID active = 0;
    static float vel = 0;
    ImGuiID me = ImGui::GetID("##dragscroll");
    // AllowWhenBlockedByActiveItem: se puede arrastrar empezando sobre un boton (antes no deslizaba)
    bool inside = ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem);
    if (!skip && inside && ImGui::IsMouseDragging(0, fs * 0.6f)) {
        float dy = ImGui::GetIO().MouseDelta.y;
        ImGui::SetScrollY(ImGui::GetScrollY() - dy);
        vel = dy;
        active = me;
        return;
    }
    if (active == me && !ImGui::IsMouseDown(0)) {  // un poco de inercia al soltar
        if (std::fabs(vel) > 0.6f) { ImGui::SetScrollY(ImGui::GetScrollY() - vel); vel *= 0.92f; }
        else { vel = 0; active = 0; }
    }
}

bool Editor::beginPage(const char* id) {
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
    bool ok = wrapui::Begin(id, nullptr,
                           ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                               ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus |
                               kNoSB | kNoSW |
                               ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleVar(2);
    return ok;
}

void Editor::endPage() { ImGui::End(); }

bool Editor::topBar(const std::string& title, bool* back, bool* menu) {
    float fs = ImGui::GetFontSize();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float bh = fs * 2.8f;
    ImGui::GetWindowDrawList()->AddRectFilledMultiColor(p, ImVec2(p.x + w_, p.y + bh), IM_COL32(24, 120, 120, 255), IM_COL32(40, 80, 170, 255), IM_COL32(30, 56, 120, 255), IM_COL32(18, 84, 92, 255));
    if (back) *back = false;
    if (menu) *menu = false;
    ImGui::SetCursorScreenPos(ImVec2(p.x + fs * 0.4f, p.y + fs * 0.4f));
    if (back) {
        ImVec2 bp = ImGui::GetCursorScreenPos();
        if (wrapui::Button("<", ImVec2(fs * 2.f, fs * 2.f))) *back = true;
        wrapui::drawIcon(ImGui::GetWindowDrawList(), wrapui::IcBack, ImVec2(bp.x + fs, bp.y + fs), fs * 1.1f, IM_COL32(255, 255, 255, 255));
        ImGui::SameLine();
    }
    ImGui::SetCursorScreenPos(ImVec2(ImGui::GetCursorScreenPos().x + fs * 0.3f, p.y + fs * 0.4f + (fs * 2.f - fs) * 0.5f));
    ImGui::TextUnformatted(shorten(title, 28).c_str());
    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + bh + fs * 0.2f));
    return true;
}

void Editor::fab(bool* play, bool* plus) {
    float fs = ImGui::GetFontSize();
    if (play) *play = false;
    if (plus) *plus = false;
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 0.8f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.f);
    ImGui::Begin("##fab", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground);
    if (play) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.60f, 0.30f, 1.f));
        if (wrapui::Button("Jugar", ImVec2(fs * 4.5f, fs * 3.f))) *play = true;
        ImGui::PopStyleColor();
        if (plus) ImGui::SameLine();
    }
    if (plus) {
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.85f, 1.f));
        if (wrapui::Button("+", ImVec2(fs * 3.f, fs * 3.f))) *plus = true;
        ImGui::PopStyleColor();
    }
    ImGui::End();
}

void Editor::thumb(Renderer* r, const Obj& o, float size) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImU32 c = IM_COL32((int)(o.color[0] * 255), (int)(o.color[1] * 255), (int)(o.color[2] * 255), 255);
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), o.bg || o.kind != Kind::Light ? c : IM_COL32(255, 220, 120, 255), 6.f);
    std::string name = !o.tex.empty() ? o.tex : (!o.looks.empty() ? o.looks[0] : "");
    if (r && !name.empty()) {
        int tw = 1, th = 1;
        unsigned tid = r->textureId(edit_, name, &tw, &th);
        if (tid) {
            float k = std::min(size / tw, size / th);
            float iw = tw * k, ih = th * k;
            ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
            dl->AddImage((ImTextureID)(intptr_t)tid, a, ImVec2(a.x + iw, a.y + ih));
        }
    }
}

std::vector<std::string> Editor::varNames(const Obj& o) const {
    std::vector<std::string> v = edit_.proj.globalVars;
    for (auto& s : o.localVars) v.push_back(s);
    return v;
}

std::vector<std::string> Editor::messageNames() const {
    std::vector<std::string> v;
    for (auto& s : edit_.proj.scenes)
        for (auto& o : s.objs)
            for (auto& b : o.blocks)
                if ((b.op == Op::WhenReceive || b.op == Op::Broadcast || b.op == Op::BroadcastWait) && !b.t.empty() &&
                    std::find(v.begin(), v.end(), b.t) == v.end())
                    v.push_back(b.t);
    if (v.empty()) v.push_back("mensaje1");
    std::sort(v.begin(), v.end());
    return v;
}

void Editor::applyRename() {
    if (!renameBuf_.empty()) {
        if (renameWhat_ == 1 && renameIdx_ >= 0 && renameIdx_ < (int)edit_.proj.scenes.size()) {
            std::string old = edit_.proj.scenes[renameIdx_].name;
            edit_.proj.scenes[renameIdx_].name = renameBuf_;
            for (auto& s : edit_.proj.scenes)  // los bloques "Iniciar escena" siguen apuntando bien
                for (auto& o : s.objs)
                    for (auto& b : o.blocks)
                        if (b.op == Op::StartScene && b.t == old) b.t = renameBuf_;
            markDirty();
        } else if (renameWhat_ == 2 && hasScene() && renameIdx_ >= 0 && renameIdx_ < (int)scene().objs.size()) {
            scene().objs[renameIdx_].name = renameBuf_;
            markDirty();
        }
    }
    renameWhat_ = 0;
}

void Editor::renameUI() {
    if (renameWhat_ <= 0) return;
    if (host_.prompt) {  // Android: directo al cuadro de texto nativo
        if (!promptActive_) {
            promptActive_ = true;
            promptDst_ = &renameBuf_;
            host_.prompt(renameWhat_ == 1 ? "Nombre de la escena" : "Nombre del objeto", renameBuf_);
        }
        return;
    }
    if (!ImGui::IsPopupOpen("Renombrar")) ImGui::OpenPopup("Renombrar");
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.3f), ImGuiCond_Always, ImVec2(0.5f, 0.f));
    if (ImGui::BeginPopupModal("Renombrar", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        textInput("##n", "Nombre", renameBuf_, nullptr, fs * 14.f);
        bool ok = wrapui::Button("Aceptar", ImVec2(fs * 6.f, 0));
        ImGui::SameLine();
        bool no = wrapui::Button("Cancelar", ImVec2(fs * 6.f, 0));
        if (ok) applyRename();
        if (no) renameWhat_ = 0;
        if (ok || no) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

float Editor::drawerW() const {
    float fs = ImGui::GetFontSize();
    return std::min(fs * 17.f, (float)w_ * 0.62f);
}

// Cajón lateral derecho (estilo de las capturas de referencia): pestaña « / » y el menú del proyecto con iconos.
void Editor::projectMenu() {
    float fs = ImGui::GetFontSize();
    if (drawerOpen_ < 0) drawerOpen_ = w_ > h_ * 1.2f ? 1 : 0;
    if (projMenu_) { drawerOpen_ = !drawerOpen_; projMenu_ = false; }
    const float top = fs * 3.4f, tabW = fs * 1.5f, pw = drawerW();
    const ImGuiWindowFlags wf = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                                ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground;
    float x = (float)w_ - (drawerOpen_ ? pw : 0.f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.5f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, fs * 0.5f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.08f, 0.13f, 0.24f, 0.97f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.14f, 0.24f, 0.42f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.35f, 0.60f, 1.f, 0.85f));
    ImGui::SetNextWindowPos(ImVec2(x, top), ImGuiCond_Always, ImVec2(1.f, 0.f));
    ImGui::Begin("##drawertab", nullptr, wf);
    if (wrapui::Button(drawerOpen_ ? ">>##dt" : "<<##dt", ImVec2(tabW, fs * 3.f)) && tapped()) drawerOpen_ = !drawerOpen_;
    ImGui::End();
    if (drawerOpen_) {
        bool doClose = false;
        ImGui::SetNextWindowPos(ImVec2((float)w_, top), ImGuiCond_Always, ImVec2(1.f, 0.f));
        ImGui::SetNextWindowSize(ImVec2(pw, 0.f));
        ImGui::SetNextWindowBgAlpha(0.96f);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.05f, 0.08f, 0.15f, 0.97f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(fs * 0.4f, fs * 0.4f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);
        ImGui::Begin("##drawer", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_AlwaysAutoResize);
        float bw = pw - fs * 0.8f, bh = fs * 2.4f;
        if (wrapui::Button("Guardar", ImVec2(bw, bh)) && tapped()) saveProject();
        if (wrapui::Button("Ayuda", ImVec2(bw, bh)) && tapped()) openHelp();
        if (wrapui::Button("Archivos (imágenes, sonidos, modelos)", ImVec2(bw, bh)) && tapped()) showAssets = true;
        if (wrapui::Button("Estudio de música y efectos", ImVec2(bw, bh)) && tapped()) openMusic();
        if (wrapui::Button("Botones y arma", ImVec2(bw, bh)) && tapped()) showHud = true;
        if (hasScene() && scene().is3d && wrapui::Button("Mundo (cielo y luz)", ImVec2(bw, bh)) && tapped()) showWorld = true;
        if (wrapui::Button("Exportar juego", ImVec2(bw, bh)) && tapped()) showExport_ = true;
        if (wrapui::Button("Cerrar proyecto", ImVec2(bw, bh)) && tapped()) doClose = true;
        ImGui::End();
        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor();
        if (doClose) { if (dirty_) saveProject(); closeProject(); }
    }
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar(3);
}

void Editor::objectMenuItems(int idx) {
    if (!hasScene() || idx < 0 || idx >= (int)scene().objs.size()) return;
    Scene& S = scene();
    Obj& o = S.objs[idx];
    if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 2; renameIdx_ = idx; renameBuf_ = o.name; }
    if (!o.bg) {
        if (ImGui::MenuItem("Duplicar")) {
            Obj c = o;
            c.name = uniqueName(o.name);
            c.pos.x += S.is3d ? 1.f : 40.f;
            S.objs.push_back(c);
            markDirty();
        }
        static int confirm = -1;
        if (confirm == idx) {
            if (ImGui::MenuItem("Confirmar: eliminar")) {
                S.objs.erase(S.objs.begin() + idx);
                sel_ = -1;
                confirm = -1;
                markDirty();
            }
        } else if (ImGui::MenuItem("Eliminar", nullptr, false, true)) {
            confirm = idx;
        }
    }
}

void Editor::newObjectMenu() {
    float fs = ImGui::GetFontSize();
    bool is3d = hasScene() && scene().is3d;
    if (plusOpen_) {
        if (is3d) grid3dOpen_ = true;
        else ImGui::OpenPopup("##plus");
        plusOpen_ = false;
    }
    if (is3d && grid3dOpen_) {  // cuadricula "Objeto nuevo" como en FPS Creator
        modalOpen("Objeto nuevo");
        ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.94f));
        if (ImGui::BeginPopupModal("Objeto nuevo", nullptr,
                                   ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                       ImGuiWindowFlags_NoSavedSettings | kNoSB |
                                       kNoSW)) {
            bool close = false;
            ImGui::TextUnformatted("OBJETO NUEVO");
            ImGui::SameLine(ImGui::GetContentRegionAvail().x - fs * 6.f);
            if (wrapui::Button("Cancelar", ImVec2(fs * 6.f, 0)) && tapped()) close = true;
            ImGui::Separator();
            wrapui::BeginChild("##grid", ImVec2(0, 0), false, kNoSB);
            dragScroll();
            static const char* groups[] = {"DISEÑO", "ENEMIGOS", "OBJETOS", "PUERTAS Y PAREDES", "NIVEL"};
            static const ImVec4 gcol[] = {{0.30f, 0.34f, 0.55f, 1}, {0.60f, 0.20f, 0.20f, 1}, {0.20f, 0.50f, 0.30f, 1},
                                          {0.60f, 0.40f, 0.15f, 1}, {0.25f, 0.45f, 0.60f, 1}};
            float aw = ImGui::GetContentRegionAvail().x;
            int cols = 5;
            float tw = (aw - ImGui::GetStyle().ItemSpacing.x * (cols - 1) - fs * 0.3f) / cols;
            int pick = -1;
            for (int g = 0; g < 5; g++) {
                ImGui::Spacing();
                ImGui::TextDisabled("%s", groups[g]);
                int n = 0;
                for (auto& pr : kPresets) {
                    if (pr.group != g) continue;
                    if (n % cols) ImGui::SameLine();
                    n++;
                    ImGui::PushID(pr.id);
                    ImGui::PushStyleColor(ImGuiCol_Button, gcol[g]);
                    std::string lab = std::string(pr.name) + "\n" + pr.sub;
                    if (wrapui::Button(lab.c_str(), ImVec2(tw, fs * 4.2f)) && tapped()) pick = pr.id;
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
            }
            ImGui::Dummy(ImVec2(1, fs * 3.f));
            ImGui::EndChild();
            if (pick >= 0) {
                if (pick == 5) { grid3dOpen_ = false; ImGui::CloseCurrentPopup(); plusOpen_ = false; modelsOpen_ = true; }
                else { addPreset(pick); close = true; }
            }
            if (close) { grid3dOpen_ = false; ImGui::CloseCurrentPopup(); }
            ImGui::EndPopup();
        } else {
            grid3dOpen_ = false;
        }
    }
    if (modelsOpen_) { ImGui::OpenPopup("##models"); modelsOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopup("##models")) {
        ImGui::TextDisabled("Modelo 3D");
        if (wrapui::Button("+ Importar modelo nuevo (obj, glb, gltf, fbx)", ImVec2(fs * 22.f, fs * 2.4f)) && tapped()) {
            pendingNewModel_ = true;
            if (host_.pickFile) host_.pickFile();
            ImGui::CloseCurrentPopup();
        }
        ImGui::TextDisabled("Si tu modelo es .blend, expórtalo a .glb desde Blender.");
        ImGui::Separator();
        auto models = assetsOf(2);
        if (models.empty()) ImGui::TextDisabled("Aún no hay modelos importados");
        for (auto& m : models)
            if (wrapui::Button(m.c_str(), ImVec2(fs * 22.f, fs * 2.2f)) && tapped()) { addObject(Kind::Model, m); ImGui::CloseCurrentPopup(); }
        ImGui::EndPopup();
    }
    if (is3d) return;
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##plus")) {
        ImGui::TextDisabled("Objeto nuevo");
        ImGui::Separator();
        if (ImGui::MenuItem("Cuadro de color")) addObject(Kind::Cube);
        if (ImGui::MenuItem("Seleccionar una imagen...")) { pendingNewObj_ = true; if (host_.pickFile) host_.pickFile(); }
        if (ImGui::BeginMenu("Biblioteca (imágenes del proyecto)")) {
            auto imgs = assetsOf(0);
            if (imgs.empty()) ImGui::TextDisabled("Aún no hay imágenes");
            for (auto& m : imgs)
                if (ImGui::MenuItem(m.c_str())) {
                    addObject(Kind::Cube);
                    if (Obj* o = selObj()) { o->tex = m; o->color[0] = o->color[1] = o->color[2] = 1.f; }
                }
            ImGui::EndMenu();
        }
        if (ImGui::MenuItem("Objeto vacío (sin imagen)")) {
            addObject(Kind::Cube);
            if (Obj* o = selObj()) { o->visible = false; o->name = uniqueName("Vacio"); }
        }
        ImGui::Separator();
        ImGui::TextDisabled("Dibujar, foto y mochila: próximamente");
        ImGui::EndPopup();
    }
}

// ---------------------------------------------------------------- objetos de juego (como "Creating a new object" de FPS Creator)
void Editor::addPreset(int id) {
    if (!hasScene()) return;
    Scene& S = scene();
    Project& P = edit_.proj;
    auto ensure = [&](const char* g) {
        if (std::find(P.globalVars.begin(), P.globalVars.end(), g) == P.globalVars.end()) P.globalVars.push_back(g);
    };
    switch (id) {
        case 0: addObject(Kind::Cube); return;
        case 1: addObject(Kind::Floor); return;
        case 2: addObject(Kind::Wall); return;
        case 3: addObject(Kind::Item); return;
        case 4: addObject(Kind::Light); return;
        case 5: grid3dOpen_ = false; ImGui::OpenPopup("##models"); return;
        case 25: {
            S.start = {std::round(target_.x), 0.05f, std::round(target_.z)};
            markDirty();
            toast("El jugador empezará aquí");
            return;
        }
    }
    Kind k = Kind::Cube;
    if (id == 12 || id == 13 || id == 14 || id == 15 || id == 21 || id == 22 || id == 23) k = Kind::Item;
    if (id >= 17 && id <= 20) k = Kind::Wall;
    addObject(k);
    Obj* o = selObj();
    if (!o) return;
    auto col = [&](float r, float g, float b) { o->color[0] = r; o->color[1] = g; o->color[2] = b; };
    auto rest = [&](float h) { o->pos.y = h * 0.5f + 0.02f; };
    auto name = [&](const char* n) { o->name = uniqueName(n); };
    o->tex.clear();
    switch (id) {
        case 10: case 11: {  // enemigo / monstruo
            bool mon = id == 11;
            name(mon ? "Monstruo" : "Enemigo");
            o->scale = mon ? V3{1.4f, 2.4f, 1.4f} : V3{0.8f, 1.8f, 0.8f};
            rest(o->scale.y);
            if (mon) col(0.5f, 0.2f, 0.7f); else col(0.8f, 0.15f, 0.15f);
            o->solid = true; o->spin = false;
            ensure("vida"); ensure("puntos");
            AiCfg& a = o->ai;
            a = AiCfg();
            a.type = mon ? AiType::Melee : AiType::Shooter;
            a.hp = mon ? 6.f : 3.f;
            a.speed = mon ? 3.f : 2.f;
            a.dmg = mon ? 10.f : 5.f;
            a.rate = mon ? 0.9f : 1.4f;
            a.reach = mon ? 1.8f : 1.3f;
            a.anim[kIdle].bob = 0.03f;
            a.anim[kWalk].bob = 0.1f; a.anim[kWalk].sway = 6.f;
            a.anim[kAttack].lunge = mon ? 0.5f : 0.15f; a.anim[kAttack].squash = 0.6f;
            a.anim[kHurt].sway = 15.f; a.anim[kHurt].squash = -0.5f;
            o->blocks.clear();
            break;
        }
        case 12: case 13: case 14: case 15: {  // recogibles
            ensure("vida"); ensure("municion"); ensure("llave");
            o->solid = false; o->spin = true;
            if (id == 12) {
                name("Arma"); o->scale = {0.7f, 0.25f, 0.25f}; col(0.55f, 0.55f, 0.65f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "municion", "15"),
                             mkB(Op::Say, "", "Arma recogida (+15 munición)"), mkB(Op::Destroy)};
            } else if (id == 13) {
                name("Municion"); o->scale = {0.4f, 0.3f, 0.3f}; col(0.9f, 0.7f, 0.2f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "municion", "10"),
                             mkB(Op::Say, "", "+10 munición"), mkB(Op::Destroy)};
            } else if (id == 14) {
                name("Botiquin"); o->scale = {0.5f, 0.4f, 0.5f}; col(0.95f, 0.95f, 0.95f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::ChangeVar, "vida", "25"),
                             mkB(Op::If, "", "\"vida\" > 100"), mkB(Op::SetVar, "vida", "100"), mkB(Op::Else), mkB(Op::EndIf),
                             mkB(Op::Say, "", "+25 vida"), mkB(Op::Destroy)};
            } else {
                name("Llave"); o->scale = {0.3f, 0.3f, 0.5f}; col(1.f, 0.82f, 0.1f);
                o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::SetVar, "llave", "1"),
                             mkB(Op::Say, "", "¡Tienes la llave!"), mkB(Op::Destroy)};
            }
            o->pos.y = o->scale.y * 0.5f + 0.6f;
            break;
        }
        case 16:  // interruptor
            name("Interruptor");
            o->scale = {0.4f, 0.8f, 0.25f}; rest(o->scale.y); col(0.8f, 0.2f, 0.2f);
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::Broadcast, "interruptor1"), mkB(Op::Say, "", "Interruptor activado")};
            break;
        case 24:  // cartel
            name("Cartel");
            o->scale = {1.0f, 0.7f, 0.1f}; o->pos.y = 1.3f; col(0.85f, 0.7f, 0.45f);
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::Say, "", "Escribe aquí tu mensaje")};
            break;
        case 17: case 18: {  // puertas
            ensure("llave");
            name(id == 17 ? "PuertaH" : "PuertaV");
            o->scale = {3.f, 2.6f, 0.3f}; o->yaw = id == 17 ? 0.f : 90.f; rest(o->scale.y); col(0.55f, 0.35f, 0.2f);
            o->solid = true; o->spin = false;
            o->blocks = {mkB(Op::WhenInteract), mkB(Op::SetSolid, "", "0"),
                         mkB(Op::Repeat, "", "20"), mkB(Op::ChangeY, "", "0.13"), mkB(Op::Wait, "", "0.02"), mkB(Op::LoopEnd),
                         mkB(Op::Wait, "", "3"),
                         mkB(Op::Repeat, "", "20"), mkB(Op::ChangeY, "", "-0.13"), mkB(Op::Wait, "", "0.02"), mkB(Op::LoopEnd),
                         mkB(Op::SetSolid, "", "1")};
            break;
        }
        case 19: case 20:  // destruibles
            name(id == 19 ? "DestruibleH" : "DestruibleV");
            o->scale = {3.f, 2.6f, 0.4f}; o->yaw = id == 19 ? 0.f : 90.f; rest(o->scale.y); col(0.6f, 0.6f, 0.65f);
            o->solid = true; o->spin = false;
            o->localVars = {"salud"};
            o->blocks = {mkB(Op::WhenStart), mkB(Op::SetVar, "salud", "3"),
                         mkB(Op::WhenShot), mkB(Op::ChangeVar, "salud", "-1"),
                         mkB(Op::If, "", "\"salud\" <= 0"), mkB(Op::BreakApart, "", "10"), mkB(Op::Else), mkB(Op::EndIf)};
            break;
        case 21: {  // fin de nivel
            name("FinNivel");
            o->scale = {1.4f, 2.2f, 1.4f}; o->pos.y = 1.1f; col(0.2f, 0.85f, 0.35f);
            o->solid = false; o->spin = true;
            std::string next = S.name;
            for (size_t i = 0; i + 1 < P.scenes.size(); i++) if (&P.scenes[i] == &S) next = P.scenes[i + 1].name;
            o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::Say, "", "¡Nivel completado!"), mkB(Op::StartScene, next.c_str())};
            break;
        }
        case 22: case 23: {  // teletransportes
            bool ini = id == 22;
            name(ini ? "TeleportInicio" : "TeleportFin");
            o->scale = {1.2f, 0.2f, 1.2f}; o->pos.y = 0.12f; o->solid = false; o->spin = false;
            if (ini) col(0.2f, 0.8f, 0.9f); else col(0.7f, 0.3f, 0.9f);
            if (ini) o->blocks = {mkB(Op::WhenCollide, "Jugador"), mkB(Op::TeleportPlayer, "", num(S.start.x).c_str(), "0.05", num(S.start.z).c_str())};
            // une inicio y fin si ya existen los dos
            Obj *a = nullptr, *b = nullptr;
            for (auto& x : S.objs) {
                if (x.name.rfind("TeleportInicio", 0) == 0) a = &x;
                if (x.name.rfind("TeleportFin", 0) == 0) b = &x;
            }
            if (a && b && a->blocks.size() >= 2) {
                a->blocks[1].f[0] = num(b->pos.x);
                a->blocks[1].f[1] = num(b->pos.y + 0.05f);
                a->blocks[1].f[2] = num(b->pos.z);
            }
            break;
        }
    }
    markDirty();
}

// ---------------------------------------------------------------- pagina: escenas del proyecto
// Filas con borde azul brillante (estilo de las capturas de referencia)
static void pushSciRows() {
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.6f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, ImGui::GetFontSize() * 0.55f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.07f, 0.12f, 0.22f, 0.96f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.12f, 0.21f, 0.38f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.16f, 0.30f, 0.52f, 1.f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.36f, 0.62f, 1.f, 0.9f));
}
static void popSciRows() { ImGui::PopStyleColor(4); ImGui::PopStyleVar(2); }
// texto girado 90 grados (se lee de abajo hacia arriba), centrado en c
static void vtext(ImDrawList* dl, ImVec2 c, const char* t, ImU32 col) {
    ImVec2 ts = ImGui::CalcTextSize(t);
    int v0 = dl->VtxBuffer.Size;
    dl->AddText(ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), col, t);
    for (int i = v0; i < dl->VtxBuffer.Size; i++) { ImVec2 q = dl->VtxBuffer[i].pos; dl->VtxBuffer[i].pos = ImVec2(c.x + (q.y - c.y), c.y - (q.x - c.x)); }
}

void Editor::pageScenes(Renderer* r) {
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    beginPage("##scenes");
    bool back, menu;
    topBar(name_.empty() ? "Proyecto" : name_, &back, &menu);
    if (back) { if (dirty_) saveProject(); ImGui::End(); closeProject(); return; }
    if (menu) projMenu_ = true;

    wrapui::BeginChild("##list", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    ImGui::Indent(fs * 0.6f);
    ImGui::TextDisabled("Escenas  (toca para abrir; mantén presionada y desliza para moverla; si no la mueves, se abre su menú)");
    static int sLongPress = -1, sOpenMenu = -1;
    if (!ImGui::IsMouseDown(0) && !ImGui::IsMouseReleased(0)) sLongPress = -1;
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8.f, 5.f));
    pushSciRows();
    float bw = (float)w_ - fs * 1.2f - (drawerOpen_ > 0 ? drawerW() : fs * 1.5f);
    int act = -1, actKind = 0;
    const bool reordering = sceneHold_ >= 0;
    int dropTo = -1;
    sceneRows_.resize(edit_.proj.scenes.size());
    if (reordering) {
        gHandle = true;  // mientras se mueve una escena la lista no se desliza
        ImVec2 m = ImGui::GetIO().MousePos, wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
        if (m.y < wp.y + fs * 3.f) ImGui::SetScrollY(ImGui::GetScrollY() - fs * 0.5f);
        else if (m.y > wp.y + ws.y - fs * 3.f) ImGui::SetScrollY(ImGui::GetScrollY() + fs * 0.5f);
        for (int j = 0; j < (int)sceneRows_.size(); j++)
            if (m.y >= sceneRows_[j].first && m.y < sceneRows_[j].second) dropTo = j;
    }
    for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
        Scene& s = edit_.proj.scenes[i];
        ImGui::PushID(i);
        std::string lab = s.name + (i == 0 ? "   (inicio)" : "") + (s.is3d ? "   [3D]" : "   [2D]") + "   " + std::to_string(s.objs.size()) + " obj.";
        bool held = reordering && sceneHold_ == i;
        if (held) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.62f, 0.55f, 1.f));
        bool hit = wrapui::Button(lab.c_str(), ImVec2(bw, fs * 2.8f));
        if (held) ImGui::PopStyleColor();
        ImVec2 rmin = ImGui::GetItemRectMin(), rmax = ImGui::GetItemRectMax();
        sceneRows_[i] = {rmin.y, rmax.y + ImGui::GetStyle().ItemSpacing.y};
        if (reordering && dropTo == i && sceneHold_ != i)  // linea que marca donde caera
            ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(rmin.x, sceneHold_ < i ? rmax.y : rmin.y - 3.f), ImVec2(rmax.x, sceneHold_ < i ? rmax.y + 3.f : rmin.y), IM_COL32(46, 217, 189, 255), 2.f);
        // pulsacion larga: abre el menu de la escena (renombrar, duplicar, mover, eliminar)
        bool lp = false;
        if (!reordering && ImGui::IsItemActive() && ImGui::GetIO().MouseDownDuration[0] > 0.45f && dragAcc_ < fs * 0.6f && sLongPress != i) {
            sLongPress = i; lp = true;
            if (host_.vibrate) host_.vibrate(0.03f);
            sceneHold_ = i;  // mantener y deslizar = mover; soltar sin mover = menú
        }
        if (sOpenMenu == i) { sOpenMenu = -1; ImGui::OpenPopup("m"); }
        if (hit && tapped() && !reordering && !lp && sLongPress != i) { setScene(i); page_ = Page::SceneHome; }
        if (ImGui::BeginPopup("m")) {
            ImGui::TextDisabled("%s", s.name.c_str());
            if (ImGui::MenuItem("Renombrar")) { renameWhat_ = 1; renameIdx_ = i; renameBuf_ = s.name; }
            if (ImGui::MenuItem("Ajustes de esta escena (mundo, cielo, clima, linterna...)")) { setScene(i); page_ = Page::SceneHome; showWorld = true; }
            if (ImGui::MenuItem("Ajustes de todo el proyecto (orientación, botones, controles)")) { setScene(i); page_ = Page::SceneHome; showHud = true; }
            if (ImGui::MenuItem("Duplicar")) { act = i; actKind = 1; }
            if (i > 0 && ImGui::MenuItem("Subir (mover antes)")) { act = i; actKind = 3; }
            if (i + 1 < (int)edit_.proj.scenes.size() && ImGui::MenuItem("Bajar (mover después)")) { act = i; actKind = 4; }
            if (edit_.proj.scenes.size() > 1 && ImGui::MenuItem("Eliminar")) { act = i; actKind = 2; }
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
    popSciRows();
    ImGui::PopStyleVar();
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::Unindent(fs * 0.6f);
    ImGui::EndChild();

    if (sceneHold_ >= 0 && !ImGui::IsMouseDown(0)) {  // al soltar: la escena se mueve a la fila donde quedo
        int from = sceneHold_, to = dropTo;
        sceneHold_ = -1;
        if (dragAcc_ < fs * 0.6f || to == from) sOpenMenu = from;  // no se movió: menú de la escena
        else if (to >= 0 && to != from && from < (int)edit_.proj.scenes.size()) {
            auto& v = edit_.proj.scenes;
            std::string cur = sceneIdx_ >= 0 && sceneIdx_ < (int)v.size() ? v[sceneIdx_].name : "";
            Scene moved = std::move(v[from]);
            v.erase(v.begin() + from);
            v.insert(v.begin() + to, std::move(moved));
            for (int j = 0; j < (int)v.size(); j++) if (v[j].name == cur) sceneIdx_ = j;
            edit_.bindScene(sceneIdx_);
            markDirty();
        }
    }
    if (act >= 0 && actKind == 1) {
        Scene c = edit_.proj.scenes[act];
        c.name += "_copia";
        edit_.proj.scenes.push_back(c);
        markDirty();
    } else if (act >= 0 && (actKind == 3 || actKind == 4)) {
        int j = actKind == 3 ? act - 1 : act + 1;
        std::swap(edit_.proj.scenes[act], edit_.proj.scenes[j]);
        if (sceneIdx_ == act) sceneIdx_ = j;
        else if (sceneIdx_ == j) sceneIdx_ = act;
        markDirty();
    } else if (act >= 0 && actKind == 2) {
        edit_.proj.scenes.erase(edit_.proj.scenes.begin() + act);
        setScene(0);
        markDirty();
    }
    renameUI();
    projectMenu();
    if (plusOpen_) { ImGui::OpenPopup("##newscene"); plusOpen_ = false; }
    ImGui::SetNextWindowPos(ImVec2((float)w_ - fs * 0.8f, (float)h_ - fs * 4.4f), ImGuiCond_Always, ImVec2(1.f, 1.f));
    if (ImGui::BeginPopup("##newscene")) {
        if (ImGui::MenuItem("Escena 2D (menús, juegos planos)")) addScene(false);
        if (ImGui::MenuItem("Escena 3D (niveles en primera persona)")) addScene(true);
        ImGui::EndPopup();
    }
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: una escena (fondo y objetos)
void Editor::pageSceneHome(Renderer* r) {
    if (!hasScene()) { page_ = Page::Scenes; return; }
    if (r) r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    float fs = ImGui::GetFontSize();
    Scene& S = scene();
    beginPage("##scene");
    bool back, menu;
    topBar(S.name + (S.is3d ? "  [3D]" : "  [2D]"), &back, &menu);
    if (back) { page_ = Page::Scenes; sel_ = -1; }
    if (menu) projMenu_ = true;

    wrapui::BeginChild("##objs", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    float rightPad = (drawerOpen_ > 0 ? drawerW() : fs * 1.5f);
    float tabW = fs * 2.6f;
    float bw = (float)w_ - fs * 1.0f - rightPad - tabW;
    float row = fs * 2.9f;
    ImVec2 top0 = ImGui::GetCursorScreenPos();
    pushSciRows();
    ImGui::Indent(fs * 0.4f);
    if (wrapui::Button("Editar la escena (ver y colocar objetos)", ImVec2(bw + tabW, fs * 2.6f)) && tapped()) {
        resetView();
        page_ = Page::Viewport;
    }
    ImGui::Unindent(fs * 0.4f);
    popSciRows();
    ImGui::Spacing();
    // pestañas verticales: Mundo / Objetos
    ImVec2 tabTop = ImGui::GetCursorScreenPos();
    {
        static const char* tn[2] = {"Mundo", "Objetos"};
        float th = fs * 6.5f;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        for (int i = 0; i < 2; i++) {
            ImGui::SetCursorScreenPos(ImVec2(tabTop.x + fs * 0.1f, tabTop.y + i * (th + fs * 0.3f)));
            ImGui::PushID(7000 + i);
            bool hit = ImGui::InvisibleButton("##tab", ImVec2(tabW, th)) && tapped();
            ImVec2 a0 = ImGui::GetItemRectMin(), b0 = ImGui::GetItemRectMax();
            bool on = homeTab_ == i;
            dl->AddRectFilled(a0, b0, on ? IM_COL32(24, 52, 100, 255) : IM_COL32(14, 22, 40, 255), fs * 0.5f, ImDrawFlags_RoundCornersLeft);
            dl->AddRect(a0, b0, on ? IM_COL32(110, 170, 255, 255) : IM_COL32(60, 90, 140, 200), fs * 0.5f, ImDrawFlags_RoundCornersLeft, 1.5f);
            vtext(dl, ImVec2((a0.x + b0.x) * 0.5f, (a0.y + b0.y) * 0.5f), tn[i], on ? IM_COL32(255, 255, 255, 255) : IM_COL32(170, 190, 220, 255));
            if (hit) homeTab_ = i;
            ImGui::PopID();
        }
    }
    ImGui::SetCursorScreenPos(ImVec2(tabTop.x + tabW + fs * 0.4f, tabTop.y));
    ImGui::BeginGroup();
    auto isWorld = [&](const Obj& o) { return S.is3d ? (o.kind == Kind::Floor || o.kind == Kind::Light) : o.bg; };
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.85f, 0.9f, 1.f, 1.f));
    ImGui::TextUnformatted(homeTab_ == 0 ? (S.is3d ? "Mundo" : "Fondo") : "Actores y objetos  (mantén presionado uno para renombrar, copiar o eliminar)");
    ImGui::PopStyleColor();
    pushSciRows();
    if (homeTab_ == 0 && S.is3d && wrapui::Button("Cielo, luz y sombras", ImVec2(bw, fs * 2.6f)) && tapped()) showWorld = true;
    static int sLongObj = -1;
    if (!ImGui::IsMouseDown(0) && !ImGui::IsMouseReleased(0)) sLongObj = -1;
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0.f, 6.f));
    for (int i = 0; i < (int)S.objs.size(); i++) {
        if (isWorld(S.objs[i]) != (homeTab_ == 0)) continue;
        ImGui::PushID(i);
        ImVec2 r0 = ImGui::GetCursorScreenPos();
        bool hit = wrapui::Button("##row", ImVec2(bw, row));
        bool lp = false;
        if (ImGui::IsItemActive() && ImGui::GetIO().MouseDownDuration[0] > 0.45f && dragAcc_ < fs * 0.6f && sLongObj != i) {
            sLongObj = i; lp = true;
            if (host_.vibrate) host_.vibrate(0.03f);
            ImGui::OpenPopup("m");
        }
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 save = ImGui::GetCursorScreenPos();
        ImGui::SetCursorScreenPos(ImVec2(r0.x + 2.f, r0.y + 2.f));
        thumb(r, S.objs[i], row - 4.f);
        ImGui::SetCursorScreenPos(save);
        float nx = r0.x + row + fs * 0.6f;
        std::string nm = S.objs[i].name + (S.objs[i].visible ? "" : "  (oculto)");
        std::string bl = std::to_string(S.objs[i].blocks.size()) + " bloques";
        ImVec2 bs = ImGui::CalcTextSize(bl.c_str());
        float ty = r0.y + (row - fs) * 0.5f;
        dl->AddLine(ImVec2(r0.x + row, r0.y + 4.f), ImVec2(r0.x + row, r0.y + row - 4.f), IM_COL32(90, 130, 200, 160));
        dl->AddText(ImVec2(nx, ty), IM_COL32(240, 245, 255, 255), nm.c_str());
        float bx = r0.x + bw - bs.x - fs * 0.8f;
        dl->AddLine(ImVec2(bx - fs * 0.5f, r0.y + 4.f), ImVec2(bx - fs * 0.5f, r0.y + row - 4.f), IM_COL32(90, 130, 200, 160));
        dl->AddText(ImVec2(bx, ty), IM_COL32(200, 215, 240, 255), bl.c_str());
        if (hit && tapped() && !lp && sLongObj != i) openObject(i);
        if (ImGui::BeginPopup("m")) { ImGui::TextDisabled("%s", S.objs[i].name.c_str()); objectMenuItems(i); ImGui::EndPopup(); }
        ImGui::PopID();
    }
    ImGui::PopStyleVar();
    popSciRows();
    ImGui::EndGroup();
    (void)top0;
    ImGui::Dummy(ImVec2(1, fs * 5.f));
    ImGui::EndChild();

    renameUI();
    projectMenu();
    newObjectMenu();
    endPage();
    bool pl = false, pu = false;
    fab(&pl, &pu);
    if (pu) plusOpen_ = true;
    if (pl) startPlay();
    worldWin();
    assetsWin();
    hudWin(r);
}

// ---------------------------------------------------------------- pagina: objeto (Scripts / Apariencias / Sonidos)
void Editor::pageObject(Renderer* r) {
    Obj* o = currentObj();
    if (!o) { page_ = Page::SceneHome; return; }
    // la escena se ve de fondo; el programa del objeto es una ventana flotante (las demas ventanas se cierran)
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
    } else if (r) {
        r->clear(w_, h_, 0.09f, 0.10f, 0.14f);
    }
    showObjs = showProps = showWorld = showHud = showAssets = false;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.36f, fs * 0.6f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.62f, h_ * 0.94f), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSizeConstraints(ImVec2(fs * 16.f, fs * 14.f), ImVec2((float)w_, (float)h_));
    bool open = true;
    std::string title = "Programa de: " + o->name + "###objwin";
    bool modal = false;
    if (wrapui::Begin(title.c_str(), &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings |
                                             kNoSB | kNoSW)) {
        wrapui::CloseBar(&open);
        if (wrapui::Button("Renombrar") && tapped()) { renameWhat_ = 2; renameIdx_ = sel_; renameBuf_ = o->name; }
        wrapui::Next("Ver escena");
        if (wrapui::Button("Ver escena") && tapped()) { resetView(); page_ = Page::Viewport; }
        ImGui::SameLine();
        bool doPlay = wrapui::Button("Jugar") && tapped();
        if (tab_ == 0) {
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.85f, 1.f));
            if (wrapui::Button("+ Añadir bloque") && tapped()) pal_ = -1;
            ImGui::PopStyleColor();
        }
        const char* names[3] = {"Scripts", "Apariencias", "Sonidos"};
        float tw = ImGui::GetContentRegionAvail().x / 3.f;
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine(0, 0);
            ImGui::PushStyleColor(ImGuiCol_Button, tab_ == i ? ImVec4(0.20f, 0.45f, 0.85f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (wrapui::Button(names[i], ImVec2(tw, fs * 2.2f)) && tapped()) tab_ = i;
            ImGui::PopStyleColor();
        }
        wrapui::BeginChild("##content", ImVec2(0, 0), false, kNoSB);
        dragScroll();
        ImGui::Indent(fs * 0.3f);
        if (tab_ == 0) scriptsTab(*o);
        else if (tab_ == 1) looksTab(*o, r);
        else soundsTab(*o);
        ImGui::Unindent(fs * 0.3f);
        ImGui::EndChild();
        renameUI();
        if (tab_ == 0) {  // ventanas emergentes: formulas, elegir texto, paleta de bloques
            if (fe_.open) { formulaPage(*o); modal = true; }
            else if (te_.open) { choosePage(*o); modal = true; }
            else if (pal_ != -2) { palettePage(*o); modal = true; }
        }
        if (doPlay) { ImGui::End(); startPlay(); return; }
    }
    ImGui::End();
    (void)modal;
    if (!open) { fe_.open = te_.open = false; pal_ = -2; page_ = Page::SceneHome; }
}

// ---------------------------------------------------------------- pestana Scripts
void Editor::scriptsTab(Obj& o) {
    float fs = ImGui::GetFontSize();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    std::vector<Block>& B = o.blocks;
    int pFrom = -1, pTo = -1, delIdx = -1, dupIdx = -1;

    if (B.empty()) {
        ImGui::Spacing();
        ImGui::TextWrapped("Este objeto no tiene bloques. Toca + para añadir (empieza con un bloque de evento, por ejemplo \"Cuando se inicie la escena\").");
    }
    int depth = 0;
    const float pad = fs * 0.7f;
    const float step = fs * 1.1f;
    std::vector<ImVec4> openCols;  // color de cada bucle / "si" abierto (rieles de la izquierda)
    ImVec4 prevCol(1, 1, 1, 1);
    if (!B.empty()) ImGui::Dummy(ImVec2(1, fs * 0.5f));
    for (int i = 0; i < (int)B.size(); i++) {
        Block& b = B[i];
        const OpInfo& in = opInfo(b.op);
        int k = in.indent;
        if (k == 2) openCols.clear();
        int lvl = (k == 2) ? 0 : ((k == -1 || k == 3) ? depth - 1 : depth);
        if (lvl < 0) lvl = 0;
        if (k == 2) depth = 0;
        else if (k == -1) depth = std::max(0, depth - 1);
        else if (k == 1) depth++;
        float ind = lvl * fs * 1.1f;

        ImGui::PushID(i);
        float availX = ImGui::GetContentRegionAvail().x;
        float rowX = ImGui::GetCursorScreenPos().x;
        float xr = rowX + availX - pad;
        dl->ChannelsSplit(2);
        dl->ChannelsSetCurrent(1);
        ImGui::BeginGroup();
        ImGui::Indent(ind + pad);
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        bool first = true;
        bool draggable = (k == 2 || k == 0 || k == 1);
        if (draggable) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.22f));
            wrapui::Button("=", ImVec2(fs * 1.7f, fs * 1.7f));
            ImGui::PopStyleColor();
            if (ImGui::IsItemActive()) gHandle = true;
            if (ImGui::IsItemDeactivated() && ImGui::IsItemHovered() && tapped() && !ImGui::GetDragDropPayload()) ImGui::OpenPopup("bm");
            if (ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID)) {
                ImGui::SetDragDropPayload("BLK", &i, sizeof(int));
                ImGui::Text("%s", plainTitle(in).c_str());
                ImGui::EndDragDropSource();
            }
            first = false;
        }
        // textos y campos
        for (auto& t : tokenize(in.title)) {
            std::string lab;
            float wd;
            if (t.type == 0) {
                wd = ImGui::CalcTextSize(t.s.c_str()).x;
            } else {
                lab = t.type == 2 ? (b.t.empty() ? "(elegir)" : shorten(b.t))
                                  : (b.f[t.s[0] - '0'].empty() ? " " : shorten(b.f[t.s[0] - '0']));
                wd = ImGui::CalcTextSize(lab.c_str()).x + ImGui::GetStyle().FramePadding.x * 2.f;
            }
            if (!first) {
                float x2 = ImGui::GetItemRectMax().x + ImGui::GetStyle().ItemSpacing.x + wd;
                if (x2 < xr) ImGui::SameLine();
            } else {
                first = false;
            }
            if (t.type == 0) {
                ImGui::AlignTextToFramePadding();
                ImGui::TextUnformatted(t.s.c_str());
            } else {
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(1, 1, 1, 0.28f));
                ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 0.40f));
                ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(1, 1, 1, 0.50f));
                ImGui::PushID(t.type == 2 ? 9 : t.s[0] - '0');
                bool hit = wrapui::Button(lab.c_str());
                ImGui::PopID();
                ImGui::PopStyleColor(3);
                if (hit && tapped()) {
                    if (t.type == 2) { te_.open = true; te_.blk = i; te_.buf = b.t; }
                    else { fe_.open = true; fe_.blk = i; fe_.field = t.s[0] - '0'; fe_.buf = b.f[fe_.field]; formulaList_ = 0; }
                }
            }
        }
        if (ImGui::BeginPopup("bm")) {
            ImGui::PushTextWrapPos(fs * 22.f);
            ImGui::TextUnformatted(in.help);
            ImGui::PopTextWrapPos();
            ImGui::Separator();
            if (ImGui::MenuItem("Duplicar")) dupIdx = i;
            if (ImGui::MenuItem("Eliminar")) delIdx = i;
            ImGui::EndPopup();
        }
        ImGui::Dummy(ImVec2(1, fs * 0.1f));
        ImGui::Unindent(ind + pad);
        ImGui::EndGroup();
        ImVec2 mn = ImGui::GetItemRectMin(), mx = ImGui::GetItemRectMax();
        if (ImGui::BeginDragDropTarget()) {
            if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = i; }
            ImGui::EndDragDropTarget();
        }
        dl->ChannelsSetCurrent(0);
        bool isHatB = (k == 2);
        bool connected = i > 0 && !isHatB;
        bool nextHat = i + 1 >= (int)B.size() || isHat(B[i + 1].op);
        ImVec4 c = catRGB(in.cat, 1.f);
        if (k == -1 && !openCols.empty()) c = openCols.back();
        float rx0 = mn.x - pad, rx1 = xr + pad;
        ImVec4 body(c.x * 0.20f + 0.07f, c.y * 0.20f + 0.08f, c.z * 0.20f + 0.10f, 1.f);  // tarjeta oscura teñida
        for (int j = 0; j < lvl && j < (int)openCols.size(); j++) {  // rieles de color de los bucles
            ImVec4 rc = openCols[j];
            dl->AddRectFilled(ImVec2(rowX + j * step, mn.y), ImVec2(rowX + j * step + fs * 0.35f, mx.y + 1.f), col32(rc));
        }
        ImDrawFlags fl = ImDrawFlags_RoundCornersNone;
        float rr = 0.f;
        if (isHatB) { fl = nextHat ? ImDrawFlags_RoundCornersAll : ImDrawFlags_RoundCornersTop; rr = 16.f; }
        else if (k == -1 || nextHat) { fl = ImDrawFlags_RoundCornersBottom; rr = 12.f; }
        dl->AddRectFilled(ImVec2(rx0, mn.y), ImVec2(rx1, mx.y), col32(body), rr, fl);
        // barra de color a la izquierda + brillo fino arriba
        dl->AddRectFilled(ImVec2(rx0, mn.y), ImVec2(rx0 + fs * 0.4f, mx.y), col32(c), rr, fl & ~ImDrawFlags_RoundCornersRight);
        dl->AddLine(ImVec2(rx0 + fs * 0.6f, mn.y + 0.5f), ImVec2(rx1 - 3.f, mn.y + 0.5f), IM_COL32(255, 255, 255, 18), 1.f);
        if (isHatB) {  // evento: etiqueta luminosa arriba a la izquierda
            dl->AddRectFilled(ImVec2(rx0 + fs * 0.9f, mn.y - fs * 0.30f), ImVec2(rx0 + fs * 3.6f, mn.y + 2.f), col32(c), 9.f, ImDrawFlags_RoundCornersTop);
        } else if (connected) {  // conector: pastilla del color del bloque anterior
            float cx = rx0 + fs * 1.6f;
            dl->AddRectFilled(ImVec2(cx - fs * 0.7f, mn.y - 1.f), ImVec2(cx + fs * 0.7f, mn.y + fs * 0.22f), col32(prevCol), 4.f, ImDrawFlags_RoundCornersBottom);
        }
        if (k == 1) openCols.push_back(c);
        if (k == -1 && !openCols.empty()) openCols.pop_back();
        prevCol = c;
        dl->ChannelsMerge();
        ImGui::PopID();
        if (!nextHat) ImGui::SetCursorPosY(ImGui::GetCursorPosY() - ImGui::GetStyle().ItemSpacing.y);  // bloques pegados
        else ImGui::Dummy(ImVec2(1, fs * 1.2f));                                                        // entre guiones
    }
    // zona final: soltar aqui = al final de la lista
    ImGui::Dummy(ImVec2(ImGui::GetContentRegionAvail().x, fs * 3.f));
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* pl = ImGui::AcceptDragDropPayload("BLK")) { pFrom = *(const int*)pl->Data; pTo = (int)B.size(); }
        ImGui::EndDragDropTarget();
    }
    ImGui::Dummy(ImVec2(1, fs * 4.f));

    if (pFrom >= 0 && pFrom < (int)B.size()) {
        bool okDrop = true;
        if (isHat(B[pFrom].op) && pTo < (int)B.size() && !isHat(B[pTo].op)) okDrop = false;  // los guiones solo entre guiones
        if (okDrop && moveRange(B, pFrom, pTo)) markDirty();
    }
    if (dupIdx >= 0 && dupIdx < (int)B.size()) {
        int e;
        if (blockRange(B, dupIdx, e)) {
            std::vector<Block> g(B.begin() + dupIdx, B.begin() + e);
            B.insert(B.begin() + e, g.begin(), g.end());
            markDirty();
        }
    }
    if (delIdx >= 0 && delIdx < (int)B.size()) {
        int e;
        if (blockRange(B, delIdx, e)) {
            B.erase(B.begin() + delIdx, B.begin() + e);
            markDirty();
        }
    }
}

// ---------------------------------------------------------------- texto (teclado del telefono)
bool Editor::textInput(const char* id, const char* title, std::string& s, const char* hint, float width) {
    if (width <= 0.f) width = ImGui::GetContentRegionAvail().x;
    if (host_.prompt) {  // Android: cuadro de texto nativo con el teclado del telefono
        bool empty = s.empty();
        std::string lab = shorten(empty ? (hint ? hint : "(toca para escribir)") : s, 60) + "##" + id;
        ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.f, 0.5f));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.10f, 0.12f, 0.18f, 1.f));
        if (empty) ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 0.45f));
        bool hit = wrapui::Button(lab.c_str(), ImVec2(width, 0));
        if (empty) ImGui::PopStyleColor();
        ImGui::PopStyleColor();
        ImGui::PopStyleVar();
        if (hit && tapped() && !promptActive_) {
            promptDst_ = &s;
            promptActive_ = true;
            host_.prompt(title ? title : "", s);
        }
        return false;
    }
    ImGui::SetNextItemWidth(width);
    return ImGui::InputTextWithHint(id, hint ? hint : "", &s);
}

void Editor::onText(const std::string& text, bool ok) {
    std::string* d = promptDst_;
    promptDst_ = nullptr;
    promptActive_ = false;
    if (!d) return;
    float* pn = promptNum_;
    promptNum_ = nullptr;
    if (ok) {
        *d = text;
        markDirty();
        if (d == &numBuf_ && pn) {  // numero escrito con el teclado
            std::string t = text;
            for (auto& c : t) if (c == ',') c = '.';
            char* end = nullptr;
            float val = strtof(t.c_str(), &end);
            if (end != t.c_str()) *pn = std::max(promptLo_, std::min(promptHi_, val));
        }
        if (d == &renameBuf_ && renameWhat_ > 0) applyRename();
    } else if (d == &renameBuf_) {
        renameWhat_ = 0;
    }
}

void Editor::modalOpen(const char* name) {
    if (!ImGui::IsPopupOpen(name)) ImGui::OpenPopup(name);
}

// ---------------------------------------------------------------- paleta de bloques (ventana emergente)

// ---------------------------------------------------------------- recetas: torres de bloques sugeridas al buscar
namespace {
struct Recipe { const char* title; const char* what; const char* words; const char* steps; };
// steps: bloques separados por "|"; cada uno: clave[=f0;f1;f2][@texto]
const Recipe kRecipes[] = {
    {"Mover con los controles 2D (derecha)", "Con los controles 2D activados (Proyecto > Botones): mueve el objeto a la derecha mientras se mantenga. Haz otro igual con Izquierda (Incrementar X en -8).", "controles botones mover personaje jugador 2d plataforma izquierda derecha teclado", "cuandoboton@Derecha|incrementax=8"},
    {"Saltar con el botón A (2D)", "Da un impulso hacia arriba con la física activada.", "saltar salto brincar plataforma boton", "cuandoboton@A|fuerza=0;600"},
    {"Oleadas de enemigos (3 oleadas de 5)", "Ponlo en un enemigo: crea 5 clones, espera 15 segundos y repite 3 veces. Cada clon es un enemigo nuevo.", "oleada enemigos generar aparec ronda horda wave spawn automatic", "cuandoempieza|repetir=3|repetir=5|crearclon|espera=1|finbucle|espera=15|finbucle"},
    {"Todos los enemigos se atacan entre sí y a ti", "Todos contra todos: cada enemigo ataca al más cercano.", "atacan entre si todos contra todos caos pelean enemigos", "cuandoempieza|todosseatacan"},
    {"Enemigos pelean entre ellos (sin atacarte)", "Los enemigos se ignoran a ti y se pelean.", "pelean entre ellos ignoran enemigos menos a ti guerra", "cuandoempieza|seatacanmenostu"},
    {"Caja que se empuja y cae (física)", "Pon esto en un cubo: es físico, pesa 2 kg, se puede empujar y las balas lo mueven.", "caja empujar fisica fisicos cubo cae empujable pesado objeto mover jugador", "cuandoempieza|fisicadinamica|masa=2|empujable=1"},
    {"Barril explosivo (explosión de fuerza)", "Al recibir un disparo empuja lejos todo lo cercano y desaparece.", "barril explosivo explosion explota bomba empuja onda expansiva", "cuandodisparo|explosionfuerza=6;14|eliminar"},
    {"Trampolín / rebote alto", "Objeto que rebota mucho: pon rebote 100% y mucha gravedad.", "rebote trampolin rebotar pelota bola saltar fisica", "cuandoempieza|fisicadinamica|rebote=95|gravedadobjeto=120"},
    {"Globo que flota", "Casi sin gravedad y con resistencia del aire: sube un poco y flota.", "globo flotar flota ligero aire gravedad pluma", "cuandoempieza|fisicadinamica|gravedadobjeto=8|resistenciaaire=40|impulso=0;3;0"},
    {"Empujón al tocar (golpe)", "Al pulsarlo sale disparado hacia arriba y adelante.", "empujon empuje golpe lanzar patada volar impulso fuerza salir disparado", "cuandopulse|fisicadinamica|impulso=4;8;0"},
    {"Todos los enemigos te atacan", "Comportamiento normal: todos contra ti.", "te atacan todos enemigos normal volver", "cuandoempieza|todostateacan"},
    {"Plataforma que sube y baja", "Se mueve en vertical sin parar (3D).", "plataforma sube baja ascensor elevador mover vertical movil", "cuandoempieza|parasiempre|repetir=60|incrementay=0.05|espera=0.02|finbucle|repetir=60|incrementay=-0.05|espera=0.02|finbucle|finbucle"},
    {"Puerta que se abre al interactuar", "Sube la puerta al tocarla o interactuar.", "puerta abrir abre interactuar tocar llave", "cuandointeractua|iniciarsonido@lib_susto.wav|repetir=40|incrementay=0.06|espera=0.02|finbucle"},
    {"Cuenta regresiva de 10 segundos", "Muestra una cuenta atrás y avisa al llegar a cero.", "cuenta regresiva tiempo temporizador contador reloj", "cuandoempieza|variable@tiempo=10|mostrarvariable@tiempo=0;440|repetir=10|espera=1|incvariable@tiempo=-1|finbucle|decir='¡Se acabó el tiempo!'"},
    {"Jefe que ruge y aparece más fuerte", "Ruge al empezar y sacude la pantalla.", "jefe boss ruge rugido final grande", "cuandoempieza|iniciarsonido@lib_rugido.wav|sacudir=1"},
    {"Susto (jumpscare)", "Sacude la pantalla y suena un grito al tocarlo.", "susto jumpscare miedo terror grito", "cuandointeractua|iniciarsonido@lib_susto.wav|sacudir=0.8|mostrar"},
    {"Moneda: sumar punto y desaparecer", "Cuando la tocas suma 1 y se elimina.", "moneda recoger coleccion tesoro item gema", "cuandointeractua|incvariable@puntos=1|eliminar"},
    {"Duplicarse solo cada cierto tiempo", "Crea un clon cada 6 segundos, 10 veces (= 1 minuto). Cambia los números: veces y segundos.", "duplic clon copia multipl spawn aparec cada generar", "cuandoempieza|repetir=10|crearclon|espera=6|finbucle"},
    {"Caminar a la derecha y a la izquierda (patrulla)", "Avanza, da la vuelta y regresa, para siempre.", "derecha izquierda patrull ida vuelta vaiven caminar ronda", "cuandoempieza|parasiempre|repetir=50|mover=2|finbucle|girarder=180|finbucle"},
    {"Perseguir al jugador", "Se acerca al jugador sin parar.", "perseg segu acerc jugador cazar atacar", "cuandoempieza|parasiempre|moverhaciajugador=0.05|finbucle"},
    {"Disparar al jugador cada 2 segundos", "Enemigo que dispara un proyectil a intervalos.", "dispar enemigo torreta tirar bala", "cuandoempieza|parasiempre|espera=2|dispararjugador|finbucle"},
    {"Sistema de parry (bloqueo con tiempo)", "Al pulsar el botón Parry se activa una ventana de 0.3 s (variable parry = 1). En tus enemigos usa: Si parry = 1 entonces ... para anular el daño.", "parry parri bloqu defens contra deflect", "cuandoboton@Parry|variable@parry=1|espera=0.3|variable@parry=0"},
    {"Tiempo lento / congelar el mundo 3 segundos", "Congela todo menos al jugador un momento.", "tiempo congel pausa lento bullet", "cuandoboton@Tiempo|congelartodo|espera=3|descongelartodo"},
    {"Desaparecer después de unos segundos", "Se elimina solo a los 5 segundos.", "desaparec elimin borrar despues temporal", "cuandoempieza|espera=5|eliminar"},
    {"Parpadear (aparecer y ocultarse)", "Se muestra y se oculta sin parar.", "parpade intermit luz titil", "cuandoempieza|parasiempre|mostrar|espera=0.5|ocultar|espera=0.5|finbucle"},
    {"Girar sin parar", "Da vueltas constantemente.", "gira rotar vueltas rueda", "cuandoempieza|parasiempre|girarder=3|finbucle"},
    {"Linterna que falla (terror)", "Se apaga y enciende al azar.", "terror linterna falla apag luz miedo", "cuandoempieza|parasiempre|espera=3|linternaoff|espera=0.15|linternaon|espera=0.1|linternaoff|espera=0.2|linternaon|finbucle"},
    {"Temblor al recibir daño", "Sacude la pantalla cuando el jugador sufre daño.", "temblor sacud dano golpe pantalla", "cuandojugadordano|sacudir=0.3"},
    {"Contar puntos al tocar", "Suma 1 punto a la variable puntos y la muestra.", "punto contar monedas moneda score sumar", "cuandointeractua|incvariable@puntos=1|mostrarvariable@puntos=10;10|eliminar"},
    {"Romper al recibir un disparo", "Se rompe en pedazos.", "romper destruir pedazos explot", "cuandodisparo|romper=10"},
    {"Música de fondo", "Música en bucle al empezar.", "musica fondo sonido ambiente", "cuandoempieza|musica"},
    {"Moverse al azar", "Camina sin rumbo cada segundo.", "azar aleator vagar pasear", "cuandoempieza|parasiempre|moveralazar=3|espera=1|finbucle"},
    {"Saltar / rebotar con gravedad", "Activa la física con gravedad.", "gravedad fisica rebot caer", "cuandoempieza|fisicadinamica"},
};

bool buildRecipe(const char* steps, std::vector<Block>& out) {
    std::string s = steps;
    size_t p = 0;
    while (p <= s.size()) {
        size_t e = s.find('|', p);
        std::string tok = s.substr(p, e == std::string::npos ? std::string::npos : e - p);
        p = e == std::string::npos ? s.size() + 1 : e + 1;
        if (tok.empty()) continue;
        std::string key = tok, txt, args;
        size_t at = key.find('@');
        if (at != std::string::npos) { txt = key.substr(at + 1); key = key.substr(0, at); }
        size_t eq = key.find('=');
        if (eq != std::string::npos) { args = key.substr(eq + 1); key = key.substr(0, eq); }
        if (txt.find('=') != std::string::npos) {  // @texto=valor
            size_t q = txt.find('=');
            args = txt.substr(q + 1); txt = txt.substr(0, q);
        }
        const OpInfo* found = nullptr;
        for (int i = 0; i < (int)Op::Count; i++) if (key == opInfo((Op)i).key) { found = &opInfo((Op)i); break; }
        if (!found) return false;
        Block b;
        b.op = found->op;
        b.t = found->t ? found->t : "";
        b.f[0] = found->f0 ? found->f0 : "";
        b.f[1] = found->f1 ? found->f1 : "";
        b.f[2] = found->f2 ? found->f2 : "";
        if (!txt.empty()) b.t = txt;
        int k = 0;
        size_t a = 0;
        while (k < 3 && !args.empty() && a <= args.size()) {
            size_t c = args.find(';', a);
            b.f[k++] = args.substr(a, c == std::string::npos ? std::string::npos : c - a);
            if (c == std::string::npos) break;
            a = c + 1;
        }
        out.push_back(b);
    }
    return !out.empty();
}
}  // namespace

void Editor::palettePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    modalOpen("Bloques");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.92f, h_ * 0.92f));
    if (!ImGui::BeginPopupModal("Bloques", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | kNoSB |
                                    kNoSW)) {
        pal_ = -2;
        return;
    }
    static const Cat cats[] = {Cat::Eventos, Cat::Control, Cat::Movimiento, Cat::Sonido, Cat::Apariencia, Cat::Datos, Cat::Forge3D, Cat::Multijugador};
    bool searching = !palSearch_.empty();
    bool close = false;
    float bw0 = ImGui::GetContentRegionAvail().x;
    if (pal_ >= 0 || searching) {
        if (wrapui::Button("< Categorías", ImVec2(fs * 7.f, fs * 2.2f)) && tapped()) { pal_ = -1; palSearch_.clear(); }
        ImGui::SameLine();
    }
    textInput("##s", "Buscar bloque", palSearch_, "Buscar bloque", bw0 - fs * 6.f - (pal_ >= 0 || searching ? fs * 7.6f : 0.f));
    wrapui::Next("Cerrar");
    if (wrapui::Button("Cerrar", ImVec2(fs * 5.f, 0)) && tapped()) close = true;
    ImGui::Separator();
    wrapui::BeginChild("##pl", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    float bw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    int pick = -1;
    if (pal_ == -1 && !searching) {
        ImGui::TextDisabled("Categorías");
        for (int i = 0; i < 8; i++) {
            ImGui::PushStyleColor(ImGuiCol_Button, catRGB(cats[i]));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(cats[i], 1.15f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(cats[i], 0.8f));
            if (wrapui::Button(catName(cats[i]), ImVec2(bw, fs * 3.f)) && tapped()) pal_ = i;
            ImGui::PopStyleColor(3);
        }
    } else {
        std::string q = normName(palSearch_);
        if (!searching) ImGui::TextColored(catRGB(cats[pal_]), "%s", catName(cats[pal_]));
        if (searching && q.size() >= 3) {  // sugerencias: torres de bloques completas segun lo que quieres hacer
            struct Hit { int score; int idx; };
            std::vector<Hit> hits;
            for (int ri = 0; ri < (int)(sizeof(kRecipes) / sizeof(kRecipes[0])); ri++) {
                int sc = 0;
                std::string w = kRecipes[ri].words;
                size_t a = 0;
                while (a < w.size()) {
                    size_t b2 = w.find(' ', a);
                    std::string st = w.substr(a, b2 == std::string::npos ? std::string::npos : b2 - a);
                    if (!st.empty() && q.find(st) != std::string::npos) sc++;
                    if (b2 == std::string::npos) break;
                    a = b2 + 1;
                }
                if (sc > 0) hits.push_back({sc, ri});
            }
            std::stable_sort(hits.begin(), hits.end(), [](const Hit& x, const Hit& y) { return x.score > y.score; });
            if (hits.size() > 3) hits.resize(3);
            if (!hits.empty()) ImGui::TextColored(ImVec4(1.f, 0.82f, 0.35f, 1.f), "Torres de bloques sugeridas para lo que quieres hacer:");
            for (auto& h : hits) {
                const Recipe& rc = kRecipes[h.idx];
                ImGui::PushID(1000 + h.idx);
                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.52f, 0.12f, 1.f));
                bool use = wrapui::Button((std::string("Agregar: ") + rc.title).c_str(), ImVec2(bw, fs * 2.6f)) && tapped();
                ImGui::PopStyleColor();
                ImGui::TextDisabled("%s", rc.what);
                ImGui::Spacing();
                if (use) {
                    std::vector<Block> bl;
                    if (buildRecipe(rc.steps, bl)) {
                        if (o.blocks.empty() && !isHat(bl[0].op)) { Block w0; w0.op = Op::WhenStart; o.blocks.push_back(w0); }
                        for (auto& b3 : bl) o.blocks.push_back(b3);
                        markDirty();
                        palSearch_.clear();
                        close = true;
                    }
                }
                ImGui::PopID();
            }
            if (!hits.empty()) ImGui::Separator();
        }
        for (int i = 0; i < (int)Op::Count; i++) {
            const OpInfo& in = opInfo((Op)i);
            if (searching) {
                if (normName(plainTitle(in)).find(q) == std::string::npos && normName(in.help).find(q) == std::string::npos) continue;
            } else if (in.cat != cats[pal_]) {
                continue;
            }
            ImGui::PushID(i);
            ImGui::PushStyleColor(ImGuiCol_Button, catRGB(in.cat));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, catRGB(in.cat, 1.15f));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, catRGB(in.cat, 0.8f));
            if (wrapui::Button(plainTitle(in).c_str(), ImVec2(bw, fs * 2.6f)) && tapped()) pick = i;
            ImGui::PopStyleColor(3);
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + bw);
            ImGui::TextDisabled("%s", in.help);
            ImGui::PopTextWrapPos();
            ImGui::Spacing();
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    if (pick >= 0) {
        addBlock(o, (Op)pick);
        palSearch_.clear();
        close = true;
    }
    if (close) { ImGui::CloseCurrentPopup(); pal_ = -2; }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- formulas por piezas (funciones = fichas)
namespace {
struct FSeg {
    bool func = false;
    std::string text;               // texto suelto (numeros, operadores...)
    std::string name;               // nombre de la funcion tal como se escribio
    bool parens = false;            // tiene parentesis
    std::vector<std::string> args;  // parametros editables
};

struct FName { std::string norm, label; int defArgs; };

static const std::vector<FName>& fnames() {
    static std::vector<FName> v = [] {
        std::vector<FName> r;
        for (auto& f : formulaFunctions()) {
            std::string l = f.label;
            size_t p = l.find('(');
            std::string nm = p == std::string::npos ? l : l.substr(0, p);
            std::string n = normName(nm);
            if (n.empty() || n == "y" || n == "o" || n == "no" || !(std::isalnum((unsigned char)n[0]) || n[0] == '_')) continue;
            int da = 0;
            if (p != std::string::npos) {
                std::string in = l.substr(p + 1, l.rfind(')') - p - 1);
                int depth = 0; bool q = false; char qc = 0;
                bool any = false;
                da = 1;
                for (char c : in) {
                    if (q) { if (c == qc) q = false; continue; }
                    if (c == '\'' || c == '"') { q = true; qc = c; any = true; continue; }
                    if (c == '(') depth++;
                    else if (c == ')') depth--;
                    else if (c == ',' && depth == 0) da++;
                    if (c != ' ') any = true;
                }
                if (!any) da = 0;
            }
            bool dup = false;
            for (auto& e : r) if (e.norm == n) { dup = true; break; }
            if (!dup) r.push_back({n, nm, da});
        }
        std::sort(r.begin(), r.end(), [](const FName& a, const FName& b) { return a.norm.size() > b.norm.size(); });
        return r;
    }();
    return v;
}

static bool idc(unsigned char c) { return std::isalnum(c) || c == '_' || c >= 0x80; }

static std::vector<FSeg> parseSegs(const std::string& s) {
    // texto normalizado con el indice del original de cada letra
    std::string nb; std::vector<size_t> st, en;
    for (size_t i = 0; i < s.size();) {
        unsigned char c = (unsigned char)s[i];
        size_t l = 1;
        std::string piece;
        if (c == 0xC3 && i + 1 < s.size()) { piece = normName(s.substr(i, 2)); l = 2; }
        else piece = normName(s.substr(i, 1));
        for (char ch : piece) { nb += ch; st.push_back(i); en.push_back(i + l); }
        if (piece.empty()) { /* nada */ }
        i += l;
    }
    std::vector<FSeg> out;
    std::string txt;
    auto flush = [&] { if (!txt.empty()) { FSeg g; g.text = txt; out.push_back(g); txt.clear(); } };
    size_t i = 0;
    while (i < s.size()) {
        char c = s[i];
        if (c == '\'' || c == '"') {  // texto entre comillas: se copia tal cual
            size_t j = s.find(c, i + 1);
            if (j == std::string::npos) j = s.size() - 1;
            txt += s.substr(i, j - i + 1);
            i = j + 1;
            continue;
        }
        // indice en el texto normalizado
        size_t ni = std::lower_bound(st.begin(), st.end(), i) - st.begin();
        bool matched = false;
        if (ni < st.size() && st[ni] == i && (i == 0 || !idc((unsigned char)s[i - 1]))) {
            for (auto& f : fnames()) {
                if (nb.compare(ni, f.norm.size(), f.norm) != 0) continue;
                size_t endN = ni + f.norm.size();
                size_t endO = endN < st.size() ? st[endN] : s.size();
                if (endN > st.size()) continue;
                if (endN >= 1) endO = en[endN - 1];
                size_t k = endO;
                FSeg g; g.func = true; g.name = s.substr(i, endO - i);
                if (k < s.size() && s[k] == '(') {
                    int depth = 0; bool q = false; char qc = 0;
                    size_t a0 = k + 1, j = k;
                    std::string cur;
                    bool closed = false;
                    for (j = k + 1; j < s.size(); j++) {
                        char d = s[j];
                        if (q) { cur += d; if (d == qc) q = false; continue; }
                        if (d == '\'' || d == '"') { q = true; qc = d; cur += d; continue; }
                        if (d == '(') { depth++; cur += d; continue; }
                        if (d == ')') { if (depth == 0) { closed = true; break; } depth--; cur += d; continue; }
                        if (d == ',' && depth == 0) { g.args.push_back(cur); cur.clear(); continue; }
                        cur += d;
                    }
                    (void)a0;
                    if (!closed) continue;  // parentesis sin cerrar: se deja como texto
                    g.args.push_back(cur);
                    for (auto& a : g.args) { size_t b = a.find_first_not_of(' '); a = b == std::string::npos ? "" : a.substr(b); }
                    if (g.args.size() == 1 && g.args[0].empty() && f.defArgs == 0) g.args.clear();
                    while ((int)g.args.size() < f.defArgs) g.args.push_back("");
                    g.parens = true;
                    k = j + 1;
                } else if (endN < nb.size() && idc((unsigned char)s[k])) {
                    continue;  // era parte de otra palabra
                } else if (f.defArgs > 0) {
                    continue;  // una funcion con parametros sin parentesis: texto
                }
                flush();
                out.push_back(g);
                i = k;
                matched = true;
                break;
            }
        }
        if (matched) continue;
        txt += c;
        i++;
    }
    flush();
    return out;
}

static std::string joinSegs(const std::vector<FSeg>& v) {
    std::string r;
    for (auto& g : v) {
        if (!g.func) { r += g.text; continue; }
        r += g.name;
        if (g.parens) {
            r += '(';
            for (size_t i = 0; i < g.args.size(); i++) { if (i) r += ", "; r += g.args[i]; }
            r += ')';
        }
    }
    return r;
}

// Borra "lo ultimo": una funcion completa, o una letra / operador.
static void popLast(std::string& s) {
    auto v = parseSegs(s);
    if (v.empty()) return;
    if (v.back().func) { v.pop_back(); s = joinSegs(v); return; }
    std::string& t = v.back().text;
    while (!t.empty() && t.back() == ' ') t.pop_back();
    while (!t.empty() && ((unsigned char)t.back() & 0xC0) == 0x80) t.pop_back();
    if (!t.empty()) t.pop_back();
    while (!t.empty() && t.back() == ' ') t.pop_back();
    if (t.empty()) v.pop_back();
    s = joinSegs(v);
}
}  // namespace

// ---------------------------------------------------------------- editor de formulas (ventana emergente)
void Editor::formulaPage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (fe_.blk < 0 || fe_.blk >= (int)o.blocks.size()) { fe_.open = false; return; }
    Block& b = o.blocks[fe_.blk];
    modalOpen("Fórmula");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.94f));
    if (!ImGui::BeginPopupModal("Fórmula", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | kNoSB |
                                    kNoSW)) {
        fe_.open = false;
        return;
    }
    float total = ImGui::GetContentRegionAvail().x;
    float lw = total * 0.48f;
    bool ok = false, cancel = false;

    // ---- barra superior fija: siempre visible aunque la pantalla sea baja
    {
        float bw = (total - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.62f, 0.40f, 1.f));
        ok = wrapui::Button("Aceptar (guardar)", ImVec2(bw, fs * 2.4f)) && tapped();
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.70f, 0.28f, 0.28f, 1.f));
        cancel = wrapui::Button("Cancelar", ImVec2(bw, fs * 2.4f)) && tapped();
        ImGui::PopStyleColor();
    }

    // ---- izquierda: formula, resultado, teclado
    wrapui::BeginChild("##fl", ImVec2(lw, 0), false, kNoSB);
    dragScroll();
    ImGui::TextDisabled("Toca un cuadrito de la función para cambiar solo ese valor");
    // --- piezas de la formula
    std::vector<FSeg> segs = parseSegs(fe_.buf);
    if (fe_.sel >= (int)segs.size() || (fe_.sel >= 0 && (!segs[fe_.sel].func || fe_.selArg >= (int)segs[fe_.sel].args.size()))) fe_.sel = -1;
    // el texto que se esta editando (nullptr = el final de la formula)
    auto active = [&](std::vector<FSeg>& v) -> std::string* {
        if (fe_.sel >= 0 && fe_.sel < (int)v.size() && v[fe_.sel].func && fe_.selArg < (int)v[fe_.sel].args.size()) return &v[fe_.sel].args[fe_.selArg];
        return nullptr;
    };
    auto insertText = [&](const std::string& t) {
        std::vector<FSeg> v = parseSegs(fe_.buf);
        std::string* a = active(v);
        if (a) { if (fe_.replaceNext) a->clear(); *a += t; fe_.buf = joinSegs(v); }
        else fe_.buf += t;
        fe_.replaceNext = false;
    };
    auto insertFunc = [&](const std::string& label) {
        std::vector<FSeg> v = parseSegs(fe_.buf);
        std::string* a = active(v);
        if (a) { if (fe_.replaceNext) a->clear(); *a += label; fe_.buf = joinSegs(v); fe_.replaceNext = false; return; }
        fe_.buf += label;
        auto nv = parseSegs(fe_.buf);
        for (int i = (int)nv.size() - 1; i >= 0; i--)
            if (nv[i].func) { if (!nv[i].args.empty()) { fe_.sel = i; fe_.selArg = 0; fe_.replaceNext = true; } break; }
    };
    float areaW = lw - fs * 0.6f, x0 = ImGui::GetCursorPosX();
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.08f, 0.10f, 0.15f, 1.f));
    wrapui::BeginChild("##fchips", ImVec2(lw - fs * 0.3f, fs * 7.2f), true, kNoSB);
    dragScroll();
    {
        float cx0 = ImGui::GetCursorPosX(), lim = cx0 + ImGui::GetContentRegionAvail().x;
        bool first = true;
        auto place = [&](float w) {
            if (!first) {
                float nx = ImGui::GetCursorPosX() + ImGui::GetStyle().ItemSpacing.x;
                if (nx + w > lim) { ImGui::NewLine(); ImGui::SetCursorPosX(cx0); }
                else ImGui::SameLine();
            }
            first = false;
        };
        auto chip = [&](const std::string& lab, const ImVec4& col, bool* hit, int id) {
            float w = ImGui::CalcTextSize(lab.c_str()).x + fs * 0.9f;
            place(w);
            ImGui::PushID(id);
            ImGui::PushStyleColor(ImGuiCol_Button, col);
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, col);
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, col);
            bool c = wrapui::Button(lab.c_str(), ImVec2(w, fs * 1.9f));
            ImGui::PopStyleColor(3);
            ImGui::PopID();
            if (hit) *hit = c && tapped();
        };
        int idn = 1;
        for (size_t i = 0; i < segs.size(); i++) {
            const FSeg& g = segs[i];
            if (!g.func) { chip(g.text, ImVec4(0.18f, 0.20f, 0.28f, 1.f), nullptr, idn++); continue; }
            chip(g.name + (g.parens ? " (" : ""), ImVec4(0.20f, 0.36f, 0.72f, 1.f), nullptr, idn++);
            for (size_t k = 0; k < g.args.size(); k++) {
                if (k) chip(",", ImVec4(0.2f, 0.2f, 0.25f, 1.f), nullptr, idn++);
                bool sel = fe_.sel == (int)i && fe_.selArg == (int)k;
                bool hit = false;
                std::string lab = g.args[k].empty() ? "  ?  " : shorten(g.args[k], 24);
                chip(lab, sel ? ImVec4(0.95f, 0.55f, 0.12f, 1.f) : ImVec4(0.34f, 0.40f, 0.52f, 1.f), &hit, idn++);
                if (hit) { fe_.sel = (int)i; fe_.selArg = (int)k; fe_.replaceNext = true; fe_.abcOn = false; }
            }
            if (g.parens) chip(")", ImVec4(0.20f, 0.36f, 0.72f, 1.f), nullptr, idn++);
        }
        bool hit = false;
        chip(fe_.sel < 0 ? "|  escribir aquí  |" : "+ al final", fe_.sel < 0 ? ImVec4(0.95f, 0.55f, 0.12f, 1.f) : ImVec4(0.25f, 0.30f, 0.40f, 1.f), &hit, idn++);
        if (hit) { fe_.sel = -1; fe_.replaceNext = false; }
    }
    ImGui::EndChild();
    ImGui::PopStyleColor();
    (void)areaW; (void)x0;
    PreviewEnv env;
    if (!formulaValid(fe_.buf)) {
        ImGui::TextColored(ImVec4(1.f, 0.6f, 0.4f, 1.f), "No es una fórmula válida: se usará como texto.");
    } else {
        Val v = evalFormula(fe_.buf, &env);
        ImGui::Text("= %s", shorten(v.txt(), 40).c_str());
    }
    ImGui::Spacing();
    float kw = (lw - fs * 0.3f - ImGui::GetStyle().ItemSpacing.x * 3.f) / 4.f, kh = fs * 2.0f;
    auto key = [&](const char* label, const char* ins, bool last = false) {
        if (wrapui::Button(label, ImVec2(kw, kh)) && tapped()) insertText(ins);
        if (!last) ImGui::SameLine();
    };
    key("7", "7"); key("8", "8"); key("9", "9"); key("/", " / ", true);
    key("4", "4"); key("5", "5"); key("6", "6"); key("*", " * ", true);
    key("1", "1"); key("2", "2"); key("3", "3"); key("-", " - ", true);
    key("0", "0"); key(".", "."); key(",", ", "); key("+", " + ", true);
    key("(", "("); key(")", ")"); key("=", " = "); key("^", "^", true);
    key("<", " < "); key(">", " > "); key("y", " y "); key("o", " o ", true);
    key("no", "no "); key("'Abc'", "'texto'");
    if (wrapui::Button("<-", ImVec2(kw, kh)) && tapped()) {  // borra una letra, o la funcion completa
        std::vector<FSeg> v = parseSegs(fe_.buf);
        std::string* a = active(v);
        if (a) { popLast(*a); fe_.buf = joinSegs(v); }
        else { popLast(fe_.buf); fe_.sel = -1; }
        fe_.replaceNext = false;
    }
    wrapui::Next("Borrar");
    if (wrapui::Button("Borrar", ImVec2(kw, kh)) && tapped()) {
        std::vector<FSeg> v = parseSegs(fe_.buf);
        std::string* a = active(v);
        if (a) { a->clear(); fe_.buf = joinSegs(v); }
        else { fe_.buf.clear(); fe_.sel = -1; }
        fe_.replaceNext = false;
    }
    // --- tecla abc: teclado del telefono solo cuando la pides
    {
        std::vector<FSeg> v = parseSegs(fe_.buf);
        std::string* a = active(v);
        if (fe_.kbPending && !promptActive_) {
            std::vector<FSeg> v2 = parseSegs(fe_.buf);
            std::string* a2 = active(v2);
            if (a2) { *a2 = fe_.kb; fe_.buf = joinSegs(v2); }
            else fe_.buf += fe_.kb;
            fe_.kbPending = false;
            fe_.kb.clear();
        }
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.30f, 0.45f, 0.30f, 1.f));
        if (wrapui::Button("abc", ImVec2(kw, kh)) && tapped()) {
            if (host_.prompt) {
                if (!promptActive_) {
                    fe_.kb.clear();
                    fe_.kbPending = true;
                    promptActive_ = true;
                    promptDst_ = &fe_.kb;
                    host_.prompt(a ? "Escribe el valor" : "Escribe el texto", a ? *a : std::string());
                }
            } else {
                fe_.abcOn = !fe_.abcOn;
                fe_.kb = a ? *a : std::string();
            }
        }
        ImGui::PopStyleColor();
        if (!host_.prompt && fe_.abcOn) {
            ImGui::SetNextItemWidth(lw - fs * 4.5f);
            ImGui::InputTextWithHint("##abcin", "escribe aquí", &fe_.kb);
            wrapui::Next("OK");
            if (wrapui::Button("OK") && tapped()) {
                std::vector<FSeg> v2 = parseSegs(fe_.buf);
                std::string* a2 = active(v2);
                if (a2) { *a2 = fe_.kb; fe_.buf = joinSegs(v2); } else fe_.buf += fe_.kb;
                fe_.abcOn = false; fe_.kb.clear();
            }
        }
    }
    ImGui::Dummy(ImVec2(1, fs));
    ImGui::EndChild();

    // ---- derecha: Funciones / Objeto / Dispositivo / Logica / Datos
    ImGui::SameLine();
    wrapui::BeginChild("##fr", ImVec2(0, 0), false, kNoSB);
    static const char* tabs[5] = {"Funciones", "Objeto", "Dispositivo", "Lógica", "Datos"};
    float rw = ImGui::GetContentRegionAvail().x;
    float tw = (rw - ImGui::GetStyle().ItemSpacing.x * 2.f) / 3.f;
    for (int i = 0; i < 5; i++) {
        if (i % 3) ImGui::SameLine();
        bool on = formulaList_ == i;
        ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.20f, 0.50f, 0.95f, 1.f) : ImVec4(0.30f, 0.34f, 0.48f, 1.f));
        if (wrapui::Button(tabs[i], ImVec2(tw, fs * 2.2f)) && tapped()) formulaList_ = i;
        ImGui::PopStyleColor();
    }
    ImGui::Separator();
    wrapui::BeginChild("##flist", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    auto inGroup = [&](const std::string& g) {
        switch (formulaList_) {
            case 0: return g == "MATEMÁTICAS" || g == "STRINGS (CADENAS)" || g == "FECHA Y HORA" || g == "3D";
            case 1: return g == "PROPIEDADES DE ASPECTO" || g == "PROPIEDADES DE MOVIMIENTO";
            case 2: return g == "SENSORES DEL DISPOSITIVO" || g == "DETECCIÓN DEL TACTO";
            case 3: return g == "OPERADORES LÓGICOS (BOOLEANOS)" || g == "OPERADOR DE COMPARACIÓN";
        }
        return false;
    };
    auto addGlobalVar = [&](const std::string& nm) {
        if (nm.empty()) return;
        auto all = varNames(o);
        if (std::find(all.begin(), all.end(), nm) == all.end()) { edit_.proj.globalVars.push_back(nm); markDirty(); }
        insertText("\"" + nm + "\"");
    };
    std::string cur;
    if (formulaList_ == 4) {
        ImGui::TextDisabled("Variables (toca una para insertarla)");
        auto vars = varNames(o);
        if (vars.empty()) ImGui::TextDisabled("Aún no hay variables.");
        for (auto& v : vars) {
            ImGui::PushID(v.c_str());
            bool local = std::find(o.localVars.begin(), o.localVars.end(), v) != o.localVars.end();
            std::string lab = v + (local ? "   (solo este objeto)" : "");
            if (wrapui::Button(shorten(lab, 40).c_str(), ImVec2(aw, fs * 2.2f)) && tapped()) insertText("\"" + v + "\"");
            ImGui::PopID();
        }
        ImGui::Spacing();
        if (host_.prompt) {
            if (newVarOpen_ && !promptActive_) { addGlobalVar(newVarName_); newVarOpen_ = false; newVarName_.clear(); }
            if (wrapui::Button("+ Variable nueva", ImVec2(aw, fs * 2.4f)) && tapped() && !promptActive_) {
                newVarName_.clear();
                newVarOpen_ = true;
                promptActive_ = true;
                promptDst_ = &newVarName_;
                host_.prompt("Nombre de la variable", "");
            }
        } else {
            textInput("##nvf", "Nombre de la variable", newVarName_, "nombre de la variable", aw);
            if (wrapui::Button("+ Variable nueva", ImVec2(aw, fs * 2.4f)) && tapped()) { addGlobalVar(newVarName_); newVarName_.clear(); }
        }
    } else {
        int n = 0;
        for (auto& f : formulaFunctions()) {
            if (!inGroup(f.group)) continue;
            if (cur != f.group) { cur = f.group; ImGui::Spacing(); ImGui::TextDisabled("%s", f.group); }
            ImGui::PushID(n++);
            if (wrapui::Button(f.label, ImVec2(aw, fs * 2.1f)) && tapped()) insertFunc(f.label);
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    ImGui::EndChild();

    if (ok) { b.f[fe_.field] = fe_.buf; markDirty(); }
    if (ok || cancel) { fe_.open = false; ImGui::CloseCurrentPopup(); }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- elegir texto (ventana emergente)
void Editor::choosePage(Obj& o) {
    float fs = ImGui::GetFontSize();
    if (te_.blk < 0 || te_.blk >= (int)o.blocks.size()) { te_.open = false; return; }
    Block& b = o.blocks[te_.blk];
    modalOpen("Elegir");
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min((float)w_ * 0.92f, fs * 30.f), h_ * 0.92f));
    if (!ImGui::BeginPopupModal("Elegir", nullptr,
                                ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse |
                                    ImGuiWindowFlags_NoSavedSettings | kNoSB |
                                    kNoSW)) {
        te_.open = false;
        return;
    }
    std::vector<std::string> items;
    const char* what = "Elegir";
    bool isVar = false, free = false;
    switch (b.op) {
        case Op::WhenReceive: case Op::Broadcast: case Op::BroadcastWait:
            items = messageNames(); what = "Mensaje"; free = true; break;
        case Op::WhenCollide: case Op::WhenNear: case Op::PointTowards: case Op::GoToObject: case Op::MoveTowards:
            what = "Objeto";
            if (hasScene() && scene().is3d) items.push_back("Jugador");
            if (hasScene()) for (auto& x : scene().objs) if (&x != &o) items.push_back(x.name);
            break;
        case Op::KeepAllOnScreen:
            what = "Excepto";
            items = {"(ninguno)"};
            if (hasScene()) for (auto& x : scene().objs) items.push_back(x.name);
            break;
        case Op::AllowLeaveScreen:
            what = "Objeto";
            items = {"Este objeto", "Todos"};
            if (hasScene()) for (auto& x : scene().objs) items.push_back(x.name);
            break;
        case Op::SetTarget:
            what = "Objetivo";
            items = {"Enemigo más cercano", "Monstruo más cercano", "Todas las entidades (la más cercana)"};
            if (hasScene()) for (auto& x : scene().objs) if (&x != &o && x.kind != Kind::Player) items.push_back(x.name);
            break;
        case Op::WhenButton: {
            what = "Botón en pantalla";
            free = true;
            const Project& PP = edit_.proj;
            if (PP.hudDefault) items = {"DISPARAR", "SALTAR"};
            else for (auto& hb : PP.hud) items.push_back(hb.label);
            break;
        }
        case Op::PlayVideo:
            what = "Video";
            free = true;
            for (auto& as : edit_.proj.assets) {
                std::string l = as.first;
                for (auto& c : l) c = (char)std::tolower((unsigned char)c);
                for (const char* e : {".mp4", ".3gp", ".webm", ".mkv", ".avi", ".mov", ".m4v"})
                    if (l.size() > strlen(e) && l.compare(l.size() - strlen(e), strlen(e), e) == 0) { items.push_back(as.first); break; }
            }
            break;
        case Op::PlayClip:
            what = "Animación de esqueleto";
            free = true;
            for (auto& n : clipsFor(o)) items.push_back(n);
            break;
        case Op::WhenObjMoves:
            what = "Objeto que se mueve";
            free = true;
            if (hasScene()) for (auto& x : scene().objs) items.push_back(x.name);
            break;
        case Op::SetCamera:
            what = "Vista de cámara";
            items = {"Primera persona", "Cámara al hombro", "Cámara fija"};
            break;
        case Op::SetFx:
            what = "Partículas";
            items = {"encender", "apagar"};
            break;
        case Op::SetScreenFx:
            what = "Efecto de pantalla";
            items = {"Ninguno", "VHS", "Cámara de video", "Visión nocturna", "Película vieja"};
            break;
        case Op::PlayAnim:
            what = "Animación";
            items = {"quieto", "caminar", "atacar", "daño"};
            break;
        case Op::PlaySoundWait:
            what = "Sonido o música";
            items = soundList();
            break;
        case Op::StartSound:
            what = "Sonido";
            items = o.sounds;
            for (auto& a : soundList()) if (std::find(items.begin(), items.end(), a) == items.end()) items.push_back(a);
            break;
        case Op::Music: what = "Música"; items = soundList(); break;
        case Op::SetLook:
            what = "Apariencia";
            items = o.looks;
            if (!o.tex.empty()) items.insert(items.begin(), o.tex);
            break;
        case Op::StartScene: what = "Escena"; for (auto& s : edit_.proj.scenes) items.push_back(s.name); break;
        case Op::SetVar: case Op::ChangeVar: case Op::ShowVar: case Op::HideVar:
            what = "Variable"; items = varNames(o); isVar = true; break;
        default: free = true; break;
    }
    ImGui::TextDisabled("%s", what);
    ImGui::SameLine(ImGui::GetContentRegionAvail().x - fs * 5.f);
    bool done = wrapui::Button("Cerrar", ImVec2(fs * 5.f, 0)) && tapped();
    ImGui::Separator();
    wrapui::BeginChild("##cl", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.3f;
    for (int i = 0; i < (int)items.size(); i++) {
        ImGui::PushID(i);
        if (wrapui::Button(shorten(items[i], 34).c_str(), ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = items[i]; done = true; markDirty(); }
        ImGui::PopID();
    }
    if (items.empty() && !isVar) ImGui::TextDisabled("(no hay nada que elegir todavía)");
    ImGui::Spacing();
    if (isVar) {
        ImGui::TextDisabled("Variable nueva");
        if (host_.prompt && newVarOpen_ && !promptActive_) {  // el nombre ya llego del cuadro de texto
            newVarOpen_ = false;
            if (!newVarName_.empty()) {
                auto all = varNames(o);
                if (std::find(all.begin(), all.end(), newVarName_) == all.end()) {
                    if (newVarLocal_) o.localVars.push_back(newVarName_);
                    else edit_.proj.globalVars.push_back(newVarName_);
                }
                b.t = newVarName_;
                newVarName_.clear();
                done = true;
                markDirty();
            }
        }
        wrapui::Checkbox("Solo para este objeto", &newVarLocal_);
        if (host_.prompt) {
            if (wrapui::Button("+ Crear variable nueva", ImVec2(aw, fs * 2.4f)) && tapped() && !promptActive_) {
                newVarName_.clear();
                newVarOpen_ = true;
                promptActive_ = true;
                promptDst_ = &newVarName_;
                host_.prompt("Nombre de la variable", "");
            }
        } else {
            textInput("##nv", "Nombre de la variable", newVarName_, "nombre de la variable", aw);
            if (wrapui::Button("Crear variable", ImVec2(aw, fs * 2.4f)) && tapped() && !newVarName_.empty()) {
                auto all = varNames(o);
                if (std::find(all.begin(), all.end(), newVarName_) == all.end()) {
                    if (newVarLocal_) o.localVars.push_back(newVarName_);
                    else edit_.proj.globalVars.push_back(newVarName_);
                }
                b.t = newVarName_;
                newVarName_.clear();
                done = true;
                markDirty();
            }
        }
    } else if (free) {
        ImGui::TextDisabled(b.op == Op::Note ? "Escribe la nota" : "Nuevo");
        textInput("##t", b.op == Op::Note ? "Nota" : "Nombre", te_.buf, "(toca para escribir)", aw);
        if (wrapui::Button("Usar este texto", ImVec2(aw, fs * 2.4f)) && tapped()) { b.t = te_.buf; done = true; markDirty(); }
    }
    ImGui::Dummy(ImVec2(1, fs * 2.f));
    ImGui::EndChild();
    if (done) { te_.open = false; ImGui::CloseCurrentPopup(); }
    ImGui::EndPopup();
}

// ---------------------------------------------------------------- pestana Apariencias
void Editor::looksTab(Obj& o, Renderer* r) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Aspecto principal");
    thumb(r, o, fs * 5.f);
    ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::Text("%s", o.tex.empty() ? "(solo color)" : shorten(o.tex, 24).c_str());
    if (wrapui::Checkbox("Sin color (transparente)", &o.noColor)) markDirty();
    if (!o.noColor && wrapui::ColorEdit3("Color", o.color, ImGuiColorEditFlags_NoInputs)) markDirty();
    if (!o.tex.empty()) {
        bool stretch = !o.texTile;
        if (wrapui::Checkbox("Estirar la imagen a toda la cara", &stretch)) { o.texTile = !stretch; markDirty(); }
    }
    ImGui::EndGroup();
    {
        bool open = wrapui::Button("Imagen principal...", ImVec2(aw, fs * 2.3f)) && tapped();
        std::string cur = o.tex;
        if (gridPicker("##mainimg", cur, 0, "(sin imagen)", open) && cur != o.tex) { o.tex = cur; markDirty(); }
    }
    ImGui::Spacing();
    ImGui::TextDisabled("Más apariencias (para \"Cambiar apariencia a\" y \"Siguiente apariencia\")");
    int del = -1;
    float th = fs * 3.2f;
    for (int i = 0; i < (int)o.looks.size(); i++) {
        ImGui::PushID(i);
        Obj tmp;
        tmp.tex = o.looks[i];
        thumb(r, tmp, th);
        ImGui::SameLine();
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.looks[i], 26).c_str());
        ImGui::SameLine(aw - fs * 2.6f);
        if (wrapui::Button("x", ImVec2(fs * 2.4f, th * 0.8f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.looks.erase(o.looks.begin() + del); markDirty(); }
    if (o.looks.empty()) ImGui::TextDisabled("(ninguna)");
    ImGui::Spacing();
    if (wrapui::Button("Importar imagen...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    {
        bool open = wrapui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped();
        std::string pick;
        if (gridPicker("##addlook", pick, 0, nullptr, open) && !pick.empty()) { o.looks.push_back(pick); markDirty(); }
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

// ---------------------------------------------------------------- pestana Sonidos
void Editor::soundsTab(Obj& o) {
    float fs = ImGui::GetFontSize();
    float aw = ImGui::GetContentRegionAvail().x - fs * 0.5f;
    ImGui::Spacing();
    ImGui::TextDisabled("Sonidos de este objeto");
    int del = -1;
    for (int i = 0; i < (int)o.sounds.size(); i++) {
        ImGui::PushID(i);
        ImGui::AlignTextToFramePadding();
        ImGui::Text("%d. %s", i + 1, shorten(o.sounds[i], 22).c_str());
        ImGui::SameLine(aw - fs * 9.f);
        if (wrapui::Button("Probar", ImVec2(fs * 5.f, fs * 2.2f)) && tapped() && audio_) audio_->play(o.sounds[i]);
        wrapui::Next("x");
        if (wrapui::Button("x", ImVec2(fs * 2.4f, fs * 2.2f)) && tapped()) del = i;
        ImGui::PopID();
    }
    if (del >= 0) { o.sounds.erase(o.sounds.begin() + del); markDirty(); }
    if (o.sounds.empty()) ImGui::TextDisabled("(ninguno)");
    ImGui::Spacing();
    if (wrapui::Button("Crear música o efecto (estudio)", ImVec2(aw, fs * 2.4f)) && tapped()) openMusic();
    if (wrapui::Button("Importar sonido...", ImVec2(aw, fs * 2.4f)) && tapped()) { if (host_.pickFile) host_.pickFile(); }
    if (wrapui::Button("Elegir de los archivos", ImVec2(aw, fs * 2.4f)) && tapped()) ImGui::OpenPopup("addsnd");
    if (ImGui::BeginPopup("addsnd")) {
        auto snds = soundList();
        if (snds.empty()) ImGui::TextDisabled("No hay audios en el proyecto");
        for (auto& a : snds) if (ImGui::MenuItem(a.c_str())) { o.sounds.push_back(a); markDirty(); }
        ImGui::EndPopup();
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
}

}  // namespace forge
