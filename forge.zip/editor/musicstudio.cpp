#include "musicstudio.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {
const char* kGenreNames[8] = {"Acción", "Terror", "Carreras", "Aventura", "Retro 8-bit", "Relajado", "Jefe final", "Menú"};
const char* kScaleNames[5] = {"Mayor (alegre)", "Menor (seria)", "Frigia (oscura)", "Pentatónica", "Blues"};
const char* kInstNames[3][4] = {{"Chip", "Pluck", "Campana", "Sierra"}, {"Pad suave", "Cuerdas", "Órgano", "Cristal"}, {"Sierra", "Sub", "Cuadrada", "Pluck"}};
const char* kSfxNames[8] = {"Salto", "Disparo", "Golpe", "Moneda", "Explosión", "Láser", "Poder", "Paso"};

namespace {
const int kRate = 22050;
const int kScaleSemi[5][7] = {{0, 2, 4, 5, 7, 9, 11}, {0, 2, 3, 5, 7, 8, 10}, {0, 1, 3, 5, 7, 8, 10}, {0, 3, 5, 7, 10, 12, 15}, {0, 3, 5, 6, 7, 10, 12}};
float semiOf(const MusicSong& s, int deg) {
    int n = 7;
    return (float)(kScaleSemi[s.scale][((deg % n) + n) % n] + 12 * (deg / n)) + (float)s.root;
}
float hzOf(float semis) { return 110.f * std::pow(2.f, semis / 12.f); }
unsigned rnd(unsigned& st) { st = st * 1664525u + 1013904223u; return st >> 8; }
float frnd(unsigned& st) { return (float)(rnd(st) & 0xFFFF) / 32768.f - 1.f; }
float wave(int w, float cyc) {
    float f = cyc - std::floor(cyc);
    switch (w) {
        case 0: return f < 0.5f ? 0.6f : -0.6f;                  // cuadrada
        case 1: return std::sin(6.2831853f * cyc);                // seno
        case 2: return 2.f * f - 1.f;                             // sierra
        default: return 4.f * std::fabs(f - 0.5f) - 1.f;          // triangular
    }
}
void put(std::vector<float>& o, size_t at, const std::vector<float>& v, float g) {
    for (size_t i = 0; i < v.size() && at + i < o.size(); i++) o[at + i] += v[i] * g;
}
// Una nota de un instrumento. kind: 0 melodía, 1 acorde, 2 bajo
std::vector<float> voice(int kind, int inst, float f, float dur) {
    size_t n = (size_t)(dur * kRate);
    std::vector<float> v(n);
    for (size_t k = 0; k < n; k++) {
        float t = (float)k / kRate, e = 1.f, s = 0.f;
        if (kind == 0) {
            if (inst == 0) { s = wave(0, f * t); e = std::exp(-t * 4.f); }
            else if (inst == 1) { s = wave(2, f * t) * 0.5f + wave(1, f * 2 * t) * 0.3f; e = std::exp(-t * 9.f); }
            else if (inst == 2) { s = std::sin(6.2831853f * f * t) + 0.5f * std::sin(6.2831853f * f * 2.76f * t) * std::exp(-t * 12.f); s *= 0.55f; e = std::exp(-t * 3.5f); }
            else { s = wave(2, f * t) * 0.6f; e = std::exp(-t * 5.f); }
            e *= std::min(1.f, t * 300.f);
        } else if (kind == 1) {
            float att = inst == 1 ? 0.12f : 0.05f;
            if (inst == 0) s = wave(1, f * t) * 0.6f + wave(3, f * 1.004f * t) * 0.4f;
            else if (inst == 1) s = wave(2, f * t) * 0.35f + wave(2, f * 1.006f * t) * 0.35f;
            else if (inst == 2) s = wave(1, f * t) * 0.5f + wave(1, f * 2 * t) * 0.3f + wave(1, f * 3 * t) * 0.2f;
            else s = wave(3, f * 2 * t) * 0.5f + wave(1, f * 3.01f * t) * 0.3f;
            e = std::min(1.f, t / att) * std::min(1.f, (dur - t) / 0.08f);
        } else {
            if (inst == 0) s = wave(2, f * t) * 0.7f;
            else if (inst == 1) s = wave(1, f * t);
            else if (inst == 2) s = wave(0, f * t);
            else s = wave(2, f * t) * 0.6f;
            e = (inst == 3 ? std::exp(-t * 7.f) : std::exp(-t * 2.5f)) * std::min(1.f, t * 200.f) * std::min(1.f, (dur - t) / 0.03f);
        }
        v[k] = s * e;
    }
    return v;
}
std::vector<float> kick() {
    std::vector<float> v((size_t)(0.28f * kRate));
    float ph = 0;
    for (size_t k = 0; k < v.size(); k++) { float t = (float)k / kRate, f = 42.f + 110.f * std::exp(-t * 28.f); ph += f / kRate; v[k] = std::sin(6.2831853f * ph) * std::exp(-t * 11.f) * 1.3f; }
    return v;
}
std::vector<float> snare(unsigned seed) {
    std::vector<float> v((size_t)(0.22f * kRate));
    unsigned st = seed;
    for (size_t k = 0; k < v.size(); k++) { float t = (float)k / kRate; v[k] = (frnd(st) * 0.7f + std::sin(6.2831853f * 190.f * t) * 0.5f) * std::exp(-t * 20.f); }
    return v;
}
std::vector<float> hat(unsigned seed) {
    std::vector<float> v((size_t)(0.06f * kRate));
    unsigned st = seed;
    float prev = 0;
    for (size_t k = 0; k < v.size(); k++) { float t = (float)k / kRate, n = frnd(st); v[k] = (n - prev) * 0.6f * std::exp(-t * 70.f); prev = n; }
    return v;
}
std::vector<uint8_t> wavOf(std::vector<float> s, float peak = 0.85f) {
    float m = 0.0001f;
    for (float x : s) m = std::max(m, std::fabs(x));
    float g = std::min(2.5f, peak / m);
    std::vector<uint8_t> o(44 + s.size() * 2);
    auto w32 = [&](size_t p, uint32_t v) { for (int i = 0; i < 4; i++) o[p + i] = (uint8_t)(v >> (8 * i)); };
    auto w16 = [&](size_t p, uint16_t v) { o[p] = (uint8_t)v; o[p + 1] = (uint8_t)(v >> 8); };
    memcpy(&o[0], "RIFF", 4); w32(4, (uint32_t)(36 + s.size() * 2)); memcpy(&o[8], "WAVEfmt ", 8);
    w32(16, 16); w16(20, 1); w16(22, 1); w32(24, kRate); w32(28, kRate * 2); w16(32, 2); w16(34, 16);
    memcpy(&o[36], "data", 4); w32(40, (uint32_t)(s.size() * 2));
    for (size_t i = 0; i < s.size(); i++) { float v = std::tanh(s[i] * g * 1.1f) * 0.92f; w16(44 + i * 2, (uint16_t)(int16_t)(v * 32000.f)); }
    return o;
}
}  // namespace

std::vector<uint8_t> musicRender(const MusicSong& s) {
    float step = 60.f / std::max(40.f, s.bpm) / 4.f;
    size_t stepN = (size_t)(step * kRate), pat = stepN * 16;
    int reps = std::max(1, std::min(16, s.bars));
    std::vector<float> o(pat * reps + (size_t)(0.5f * kRate), 0.f);
    unsigned st = 77;
    for (int r = 0; r < reps; r++)
        for (int i = 0; i < 16; i++) {
            size_t at = r * pat + i * stepN + ((i & 1) ? (size_t)(s.swing * 0.3f * stepN) : 0);
            // melodía y bajo: la nota dura hasta la siguiente (máx. 4 pasos)
            for (int tr : {0, 2}) {
                int d = s.cell[tr][i];
                if (d < 0) continue;
                int len = 1;
                while (len < 4 && s.cell[tr][(i + len) % 16] < 0 && i + len < 16) len++;
                float semi = semiOf(s, d + (tr == 2 ? -7 : 7));
                if (tr == 2) semi -= 12.f + 0.f;
                put(o, at, voice(tr == 2 ? 2 : 0, s.inst[tr == 2 ? 2 : 0], hzOf(semi), len * step * 1.05f), s.vol[tr == 2 ? 2 : 0] * 0.5f);
            }
            int d = s.cell[1][i];
            if (d >= 0) {
                int len = 1;
                while (len < 16 && i + len < 16 && s.cell[1][i + len] < 0) len++;
                for (int k : {0, 2, 4}) put(o, at, voice(1, s.inst[1], hzOf(semiOf(s, d + k + 7)), len * step * 1.05f), s.vol[1] * 0.2f);
            }
            if (s.cell[3][i] > 0) put(o, at, kick(), s.vol[3] * 0.8f);
            if (s.cell[4][i] > 0) put(o, at, snare(st += 13), s.vol[4] * 0.6f);
            if (s.cell[5][i] > 0) put(o, at, hat(st += 7), s.vol[5] * 0.5f);
        }
    // la cola final se suma al inicio para que el bucle suene continuo
    size_t loopLen = pat * reps;
    for (size_t i = loopLen; i < o.size(); i++) o[i - loopLen] += o[i];
    o.resize(loopLen);
    return wavOf(o, 0.8f);
}

std::vector<uint8_t> sfxRender(int kind, float pitch, float length, unsigned seed) {
    pitch = std::max(0.4f, std::min(2.5f, pitch));
    length = std::max(0.4f, std::min(3.f, length));
    unsigned st = seed * 2654435761u + 5;
    float dur = 0.3f;
    switch (kind) { case 0: dur = 0.28f; break; case 1: dur = 0.32f; break; case 2: dur = 0.22f; break; case 3: dur = 0.28f; break; case 4: dur = 1.1f; break; case 5: dur = 0.35f; break; case 6: dur = 0.5f; break; default: dur = 0.1f; }
    dur *= length;
    size_t n = (size_t)(dur * kRate);
    std::vector<float> v(n);
    float ph = 0, lp = 0;
    for (size_t k = 0; k < n; k++) {
        float t = (float)k / kRate, u = t / dur, s = 0.f;
        switch (kind) {
            case 0: ph += (300.f + 700.f * u) * pitch / kRate; s = wave(1, ph) * (1.f - u) * 0.9f; break;
            case 1: ph += (1300.f * std::exp(-u * 4.f) + 120.f) * pitch / kRate; s = (frnd(st) * 0.5f + wave(2, ph) * 0.5f) * std::exp(-u * 6.f); break;
            case 2: ph += (160.f * std::exp(-u * 5.f) + 40.f) * pitch / kRate; s = (std::sin(6.2831853f * ph) * 1.2f + frnd(st) * 0.4f) * std::exp(-u * 9.f); break;
            case 3: { float f = (u < 0.35f ? 988.f : 1319.f) * pitch; ph += f / kRate; s = wave(0, ph) * (u < 0.35f ? 1.f : std::exp(-(u - 0.35f) * 6.f)) * 0.7f; break; }
            case 4: { lp += (frnd(st) - lp) * (0.25f - 0.2f * u); s = lp * 3.f * std::exp(-u * 3.2f) + std::sin(6.2831853f * (50.f * pitch) * t) * std::exp(-u * 6.f); break; }
            case 5: ph += (2000.f * std::exp(-u * 3.f) + 200.f) * pitch / kRate; s = wave(2, ph) * (1.f - u) * 0.8f; break;
            case 6: { int a = std::min(4, (int)(u * 5.f)); static const float m[5] = {1.f, 1.26f, 1.5f, 1.89f, 2.f}; ph += 440.f * m[a] * pitch / kRate; s = wave(0, ph) * (1.f - u * 0.6f) * 0.6f; break; }
            default: lp += (frnd(st) - lp) * 0.3f; s = lp * 2.f * std::exp(-u * 8.f); break;
        }
        v[k] = s * std::min(1.f, t * 400.f);
    }
    return wavOf(v, 0.85f);
}

void musicPreset(MusicSong& s, int g) {
    s.clear();
    auto row = [&](int tr, std::initializer_list<int> v) { int i = 0; for (int x : v) { if (i < 16) s.cell[tr][i++] = x; } };
    s.swing = 0.f;
    s.inst[0] = 0; s.inst[1] = 0; s.inst[2] = 0;
    switch (g) {
        case 0: s.bpm = 150; s.scale = 1; s.root = 0; s.inst[0] = 3; s.inst[1] = 1; s.inst[2] = 0;
            row(0, {0, -1, 2, -1, 4, -1, 2, -1, 0, -1, 3, -1, 5, 4, 2, -1});
            row(1, {0, -1, -1, -1, -1, -1, -1, -1, 5, -1, -1, -1, 3, -1, -1, -1});
            row(2, {0, -1, 0, 0, -1, 0, 0, -1, 5, -1, 5, 5, -1, 3, 3, -1});
            row(3, {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 0}); row(4, {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1}); row(5, {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0}); break;
        case 1: s.bpm = 66; s.scale = 2; s.root = -3; s.inst[0] = 2; s.inst[1] = 0; s.inst[2] = 1;
            row(0, {0, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 4, -1});
            row(1, {0, -1, -1, -1, -1, -1, -1, -1, 1, -1, -1, -1, -1, -1, -1, -1});
            row(2, {0, -1, -1, -1, -1, -1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1});
            row(3, {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}); break;
        case 2: s.bpm = 140; s.scale = 3; s.root = 2; s.inst[0] = 3; s.inst[1] = 2; s.inst[2] = 0;
            row(0, {0, 2, 4, 2, 0, 2, 4, 5, 4, 2, 0, 2, 4, 2, 5, 4});
            row(1, {0, -1, -1, -1, 3, -1, -1, -1, 4, -1, -1, -1, 3, -1, -1, -1});
            row(2, {0, -1, 0, -1, 0, -1, 0, -1, 3, -1, 3, -1, 4, -1, 4, -1});
            row(3, {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}); row(4, {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}); row(5, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}); break;
        case 3: s.bpm = 100; s.scale = 0; s.root = 3; s.inst[0] = 1; s.inst[1] = 1; s.inst[2] = 3;
            row(0, {0, -1, 2, 4, -1, 2, -1, 0, 4, -1, 5, 4, -1, 2, -1, -1});
            row(1, {0, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, 4, -1, -1, -1});
            row(2, {0, -1, -1, 0, -1, -1, 0, -1, 3, -1, -1, 3, -1, -1, 4, -1});
            row(3, {1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 1, 0}); row(5, {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0}); break;
        case 4: s.bpm = 128; s.scale = 0; s.root = 0; s.inst[0] = 0; s.inst[1] = 2; s.inst[2] = 2;
            row(0, {0, 2, 4, 7, 4, 2, 0, 2, 3, 5, 7, 9, 7, 5, 3, 5});
            row(2, {0, -1, 0, -1, 0, -1, 0, -1, 3, -1, 3, -1, 4, -1, 4, -1});
            row(3, {1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0}); row(4, {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}); row(5, {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0}); break;
        case 5: s.bpm = 78; s.scale = 3; s.root = 5; s.inst[0] = 2; s.inst[1] = 3; s.inst[2] = 1;
            row(0, {0, -1, -1, 2, -1, -1, 4, -1, -1, 2, -1, -1, 1, -1, -1, -1});
            row(1, {0, -1, -1, -1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1});
            row(2, {0, -1, -1, -1, -1, -1, -1, -1, 2, -1, -1, -1, -1, -1, -1, -1}); row(5, {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0}); break;
        case 6: s.bpm = 168; s.scale = 2; s.root = 0; s.inst[0] = 3; s.inst[1] = 1; s.inst[2] = 0;
            row(0, {0, 0, -1, 1, 0, -1, 3, -1, 0, 0, -1, 1, 0, -1, 4, 3});
            row(1, {0, -1, -1, -1, 1, -1, -1, -1, 0, -1, -1, -1, 5, -1, -1, -1});
            row(2, {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0});
            row(3, {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1}); row(4, {0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0}); row(5, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}); break;
        default: s.bpm = 92; s.scale = 0; s.root = 5; s.inst[0] = 2; s.inst[1] = 3; s.inst[2] = 3;
            row(0, {4, -1, 2, -1, 0, -1, 2, -1, 4, -1, 5, -1, 4, -1, -1, -1});
            row(1, {0, -1, -1, -1, -1, -1, -1, -1, 3, -1, -1, -1, -1, -1, -1, -1});
            row(2, {0, -1, -1, -1, 0, -1, -1, -1, 3, -1, -1, -1, 3, -1, -1, -1}); row(3, {1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0}); row(5, {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0}); break;
    }
    for (int i = 0; i < 6; i++) if (s.cell[i][0] == -1 && i >= 3) for (int j = 0; j < 16; j++) if (s.cell[i][j] < 0) s.cell[i][j] = 0;
}

void musicRandom(MusicSong& s, unsigned seed) {
    unsigned st = seed * 2246822519u + 11;
    s.clear();
    static const int chords[4] = {0, 5, 3, 4};
    for (int i = 0; i < 16; i++) {
        if (i % 4 == 0) { s.cell[1][i] = chords[(i / 4 + (int)(rnd(st) % 2)) % 4]; s.cell[2][i] = s.cell[1][i]; }
        if (rnd(st) % 100 < 55) s.cell[0][i] = (int)(rnd(st) % 8);
        else s.cell[0][i] = -1;
        s.cell[3][i] = (i % 4 == 0) ? 1 : (int)(rnd(st) % 100 < 12);
        s.cell[4][i] = (i % 8 == 4) ? 1 : (int)(rnd(st) % 100 < 8);
        s.cell[5][i] = (i % 2 == 0) ? 1 : (int)(rnd(st) % 100 < 35);
    }
    s.inst[0] = (int)(rnd(st) % 4); s.inst[1] = (int)(rnd(st) % 4); s.inst[2] = (int)(rnd(st) % 4);
}
}  // namespace forge
