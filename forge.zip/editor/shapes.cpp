// Formas básicas 3D (esfera, cilindro, cono, pirámide, rampa, escalera, domo...) hechas con código.
// Se guardan como modelos (.fmdl) dentro del proyecto, así tienen textura, color, colisión y rampas caminables como cualquier modelo.
#include "editor.h"
#include "model.h"
#include <array>
#include <cmath>

namespace forge {

namespace {
const float kPi = 3.14159265f;
struct MB {
    ModelData m;
    void vert(float x, float y, float z, float nx, float ny, float nz, float u, float v) {
        for (float f : {x, y, z, nx, ny, nz, u, v}) m.v.push_back(f);
    }
    uint32_t n() const { return (uint32_t)(m.v.size() / 8); }
    // triángulo con la cara hacia afuera (se arregla el giro mirando contra un punto interior)
    void tri(uint32_t a, uint32_t b, uint32_t c, float ix = 0, float iy = 0, float iz = 0) {
        auto P = [&](uint32_t i, int k) { return m.v[i * 8 + k]; };
        float ux = P(b, 0) - P(a, 0), uy = P(b, 1) - P(a, 1), uz = P(b, 2) - P(a, 2);
        float vx = P(c, 0) - P(a, 0), vy = P(c, 1) - P(a, 1), vz = P(c, 2) - P(a, 2);
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float cx = (P(a, 0) + P(b, 0) + P(c, 0)) / 3 - ix, cy = (P(a, 1) + P(b, 1) + P(c, 1)) / 3 - iy, cz = (P(a, 2) + P(b, 2) + P(c, 2)) / 3 - iz;
        if (nx * cx + ny * cy + nz * cz >= 0) { m.idx.push_back(a); m.idx.push_back(b); m.idx.push_back(c); }
        else { m.idx.push_back(a); m.idx.push_back(c); m.idx.push_back(b); }
    }
    // igual, pero la cara mira hacia el eje (pared interior de un tubo)
    void triIn(uint32_t a, uint32_t b, uint32_t c) {
        size_t n0 = m.idx.size();
        tri(a, b, c);
        std::swap(m.idx[n0 + 1], m.idx[n0 + 2]);
    }
    // cara plana (polígono convexo) con su propia normal
    void face(const std::vector<std::array<float, 5>>& pts, float ix = 0, float iy = 0, float iz = 0) {
        if (pts.size() < 3) return;
        uint32_t s = n();
        float ux = pts[1][0] - pts[0][0], uy = pts[1][1] - pts[0][1], uz = pts[1][2] - pts[0][2];
        float vx = pts[2][0] - pts[0][0], vy = pts[2][1] - pts[0][1], vz = pts[2][2] - pts[0][2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float l = std::sqrt(nx * nx + ny * ny + nz * nz); if (l < 1e-8f) return;
        nx /= l; ny /= l; nz /= l;
        float cx = pts[0][0] - ix, cy = pts[0][1] - iy, cz = pts[0][2] - iz;
        if (nx * cx + ny * cy + nz * cz < 0) { nx = -nx; ny = -ny; nz = -nz; }
        for (auto& p : pts) vert(p[0], p[1], p[2], nx, ny, nz, p[3], p[4]);
        for (size_t i = 1; i + 1 < pts.size(); i++) tri(s, s + (uint32_t)i, s + (uint32_t)i + 1, ix, iy, iz);
    }
    void box(float x0, float y0, float z0, float x1, float y1, float z1) {
        float cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, cz = (z0 + z1) / 2;
        face({{x0, y0, z1, 0, 0}, {x1, y0, z1, 1, 0}, {x1, y1, z1, 1, 1}, {x0, y1, z1, 0, 1}}, cx, cy, cz);
        face({{x1, y0, z0, 0, 0}, {x0, y0, z0, 1, 0}, {x0, y1, z0, 1, 1}, {x1, y1, z0, 0, 1}}, cx, cy, cz);
        face({{x0, y0, z0, 0, 0}, {x0, y0, z1, 1, 0}, {x0, y1, z1, 1, 1}, {x0, y1, z0, 0, 1}}, cx, cy, cz);
        face({{x1, y0, z1, 0, 0}, {x1, y0, z0, 1, 0}, {x1, y1, z0, 1, 1}, {x1, y1, z1, 0, 1}}, cx, cy, cz);
        face({{x0, y1, z1, 0, 0}, {x1, y1, z1, 1, 0}, {x1, y1, z0, 1, 1}, {x0, y1, z0, 0, 1}}, cx, cy, cz);
        face({{x0, y0, z0, 0, 0}, {x1, y0, z0, 1, 0}, {x1, y0, z1, 1, 1}, {x0, y0, z1, 0, 1}}, cx, cy, cz);
    }
};
}  // namespace

const char* shapeName(int id) {
    static const char* n[] = {"Esfera", "Cilindro", "Cono", "Pirámide", "Rampa", "Escalera", "Domo (media esfera)", "Prisma triangular", "Tubo (cilindro hueco)", "Cápsula"};
    return id >= 0 && id < kShapeCount ? n[id] : "Forma";
}

bool makeShape(int id, ModelData& out) {
    MB b;
    const int S = 28;
    auto ring = [&](float y, float r, int k) { return std::array<float, 2>{r * std::cos(2 * kPi * k / S), r * std::sin(2 * kPi * k / S)}; };
    switch (id) {
        case 0: case 6: case 9: {   // esfera / domo / cápsula
            const int St = 16;
            float rad = id == 9 ? 0.25f : 0.5f;
            int from = id == 6 ? St / 2 : 0;   // el domo solo usa la mitad de arriba
            struct Row { float ph, yoff; };
            std::vector<Row> rows;
            for (int i = (id == 6 ? 0 : from); i <= (id == 6 ? St / 2 : St); i++) {
                float ph = kPi * i / St;
                if (id == 9 && i == St / 2) { rows.push_back({ph, 0.25f}); rows.push_back({ph, -0.25f}); }   // la cápsula tiene un cuerpo recto en medio
                else rows.push_back({ph, id == 9 ? (i < St / 2 ? 0.25f : -0.25f) : 0.f});
            }
            uint32_t base = b.n();
            for (size_t i = 0; i < rows.size(); i++) {
                float ph = rows[i].ph;
                for (int k = 0; k <= S; k++) {
                    float th = 2 * kPi * k / S;
                    float nx = std::sin(ph) * std::cos(th), ny = std::cos(ph), nz = std::sin(ph) * std::sin(th);
                    b.vert(nx * rad, ny * rad + rows[i].yoff, nz * rad, nx, ny, nz, (float)k / S, 1.f - (float)i / (float)(rows.size() - 1));
                }
            }
            for (size_t i = 0; i + 1 < rows.size(); i++)
                for (int k = 0; k < S; k++) {
                    uint32_t a = base + (uint32_t)i * (S + 1) + k, c = a + S + 1;
                    b.tri(a, c, a + 1, 0, id == 6 ? -0.2f : 0.f, 0); b.tri(a + 1, c, c + 1, 0, id == 6 ? -0.2f : 0.f, 0);
                }
            if (id == 6) {   // base plana del domo
                std::vector<std::array<float, 5>> pts;
                for (int k = 0; k < S; k++) { auto r = ring(0, 0.5f, k); pts.push_back({r[0], 0.f, r[1], 0.5f + r[0], 0.5f + r[1]}); }
                b.face(pts, 0, 0.3f, 0);
                // el domo ocupa la mitad de abajo del cubo unitario hasta arriba: se estira al alto completo
                for (size_t i = 1; i < b.m.v.size(); i += 8) b.m.v[i] = b.m.v[i] * 2.f - 0.5f;
            }
            break;
        }
        case 1: case 8: {   // cilindro / tubo
            float r = 0.5f, ri = 0.32f;
            uint32_t s0 = b.n();
            for (int k = 0; k <= S; k++) {
                float c = std::cos(2 * kPi * k / S), s = std::sin(2 * kPi * k / S);
                b.vert(r * c, -.5f, r * s, c, 0, s, (float)k / S, 0); b.vert(r * c, .5f, r * s, c, 0, s, (float)k / S, 1);
            }
            for (int k = 0; k < S; k++) { uint32_t a = s0 + k * 2; b.tri(a, a + 1, a + 2); b.tri(a + 2, a + 1, a + 3); }
            if (id == 1) {
                for (float y : {-.5f, .5f}) {
                    std::vector<std::array<float, 5>> pts;
                    for (int k = 0; k < S; k++) { auto q = ring(y, r, k); pts.push_back({q[0], y, q[1], 0.5f + q[0], 0.5f + q[1]}); }
                    b.face(pts, 0, 0, 0);
                }
            } else {
                uint32_t s1 = b.n();
                for (int k = 0; k <= S; k++) {
                    float c = std::cos(2 * kPi * k / S), s = std::sin(2 * kPi * k / S);
                    b.vert(ri * c, -.5f, ri * s, -c, 0, -s, (float)k / S, 0); b.vert(ri * c, .5f, ri * s, -c, 0, -s, (float)k / S, 1);
                }
                for (int k = 0; k < S; k++) { uint32_t a = s1 + k * 2; b.triIn(a, a + 2, a + 1); b.triIn(a + 2, a + 3, a + 1); }
                // las tapas ya no se ven con el hueco: se hacen anillos
                for (float y : {-.5f, .5f}) {
                    uint32_t t0 = b.n();
                    for (int k = 0; k <= S; k++) {
                        float c = std::cos(2 * kPi * k / S), s = std::sin(2 * kPi * k / S);
                        b.vert(r * c, y, r * s, 0, y > 0 ? 1.f : -1.f, 0, 0.5f + 0.5f * c, 0.5f + 0.5f * s);
                        b.vert(ri * c, y, ri * s, 0, y > 0 ? 1.f : -1.f, 0, 0.5f + 0.5f * ri / r * c, 0.5f + 0.5f * ri / r * s);
                    }
                    for (int k = 0; k < S; k++) { uint32_t a = t0 + k * 2; b.tri(a, a + 1, a + 2, 0, y > 0 ? -1.f : 1.f, 0); b.tri(a + 2, a + 1, a + 3, 0, y > 0 ? -1.f : 1.f, 0); }
                }
            }
            if (id == 9) {}
            break;
        }
        case 2: {   // cono
            uint32_t s0 = b.n();
            for (int k = 0; k <= S; k++) {
                float c = std::cos(2 * kPi * k / S), s = std::sin(2 * kPi * k / S);
                b.vert(0, .5f, 0, c * 0.894f, 0.447f, s * 0.894f, (float)k / S, 1);
                b.vert(0.5f * c, -.5f, 0.5f * s, c * 0.894f, 0.447f, s * 0.894f, (float)k / S, 0);
            }
            for (int k = 0; k < S; k++) { uint32_t a = s0 + k * 2; b.tri(a, a + 1, a + 3, 0, 0, 0); }
            std::vector<std::array<float, 5>> pts;
            for (int k = 0; k < S; k++) { auto q = ring(-.5f, .5f, k); pts.push_back({q[0], -.5f, q[1], 0.5f + q[0], 0.5f + q[1]}); }
            b.face(pts, 0, 0, 0);
            break;
        }
        case 3: {   // pirámide
            float ap[3] = {0, .5f, 0};
            auto side = [&](float x0, float z0, float x1, float z1) {
                b.face({{x0, -.5f, z0, 0, 0}, {x1, -.5f, z1, 1, 0}, {ap[0], ap[1], ap[2], .5f, 1}}, 0, 0, 0);
            };
            side(-.5f, .5f, .5f, .5f); side(.5f, .5f, .5f, -.5f); side(.5f, -.5f, -.5f, -.5f); side(-.5f, -.5f, -.5f, .5f);
            b.face({{-.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, -.5f, 1, 0}, {.5f, -.5f, .5f, 1, 1}, {-.5f, -.5f, .5f, 0, 1}}, 0, 0, 0);
            break;
        }
        case 4: {   // rampa: sube hacia -Z (el lado alto queda atrás)
            b.face({{-.5f, -.5f, .5f, 0, 0}, {.5f, -.5f, .5f, 1, 0}, {.5f, .5f, -.5f, 1, 1}, {-.5f, .5f, -.5f, 0, 1}}, 0, -.2f, 0);   // la cuesta
            b.face({{-.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, -.5f, 1, 0}, {.5f, .5f, -.5f, 1, 1}, {-.5f, .5f, -.5f, 0, 1}}, 0, 0, 0);       // atrás
            b.face({{-.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, -.5f, 1, 0}, {.5f, -.5f, .5f, 1, 1}, {-.5f, -.5f, .5f, 0, 1}}, 0, 0, 0);       // abajo
            b.face({{-.5f, -.5f, .5f, 0, 0}, {-.5f, -.5f, -.5f, 1, 0}, {-.5f, .5f, -.5f, 1, 1}}, 0, 0, 0);                               // lado izq
            b.face({{.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, .5f, 1, 0}, {.5f, .5f, -.5f, 0, 1}}, 0, 0, 0);                                   // lado der
            break;
        }
        case 5: {   // escalera de 6 escalones (sube hacia -Z)
            const int N = 6;
            for (int i = 0; i < N; i++) {
                float z1 = .5f - (float)i / N, z0 = z1 - 1.f / N, top = -.5f + (float)(i + 1) / N;
                b.box(-.5f, -.5f, z0, .5f, top, z1);
            }
            break;
        }
        case 7: {   // prisma triangular (techo)
            b.face({{-.5f, -.5f, .5f, 0, 0}, {.5f, -.5f, .5f, 1, 0}, {.5f, .5f, 0, 1, 1}, {-.5f, .5f, 0, 0, 1}}, 0, 0, 0);
            b.face({{.5f, -.5f, -.5f, 0, 0}, {-.5f, -.5f, -.5f, 1, 0}, {-.5f, .5f, 0, 1, 1}, {.5f, .5f, 0, 0, 1}}, 0, 0, 0);
            b.face({{-.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, -.5f, 1, 0}, {.5f, -.5f, .5f, 1, 1}, {-.5f, -.5f, .5f, 0, 1}}, 0, 0, 0);
            b.face({{-.5f, -.5f, .5f, 0, 0}, {-.5f, -.5f, -.5f, 1, 0}, {-.5f, .5f, 0, .5f, 1}}, 0, 0, 0);
            b.face({{.5f, -.5f, -.5f, 0, 0}, {.5f, -.5f, .5f, 1, 0}, {.5f, .5f, 0, .5f, 1}}, 0, 0, 0);
            break;
        }
        default: return false;
    }
    b.m.color[0] = b.m.color[1] = b.m.color[2] = 1.f;
    out = std::move(b.m);
    return !out.idx.empty();
}

void Editor::addShape(int id) {
    if (!hasScene()) return;
    ModelData md;
    if (!makeShape(id, md)) return;
    static const char* key[] = {"esfera", "cilindro", "cono", "piramide", "rampa", "escalera", "domo", "prisma", "tubo", "capsula"};
    std::string file = std::string("forma_") + key[id] + ".fmdl";
    if (!edit_.proj.assets.count(file)) {
        std::vector<uint8_t> bytes;
        if (!modelWrite(md, bytes)) { toast("No pude crear la forma"); return; }
        edit_.proj.assets[file] = std::move(bytes);
    }
    addObject(Kind::Model, file);
    Scene& S = scene();
    if (!S.objs.empty()) {
        Obj& o = S.objs.back();
        o.name = uniqueName(shapeName(id));
        o.color[0] = o.color[1] = o.color[2] = 0.8f;
        o.solid = true;
        if (id == 4 || id == 5) o.scale = V3{3, 1.5f, 4};
        if (id == 1 || id == 8 || id == 9) o.scale = V3{1.5f, 2, 1.5f};
        o.pos.y = o.scale.y * 0.5f;
        if (id == 9) o.scale = V3{1, 2, 1};
        sel_ = (int)S.objs.size() - 1;
    }
    markDirty();
}

}  // namespace forge
