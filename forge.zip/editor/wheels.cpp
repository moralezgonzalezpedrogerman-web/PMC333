// «Crear llantas»: se marcan las llantas sobre varias vistas del modelo y «Recortar» las separa en objetos que giran solos.
#include "editor.h"
#include "model.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <map>

namespace forge {

namespace {
struct WheelDef { float c[3] = {0, 0, 0}; float r = 0.3f, hw = 0.1f; };   // en unidades del mundo (ya con el tamaño del objeto), ejes del modelo
std::vector<WheelDef> gW;
int gSel = -1, gAxle = 0;
std::string gCloudFor;
std::vector<V3> gCloud;
}

void Editor::openWheels(Obj& o) {
    wheelsOpen_ = true;
    gW.clear(); gSel = -1; gCloudFor.clear();
    gAxle = o.wheelAxle;
    float fo = o.frontOff;
    if (std::fabs(fo - 90.f) < 1.f || std::fabs(fo - 270.f) < 1.f) gAxle = 1; else gAxle = 0;
}

bool Editor::wheelsWindow(Obj& o, Scene& S) {
    bool ch = false;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ds, ImGuiCond_Appearing);
    if (!ImGui::Begin("Crear llantas", &wheelsOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) { ImGui::End(); return false; }
    const float fs = ImGui::GetFontSize();
    Files& A = edit_.proj.assets;
    if (gCloudFor != o.model) {   // nube de puntos del modelo, ya con el tamaño del objeto
        gCloudFor = o.model; gCloud.clear();
        ModelData md;
        auto it = A.find(o.model);
        if (it != A.end() && modelRead(it->second.data(), it->second.size(), md) && md.v.size() >= 8) {
            size_t n = md.v.size() / 8, step = std::max<size_t>(1, n / 6000);
            for (size_t i = 0; i < n; i += step) gCloud.push_back(V3{md.v[i * 8] * o.scale.x, md.v[i * 8 + 1] * o.scale.y, md.v[i * 8 + 2] * o.scale.z});
        }
    }
    if (gCloud.empty()) { ImGui::TextWrapped("Este objeto no tiene un modelo 3D editable."); if (wrapui::Button("Cerrar")) wheelsOpen_ = false; ImGui::End(); return false; }
    const int ax = gAxle == 0 ? 0 : 2, lg = gAxle == 0 ? 2 : 0;   // eje de la llanta y eje largo del auto
    const float sc[3] = {o.scale.x, o.scale.y, o.scale.z};
    ImGui::TextWrapped("Toca la vista de lado y arrastra para mover la llanta elegida. Ajusta tamaño y ancho abajo. «Recortar» separa esa parte del modelo y la convierte en llanta que gira al avanzar.");
    {
        static const char* an[2] = {"Eje de las llantas: X (el auto mira hacia delante/atrás)", "Eje de las llantas: Z (el auto mira hacia los lados)"};
        if (ImGui::BeginCombo("##axl", an[gAxle])) { for (int k = 0; k < 2; k++) if (ImGui::Selectable(an[k], k == gAxle)) gAxle = k; ImGui::EndCombo(); }
        float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int per = aw > fs * 40.f ? 5 : 3;
        float bw = (aw - sp * (per - 1)) / per;
        int bi = 0;
        auto nb = [&](const char* t) { if (bi++ % per) ImGui::SameLine(); return wrapui::Button(t, ImVec2(bw, fs * 2.2f)); };
        if (nb("Añadir llanta") && gW.size() < 8) {
            WheelDef w; w.r = 0.2f * sc[1]; w.hw = 0.07f * sc[ax];
            w.c[ax] = 0.5f * sc[ax] - w.hw; w.c[1] = -0.5f * sc[1] + w.r; w.c[lg] = 0.3f * sc[lg];
            gW.push_back(w); gSel = (int)gW.size() - 1;
        }
        if (nb("Espejo") && gSel >= 0 && gSel < (int)gW.size() && gW.size() < 8) { WheelDef w = gW[gSel]; w.c[ax] = -w.c[ax]; gW.push_back(w); gSel = (int)gW.size() - 1; }
        if (nb("Quitar") && gSel >= 0 && gSel < (int)gW.size()) { gW.erase(gW.begin() + gSel); gSel = gW.empty() ? -1 : 0; }
        bool doCut = nb("Recortar");
        if (nb("Cerrar")) wheelsOpen_ = false;
        if (doCut) {
            if (gW.empty()) toast("Primero añade al menos una llanta");
            else {
                ModelData md;
                auto it = A.find(o.model);
                if (it == A.end() || !modelRead(it->second.data(), it->second.size(), md)) { toast("No se pudo leer el modelo"); }
                else {
                    size_t nt = md.idx.size() / 3;
                    std::vector<int> owner(nt, -1);
                    std::vector<int> cnt(gW.size(), 0);
                    for (size_t t = 0; t < nt; t++) {
                        float p[3] = {0, 0, 0};
                        for (int k = 0; k < 3; k++) for (int a = 0; a < 3; a++) p[a] += md.v[md.idx[t * 3 + k] * 8 + a] * sc[a] / 3.f;
                        for (size_t j = 0; j < gW.size(); j++) {
                            const WheelDef& w = gW[j];
                            float dl = p[lg] - w.c[lg], dy = p[1] - w.c[1];
                            if (std::fabs(p[ax] - w.c[ax]) <= w.hw && dl * dl + dy * dy <= w.r * w.r) { owner[t] = (int)j; cnt[j]++; break; }
                        }
                    }
                    int empty = -1;
                    for (size_t j = 0; j < gW.size(); j++) if (cnt[j] == 0) empty = (int)j + 1;
                    if (empty > 0) toast("La llanta " + std::to_string(empty) + " no toma ninguna parte del modelo: acércala o hazla más grande");
                    else {
                        auto build = [&](int who, const float* ctr, ModelData& out) {
                            out.tex = md.tex; for (int k = 0; k < 3; k++) out.color[k] = md.color[k];
                            std::map<uint32_t, uint32_t> mp;
                            for (size_t t = 0; t < nt; t++) {
                                if (owner[t] != who) continue;
                                for (int k = 0; k < 3; k++) {
                                    uint32_t oi = md.idx[t * 3 + k];
                                    auto f = mp.find(oi);
                                    if (f == mp.end()) {
                                        uint32_t ni = (uint32_t)(out.v.size() / 8);
                                        for (int a = 0; a < 8; a++) out.v.push_back(md.v[oi * 8 + a]);
                                        if (ctr) for (int a = 0; a < 3; a++) out.v[ni * 8 + a] -= ctr[a] / sc[a];
                                        f = mp.emplace(oi, ni).first;
                                    }
                                    out.idx.push_back(f->second);
                                }
                            }
                        };
                        std::string base = o.model.size() > 5 ? o.model.substr(0, o.model.size() - 5) : o.model;
                        auto freeName = [&](const std::string& b) { std::string n = b + ".fmdl"; for (int i = 2; A.count(n); i++) n = b + "_" + std::to_string(i) + ".fmdl"; return n; };
                        ModelData body; build(-1, nullptr, body);
                        std::vector<uint8_t> bytes;
                        std::string bodyName = freeName(base + "_cuerpo");
                        bool ok = !body.idx.empty() && modelWrite(body, bytes);
                        if (!ok) toast("El cuerpo quedó vacío: las llantas son demasiado grandes");
                        else {
                            A[bodyName] = bytes; assetDirty_.insert(bodyName);
                            float fo = o.frontOff * 0.0174532925f, fl[2] = {-std::sin(fo), -std::cos(fo)};
                            std::string carName = o.name;
                            const Obj car = o;   // copia: al agregar objetos la referencia a 'o' dejaría de ser válida
                            o.model = bodyName;
                            int made = 0;
                            std::vector<Obj> newObjs;
                            for (size_t j = 0; j < gW.size(); j++) {
                                ModelData wm; build((int)j, gW[j].c, wm);
                                std::vector<uint8_t> wb;
                                if (!modelWrite(wm, wb)) continue;
                                std::string wn = freeName(base + "_llanta");
                                A[wn] = wb; assetDirty_.insert(wn);
                                Obj w; w.kind = Kind::Model; w.model = wn; w.scale = car.scale; w.yaw = car.yaw; w.solid = false;
                                w.color[0] = w.color[1] = w.color[2] = 1.f; w.noColor = false;
                                w.wheelOf = carName; w.wheelAxle = gAxle; w.wheelR = std::max(0.02f, gW[j].r);
                                w.wheelOff = V3{gW[j].c[0] / sc[0], gW[j].c[1] / sc[1], gW[j].c[2] / sc[2]};
                                w.wheelFront = (gW[j].c[0] * fl[0] + gW[j].c[2] * fl[1]) > 0.f;
                                float ya = car.yaw * 0.0174532925f, cs = std::cos(ya), sn = std::sin(ya);
                                V3 lo{gW[j].c[0], gW[j].c[1], gW[j].c[2]};
                                w.pos = V3{car.pos.x + cs * lo.x + sn * lo.z, car.pos.y + lo.y, car.pos.z - sn * lo.x + cs * lo.z};
                                w.name = carName + "_llanta" + std::to_string(j + 1);
                                wheelNew_.push_back(w);   // se agregan al inicio del siguiente cuadro (así no se invalidan referencias)
                                made++;
                            }
                            wheelsOpen_ = false;
                            toast(std::to_string(made) + " llanta(s) creadas: giran al avanzar y las de adelante giran al dar vuelta");
                            markDirty(); ch = true;
                        }
                    }
                }
            }
        }
    }
    if (!wheelsOpen_) { ImGui::End(); return ch; }
    if (gSel >= 0 && gSel < (int)gW.size()) {
        WheelDef& w = gW[gSel];
        const float hx = 0.6f * sc[0], hy = 0.6f * sc[1], hz = 0.6f * sc[2];
        float pl = w.c[lg], py = w.c[1], pa = w.c[ax];
        float hl = lg == 2 ? hz : hx, ha = ax == 0 ? hx : hz;
        wrapui::SliderFloat("Adelante / atrás", &pl, -hl, hl);
        wrapui::SliderFloat("Altura", &py, -hy, hy);
        wrapui::SliderFloat("Lado (hacia afuera)", &pa, -ha, ha);
        wrapui::SliderFloat("Tamaño (radio)", &w.r, 0.02f * sc[1], 0.5f * sc[1] + 0.001f);
        wrapui::SliderFloat("Ancho", &w.hw, 0.01f * sc[ax], 0.35f * sc[ax]);
        w.c[lg] = pl; w.c[1] = py; w.c[ax] = pa;
    }
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(120.f, av.y - 2.f);
    bool wide = av.x > av.y * 1.4f;
    struct R { ImVec2 a, b; };
    R rs[3];
    if (wide) { float w3 = av.x / 3.f; for (int i = 0; i < 3; i++) rs[i] = {ImVec2(org.x + w3 * i + 2, org.y), ImVec2(org.x + w3 * (i + 1) - 2, org.y + av.y)}; }
    else {
        float h1 = av.y * 0.58f, h2 = av.y - h1;
        rs[0] = {ImVec2(org.x, org.y), ImVec2(org.x + av.x, org.y + h1 - 2)};
        rs[1] = {ImVec2(org.x, org.y + h1), ImVec2(org.x + av.x * 0.5f - 2, org.y + av.y)};
        rs[2] = {ImVec2(org.x + av.x * 0.5f + 2, org.y + h1), ImVec2(org.x + av.x, org.y + av.y)};
    }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    // vista 0: de lado (largo × altura); 1: de frente (lado × altura); 2: desde arriba (lado × largo)
    static const char* vn[3] = {"Lado (izq./der.)", "Frente / atrás", "Desde arriba"};
    ImVec2 sideC(0, 0); float sideK = 1.f;
    for (int vi = 0; vi < 3; vi++) {
        int hu = vi == 0 ? lg : ax, hv = vi == 2 ? lg : 1;
        float eu = 0.62f * sc[hu], ev = 0.62f * sc[hv];
        ImVec2 a = rs[vi].a, b = rs[vi].b;
        float k = std::min((b.x - a.x) / (2 * eu), (b.y - a.y - fs) / (2 * ev));
        ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f + fs * 0.5f);
        auto P = [&](float u, float v) { return ImVec2(c.x + u * k, c.y - v * k); };
        dl->AddRectFilled(a, b, IM_COL32(22, 26, 34, 255));
        dl->AddRect(a, b, IM_COL32(90, 100, 120, 255));
        dl->AddText(ImVec2(a.x + 6, a.y + 3), IM_COL32(255, 255, 255, 220), vn[vi]);
        for (auto& p : gCloud) { float u = (vi == 0 ? p.x * (lg == 0) + p.z * (lg == 2) : (ax == 0 ? p.x : p.z)); float v = vi == 2 ? (lg == 0 ? p.x : p.z) : p.y; ImVec2 q = P(u, v); dl->AddRectFilled(q, ImVec2(q.x + 1.6f, q.y + 1.6f), IM_COL32(170, 190, 220, 200)); }
        for (size_t j = 0; j < gW.size(); j++) {
            const WheelDef& w = gW[j];
            ImU32 col = (int)j == gSel ? IM_COL32(255, 220, 60, 255) : IM_COL32(80, 220, 255, 255);
            float cl = w.c[lg], cy = w.c[1], ca = w.c[ax];
            if (vi == 0) dl->AddCircle(P(cl, cy), w.r * k, col, 48, 2.5f);
            else if (vi == 1) dl->AddRect(P(ca - w.hw, cy + w.r), P(ca + w.hw, cy - w.r), col, 0.f, 0, 2.5f);
            else dl->AddRect(P(ca - w.hw, cl + w.r), P(ca + w.hw, cl - w.r), col, 0.f, 0, 2.5f);
            if (vi == 0) { char n[16]; snprintf(n, sizeof n, "%d", (int)j + 1); dl->AddText(P(cl, cy), col, n); }
        }
        if (vi == 0) { sideC = c; sideK = k; }
    }
    ImGui::SetCursorScreenPos(rs[0].a);
    ImGui::InvisibleButton("##wside", ImVec2(rs[0].b.x - rs[0].a.x, rs[0].b.y - rs[0].a.y));
    ImVec2 mp = ImGui::GetIO().MousePos;
    static bool dragging = false;
    if (ImGui::IsItemActivated()) {
        dragging = false;
        float best = 1e9f; int bi = -1;
        for (size_t j = 0; j < gW.size(); j++) {
            float dx = sideC.x + gW[j].c[lg] * sideK - mp.x, dy = sideC.y - gW[j].c[1] * sideK - mp.y, d = std::sqrt(dx * dx + dy * dy);
            if (d < gW[j].r * sideK + 28.f && d < best) { best = d; bi = (int)j; }
        }
        if (bi >= 0) { gSel = bi; dragging = true; }
    }
    if (ImGui::IsItemActive() && dragging && gSel >= 0 && gSel < (int)gW.size() && std::fabs(mp.x) < 1e6f) {
        gW[gSel].c[lg] = (mp.x - sideC.x) / sideK;
        gW[gSel].c[1] = (sideC.y - mp.y) / sideK;
    }
    if (!ImGui::IsItemActive()) dragging = false;
    ImGui::End();
    return ch;
}

}  // namespace forge
