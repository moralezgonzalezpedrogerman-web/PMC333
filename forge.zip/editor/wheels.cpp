// «Crear llantas»: se marcan las llantas sobre varias vistas del modelo y «Recortar» las separa en objetos que giran solos.
#include "editor.h"
#include "model.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <map>

namespace forge {

namespace {
struct WheelDef { float c[3] = {0, 0, 0}; float r = 0.3f, hw = 0.1f; };   // en unidades del mundo (ya con el tamaño del objeto), ejes del modelo
std::vector<WheelDef> gW;
int gSel = -1, gAxle = 0;
std::string gCloudFor;
std::vector<V3> gCloud;
}

void Editor::openWheels(Obj& o) {
    wheelsOpen_ = true; wheelsPlayer_ = false;
    gW.clear(); gSel = -1; gCloudFor.clear();
    gAxle = o.wheelAxle;
    float fo = o.frontOff;
    if (std::fabs(fo - 90.f) < 1.f || std::fabs(fo - 270.f) < 1.f) gAxle = 1; else gAxle = 0;
}

// Llantas del jugador (modo auto): se usa un objeto "de mentira" con el modelo y el tamaño con que se dibuja el jugador.
void Editor::openPlayerWheels() {
    if (!hasScene()) return;
    int pi = playerIndex(scene());
    if (pi < 0) return;
    const Obj& po = scene().objs[pi];
    const PlayerCfg& pc = edit_.proj.player;
    Obj p = po;
    p.model = pc.model; p.kind = Kind::Model; p.frontOff = 180.f; p.yaw = 0.f; p.wheelOf.clear();
    wheelBminY_ = 0.f;
    V3 sc = po.scale * pc.mscale;
    auto it = edit_.proj.assets.find(pc.model);
    ModelData md;
    if (it != edit_.proj.assets.end() && modelRead(it->second.data(), it->second.size(), md) && md.v.size() >= 8) {
        float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
        for (size_t i = 0; i + 7 < md.v.size(); i += 8) for (int a = 0; a < 3; a++) { mn[a] = std::min(mn[a], md.v[i + a]); mx[a] = std::max(mx[a], md.v[i + a]); }
        if (pc.fit) {
            float ex = std::max(0.001f, mx[0] - mn[0]), ey = std::max(0.001f, mx[1] - mn[1]), ez = std::max(0.001f, mx[2] - mn[2]);
            float k = std::min(po.scale.x / ex, std::min(po.scale.y / ey, po.scale.z / ez)) * pc.mscale;
            sc = V3{k, k, k};
        }
        wheelBminY_ = mn[1];
    }
    p.scale = sc;
    wheelProxy_ = p;
    openWheels(wheelProxy_);
    wheelsPlayer_ = true;
}

bool Editor::wheelsWindow(Obj& o, Scene& S) {
    bool ch = false;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f));
    ImGui::SetNextWindowSize(ds);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6.f, 4.f));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(5.f, 3.f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(5.f, 2.f));
    struct PopV { ~PopV() { ImGui::PopStyleVar(3); } } popv;
    if (!ImGui::Begin("Crear llantas", &wheelsOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings)) { ImGui::End(); return false; }
    const float fs = ImGui::GetFontSize();
    Files& A = edit_.proj.assets;
    if (gCloudFor != o.model) {   // nube de puntos del modelo, ya con el tamaño del objeto
        gCloudFor = o.model; gCloud.clear();
        ModelData md;
        auto it = A.find(o.model);
        if (it != A.end() && modelRead(it->second.data(), it->second.size(), md) && md.v.size() >= 8) {
            size_t n = md.v.size() / 8, step = std::max<size_t>(1, n / 1500);
            for (size_t i = 0; i < n; i += step) gCloud.push_back(V3{md.v[i * 8] * o.scale.x, md.v[i * 8 + 1] * o.scale.y, md.v[i * 8 + 2] * o.scale.z});
        }
    }
    if (gCloud.empty()) { ImGui::TextWrapped("Este objeto no tiene un modelo 3D editable."); if (wrapui::Button("Cerrar")) wheelsOpen_ = false; ImGui::End(); return false; }
    const int ax = gAxle == 0 ? 0 : 2, lg = gAxle == 0 ? 2 : 0;   // eje de la llanta y eje largo del auto
    const float sc[3] = {o.scale.x, o.scale.y, o.scale.z};
    ImGui::TextDisabled("Arrastra una llanta en las vistas de lado. Ajustes abajo. «Recortar» la separa y gira al avanzar.");
    {
        static const char* an[2] = {"Eje de las llantas: X (el auto mira hacia delante/atrás)", "Eje de las llantas: Z (el auto mira hacia los lados)"};
        if (ImGui::BeginCombo("##axl", an[gAxle])) { for (int k = 0; k < 2; k++) if (ImGui::Selectable(an[k], k == gAxle)) gAxle = k; ImGui::EndCombo(); }
        float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int per = aw > fs * 40.f ? 5 : 3;
        float bw = (aw - sp * (per - 1)) / per;
        int bi = 0;
        auto nb = [&](const char* t) { if (bi++ % per) ImGui::SameLine(); return wrapui::Button(t, ImVec2(bw, fs * 1.6f)); };
        if (nb("Añadir llanta") && gW.size() < 8) {
            WheelDef w; w.r = 0.2f * sc[1]; w.hw = 0.07f * sc[ax];
            w.c[ax] = 0.5f * sc[ax] - w.hw; w.c[1] = -0.5f * sc[1] + w.r; w.c[lg] = 0.3f * sc[lg];
            gW.push_back(w); gSel = (int)gW.size() - 1;
        }
        if (nb("Espejo") && gSel >= 0 && gSel < (int)gW.size() && gW.size() < 8) { WheelDef w = gW[gSel]; w.c[ax] = -w.c[ax]; gW.push_back(w); gSel = (int)gW.size() - 1; }
        if (nb("Quitar") && gSel >= 0 && gSel < (int)gW.size()) { gW.erase(gW.begin() + gSel); gSel = gW.empty() ? -1 : 0; }
        bool doCut = nb("Recortar");
        if (nb("Cerrar")) wheelsOpen_ = false;
        if (doCut) {
            if (gW.empty()) toast("Primero añade al menos una llanta");
            else {
                ModelData md;
                auto it = A.find(o.model);
                if (it == A.end() || !modelRead(it->second.data(), it->second.size(), md)) { toast("No se pudo leer el modelo"); }
                else {
                    size_t nt = md.idx.size() / 3;
                    std::vector<int> owner(nt, -1);
                    std::vector<int> cnt(gW.size(), 0);
                    for (size_t t = 0; t < nt; t++) {
                        float p[3] = {0, 0, 0};
                        for (int k = 0; k < 3; k++) for (int a = 0; a < 3; a++) p[a] += md.v[md.idx[t * 3 + k] * 8 + a] * sc[a] / 3.f;
                        for (size_t j = 0; j < gW.size(); j++) {
                            const WheelDef& w = gW[j];
                            float dl = p[lg] - w.c[lg], dy = p[1] - w.c[1];
                            if (std::fabs(p[ax] - w.c[ax]) <= w.hw && dl * dl + dy * dy <= w.r * w.r) { owner[t] = (int)j; cnt[j]++; break; }
                        }
                    }
                    int empty = -1;
                    for (size_t j = 0; j < gW.size(); j++) if (cnt[j] == 0) empty = (int)j + 1;
                    if (empty > 0) toast("La llanta " + std::to_string(empty) + " no toma ninguna parte del modelo: acércala o hazla más grande");
                    else {
                        auto build = [&](int who, const float* ctr, ModelData& out, float rad = 0.f, float hwid = 0.f) {
                            out.tex = md.tex; for (int k = 0; k < 3; k++) out.color[k] = md.color[k];
                            std::map<uint32_t, uint32_t> mp;
                            for (size_t t = 0; t < nt; t++) {
                                if (owner[t] != who) continue;
                                for (int k = 0; k < 3; k++) {
                                    uint32_t oi = md.idx[t * 3 + k];
                                    auto f = mp.find(oi);
                                    if (f == mp.end()) {
                                        uint32_t ni = (uint32_t)(out.v.size() / 8);
                                        for (int a = 0; a < 8; a++) out.v.push_back(md.v[oi * 8 + a]);
                                        if (ctr) {   // se moldea: todo punto queda dentro del cilindro de la llanta (sin picos ni partes aplastadas)
                                            float q[3];
                                            for (int a = 0; a < 3; a++) q[a] = out.v[ni * 8 + a] * sc[a] - ctr[a];
                                            float dd = std::sqrt(q[lg] * q[lg] + q[1] * q[1]);
                                            if (dd > rad && dd > 1e-6f) { q[lg] *= rad / dd; q[1] *= rad / dd; }
                                            q[ax] = std::max(-hwid, std::min(hwid, q[ax]));
                                            for (int a = 0; a < 3; a++) out.v[ni * 8 + a] = q[a] / sc[a];
                                        }
                                        f = mp.emplace(oi, ni).first;
                                    }
                                    out.idx.push_back(f->second);
                                }
                            }
                        };
                        std::string base = o.model.size() > 5 ? o.model.substr(0, o.model.size() - 5) : o.model;
                        auto freeName = [&](const std::string& b) { std::string n = b + ".fmdl"; for (int i = 2; A.count(n); i++) n = b + "_" + std::to_string(i) + ".fmdl"; return n; };
                        ModelData body; build(-1, nullptr, body);
                        std::vector<uint8_t> bytes;
                        std::string bodyName = freeName(base + "_cuerpo");
                        bool ok = !body.idx.empty() && modelWrite(body, bytes);
                        if (!ok) toast("El cuerpo quedó vacío: las llantas son demasiado grandes");
                        else {
                            A[bodyName] = bytes; assetDirty_.insert(bodyName);
                            float fo = o.frontOff * 0.0174532925f, fl[2] = {-std::sin(fo), -std::cos(fo)};
                            std::string carName = o.name;
                            const Obj car = o;   // copia: al agregar objetos la referencia a 'o' dejaría de ser válida
                            o.model = bodyName;
                            int made = 0;
                            std::vector<Obj> newObjs;
                            for (size_t j = 0; j < gW.size(); j++) {
                                ModelData wm; build((int)j, gW[j].c, wm, gW[j].r, gW[j].hw);
                                std::vector<uint8_t> wb;
                                if (!modelWrite(wm, wb)) continue;
                                std::string wn = freeName(base + "_llanta");
                                A[wn] = wb; assetDirty_.insert(wn);
                                Obj w; w.kind = Kind::Model; w.model = wn; w.scale = car.scale; w.yaw = car.yaw; w.solid = false;
                                w.color[0] = w.color[1] = w.color[2] = 1.f; w.noColor = false;
                                w.wheelOf = carName; w.wheelAxle = gAxle; w.wheelR = std::max(0.02f, gW[j].r);
                                w.wheelOff = V3{gW[j].c[0] / sc[0], gW[j].c[1] / sc[1], gW[j].c[2] / sc[2]};
                                if (wheelsPlayer_) w.wheelOff.y -= wheelBminY_;
                                w.wheelFront = (gW[j].c[0] * fl[0] + gW[j].c[2] * fl[1]) > 0.f;
                                float ya = car.yaw * 0.0174532925f, cs = std::cos(ya), sn = std::sin(ya);
                                V3 lo{gW[j].c[0], gW[j].c[1], gW[j].c[2]};
                                w.pos = V3{car.pos.x + cs * lo.x + sn * lo.z, car.pos.y + lo.y, car.pos.z - sn * lo.x + cs * lo.z};
                                w.name = carName + "_llanta" + std::to_string(j + 1);
                                {   // relleno negro: tapa los huecos transparentes que deja el recorte (cilindro que gira con la llanta)
                                    ModelData fm; fm.color[0] = fm.color[1] = fm.color[2] = 0.03f;
                                    const int SG = 20; const float rr = gW[j].r * 0.99f, hh = gW[j].hw * 0.99f;   // solo la banda del grosor (la banda de rodamiento); las caras laterales NO se rellenan
                                    auto pv = [&](float l, float y, float a, float nl, float ny, float na) {
                                        float q[3]; q[lg] = l; q[1] = y; q[ax] = a;
                                        float nn[3]; nn[lg] = nl; nn[1] = ny; nn[ax] = na;
                                        fm.v.insert(fm.v.end(), {q[0] / sc[0], q[1] / sc[1], q[2] / sc[2], nn[0], nn[1], nn[2], 0.5f, 0.5f});
                                    };
                                    for (int sgi = 0; sgi < SG; sgi++) {
                                        float a0 = sgi * 6.2831853f / SG, a1 = (sgi + 1) * 6.2831853f / SG;
                                        float c0 = std::cos(a0), s0 = std::sin(a0), c1 = std::cos(a1), s1 = std::sin(a1);
                                        uint32_t b = (uint32_t)(fm.v.size() / 8);
                                        pv(rr * c0, rr * s0, -hh, c0, s0, 0); pv(rr * c0, rr * s0, hh, c0, s0, 0);
                                        pv(rr * c1, rr * s1, hh, c1, s1, 0); pv(rr * c1, rr * s1, -hh, c1, s1, 0);
                                        fm.idx.insert(fm.idx.end(), {b, b + 1, b + 2, b, b + 2, b + 3, b, b + 2, b + 1, b, b + 3, b + 2});
                                    }
                                    std::vector<uint8_t> fb;
                                    if (modelWrite(fm, fb)) {
                                        std::string fn = freeName(base + "_relleno");
                                        A[fn] = fb; assetDirty_.insert(fn);
                                        Obj f = w; f.model = fn; f.name = w.name + "_relleno";
                                        wheelNew_.push_back(f);
                                    }
                                }
                                wheelNew_.push_back(w);   // se agregan al inicio del siguiente cuadro (así no se invalidan referencias)
                                made++;
                            }
                            wheelsOpen_ = false;
                            toast(std::to_string(made) + " llanta(s) creadas: giran al avanzar y las de adelante giran al dar vuelta");
                            markDirty(); ch = true;
                        }
                    }
                }
            }
        }
    }
    if (!wheelsOpen_) { ImGui::End(); return ch; }
    // Vistas arriba (zona fija) y ajustes abajo en un panel fijo que se desliza con el dedo.
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    const float panelH = std::max(fs * 6.5f, av.y * 0.30f);
    av.y = std::max(100.f, av.y - panelH - 4.f);
    const bool wide = av.x > av.y * 2.2f;
    struct R { ImVec2 a, b; };
    R rs[4];   // 0 lado A (+), 1 lado B (-, visto desde el lado contrario), 2 frente, 3 arriba
    if (wide) { float w4 = av.x / 4.f; for (int i = 0; i < 4; i++) rs[i] = {ImVec2(org.x + w4 * i + 1, org.y), ImVec2(org.x + w4 * (i + 1) - 1, org.y + av.y)}; }
    else {
        float hw2 = av.x * 0.5f, hh2 = av.y * 0.5f;
        for (int i = 0; i < 4; i++) { float x0 = org.x + (i % 2) * hw2, y0 = org.y + (i / 2) * hh2; rs[i] = {ImVec2(x0 + 1, y0 + 1), ImVec2(x0 + hw2 - 1, y0 + hh2 - 1)}; }
    }
    ImDrawList* dl = ImGui::GetWindowDrawList();
    static const char* vn[4] = {"Lado A (+)", "Lado B (-) opuesto", "Frente / atrás", "Desde arriba"};
    ImVec2 sideC[2] = {ImVec2(0, 0), ImVec2(0, 0)}; float sideK[2] = {1.f, 1.f};
    for (int vi = 0; vi < 4; vi++) {
        const bool side = vi < 2;
        int hu = side ? lg : ax, hv = vi == 3 ? lg : 1;
        float eu = 0.62f * sc[hu], ev = 0.62f * sc[hv];
        ImVec2 a = rs[vi].a, b = rs[vi].b;
        float k = std::min((b.x - a.x) / (2 * eu), (b.y - a.y - fs) / (2 * ev));
        ImVec2 c((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f + fs * 0.5f);
        const float flip = vi == 1 ? -1.f : 1.f;   // el lado opuesto se ve como en un espejo
        auto P = [&](float u, float v) { return ImVec2(c.x + flip * u * k, c.y - v * k); };
        dl->AddRectFilled(a, b, IM_COL32(22, 26, 34, 255));
        dl->AddRect(a, b, IM_COL32(90, 100, 120, 255));
        dl->AddText(ImVec2(a.x + 4, a.y + 2), IM_COL32(255, 255, 255, 220), vn[vi]);
        for (auto& p : gCloud) {
            float pa = ax == 0 ? p.x : p.z, pl = lg == 0 ? p.x : p.z;
            if (vi == 0 && pa < -0.02f * sc[ax]) continue;
            if (vi == 1 && pa > 0.02f * sc[ax]) continue;
            float u = side ? pl : pa, v = vi == 3 ? pl : p.y;
            ImVec2 q = P(u, v); dl->AddRectFilled(q, ImVec2(q.x + 1.5f, q.y + 1.5f), IM_COL32(170, 190, 220, 200));
        }
        for (size_t j = 0; j < gW.size(); j++) {
            const WheelDef& w = gW[j];
            bool mine = (vi == 0 && w.c[ax] >= 0.f) || (vi == 1 && w.c[ax] < 0.f) || !side;
            ImU32 col = (int)j == gSel ? IM_COL32(255, 220, 60, mine ? 255 : 110) : IM_COL32(80, 220, 255, mine ? 255 : 90);
            float cl = w.c[lg], cy = w.c[1], ca = w.c[ax];
            if (side) { dl->AddCircle(P(cl, cy), w.r * k, col, 40, mine ? 2.5f : 1.f); if (mine) { char n[16]; snprintf(n, sizeof n, "%d", (int)j + 1); dl->AddText(P(cl, cy), col, n); } }
            else if (vi == 2) dl->AddRect(P(ca - w.hw, cy + w.r), P(ca + w.hw, cy - w.r), col, 0.f, 0, 2.f);
            else dl->AddRect(P(ca - w.hw, cl + w.r), P(ca + w.hw, cl - w.r), col, 0.f, 0, 2.f);
        }
        if (side) { sideC[vi] = c; sideK[vi] = k; }
    }
    static int dragView = -1;
    for (int vi = 0; vi < 2; vi++) {
        ImGui::SetCursorScreenPos(rs[vi].a);
        char idn[16]; snprintf(idn, sizeof idn, "##wside%d", vi);
        ImGui::InvisibleButton(idn, ImVec2(rs[vi].b.x - rs[vi].a.x, rs[vi].b.y - rs[vi].a.y));
        ImVec2 mp = ImGui::GetIO().MousePos;
        const float flip = vi == 1 ? -1.f : 1.f;
        if (ImGui::IsItemActivated()) {
            float best = 1e9f; int bi = -1;
            for (size_t j = 0; j < gW.size(); j++) {
                float dx = sideC[vi].x + flip * gW[j].c[lg] * sideK[vi] - mp.x, dy = sideC[vi].y - gW[j].c[1] * sideK[vi] - mp.y, d = std::sqrt(dx * dx + dy * dy);
                if (d < gW[j].r * sideK[vi] + 28.f && d < best) { best = d; bi = (int)j; }
            }
            if (bi >= 0) { gSel = bi; dragView = vi; }
        }
        if (ImGui::IsItemActive() && dragView == vi && gSel >= 0 && gSel < (int)gW.size() && std::fabs(mp.x) < 1e6f) {
            gW[gSel].c[lg] = flip * (mp.x - sideC[vi].x) / sideK[vi];
            gW[gSel].c[1] = (sideC[vi].y - mp.y) / sideK[vi];
        }
    }
    if (!ImGui::IsMouseDown(0)) dragView = -1;
    ImGui::SetCursorScreenPos(ImVec2(org.x, org.y + av.y + 4.f));
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(4.f, 1.f));
    wrapui::BeginChild("##wopts", ImVec2(0, 0), true, kNoSB);
    dragScroll();
    if (gSel >= 0 && gSel < (int)gW.size()) {
        WheelDef& w = gW[gSel];
        const float hx = 0.6f * sc[0], hy = 0.6f * sc[1], hz = 0.6f * sc[2];
        float pl = w.c[lg], py = w.c[1], pa = w.c[ax];
        float hl = lg == 2 ? hz : hx, ha = ax == 0 ? hx : hz;
        ImGui::Text("Llanta %d", gSel + 1);
        const float cw = ImGui::GetContentRegionAvail().x - fs * 3.f, h2 = (cw - ImGui::GetStyle().ItemSpacing.x) * 0.5f;   // orilla derecha libre para deslizar
        stepField("Adelante", pl, 0.05f, -hl, hl, h2, "%.2f"); ImGui::SameLine(); stepField("Altura", py, 0.05f, -hy, hy, h2, "%.2f");
        stepField("Lado", pa, 0.05f, -ha, ha, h2, "%.2f"); ImGui::SameLine(); stepField("Radio", w.r, 0.02f, 0.02f * sc[1], 0.5f * sc[1] + 0.001f, h2, "%.2f");
        stepField("Ancho", w.hw, 0.01f, 0.01f * sc[ax], 0.35f * sc[ax], h2, "%.2f");
        w.c[lg] = pl; w.c[1] = py; w.c[ax] = pa;
    } else ImGui::TextDisabled("Toca una llanta en una vista de lado (o pulsa «Añadir llanta»).");
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    ImGui::PopStyleVar();
    ImGui::End();
    return ch;
}


// «Orientar el modelo»: el modelo del jugador se ve desde arriba y se marcan su frente y su parte de atrás; el giro se calcula solo.
void Editor::orientWindow() {
    if (!orientOpen_) return;
    PlayerCfg& P = edit_.proj.player;
    if (P.model.empty()) { orientOpen_ = false; return; }
    static std::string cloudFor; static std::vector<V3> cloud;
    static int step = 0; static bool hasF = false, hasB = false; static float fx = 0, fz = 0, bx = 0, bz = 0;
    if (cloudFor != P.model) {
        cloudFor = P.model; cloud.clear(); step = 0; hasF = hasB = false;
        ModelData md; auto it = edit_.proj.assets.find(P.model);
        if (it != edit_.proj.assets.end() && modelRead(it->second.data(), it->second.size(), md) && md.v.size() >= 8) {
            size_t n = md.v.size() / 8, st = std::max<size_t>(1, n / 1800);
            for (size_t i = 0; i < n; i += st) cloud.push_back(V3{md.v[i * 8], md.v[i * 8 + 1], md.v[i * 8 + 2]});
        }
    }
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f));
    ImGui::SetNextWindowSize(ds);
    if (!ImGui::Begin("Orientar el modelo", &orientOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings)) { ImGui::End(); return; }
    const float fs = ImGui::GetFontSize();
    ImGui::TextWrapped(step == 0 ? "Vista desde arriba. Toca la parte de ADELANTE (frente) del modelo." : step == 1 ? "Ahora toca la parte de ATRÁS del modelo (o pulsa «Solo frente»)." : "Listo. Si algo se ve mal, vuelve a marcar.");
    float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x, bw = (aw - sp * 3) / 4;
    if (wrapui::Button("Solo frente", ImVec2(bw, fs * 1.8f)) && step == 1) step = 2;
    ImGui::SameLine();
    if (wrapui::Button("Volver a marcar", ImVec2(bw, fs * 1.8f))) { step = 0; hasF = hasB = false; }
    ImGui::SameLine();
    if (wrapui::Button("Quitar giro", ImVec2(bw, fs * 1.8f))) { P.myaw = 0.f; markDirty(); }
    ImGui::SameLine();
    if (wrapui::Button("Listo", ImVec2(bw, fs * 1.8f))) orientOpen_ = false;
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(100.f, av.y - 4.f);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(org, ImVec2(org.x + av.x, org.y + av.y), IM_COL32(22, 26, 34, 255));
    float x0 = 1e9f, x1 = -1e9f, z0 = 1e9f, z1 = -1e9f;
    for (auto& q : cloud) { x0 = std::min(x0, q.x); x1 = std::max(x1, q.x); z0 = std::min(z0, q.z); z1 = std::max(z1, q.z); }
    float ex = std::max(0.05f, (x1 - x0) * 0.5f * 1.15f), ez = std::max(0.05f, (z1 - z0) * 0.5f * 1.15f);
    float k = std::min(av.x * 0.5f / ex, av.y * 0.5f / ez);
    ImVec2 c(org.x + av.x * 0.5f, org.y + av.y * 0.5f);
    float mx = (x0 + x1) * 0.5f, mz = (z0 + z1) * 0.5f;
    auto S2 = [&](float x, float z) { return ImVec2(c.x + (x - mx) * k, c.y + (z - mz) * k); };   // arriba de la pantalla = -Z del modelo
    for (auto& q : cloud) { ImVec2 p = S2(q.x, q.z); dl->AddRectFilled(p, ImVec2(p.x + 2.f, p.y + 2.f), IM_COL32(170, 190, 220, 210)); }
    if (hasF) { ImVec2 p = S2(fx, fz); dl->AddCircleFilled(p, fs * 0.7f, IM_COL32(60, 220, 90, 255)); dl->AddText(ImVec2(p.x + fs, p.y - fs * 0.5f), IM_COL32(120, 255, 150, 255), "FRENTE"); }
    if (hasB) { ImVec2 p = S2(bx, bz); dl->AddCircleFilled(p, fs * 0.7f, IM_COL32(240, 80, 70, 255)); dl->AddText(ImVec2(p.x + fs, p.y - fs * 0.5f), IM_COL32(255, 140, 130, 255), "ATRÁS"); }
    if (hasF && hasB) dl->AddLine(S2(bx, bz), S2(fx, fz), IM_COL32(255, 220, 60, 255), 3.f);
    ImGui::SetCursorScreenPos(org);
    ImGui::InvisibleButton("##orient", av);
    if (ImGui::IsItemDeactivated() && tapped()) {
        ImVec2 mp = ImGui::GetIO().MousePos;
        if (std::isfinite(mp.x) && std::fabs(mp.x) < 1e6f) {
            float wx = mx + (mp.x - c.x) / k, wz = mz + (mp.y - c.y) / k;
            if (step == 0) { fx = wx; fz = wz; hasF = true; hasB = false; step = 1; }
            else if (step == 1) { bx = wx; bz = wz; hasB = true; step = 2; }
            else { fx = wx; fz = wz; hasF = true; hasB = false; step = 1; }
            float dx = hasB ? fx - bx : fx - mx, dz = hasB ? fz - bz : fz - mz;
            if (hasF && (dx * dx + dz * dz) > 1e-8f) {   // +Z del modelo es el frente por defecto: se gira para que la marca quede al frente
                int pi = hasScene() ? playerIndex(scene()) : -1;
                V3 so = pi >= 0 ? scene().objs[pi].scale : V3{1, 1, 1};
                float a = std::atan2(dx * so.x, dz * so.z) / 0.0174532925f;
                P.myaw = std::round(-a);
                markDirty();
            }
        }
    }
    ImGui::End();
}


// Ajustes de un objeto sostenido en la mano: lado, giro (para cambiar por dónde se agarra), desplazamiento y tamaño.
bool Editor::handFields(int& side, float* rot, float* off, float& hs) {
    bool ch = false;
    const float fs = ImGui::GetFontSize();
    ch |= wrapui::RadioButton("Mano derecha", &side, 0); ImGui::SameLine();
    ch |= wrapui::RadioButton("Mano izquierda", &side, 1);
    const float cw = ImGui::GetContentRegionAvail().x - fs * 2.5f, h2 = (cw - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
    ImGui::TextDisabled("Giro (grados): cambia por dónde se agarra");
    ch |= stepField("Giro X", rot[0], 15.f, -180.f, 180.f, h2); ImGui::SameLine(); ch |= stepField("Giro Y", rot[1], 15.f, -180.f, 180.f, h2);
    ch |= stepField("Giro Z", rot[2], 15.f, -180.f, 180.f, h2);
    ImGui::TextDisabled("Posición respecto a la mano");
    ch |= stepField("Mover X", off[0], 0.02f, -2.f, 2.f, h2, "%.2f"); ImGui::SameLine(); ch |= stepField("Mover Y", off[1], 0.02f, -2.f, 2.f, h2, "%.2f");
    ch |= stepField("Mover Z", off[2], 0.02f, -2.f, 2.f, h2, "%.2f"); ImGui::SameLine(); ch |= stepField("Tamaño", hs, 0.1f, 0.1f, 5.f, h2, "%.2f");
    return ch;
}

}  // namespace forge
