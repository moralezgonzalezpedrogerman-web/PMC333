#include "editor.h"
#include "library.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>

namespace forge {

static const char* kPrev = "__prev_estudio.wav";
static std::string cleanName(const std::string& in) {
    std::string o;
    for (unsigned char c : in) o += (isalnum(c) || c == '_' || c == '-' || c >= 128) ? (char)c : (c == ' ' ? '_' : '\0');
    o.erase(std::remove(o.begin(), o.end(), '\0'), o.end());
    return o;
}
static std::string shortName(const std::string& s, size_t n) { return s.size() <= n ? s : s.substr(0, n - 1) + "…"; }

void Editor::openMusic() {
    musicOpen_ = true;
    if (song_.cell[3][0] == -1 && song_.cell[0][0] == -1) musicPreset(song_, 0);
}

void Editor::closeMusic() {
    musicOpen_ = false;
    musicPlaying_ = false;
    if (audio_) audio_->stopMusic();
    edit_.proj.assets.erase(kPrev);
    if (audio_) audio_->setAssets(edit_.proj.assets);
}

void Editor::musicWin() {
    if (!musicOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    bool open = true;
    if (!wrapui::Begin("Estudio de música", &open, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB |
                                                      kNoSW | ImGuiWindowFlags_NoSavedSettings)) { ImGui::End(); return; }
    wrapui::CloseBar(&open);
    if (!open) { ImGui::End(); closeMusic(); return; }
    float sp = ImGui::GetStyle().ItemSpacing.x;
    float fw = ImGui::GetContentRegionAvail().x;
    static const char* tabs[3] = {"Canción", "Efectos", "Biblioteca"};
    float tw = fw / 3.f;
    for (int i = 0; i < 3; i++) {
        if (i) ImGui::SameLine(0, 0);
        ImGui::PushStyleColor(ImGuiCol_Button, musicTab_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(tabs[i], ImVec2(tw, fs * 2.4f)) && tapped()) musicTab_ = i;
        ImGui::PopStyleColor();
    }
    wrapui::BeginChild("##mbody", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    auto saveWav = [&](const std::string& nm, std::vector<uint8_t> wav) {
        std::string n = cleanName(nm);
        if (n.empty()) n = "sonido";
        std::string f = n + ".wav";
        edit_.proj.assets[f] = std::move(wav);
        assetDirty_.insert(f);
        if (audio_) audio_->setAssets(edit_.proj.assets);
        markDirty();
        toast("Guardado en el proyecto: " + f);
    };
    auto preview = [&](const std::vector<uint8_t>& wav, bool loop) {
        edit_.proj.assets[kPrev] = wav;
        if (audio_) { audio_->setAssets(edit_.proj.assets); if (loop) audio_->music(kPrev); else audio_->play(kPrev); }
        musicPlaying_ = loop;
    };
    fw = ImGui::GetContentRegionAvail().x;
    float c2 = (fw - sp) / 2.f, c4 = (fw - sp * 3.f) / 4.f, bh = fs * 2.4f;

    if (musicTab_ == 0) {
        ImGui::TextDisabled("1) Elige un tipo de juego  2) Ajusta las notas  3) Escucha y guarda");
        for (int i = 0; i < 8; i++) {
            if (i % 4) ImGui::SameLine();
            if (wrapui::Button(kGenreNames[i], ImVec2(c4, bh)) && tapped()) { musicPreset(song_, i); if (musicPlaying_) preview(musicRender(song_), true); }
        }
        if (wrapui::Button("Aleatoria", ImVec2(c2, bh)) && tapped()) { musicRandom(song_, (unsigned)(ImGui::GetTime() * 1000)); if (musicPlaying_) preview(musicRender(song_), true); }
        ImGui::SameLine();
        if (wrapui::Button("Vaciar", ImVec2(c2, bh)) && tapped()) song_.clear();
        wrapui::SliderFloat("Velocidad (BPM)", &song_.bpm, 60.f, 200.f, "%.0f");
        ImGui::SetNextItemWidth(-1.f);
        if (wrapui::BeginCombo("Escala", kScaleNames[song_.scale])) {
            for (int i = 0; i < 5; i++) if (wrapui::Selectable(kScaleNames[i], song_.scale == i)) song_.scale = i;
            ImGui::EndCombo();
        }
        { float r = (float)song_.root; if (wrapui::SliderFloat("Tono", &r, -6.f, 6.f, "%.0f")) song_.root = (int)std::lround(r); }
        { float b = (float)song_.bars; if (wrapui::SliderFloat("Repeticiones en el archivo", &b, 1.f, 16.f, "%.0f")) song_.bars = (int)std::lround(b); }
        wrapui::SliderFloat("Vaivén (swing)", &song_.swing, 0.f, 1.f, "%.2f");
        static const char* tn[6] = {"Melodía", "Acordes", "Bajo", "Bombo", "Caja", "Platillo"};
        for (int t = 0; t < 3; t++) {
            ImGui::PushID(100 + t);
            ImGui::TextUnformatted(tn[t]);
            ImGui::SameLine();
            if (wrapui::Button(kInstNames[t][song_.inst[t]], ImVec2(fs * 7.f, fs * 2.f)) && tapped()) song_.inst[t] = (song_.inst[t] + 1) % 4;
            ImGui::PopID();
        }
        ImGui::SeparatorText("Pincel de notas (toca una nota y luego las casillas)");
        {
            float cb = (fw - sp * 8.f) / 9.f;
            for (int i = 0; i < 9; i++) {
                if (i) ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Button, musicBrush_ == i ? ImVec4(0.85f, 0.55f, 0.15f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
                ImGui::PushID(200 + i);
                if (wrapui::Button(i == 8 ? "x" : std::to_string(i + 1).c_str(), ImVec2(cb, bh)) && tapped()) musicBrush_ = i;
                ImGui::PopID();
                ImGui::PopStyleColor();
            }
            ImGui::TextDisabled("1-8 = nota de la escala, x = borrar. En bombo, caja y platillo basta tocar.");
        }
        for (int i = 0; i < 2; i++) {
            if (i) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, musicPage_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (wrapui::Button(i ? "Pasos 9-16" : "Pasos 1-8", ImVec2(c2, fs * 2.1f)) && tapped()) musicPage_ = i;
            ImGui::PopStyleColor();
        }
        float lab = fs * 4.6f, cell = std::max(fs * 1.6f, (fw - lab - sp * 8.f) / 8.f), ch = fs * 2.1f;
        ImDrawList* dl = ImGui::GetWindowDrawList();
        for (int t = 0; t < 6; t++) {
            ImGui::PushID(300 + t);
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(tn[t]);
            ImGui::SameLine(lab);
            for (int k = 0; k < 8; k++) {
                int i = musicPage_ * 8 + k;
                if (k) ImGui::SameLine(0, sp * 0.6f);
                ImGui::PushID(k);
                ImVec2 p0 = ImGui::GetCursorScreenPos();
                bool hit = ImGui::InvisibleButton("##c", ImVec2(cell, ch)) && tapped();
                int v = song_.cell[t][i];
                bool on = t < 3 ? v >= 0 : v > 0;
                ImU32 col = on ? (t < 3 ? IM_COL32(40, 190, 170, 255) : IM_COL32(230, 150, 50, 255)) : IM_COL32(40, 46, 66, 255);
                if ((k % 4) == 0 && !on) col = IM_COL32(52, 60, 86, 255);
                dl->AddRectFilled(p0, ImVec2(p0.x + cell, p0.y + ch), col, 5.f);
                if (t < 3 && on) {
                    char b[4]; snprintf(b, sizeof b, "%d", v % 8 + 1);
                    ImVec2 ts = ImGui::CalcTextSize(b);
                    dl->AddText(ImVec2(p0.x + (cell - ts.x) * 0.5f, p0.y + (ch - ts.y) * 0.5f), IM_COL32(10, 20, 30, 255), b);
                }
                if (hit) {
                    if (t < 3) {
                        int nv = musicBrush_ == 8 ? -1 : musicBrush_;
                        song_.cell[t][i] = (song_.cell[t][i] == nv) ? -1 : nv;
                    } else song_.cell[t][i] = on ? 0 : 1;
                    if (musicPlaying_) preview(musicRender(song_), true);
                    else if (audio_ && t < 3 && song_.cell[t][i] >= 0) { MusicSong one; one.bpm = 200; one.scale = song_.scale; one.root = song_.root; one.bars = 1; one.inst[t == 2 ? 2 : t] = song_.inst[t]; one.cell[t][0] = song_.cell[t][i]; preview(musicRender(one), false); }
                }
                ImGui::PopID();
            }
            ImGui::PopID();
        }
        ImGui::Spacing();
        if (wrapui::Button(musicPlaying_ ? "Parar" : "Escuchar", ImVec2(c2, bh)) && tapped()) {
            if (musicPlaying_) { musicPlaying_ = false; if (audio_) audio_->stopMusic(); }
            else preview(musicRender(song_), true);
        }
        ImGui::SameLine();
        if (wrapui::Button("Actualizar sonido", ImVec2(c2, bh)) && tapped() && musicPlaying_) preview(musicRender(song_), true);
        textInput("##mname", "Nombre de la música", musicName_, "mi_musica");
        if (wrapui::Button("Guardar en el proyecto", ImVec2(-1, bh)) && tapped()) saveWav(musicName_, musicRender(song_));
        ImGui::TextDisabled("Se guarda como audio del proyecto: úsala con el bloque «Música» o en un objeto.");
    } else if (musicTab_ == 1) {
        ImGui::TextDisabled("Crea efectos de sonido: salto, disparo, golpe, moneda, explosión...");
        for (int i = 0; i < 8; i++) {
            if (i % 4) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, sfxKind_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            ImGui::PushID(400 + i);
            if (wrapui::Button(kSfxNames[i], ImVec2(c4, bh)) && tapped()) { sfxKind_ = i; preview(sfxRender(sfxKind_, sfxPitch_, sfxLen_, (unsigned)sfxSeed_), false); }
            ImGui::PopID();
            ImGui::PopStyleColor();
        }
        wrapui::SliderFloat("Tono (grave - agudo)", &sfxPitch_, 0.5f, 2.f, "%.2f");
        wrapui::SliderFloat("Duración", &sfxLen_, 0.5f, 2.5f, "%.2f");
        if (wrapui::Button("Otra variación", ImVec2(c2, bh)) && tapped()) { sfxSeed_ = (int)(ImGui::GetTime() * 1000) & 0xFFFF; preview(sfxRender(sfxKind_, sfxPitch_, sfxLen_, (unsigned)sfxSeed_), false); }
        ImGui::SameLine();
        if (wrapui::Button("Escuchar", ImVec2(c2, bh)) && tapped()) preview(sfxRender(sfxKind_, sfxPitch_, sfxLen_, (unsigned)sfxSeed_), false);
        textInput("##sname", "Nombre del efecto", sfxName_, "mi_efecto");
        if (wrapui::Button("Guardar en el proyecto", ImVec2(-1, bh)) && tapped()) saveWav(sfxName_, sfxRender(sfxKind_, sfxPitch_, sfxLen_, (unsigned)sfxSeed_));
    } else {
        ImGui::TextDisabled("Música y sonidos listos. Toca uno para añadirlo al proyecto; «Probar» lo escucha.");
        for (auto& it : libraryItems()) {
            if (it.kind != 1) continue;
            ImGui::PushID(it.name.c_str());
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(shortName(it.name, 22).c_str());
            ImGui::SameLine(fw - fs * 13.f);
            if (wrapui::Button("Probar", ImVec2(fs * 5.5f, fs * 2.1f)) && tapped()) {
                Files tmp;
                if (libraryAdd(it.name, tmp)) { auto f = tmp.find(it.name); if (f != tmp.end()) preview(f->second, false); }
            }
            ImGui::SameLine();
            if (wrapui::Button("Añadir", ImVec2(fs * 5.5f, fs * 2.1f)) && tapped()) {
                if (libraryAdd(it.name, edit_.proj.assets)) { assetDirty_.insert(it.name); if (audio_) audio_->setAssets(edit_.proj.assets); markDirty(); toast("Añadido: " + it.name); }
            }
            ImGui::PopID();
        }
    }
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    ImGui::End();
}

}  // namespace forge
