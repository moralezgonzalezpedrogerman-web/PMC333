// Editor de modelos 3D por bloques (voxel): se construye por capas, se pinta con una paleta o se cubre con una textura.
#include "editor.h"
#include "model.h"
#include "preview.h"
#include "renderer.h"
#include "imgui.h"
#include "stb_image_write.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

namespace {
const int N = 16;
const int kPalN = 32;
const unsigned char kVC[kPalN][3] = {
    {235, 235, 235}, {40, 40, 44},   {120, 120, 130}, {200, 40, 40},  {230, 120, 40}, {240, 210, 60}, {70, 170, 70},  {40, 110, 60},
    {60, 120, 220},  {30, 60, 140},  {150, 80, 190},  {240, 130, 190}, {130, 85, 50},  {90, 55, 30},   {200, 160, 110}, {235, 200, 170},
    {85, 100, 70},   {60, 70, 50},   {170, 175, 185}, {255, 255, 120}, {20, 20, 20},   {110, 20, 20},  {90, 140, 90},   {150, 60, 20},
    {70, 70, 90},    {255, 240, 200}, {40, 140, 160}, {190, 190, 60},  {120, 60, 60},  {245, 245, 120}, {10, 10, 10},   {255, 90, 90}};

void pngSink(void* ctx, void* data, int size) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + size);
}
std::vector<uint8_t> voxPaletteTex() {
    const int W = 256, H = 8;
    std::vector<uint8_t> px(W * H * 4), o;
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            int c = x / 8;
            for (int k = 0; k < 3; k++) px[(y * W + x) * 4 + k] = kVC[c][k];
            px[(y * W + x) * 4 + 3] = 255;
        }
    stbi_write_png_to_func(pngSink, &o, W, H, 4, px.data(), W * 4);
    return o;
}
inline int vi(int x, int y, int z) { return (y * N + z) * N + x; }

// Convierte la cuadrícula en malla: solo las caras visibles. Queda centrada y con tamaño unitario (frente = +Z).
bool buildVox(const std::vector<uint8_t>& g, const std::string& tex, ModelData& md) {
    md = ModelData();
    bool any = false;
    int mn[3] = {N, N, N}, mx[3] = {-1, -1, -1};
    for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++)
        if (g[vi(x, y, z)]) { any = true; int c[3] = {x, y, z}; for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], c[k]); mx[k] = std::max(mx[k], c[k] + 1); } }
    if (!any) return false;
    float ext = (float)std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    float ctr[3] = {(mn[0] + mx[0]) * 0.5f, (mn[1] + mx[1]) * 0.5f, (mn[2] + mx[2]) * 0.5f};
    static const int F[6][9] = {  // p0 (desplazamiento), u, v, normal por eje
        {1, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 1, 0, 1, 0}, {0, 1, 0, 0, 0, 1, 1, 0, 0},
        {0, 0, 0, 1, 0, 0, 0, 0, 1}, {0, 0, 1, 1, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 1, 0, 1, 0, 0}};
    static const int NRM[6][3] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    bool useTex = !tex.empty();
    md.tex = useTex ? tex : "vox_paleta.png";
    for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
        int c = g[vi(x, y, z)];
        if (!c) continue;
        for (int f = 0; f < 6; f++) {
            int nx = x + NRM[f][0], ny = y + NRM[f][1], nz = z + NRM[f][2];
            if (nx >= 0 && ny >= 0 && nz >= 0 && nx < N && ny < N && nz < N && g[vi(nx, ny, nz)]) continue;
            uint32_t base = (uint32_t)(md.v.size() / 8);
            const int* d = F[f];
            for (int q = 0; q < 4; q++) {
                int du = (q == 1 || q == 2) ? 1 : 0, dv = (q >= 2) ? 1 : 0;
                float p[3] = {(float)(x + d[0] + du * d[3] + dv * d[6]), (float)(y + d[1] + du * d[4] + dv * d[7]), (float)(z + d[2] + du * d[5] + dv * d[8])};
                for (int k = 0; k < 3; k++) md.v.push_back((p[k] - ctr[k]) / ext);
                for (int k = 0; k < 3; k++) md.v.push_back((float)NRM[f][k]);
                if (useTex) { md.v.push_back((float)du); md.v.push_back((float)dv); }
                else { md.v.push_back(((c - 1) * 8 + 4) / 256.f); md.v.push_back(0.5f); }
            }
            uint32_t ix[6] = {0, 1, 2, 0, 2, 3};
            for (uint32_t k : ix) md.idx.push_back(base + k);
        }
    }
    return true;
}
}  // namespace

void Editor::openVoxEditor(const std::string& name) {
    voxOpen_ = true;
    if (!edit_.proj.assets.count("vox_paleta.png")) { edit_.proj.assets["vox_paleta.png"] = voxPaletteTex(); assetDirty_.insert("vox_paleta.png"); }
    vox_.assign(N * N * N, 0);
    voxY_ = 0; voxTex_.clear(); voxDirty_ = true;
    if (!name.empty()) {
        auto a = edit_.proj.assets.find(name + ".fvox");
        if (a != edit_.proj.assets.end() && a->second.size() >= N * N * N) {
            const auto& d = a->second;
            std::copy(d.begin(), d.begin() + N * N * N, vox_.begin());
            voxTex_.assign(d.begin() + N * N * N, d.end());
        }
        voxName_ = name;
    }
}

bool Editor::voxSave(bool toScene) {
    ModelData md;
    if (!buildVox(vox_, voxTex_, md)) { toast("El modelo está vacío: pon algunos bloques primero"); return false; }
    std::string nm = voxName_.empty() ? "mi_modelo" : voxName_;
    for (auto& c : nm) if (c == ' ' || c == '/' || c == '\\' || c == '.') c = '_';
    voxName_ = nm;
    std::vector<uint8_t> out;
    if (!modelWrite(md, out)) { toast("No se pudo guardar el modelo"); return false; }
    edit_.proj.assets[nm + ".fmdl"] = out;
    std::vector<uint8_t> raw(vox_.begin(), vox_.end());
    raw.insert(raw.end(), voxTex_.begin(), voxTex_.end());
    edit_.proj.assets[nm + ".fvox"] = raw;
    assetDirty_.insert(nm + ".fmdl");
    assetDirty_.insert(nm + ".fvox");
    markDirty();
    if (toScene && hasScene() && scene().is3d) { addObject(Kind::Model, nm + ".fmdl"); toast("Modelo añadido a la escena: " + nm); }
    else toast("Modelo guardado: " + nm + " (elígelo en Añadir > Modelo 3D)");
    return true;
}

void Editor::voxWin() {
    if (!voxOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.07f, 0.09f, 0.13f, 1.f));
    bool voxOk = wrapui::Begin("Editor de modelos 3D", &voxOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB | kNoSW | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleColor();
    if (!voxOk) {
        ImGui::End();
        return;
    }
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, fs * 0.6f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.14f, 0.19f, 0.26f, 0.95f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.28f, 0.38f, 1.f));
    float hw = ImGui::GetContentRegionAvail().x;
    if (wrapui::Button("<  VOLVER", ImVec2(fs * 7.f, fs * 2.2f)) && tapped()) voxOpen_ = false;
    ImGui::SameLine();
    const char* ttl = "EDITOR DE MODELOS 3D";
    ImGui::SetCursorPosX((hw - ImGui::CalcTextSize(ttl).x) * 0.5f);
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(ttl);
    ImGui::SameLine(hw - fs * 6.f);
    if (wrapui::Button("Cerrar x", ImVec2(fs * 6.f, fs * 2.2f)) && tapped()) voxOpen_ = false;

    bool wide = w_ >= h_;
    ImVec2 av = ImGui::GetContentRegionAvail();
    float Q = wide ? std::min(av.y - fs * 0.5f, av.x * 0.42f) : std::min(av.x, av.y * 0.40f);
    Q = std::max(fs * 8.f, Q);
    ImGui::BeginGroup();
    // ---------- cuadrícula de la capa actual (vista desde arriba)
    ImVec2 org = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##vgrid", ImVec2(Q, Q));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float cs = Q / N;
    dl->AddRectFilled(org, ImVec2(org.x + Q, org.y + Q), IM_COL32(24, 28, 38, 255), 6.f);
    for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
        ImVec2 a(org.x + x * cs, org.y + z * cs), b(a.x + cs, a.y + cs);
        if (voxY_ > 0 && vox_[vi(x, voxY_ - 1, z)]) { const unsigned char* c = kVC[vox_[vi(x, voxY_ - 1, z)] - 1]; dl->AddRectFilled(a, b, IM_COL32(c[0], c[1], c[2], 70)); }
        int v = vox_[vi(x, voxY_, z)];
        if (v) { const unsigned char* c = kVC[v - 1]; dl->AddRectFilled(ImVec2(a.x + 1, a.y + 1), ImVec2(b.x - 1, b.y - 1), IM_COL32(c[0], c[1], c[2], 255), 2.f); }
    }
    for (int g = 0; g <= N; g++) {
        int al = (g % 4 == 0) ? 50 : 20;
        dl->AddLine(ImVec2(org.x + g * cs, org.y), ImVec2(org.x + g * cs, org.y + Q), IM_COL32(255, 255, 255, al));
        dl->AddLine(ImVec2(org.x, org.y + g * cs), ImVec2(org.x + Q, org.y + g * cs), IM_COL32(255, 255, 255, al));
    }
    dl->AddText(ImVec2(org.x + 4, org.y + Q - fs * 1.3f), IM_COL32(170, 190, 210, 200), "Frente (+Z) = abajo");
    if (ImGui::IsItemActive() && !ImGui::IsMouseReleased(0)) {
        ImVec2 m = ImGui::GetIO().MousePos;
        int x = (int)std::floor((m.x - org.x) / cs), z = (int)std::floor((m.y - org.y) / cs);
        if (x >= 0 && z >= 0 && x < N && z < N) {
            uint8_t& cell = vox_[vi(x, voxY_, z)];
            uint8_t before = cell;
            if (voxTool_ == 0) cell = (uint8_t)(voxCol_ + 1);
            else if (voxTool_ == 1) cell = 0;
            else if (voxTool_ == 2) { if (cell) cell = (uint8_t)(voxCol_ + 1); }
            else if (voxTool_ == 3 && ImGui::IsMouseClicked(0) && cell) { voxCol_ = cell - 1; voxTool_ = 0; }
            if (cell != before) { voxDirty_ = true; markDirty(); }
        }
    }
    ImGui::EndGroup();
    if (wide) ImGui::SameLine(); else ImGui::Dummy(ImVec2(1, fs * 0.3f));

    // ---------- derecha / abajo: vista previa y herramientas
    wrapui::BeginChild("##vpanel", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    {
        float PQ = std::min(ImGui::GetContentRegionAvail().x, fs * 14.f);
        ImVec2 po = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##vprev", ImVec2(PQ, PQ));
        if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0, 1.f)) { voxYaw_ -= ImGui::GetIO().MouseDelta.x * 0.01f; voxDirty_ = true; }
        ImDrawList* d2 = ImGui::GetWindowDrawList();
        d2->AddRectFilled(po, ImVec2(po.x + PQ, po.y + PQ), IM_COL32(24, 28, 38, 255), 6.f);
        if (rend_) {
            if (voxDirty_) {
                ModelData md;
                if (buildVox(vox_, voxTex_, md)) {
                    if (meshRaster(md, md.v, edit_.proj.assets, 256, voxYaw_, 0.45f, voxPx_, 0.9f)) rend_->updateRGBA("::voxprev", 256, 256, voxPx_.data());
                } else { voxPx_.assign(256 * 256 * 4, 0); rend_->updateRGBA("::voxprev", 256, 256, voxPx_.data()); }
                voxDirty_ = false;
            }
            unsigned id = rend_->rawTexture("::voxprev");
            if (id) d2->AddImage((ImTextureID)(intptr_t)id, po, ImVec2(po.x + PQ, po.y + PQ));
        }
        d2->AddText(ImVec2(po.x + 6, po.y + 4), IM_COL32(170, 190, 210, 200), "Arrastra para girar");
    }
    // capa
    ImGui::Text("Capa (altura): %d / %d", voxY_ + 1, N);
    if (wrapui::Button("Capa +", ImVec2(0, fs * 2.2f)) && tapped()) voxY_ = std::min(N - 1, voxY_ + 1);
    wrapui::Next("Capa -", 0.f);
    if (wrapui::Button("Capa -", ImVec2(0, fs * 2.2f)) && tapped()) voxY_ = std::max(0, voxY_ - 1);
    // herramientas
    static const char* tn[4] = {"Poner", "Borrar", "Pintar", "Gotero"};
    for (int i = 0; i < 4; i++) {
        if (i) wrapui::Next(tn[i], 0.f);
        ImGui::PushStyleColor(ImGuiCol_Button, voxTool_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(tn[i], ImVec2(0, fs * 2.2f)) && tapped()) voxTool_ = i;
        ImGui::PopStyleColor();
    }
    // paleta
    ImGui::TextDisabled("Color");
    for (int i = 0; i < kPalN; i++) {
        ImGui::PushID(i);
        ImVec4 c(kVC[i][0] / 255.f, kVC[i][1] / 255.f, kVC[i][2] / 255.f, 1.f);
        ImGui::PushStyleColor(ImGuiCol_Button, c);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, c);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, c);
        ImGui::PushStyleColor(ImGuiCol_Border, voxCol_ == i ? ImVec4(1, 1, 1, 1) : ImVec4(0, 0, 0, 0.4f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, voxCol_ == i ? 3.f : 1.f);
        if (ImGui::Button("##c", ImVec2(fs * 2.1f, fs * 2.1f)) && tapped()) { voxCol_ = i; if (voxTool_ == 1 || voxTool_ == 3) voxTool_ = 0; }
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(4);
        ImGui::PopID();
        if (i % 8 != 7) ImGui::SameLine();
    }
    // textura
    ImGui::Spacing();
    ImGui::TextDisabled("Textura (cubre todo el modelo; sin textura se usan los colores)");
    if (assetCombo("Textura", voxTex_, 0, "(sin textura: colores)")) voxDirty_ = true;
    // acciones
    if (wrapui::Button("Espejo (izq-der)", ImVec2(0, fs * 2.2f)) && tapped()) {
        for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N / 2; x++) { uint8_t a = vox_[vi(x, y, z)]; if (a) vox_[vi(N - 1 - x, y, z)] = a; }
        voxDirty_ = true; markDirty();
    }
    wrapui::Next("Limpiar todo", 0.f);
    if (wrapui::Button("Limpiar todo", ImVec2(0, fs * 2.2f)) && tapped()) { std::fill(vox_.begin(), vox_.end(), 0); voxDirty_ = true; }
    ImGui::SeparatorText("Guardar");
    textInput("##vname", "Nombre del modelo", voxName_, "mi_modelo");
    if (wrapui::Button("Guardar modelo", ImVec2(0, fs * 2.4f)) && tapped()) voxSave(false);
    wrapui::Next("Guardar y añadir a la escena", 0.f);
    if (wrapui::Button("Guardar y añadir a la escena", ImVec2(0, fs * 2.4f)) && tapped()) { if (voxSave(true)) voxOpen_ = false; }
    ImGui::SeparatorText("Abrir uno guardado");
    bool anyv = false;
    for (auto& kv : edit_.proj.assets) {
        const std::string& k = kv.first;
        if (k.size() > 5 && k.compare(k.size() - 5, 5, ".fvox") == 0) {
            anyv = true;
            std::string nm = k.substr(0, k.size() - 5);
            if (wrapui::Button((nm + "##open").c_str(), ImVec2(0, fs * 2.2f)) && tapped()) { openVoxEditor(nm); break; }
        }
    }
    if (!anyv) ImGui::TextDisabled("Aún no has guardado modelos.");
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar();
    ImGui::End();
}

}  // namespace forge
