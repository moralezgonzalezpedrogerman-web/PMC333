// Editor de modelos 3D por bloques (voxel): se construye por capas, se pinta con una paleta o se cubre con una textura.
#include "editor.h"
#include "model.h"
#include "preview.h"
#include "renderer.h"
#include "imgui.h"
#include "stb_image_write.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

namespace {
const int N = 16;
const int kPalN = 32;
const unsigned char kVC[kPalN][3] = {
    {235, 235, 235}, {40, 40, 44},   {120, 120, 130}, {200, 40, 40},  {230, 120, 40}, {240, 210, 60}, {70, 170, 70},  {40, 110, 60},
    {60, 120, 220},  {30, 60, 140},  {150, 80, 190},  {240, 130, 190}, {130, 85, 50},  {90, 55, 30},   {200, 160, 110}, {235, 200, 170},
    {85, 100, 70},   {60, 70, 50},   {170, 175, 185}, {255, 255, 120}, {20, 20, 20},   {110, 20, 20},  {90, 140, 90},   {150, 60, 20},
    {70, 70, 90},    {255, 240, 200}, {40, 140, 160}, {190, 190, 60},  {120, 60, 60},  {245, 245, 120}, {10, 10, 10},   {255, 90, 90}};


inline int vi(int x, int y, int z) { return (y * N + z) * N + x; }
// ---------------- modelos por bloques que vienen por defecto en la biblioteca
const char* const kVoxLib[] = {"arbol", "pino", "casa", "coche", "cofre", "barril", "roca", "espada", "escudo", "llave", "robot", "hongo", "farol", "valla", "flor", "torre"};
const int kVoxLibN = (int)(sizeof(kVoxLib) / sizeof(kVoxLib[0]));
bool voxLibGrid(const std::string& nm, std::vector<uint8_t>& g) {
    g.assign(N * N * N, 0);
    auto box = [&](int x0, int y0, int z0, int x1, int y1, int z1, int c) {
        for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) for (int x = x0; x <= x1; x++)
            if (x >= 0 && y >= 0 && z >= 0 && x < N && y < N && z < N) g[vi(x, y, z)] = (uint8_t)(c + 1);
    };
    auto ball = [&](float cx, float cy, float cz, float r, int c) {
        for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
            float dx = x - cx, dy = y - cy, dz = z - cz;
            if (dx * dx + dy * dy + dz * dz <= r * r) g[vi(x, y, z)] = (uint8_t)(c + 1);
        }
    };
    if (nm == "arbol") { box(7, 0, 7, 8, 6, 8, 12); ball(7.5f, 10.f, 7.5f, 5.2f, 6); ball(7.5f, 12.f, 7.5f, 3.f, 22); }
    else if (nm == "pino") { box(7, 0, 7, 8, 3, 8, 13); for (int k = 0; k < 4; k++) { int r = 5 - k; box(8 - r, 3 + k * 3, 8 - r, 7 + r, 5 + k * 3, 7 + r, k % 2 ? 7 : 6); } box(7, 15, 7, 8, 15, 8, 7); }
    else if (nm == "casa") { box(2, 0, 3, 13, 6, 12, 14); box(2, 0, 3, 13, 0, 12, 2); for (int k = 0; k < 6; k++) box(1 + k, 7 + k, 2, 14 - k, 7 + k, 13, 3); box(7, 0, 12, 9, 4, 12, 13); box(3, 3, 12, 5, 5, 12, 26); box(11, 3, 12, 12, 5, 12, 26); }
    else if (nm == "coche") { box(1, 1, 5, 14, 3, 10, 3); box(4, 4, 5, 11, 6, 10, 3); box(5, 4, 5, 10, 6, 5, 26); box(5, 4, 10, 10, 6, 10, 26); box(2, 0, 4, 4, 2, 5, 1); box(11, 0, 4, 13, 2, 5, 1); box(2, 0, 10, 4, 2, 11, 1); box(11, 0, 10, 13, 2, 11, 1); box(14, 2, 6, 14, 2, 6, 5); box(14, 2, 9, 14, 2, 9, 5); }
    else if (nm == "cofre") { box(2, 0, 4, 13, 6, 11, 12); box(2, 7, 4, 13, 9, 11, 13); box(2, 6, 4, 13, 6, 11, 1); box(7, 4, 11, 8, 8, 11, 5); box(2, 0, 4, 13, 0, 11, 13); }
    else if (nm == "barril") { for (int y = 0; y < 12; y++) { int r = (y == 0 || y == 11) ? 3 : (y == 1 || y == 10) ? 4 : 5; for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) { float dx = x - 7.5f, dz = z - 7.5f; if (dx * dx + dz * dz <= r * r) g[vi(x, y, z)] = (uint8_t)((y == 3 || y == 8 ? 2 : 12) + 1); } } }
    else if (nm == "roca") { ball(7.5f, 4.f, 7.5f, 5.f, 2); ball(5.f, 3.f, 9.f, 3.2f, 18); ball(10.f, 3.f, 6.f, 3.f, 24); box(0, 0, 0, 15, 0, 0, 0); for (int x = 0; x < N; x++) for (int z = 0; z < N; z++) g[vi(x, 0, z)] = g[vi(x, 0, z)] == 1 ? 0 : g[vi(x, 0, z)]; }
    else if (nm == "espada") { box(7, 5, 7, 8, 15, 7, 18); box(7, 15, 7, 8, 15, 7, 0); box(5, 4, 7, 10, 4, 7, 5); box(7, 0, 7, 8, 3, 7, 13); box(7, 0, 6, 8, 0, 8, 5); }
    else if (nm == "escudo") { box(3, 3, 7, 12, 13, 8, 8); box(4, 2, 7, 11, 2, 8, 8); box(5, 1, 7, 10, 1, 8, 8); box(6, 0, 7, 9, 0, 8, 8); box(3, 13, 7, 12, 13, 8, 18); box(7, 3, 9, 8, 12, 9, 5); box(4, 7, 9, 11, 8, 9, 5); box(7, 7, 6, 8, 8, 6, 13); }
    else if (nm == "llave") { ball(7.5f, 12.f, 7.5f, 3.2f, 5); ball(7.5f, 12.f, 7.5f, 1.5f, -1 + 0); for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) if (g[vi(x, y, z)] == 0) {} box(7, 2, 7, 8, 9, 8, 5); box(9, 2, 7, 10, 3, 8, 5); box(9, 5, 7, 11, 6, 8, 5); for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) for (int y = 11; y <= 13; y++) { float dx = x - 7.5f, dy = y - 12.f; (void)z; if (dx * dx + dy * dy < 2.0f) g[vi(x, y, 7)] = 0, g[vi(x, y, 8)] = 0; } }
    else if (nm == "robot") { box(5, 0, 6, 6, 3, 9, 2); box(9, 0, 6, 10, 3, 9, 2); box(4, 4, 5, 11, 9, 10, 18); box(2, 5, 6, 3, 9, 9, 2); box(12, 5, 6, 13, 9, 9, 2); box(5, 10, 5, 10, 14, 10, 0); box(6, 12, 10, 6, 12, 10, 3); box(9, 12, 10, 9, 12, 10, 3); box(7, 15, 7, 8, 15, 8, 5); box(6, 6, 10, 9, 8, 10, 8); }
    else if (nm == "hongo") { box(6, 0, 6, 9, 5, 9, 25); for (int y = 6; y < 11; y++) { int r = y < 8 ? 6 : y < 10 ? 5 : 3; for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) { float dx = x - 7.5f, dz = z - 7.5f; if (dx * dx + dz * dz <= r * r) g[vi(x, y, z)] = (uint8_t)(3 + 1); } } box(4, 10, 7, 5, 10, 8, 0); box(10, 9, 5, 11, 9, 6, 0); box(7, 11, 9, 8, 11, 10, 0); }
    else if (nm == "farol") { box(7, 0, 7, 8, 11, 8, 24); box(6, 0, 6, 9, 1, 9, 24); box(5, 12, 5, 10, 14, 10, 19); box(4, 15, 4, 11, 15, 11, 24); box(7, 16, 7, 8, 16, 8, 24); }
    else if (nm == "valla") { for (int i = 0; i < 3; i++) box(1 + i * 6, 0, 7, 2 + i * 6, 8, 8, 14); box(1, 2, 7, 14, 3, 8, 14); box(1, 6, 7, 14, 7, 8, 14); }
    else if (nm == "flor") { box(7, 0, 7, 8, 8, 8, 6); box(9, 3, 7, 11, 3, 8, 6); box(4, 5, 7, 6, 5, 8, 6); box(7, 9, 7, 8, 12, 8, 5); box(5, 10, 7, 10, 11, 8, 11); box(6, 9, 7, 9, 12, 8, 11); box(7, 10, 7, 8, 11, 8, 5); }
    else if (nm == "torre") { box(3, 0, 3, 12, 11, 12, 18); box(4, 0, 12, 11, 11, 12, 2); for (int i = 0; i < 4; i++) box(3 + i * 3, 12, 3, 4 + i * 3, 14, 12, 18); box(7, 0, 12, 8, 4, 12, 13); box(5, 7, 12, 6, 9, 12, 1); box(9, 7, 12, 10, 9, 12, 1); }
    else return false;
    return true;
}

void pngSink(void* ctx, void* data, int size) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + size);
}
std::vector<uint8_t> voxPaletteTex() {
    const int W = 256, H = 8;
    std::vector<uint8_t> px(W * H * 4), o;
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            int c = x / 8;
            for (int k = 0; k < 3; k++) px[(y * W + x) * 4 + k] = kVC[c][k];
            px[(y * W + x) * 4 + 3] = 255;
        }
    stbi_write_png_to_func(pngSink, &o, W, H, 4, px.data(), W * 4);
    return o;
}

// Convierte la cuadrícula en malla: solo las caras visibles. Queda centrada y con tamaño unitario (frente = +Z).
bool buildVox(const std::vector<uint8_t>& g, const std::string& tex, ModelData& md) {
    md = ModelData();
    bool any = false;
    int mn[3] = {N, N, N}, mx[3] = {-1, -1, -1};
    for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++)
        if (g[vi(x, y, z)]) { any = true; int c[3] = {x, y, z}; for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], c[k]); mx[k] = std::max(mx[k], c[k] + 1); } }
    if (!any) return false;
    float ext = (float)std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    float ctr[3] = {(mn[0] + mx[0]) * 0.5f, (mn[1] + mx[1]) * 0.5f, (mn[2] + mx[2]) * 0.5f};
    static const int F[6][9] = {  // p0 (desplazamiento), u, v, normal por eje
        {1, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 1, 0, 1, 0}, {0, 1, 0, 0, 0, 1, 1, 0, 0},
        {0, 0, 0, 1, 0, 0, 0, 0, 1}, {0, 0, 1, 1, 0, 0, 0, 1, 0}, {0, 0, 0, 0, 1, 0, 1, 0, 0}};
    static const int NRM[6][3] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    bool useTex = !tex.empty();
    md.tex = useTex ? tex : "vox_paleta.png";
    for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
        int c = g[vi(x, y, z)];
        if (!c) continue;
        for (int f = 0; f < 6; f++) {
            int nx = x + NRM[f][0], ny = y + NRM[f][1], nz = z + NRM[f][2];
            if (nx >= 0 && ny >= 0 && nz >= 0 && nx < N && ny < N && nz < N && g[vi(nx, ny, nz)]) continue;
            uint32_t base = (uint32_t)(md.v.size() / 8);
            const int* d = F[f];
            for (int q = 0; q < 4; q++) {
                int du = (q == 1 || q == 2) ? 1 : 0, dv = (q >= 2) ? 1 : 0;
                float p[3] = {(float)(x + d[0] + du * d[3] + dv * d[6]), (float)(y + d[1] + du * d[4] + dv * d[7]), (float)(z + d[2] + du * d[5] + dv * d[8])};
                for (int k = 0; k < 3; k++) md.v.push_back((p[k] - ctr[k]) / ext);
                for (int k = 0; k < 3; k++) md.v.push_back((float)NRM[f][k]);
                if (useTex) { md.v.push_back((float)du); md.v.push_back((float)dv); }
                else { md.v.push_back(((c - 1) * 8 + 4) / 256.f); md.v.push_back(0.5f); }
            }
            uint32_t ix[6] = {0, 1, 2, 0, 2, 3};
            for (uint32_t k : ix) md.idx.push_back(base + k);
        }
    }
    return true;
}
}  // namespace

void Editor::openVoxEditor(const std::string& name) {
    voxOpen_ = true;
    if (!edit_.proj.assets.count("vox_paleta.png")) { edit_.proj.assets["vox_paleta.png"] = voxPaletteTex(); assetDirty_.insert("vox_paleta.png"); }
    vox_.assign(N * N * N, 0);
    voxY_ = 0; voxTex_.clear(); voxDirty_ = true;
    if (!name.empty()) {
        auto a = edit_.proj.assets.find(name + ".fvox");
        if (a != edit_.proj.assets.end() && a->second.size() >= N * N * N) {
            const auto& d = a->second;
            std::copy(d.begin(), d.begin() + N * N * N, vox_.begin());
            voxTex_.assign(d.begin() + N * N * N, d.end());
        }
        voxName_ = name;
    }
}

bool Editor::voxSave(bool toScene) {
    ModelData md;
    if (!buildVox(vox_, voxTex_, md)) { toast("El modelo está vacío: pon algunos bloques primero"); return false; }
    std::string nm = voxName_.empty() ? "mi_modelo" : voxName_;
    for (auto& c : nm) if (c == ' ' || c == '/' || c == '\\' || c == '.') c = '_';
    voxName_ = nm;
    std::vector<uint8_t> out;
    if (!modelWrite(md, out)) { toast("No se pudo guardar el modelo"); return false; }
    edit_.proj.assets[nm + ".fmdl"] = out;
    std::vector<uint8_t> raw(vox_.begin(), vox_.end());
    raw.insert(raw.end(), voxTex_.begin(), voxTex_.end());
    edit_.proj.assets[nm + ".fvox"] = raw;
    assetDirty_.insert(nm + ".fmdl");
    assetDirty_.insert(nm + ".fvox");
    markDirty();
    if (toScene && hasScene() && scene().is3d) { addObject(Kind::Model, nm + ".fmdl"); toast("Modelo añadido a la escena: " + nm); }
    else toast("Modelo guardado: " + nm + " (elígelo en Añadir > Modelo 3D)");
    return true;
}

void Editor::voxWin() {
    if (!voxOpen_) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.07f, 0.09f, 0.13f, 1.f));
    bool voxOk = wrapui::Begin("Editor de modelos 3D", &voxOpen_, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB | kNoSW | ImGuiWindowFlags_NoSavedSettings);
    ImGui::PopStyleColor();
    if (!voxOk) {
        ImGui::End();
        return;
    }
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, fs * 0.6f);
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.14f, 0.19f, 0.26f, 0.95f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.28f, 0.38f, 1.f));
    float hw = ImGui::GetContentRegionAvail().x;
    if (wrapui::Button("<  VOLVER", ImVec2(fs * 7.f, fs * 2.2f)) && tapped()) voxOpen_ = false;
    ImGui::SameLine();
    const char* ttl = "EDITOR DE MODELOS 3D";
    ImGui::SetCursorPosX((hw - ImGui::CalcTextSize(ttl).x) * 0.5f);
    ImGui::AlignTextToFramePadding();
    ImGui::TextUnformatted(ttl);
    ImGui::SameLine(hw - fs * 6.f);
    if (wrapui::Button("Cerrar x", ImVec2(fs * 6.f, fs * 2.2f)) && tapped()) voxOpen_ = false;

    bool wide = w_ >= h_;
    ImVec2 av = ImGui::GetContentRegionAvail();
    float Q = wide ? std::min(av.y - fs * 0.5f, av.x * 0.42f) : std::min(av.x, av.y * 0.40f);
    Q = std::max(fs * 8.f, Q);
    ImGui::BeginGroup();
    // ---------- cuadrícula de la capa actual (vista desde arriba)
    ImVec2 org = ImGui::GetCursorScreenPos();
    ImGui::InvisibleButton("##vgrid", ImVec2(Q, Q));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float cs = Q / N;
    dl->AddRectFilled(org, ImVec2(org.x + Q, org.y + Q), IM_COL32(24, 28, 38, 255), 6.f);
    for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
        ImVec2 a(org.x + x * cs, org.y + z * cs), b(a.x + cs, a.y + cs);
        if (voxY_ > 0 && vox_[vi(x, voxY_ - 1, z)]) { const unsigned char* c = kVC[vox_[vi(x, voxY_ - 1, z)] - 1]; dl->AddRectFilled(a, b, IM_COL32(c[0], c[1], c[2], 70)); }
        int v = vox_[vi(x, voxY_, z)];
        if (v) { const unsigned char* c = kVC[v - 1]; dl->AddRectFilled(ImVec2(a.x + 1, a.y + 1), ImVec2(b.x - 1, b.y - 1), IM_COL32(c[0], c[1], c[2], 255), 2.f); }
    }
    for (int g = 0; g <= N; g++) {
        int al = (g % 4 == 0) ? 50 : 20;
        dl->AddLine(ImVec2(org.x + g * cs, org.y), ImVec2(org.x + g * cs, org.y + Q), IM_COL32(255, 255, 255, al));
        dl->AddLine(ImVec2(org.x, org.y + g * cs), ImVec2(org.x + Q, org.y + g * cs), IM_COL32(255, 255, 255, al));
    }
    dl->AddText(ImVec2(org.x + 4, org.y + Q - fs * 1.3f), IM_COL32(170, 190, 210, 200), "Frente (+Z) = abajo");
    if (ImGui::IsItemActive() && !ImGui::IsMouseReleased(0)) {
        ImVec2 m = ImGui::GetIO().MousePos;
        int x = (int)std::floor((m.x - org.x) / cs), z = (int)std::floor((m.y - org.y) / cs);
        if (ImGui::IsMouseClicked(0)) { voxUndo_.push_back(vox_); if (voxUndo_.size() > 40) voxUndo_.erase(voxUndo_.begin()); }
        if (x >= 0 && z >= 0 && x < N && z < N) {
            bool chg = false;
            if (voxTool_ == 3) {
                uint8_t cell = vox_[vi(x, voxY_, z)];
                if (ImGui::IsMouseClicked(0) && cell) { voxCol_ = cell - 1; voxTool_ = 0; }
            } else if (voxTool_ == 4) {   // relleno: pinta toda la zona conectada del mismo color
                if (ImGui::IsMouseClicked(0)) {
                    uint8_t from = vox_[vi(x, voxY_, z)], to = (uint8_t)(voxCol_ + 1);
                    if (from != to) {
                        std::vector<int> st{vi(x, voxY_, z)};
                        while (!st.empty()) {
                            int c = st.back(); st.pop_back();
                            if (vox_[c] != from) continue;
                            vox_[c] = to; chg = true;
                            int cx = c % N, cz = (c / N) % N, cy = c / (N * N);
                            if (cx > 0) st.push_back(vi(cx - 1, cy, cz));
                            if (cx < N - 1) st.push_back(vi(cx + 1, cy, cz));
                            if (cy > 0) st.push_back(vi(cx, cy - 1, cz));
                            if (cy < N - 1) st.push_back(vi(cx, cy + 1, cz));
                            if (cz > 0) st.push_back(vi(cx, cy, cz - 1));
                            if (cz < N - 1) st.push_back(vi(cx, cy, cz + 1));
                        }
                    }
                }
            } else {
                int r = voxBrush_ - 1;
                for (int dz = 0; dz <= r; dz++) for (int dx = 0; dx <= r; dx++) {
                    int xx = x + dx - r / 2, zz = z + dz - r / 2;
                    if (xx < 0 || zz < 0 || xx >= N || zz >= N) continue;
                    uint8_t& cell = vox_[vi(xx, voxY_, zz)];
                    uint8_t before = cell;
                    if (voxTool_ == 0) cell = (uint8_t)(voxCol_ + 1);
                    else if (voxTool_ == 1) cell = 0;
                    else if (voxTool_ == 2) { if (cell) cell = (uint8_t)(voxCol_ + 1); }
                    if (cell != before) chg = true;
                }
            }
            if (chg) { voxDirty_ = true; markDirty(); }
        }
    }
    ImGui::EndGroup();
    if (wide) ImGui::SameLine(); else ImGui::Dummy(ImVec2(1, fs * 0.3f));

    // ---------- derecha / abajo: vista previa y herramientas
    wrapui::BeginChild("##vpanel", ImVec2(0, 0), false, kNoSB);
    dragScroll();
    {
        float PQ = std::min(ImGui::GetContentRegionAvail().x, fs * 14.f);
        ImVec2 po = ImGui::GetCursorScreenPos();
        ImGui::InvisibleButton("##vprev", ImVec2(PQ, PQ));
        if (ImGui::IsItemActive() && ImGui::IsMouseDragging(0, 1.f)) { voxYaw_ -= ImGui::GetIO().MouseDelta.x * 0.01f; voxDirty_ = true; }
        ImDrawList* d2 = ImGui::GetWindowDrawList();
        d2->AddRectFilled(po, ImVec2(po.x + PQ, po.y + PQ), IM_COL32(24, 28, 38, 255), 6.f);
        if (rend_) {
            if (voxDirty_) {
                ModelData md;
                if (buildVox(vox_, voxTex_, md)) {
                    if (meshRaster(md, md.v, edit_.proj.assets, 256, voxYaw_, 0.45f, voxPx_, 0.9f)) rend_->updateRGBA("::voxprev", 256, 256, voxPx_.data());
                } else { voxPx_.assign(256 * 256 * 4, 0); rend_->updateRGBA("::voxprev", 256, 256, voxPx_.data()); }
                voxDirty_ = false;
            }
            unsigned id = rend_->rawTexture("::voxprev");
            if (id) d2->AddImage((ImTextureID)(intptr_t)id, po, ImVec2(po.x + PQ, po.y + PQ));
        }
        d2->AddText(ImVec2(po.x + 6, po.y + 4), IM_COL32(170, 190, 210, 200), "Arrastra para girar");
    }
    // capa
    ImGui::Text("Capa (altura): %d / %d", voxY_ + 1, N);
    if (wrapui::Button("Capa +", ImVec2(0, fs * 2.2f)) && tapped()) voxY_ = std::min(N - 1, voxY_ + 1);
    wrapui::Next("Capa -", 0.f);
    if (wrapui::Button("Capa -", ImVec2(0, fs * 2.2f)) && tapped()) voxY_ = std::max(0, voxY_ - 1);
    // herramientas
    static const char* tn[5] = {"Poner", "Borrar", "Pintar", "Gotero", "Relleno"};
    for (int i = 0; i < 5; i++) {
        if (i) wrapui::Next(tn[i], 0.f);
        ImGui::PushStyleColor(ImGuiCol_Button, voxTool_ == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(tn[i], ImVec2(0, fs * 2.2f)) && tapped()) voxTool_ = i;
        ImGui::PopStyleColor();
    }
    ImGui::TextDisabled("Tamaño del pincel");
    for (int i = 1; i <= 3; i++) {
        char b[8]; snprintf(b, sizeof b, "%dx%d", i, i);
        if (i > 1) wrapui::Next(b, 0.f);
        if (wrapui::RadioButton(b, voxBrush_ == i)) voxBrush_ = i;
        if (i < 3) ImGui::SameLine();
    }
    // paleta
    ImGui::TextDisabled("Color");
    for (int i = 0; i < kPalN; i++) {
        ImGui::PushID(i);
        ImVec4 c(kVC[i][0] / 255.f, kVC[i][1] / 255.f, kVC[i][2] / 255.f, 1.f);
        ImGui::PushStyleColor(ImGuiCol_Button, c);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, c);
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, c);
        ImGui::PushStyleColor(ImGuiCol_Border, voxCol_ == i ? ImVec4(1, 1, 1, 1) : ImVec4(0, 0, 0, 0.4f));
        ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, voxCol_ == i ? 3.f : 1.f);
        if (ImGui::Button("##c", ImVec2(fs * 2.1f, fs * 2.1f)) && tapped()) { voxCol_ = i; if (voxTool_ == 1 || voxTool_ == 3) voxTool_ = 0; }
        ImGui::PopStyleVar();
        ImGui::PopStyleColor(4);
        ImGui::PopID();
        if (i % 8 != 7) ImGui::SameLine();
    }
    // textura
    ImGui::Spacing();
    ImGui::TextDisabled("Textura (cubre todo el modelo; sin textura se usan los colores)");
    if (assetCombo("Textura", voxTex_, 0, "(sin textura: colores)")) voxDirty_ = true;
    // acciones
    if (wrapui::Button("Espejo (izq-der)", ImVec2(0, fs * 2.2f)) && tapped()) {
        for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N / 2; x++) { uint8_t a = vox_[vi(x, y, z)]; if (a) vox_[vi(N - 1 - x, y, z)] = a; }
        voxDirty_ = true; markDirty();
    }
    wrapui::Next("Limpiar todo", 0.f);
    if (wrapui::Button("Limpiar todo", ImVec2(0, fs * 2.2f)) && tapped()) { voxUndo_.push_back(vox_); std::fill(vox_.begin(), vox_.end(), 0); voxDirty_ = true; }
    wrapui::Next("Deshacer", 0.f);
    if (wrapui::Button("Deshacer", ImVec2(0, fs * 2.2f)) && tapped() && !voxUndo_.empty()) { vox_ = voxUndo_.back(); voxUndo_.pop_back(); voxDirty_ = true; }
    ImGui::SeparatorText("Transformar el modelo");
    auto snap = [&]() { voxUndo_.push_back(vox_); if (voxUndo_.size() > 40) voxUndo_.erase(voxUndo_.begin()); };
    auto remap = [&](auto fn) {   // fn(x,y,z,&nx,&ny,&nz) -> false si sale de la rejilla
        snap();
        std::vector<uint8_t> o(vox_.size(), 0);
        for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
            uint8_t c = vox_[vi(x, y, z)];
            int nx, ny, nz;
            if (c && fn(x, y, z, nx, ny, nz) && nx >= 0 && ny >= 0 && nz >= 0 && nx < N && ny < N && nz < N) o[vi(nx, ny, nz)] = c;
        }
        vox_ = o; voxDirty_ = true; markDirty();
    };
    struct Mv { const char* l; int dx, dy, dz; };
    static const Mv mv[] = {{"← Izq", -1, 0, 0}, {"Der →", 1, 0, 0}, {"↑ Subir", 0, 1, 0}, {"↓ Bajar", 0, -1, 0}, {"Atrás", 0, 0, -1}, {"Adelante", 0, 0, 1}};
    for (int i = 0; i < 6; i++) {
        if (i) wrapui::Next(mv[i].l, 0.f);
        if (wrapui::Button(mv[i].l, ImVec2(0, fs * 2.f)) && tapped()) remap([&](int x, int y, int z, int& nx, int& ny, int& nz) { nx = x + mv[i].dx; ny = y + mv[i].dy; nz = z + mv[i].dz; return true; });
    }
    if (wrapui::Button("Girar 90°", ImVec2(0, fs * 2.f)) && tapped()) remap([&](int x, int y, int z, int& nx, int& ny, int& nz) { nx = N - 1 - z; ny = y; nz = x; return true; });
    wrapui::Next("Voltear izq-der", 0.f);
    if (wrapui::Button("Voltear izq-der", ImVec2(0, fs * 2.f)) && tapped()) remap([&](int x, int y, int z, int& nx, int& ny, int& nz) { nx = N - 1 - x; ny = y; nz = z; return true; });
    wrapui::Next("Voltear arriba-abajo", 0.f);
    if (wrapui::Button("Voltear arriba-abajo", ImVec2(0, fs * 2.f)) && tapped()) remap([&](int x, int y, int z, int& nx, int& ny, int& nz) { nx = x; ny = N - 1 - y; nz = z; return true; });
    wrapui::Next("Espejo adelante-atrás", 0.f);
    if (wrapui::Button("Espejo adelante-atrás", ImVec2(0, fs * 2.f)) && tapped()) {
        snap();
        for (int y = 0; y < N; y++) for (int z = 0; z < N / 2; z++) for (int x = 0; x < N; x++) { uint8_t a = vox_[vi(x, y, z)]; if (a) vox_[vi(x, y, N - 1 - z)] = a; }
        voxDirty_ = true; markDirty();
    }
    wrapui::Next("Vaciar por dentro", 0.f);
    if (wrapui::Button("Vaciar por dentro", ImVec2(0, fs * 2.f)) && tapped()) {   // quita los bloques tapados: modelo más ligero
        snap();
        std::vector<uint8_t> o = vox_;
        auto at = [&](int x, int y, int z) { return x < 0 || y < 0 || z < 0 || x >= N || y >= N || z >= N ? 0 : (int)vox_[vi(x, y, z)]; };
        for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++)
            if (at(x, y, z) && at(x - 1, y, z) && at(x + 1, y, z) && at(x, y - 1, z) && at(x, y + 1, z) && at(x, y, z - 1) && at(x, y, z + 1)) o[vi(x, y, z)] = 0;
        vox_ = o; voxDirty_ = true; markDirty();
    }
    ImGui::SeparatorText("Formas (usan el color elegido)");
    {
        static const char* fn[5] = {"Esfera", "Cilindro", "Cubo", "Pirámide", "Cono"};
        for (int k = 0; k < 5; k++) {
            if (k) wrapui::Next(fn[k], 0.f);
            if (wrapui::Button(fn[k], ImVec2(0, fs * 2.f)) && tapped()) {
                snap();
                float c = (N - 1) * 0.5f;
                for (int y = 0; y < N; y++) for (int z = 0; z < N; z++) for (int x = 0; x < N; x++) {
                    float dx = x - c, dy = y - c, dz = z - c;
                    float r = N * 0.42f;
                    bool in = false;
                    if (k == 0) in = dx * dx + dy * dy + dz * dz <= r * r;
                    else if (k == 1) in = dx * dx + dz * dz <= r * r && std::fabs(dy) <= r;
                    else if (k == 2) in = std::fabs(dx) <= r * 0.85f && std::fabs(dy) <= r * 0.85f && std::fabs(dz) <= r * 0.85f;
                    else if (k == 3) { float t = (float)y / (N - 1); float h = (1.f - t) * r + 0.3f; in = std::fabs(dx) <= h && std::fabs(dz) <= h; }
                    else { float t = (float)y / (N - 1); float h = (1.f - t) * r + 0.3f; in = dx * dx + dz * dz <= h * h; }
                    if (in) vox_[vi(x, y, z)] = (uint8_t)(voxCol_ + 1);
                }
                voxDirty_ = true; markDirty();
            }
        }
    }
    ImGui::SeparatorText("Guardar");
    textInput("##vname", "Nombre del modelo", voxName_, "mi_modelo");
    if (wrapui::Button("Guardar modelo", ImVec2(0, fs * 2.4f)) && tapped()) voxSave(false);
    wrapui::Next("Guardar y añadir a la escena", 0.f);
    if (wrapui::Button("Guardar y añadir a la escena", ImVec2(0, fs * 2.4f)) && tapped()) { if (voxSave(true)) voxOpen_ = false; }
    ImGui::SeparatorText("Abrir uno guardado");
    bool anyv = false;
    for (auto& kv : edit_.proj.assets) {
        const std::string& k = kv.first;
        if (k.size() > 5 && k.compare(k.size() - 5, 5, ".fvox") == 0) {
            anyv = true;
            std::string nm = k.substr(0, k.size() - 5);
            if (wrapui::Button((nm + "##open").c_str(), ImVec2(0, fs * 2.2f)) && tapped()) { openVoxEditor(nm); break; }
        }
    }
    if (!anyv) ImGui::TextDisabled("Aún no has guardado modelos.");
    ImGui::Dummy(ImVec2(1, fs * 3.f));
    ImGui::EndChild();
    ImGui::PopStyleColor(2);
    ImGui::PopStyleVar();
    ImGui::End();
}


const char* voxLibName(int i) { return kVoxLib[i]; }
int voxLibCount() { return kVoxLibN; }
// modelo por bloques de la biblioteca: "lib_vx_<nombre>.fmdl" (+ la paleta de colores)
bool voxLibraryAdd(const std::string& name, Files& assets) {
    if (name.size() < 13 || name.compare(0, 7, "lib_vx_") != 0) return false;
    std::string nm = name.substr(7, name.size() - 7 - 5);
    std::vector<uint8_t> g;
    ModelData md;
    if (!voxLibGrid(nm, g) || !buildVox(g, "", md)) return false;
    std::vector<uint8_t> b;
    if (!modelWrite(md, b)) return false;
    assets[name] = b;
    if (!assets.count("vox_paleta.png")) assets["vox_paleta.png"] = voxPaletteTex();
    return true;
}

}  // namespace forge
