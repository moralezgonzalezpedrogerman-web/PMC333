// «Crear ragdoll»: parte el modelo de un personaje en cabeza, cuerpo, brazos y piernas. Al activarse (bloque o al morir) caen sueltos.
#include "editor.h"
#include "model.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>
#include <map>

namespace forge {

namespace {
struct Cut { float head = 0.80f, hip = 0.48f, torso = 0.22f; bool death = true; };
Cut gCut;
const char* kPart[7] = {"cabeza", "cuerpo", "brazo_izq", "brazo_der", "pierna_izq", "pierna_der", ""};
const ImU32 kCol[6] = {IM_COL32(255, 210, 90, 255), IM_COL32(90, 170, 255, 255), IM_COL32(120, 230, 120, 255),
                       IM_COL32(60, 190, 90, 255), IM_COL32(255, 130, 130, 255), IM_COL32(210, 70, 70, 255)};

// De qué pedazo es un punto (coordenadas del modelo ya normalizadas: x -1..1 a lo ancho, y 0..1 de pies a cabeza).
int partOf(float xn, float yn, const Cut& c) {
    if (yn >= c.head) return 0;
    if (yn >= c.hip) return std::fabs(xn) < c.torso ? 1 : (xn < 0 ? 2 : 3);
    return xn < 0 ? 4 : 5;
}
}

bool Editor::ragdollUI(Obj& o, Scene& S) {
    (void)S;
    bool ch = false;
    if (o.kind != Kind::Model || o.model.empty() || !o.ragOf.empty()) return false;
    Files& A = edit_.proj.assets;
    auto it = A.find(o.model);
    ModelData md;
    if (it == A.end() || !modelRead(it->second.data(), it->second.size(), md) || md.v.size() < 24 || md.idx.size() < 3) return false;
    ImGui::SeparatorText("Ragdoll (cae a pedazos)");
    ImGui::TextDisabled("Parte el modelo en 6 pedazos: cabeza, cuerpo, 2 brazos y 2 piernas. Pensado para personajes de pie. Ajusta los cortes viendo los colores.");
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    size_t nv = md.v.size() / 8;
    for (size_t i = 0; i < nv; i++) for (int a = 0; a < 3; a++) { mn[a] = std::min(mn[a], md.v[i * 8 + a]); mx[a] = std::max(mx[a], md.v[i * 8 + a]); }
    float cx = (mn[0] + mx[0]) * 0.5f, hx = std::max(0.001f, (mx[0] - mn[0]) * 0.5f), hy = std::max(0.001f, mx[1] - mn[1]);
    ch |= wrapui::SliderFloat("Dónde empieza la cabeza (altura)", &gCut.head, 0.5f, 0.95f, "%.2f");
    ch |= wrapui::SliderFloat("Dónde empiezan las piernas (cadera)", &gCut.hip, 0.2f, 0.7f, "%.2f");
    ch |= wrapui::SliderFloat("Ancho del cuerpo (lo de afuera son brazos)", &gCut.torso, 0.05f, 0.8f, "%.2f");
    wrapui::Checkbox("Se vuelve ragdoll solo al morir (enemigos)", &gCut.death);
    // vista de frente con colores
    const float fs = ImGui::GetFontSize();
    float vh = fs * 9.f, vw = std::min(ImGui::GetContentRegionAvail().x, vh * 0.9f);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(vw, vh));
    if (!ImGui::GetCurrentWindow()->SkipItems) {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRectFilled(p0, ImVec2(p0.x + vw, p0.y + vh), IM_COL32(20, 26, 40, 255), 6.f);
        size_t step = std::max<size_t>(1, nv / 1500);
        for (size_t i = 0; i < nv; i += step) {
            float xn = (md.v[i * 8] - cx) / hx, yn = (md.v[i * 8 + 1] - mn[1]) / hy;
            dl->AddCircleFilled(ImVec2(p0.x + vw * (0.5f + 0.45f * xn), p0.y + vh * (0.96f - 0.92f * yn)), 1.8f, kCol[partOf(xn, yn, gCut)]);
        }
    }
    if (wrapui::Button("Crear ragdoll de este modelo")) {
        size_t nt = md.idx.size() / 3;
        std::vector<int> owner(nt, 1);
        std::vector<int> cnt(6, 0);
        for (size_t t = 0; t < nt; t++) {
            float x = 0, y = 0;
            for (int k = 0; k < 3; k++) { x += md.v[md.idx[t * 3 + k] * 8]; y += md.v[md.idx[t * 3 + k] * 8 + 1]; }
            owner[t] = partOf((x / 3 - cx) / hx, (y / 3 - mn[1]) / hy, gCut);
            cnt[owner[t]]++;
        }
        std::string base = o.model.size() > 5 ? o.model.substr(0, o.model.size() - 5) : o.model;
        const Obj par = o;
        int made = 0;
        for (int pi = 0; pi < 6; pi++) {
            if (cnt[pi] == 0) continue;
            ModelData pm; pm.tex = md.tex; for (int k = 0; k < 3; k++) pm.color[k] = md.color[k];
            std::map<uint32_t, uint32_t> mp;
            float lo[3] = {1e9f, 1e9f, 1e9f}, hi[3] = {-1e9f, -1e9f, -1e9f}, sum[3] = {0, 0, 0};
            for (size_t t = 0; t < nt; t++) if (owner[t] == pi) for (int k = 0; k < 3; k++) {
                uint32_t oi = md.idx[t * 3 + k];
                if (mp.emplace(oi, 0).second) for (int a = 0; a < 3; a++) { float v = md.v[oi * 8 + a]; lo[a] = std::min(lo[a], v); hi[a] = std::max(hi[a], v); sum[a] += v; }
            }
            float ctr[3];
            for (int a = 0; a < 3; a++) ctr[a] = (lo[a] + hi[a]) * 0.5f;
            mp.clear();
            for (size_t t = 0; t < nt; t++) {
                if (owner[t] != pi) continue;
                for (int k = 0; k < 3; k++) {
                    uint32_t oi = md.idx[t * 3 + k];
                    auto f = mp.find(oi);
                    if (f == mp.end()) {
                        uint32_t ni = (uint32_t)(pm.v.size() / 8);
                        for (int a = 0; a < 8; a++) pm.v.push_back(md.v[oi * 8 + a]);
                        for (int a = 0; a < 3; a++) pm.v[ni * 8 + a] -= ctr[a];   // el pedazo gira sobre su propio centro
                        f = mp.emplace(oi, ni).first;
                    }
                    pm.idx.push_back(f->second);
                }
            }
            std::vector<uint8_t> bytes;
            if (!modelWrite(pm, bytes)) continue;
            std::string fn = base + "_rag_" + kPart[pi] + ".fmdl";
            A[fn] = bytes; assetDirty_.insert(fn);
            Obj w; w.kind = Kind::Model; w.model = fn; w.scale = par.scale; w.yaw = par.yaw; w.solid = false; w.visible = false;
            w.color[0] = w.color[1] = w.color[2] = 1.f; w.noColor = false;
            w.ragOf = par.name; w.ragOff = V3{ctr[0], ctr[1], ctr[2]}; w.ragDeath = gCut.death;
            float ex = (hi[0] - lo[0]) * par.scale.x, ey = (hi[1] - lo[1]) * par.scale.y, ez = (hi[2] - lo[2]) * par.scale.z;
            w.ragR = std::max(0.04f, 0.5f * std::min(ex, std::min(ey, ez)));
            float ya = par.yaw * 0.0174532925f, cs = std::cos(ya), sn = std::sin(ya);
            V3 l{ctr[0] * par.scale.x, ctr[1] * par.scale.y, ctr[2] * par.scale.z};
            w.pos = V3{par.pos.x + cs * l.x + sn * l.z, par.pos.y + l.y, par.pos.z - sn * l.x + cs * l.z};
            w.name = par.name + "_rag_" + kPart[pi];
            wheelNew_.push_back(w);
            made++;
        }
        toast(std::to_string(made) + " pedazos creados. Usa el bloque «Convertir este objeto en ragdoll» o deja que se active al morir.");
        markDirty(); ch = true;
    }
    return ch;
}

}  // namespace forge
