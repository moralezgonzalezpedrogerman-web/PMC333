// Editor de cinemáticas: se vuela la cámara del editor, se graba un punto, y la cámara y los objetos se mueven solos al jugar.
#include "editor.h"
#include "imgui.h"
#include "wrapui.h"
#include <algorithm>
#include <cmath>

namespace forge {

namespace {
const float K = 0.0174532925f;
float lerpAng(float a, float b, float t) { float d = std::fmod(b - a + 540.f, 360.f) - 180.f; return a + d * t; }
// Misma curva que usa el juego (Catmull-Rom por los puntos grabados).
bool camAt(const Cine& C, float t, V3& eye, float& yaw, float& pitch) {
    if (C.cam.empty()) return false;
    size_t n = C.cam.size(), b = 0;
    while (b < n && C.cam[b].t < t) b++;
    CineKey k = C.cam[std::min(b, n - 1)];
    if (b > 0 && b < n) {
        const CineKey &p1 = C.cam[b - 1], &p2 = C.cam[b];
        const CineKey &p0 = C.cam[b >= 2 ? b - 2 : b - 1], &p3 = C.cam[b + 1 < n ? b + 1 : b];
        float f = (t - p1.t) / std::max(1e-4f, p2.t - p1.t), f2 = f * f, f3 = f2 * f;
        auto cr = [&](float a, float bb, float c, float d) { return 0.5f * ((2.f * bb) + (-a + c) * f + (2.f * a - 5.f * bb + 4.f * c - d) * f2 + (-a + 3.f * bb - 3.f * c + d) * f3); };
        k.eye = V3{cr(p0.eye.x, p1.eye.x, p2.eye.x, p3.eye.x), cr(p0.eye.y, p1.eye.y, p2.eye.y, p3.eye.y), cr(p0.eye.z, p1.eye.z, p2.eye.z, p3.eye.z)};
        k.yaw = lerpAng(p1.yaw, p2.yaw, f); k.pitch = p1.pitch + (p2.pitch - p1.pitch) * f;
    }
    eye = k.eye; yaw = k.yaw; pitch = k.pitch;
    return true;
}
}

// Pone la cámara del editor mirando como el punto grabado.
static void viewFrom(Editor& e, V3 eye, float yawDeg, float pitchDeg, V3& target, float& yawE, float& pitchE, float dist) {
    float yr = yawDeg * K, pr = pitchDeg * K;
    V3 fwd{std::sin(yr) * std::cos(pr), std::sin(pr), -std::cos(yr) * std::cos(pr)};
    target = eye + fwd * dist;
    // el editor guarda dir = (sin y cos p, sin p, cos y cos p) y eye = target + dir * dist  →  dir = -fwd
    pitchE = -pr;
    yawE = std::atan2(-fwd.x, -fwd.z);
    (void)e;
}

void Editor::cineWindow() {
    if (!cineOpen_ || !hasScene()) return;
    Project& P = edit_.proj;
    Scene& S = scene();
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    const float fs = ImGui::GetFontSize();
    float h = ds.y * 0.52f;
    ImGui::SetNextWindowPos(ImVec2(0.f, ds.y - h));
    ImGui::SetNextWindowSize(ImVec2(ds.x, h));
    if (!wrapui::Begin("Cinemáticas", &cineOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings)) { ImGui::End(); return; }
    bool ch = false;
    auto& L = P.cines;
    if (cineSel_ >= (int)L.size()) cineSel_ = (int)L.size() - 1;
    float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
    if (wrapui::Button("Nueva cinemática", ImVec2((aw - sp * 2) / 3, fs * 2.2f))) {
        Cine c; c.name = "Cinemática " + std::to_string(L.size() + 1);
        L.push_back(c); cineSel_ = (int)L.size() - 1; ch = true;
    }
    ImGui::SameLine();
    if (cineSel_ >= 0 && resetBtn("cine_del", "Borrar esta")) { L.erase(L.begin() + cineSel_); cineSel_ = std::min(cineSel_, (int)L.size() - 1); ch = true; }
    ImGui::SameLine();
    if (wrapui::Button("Cerrar", ImVec2((aw - sp * 2) / 3, fs * 2.2f))) { cineOpen_ = false; cinePrev_ = -1.f; }
    if (L.empty()) {
        ImGui::TextWrapped("Aún no hay cinemáticas. Toca «Nueva cinemática». Luego mueve la cámara del editor y graba puntos: al jugar, la cámara los recorre sola.");
        ImGui::End();
        if (ch) markDirty();
        return;
    }
    if (cineSel_ < 0) cineSel_ = 0;
    for (int i = 0; i < (int)L.size(); i++) {
        if (i) ImGui::SameLine();
        ImGui::PushID(i + 9100);
        ImGui::PushStyleColor(ImGuiCol_Button, i == cineSel_ ? ImVec4(0.18f, 0.55f, 0.85f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
        if (wrapui::Button(L[i].name.c_str())) { cineSel_ = i; cinePrev_ = -1.f; }
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    Cine& C = L[cineSel_];
    {
        char nb[64]; snprintf(nb, sizeof nb, "%s", C.name.c_str());
        ImGui::SetNextItemWidth(-1.f);
        if (ImGui::InputText("##cnm", nb, sizeof nb)) { C.name = nb; ch = true; }
    }
    ch |= wrapui::SliderFloat("Duración (segundos)", &C.dur, 1.f, 120.f, "%.1f");
    if (wrapui::RadioButton("Cámara libre (puntos que grabas)", C.mode == 0)) { C.mode = 0; ch = true; }
    if (wrapui::RadioButton("Primera persona del jugador (sigue su pista)", C.mode == 1)) { C.mode = 1; ch = true; }
    ch |= wrapui::Checkbox("Se puede saltar tocando la pantalla", &C.skip);
    ImGui::TextDisabled("En el juego usa el bloque «Reproducir cinemática» con este nombre.");

    // --- vista previa de la cámara en el editor
    if (C.mode == 0 && C.cam.size() >= 1) {
        if (cinePrev_ < 0.f) { if (wrapui::Button("▶ Ver la cámara (vista previa)")) { cinePrev_ = 0.f; cinePrevDist_ = dist_; } }
        else {
            if (wrapui::Button("■ Parar vista previa")) cinePrev_ = -1.f;
            else {
                cinePrev_ += ImGui::GetIO().DeltaTime;
                V3 eye; float yw, pt;
                if (camAt(C, std::min(cinePrev_, C.dur), eye, yw, pt)) viewFrom(*this, eye, yw, pt, target_, yaw_, pitch_, 0.5f), dist_ = 0.5f;
                if (cinePrev_ >= C.dur) { cinePrev_ = -1.f; dist_ = cinePrevDist_; }
            }
        }
    }

    // --- puntos de cámara
    if (C.mode == 0) {
        ImGui::SeparatorText("Puntos de cámara");
        ImGui::TextDisabled("1) Mueve la vista del editor a donde quieras la cámara.  2) Toca «Grabar punto».  La cámara pasa suave por todos.");
        if (wrapui::Button("● Grabar punto de cámara aquí")) {
            EditorView ev = view();
            CineKey k; k.eye = ev.eye;
            V3 f = ev.fwd;
            k.pitch = std::asin(std::max(-1.f, std::min(1.f, f.y))) / K;
            k.yaw = std::atan2(f.x, -f.z) / K;
            k.t = C.cam.empty() ? 0.f : std::min(C.dur, C.cam.back().t + std::max(0.5f, C.dur / std::max<size_t>(2, C.cam.size() + 1)));
            C.cam.push_back(k);
            std::sort(C.cam.begin(), C.cam.end(), [](const CineKey& a, const CineKey& b) { return a.t < b.t; });
            ch = true;
        }
        for (int i = 0; i < (int)C.cam.size(); i++) {
            ImGui::PushID(i + 9300);
            CineKey& k = C.cam[i];
            ImGui::Text("Punto %d", i + 1);
            ImGui::SameLine();
            if (wrapui::Button("Ir")) { viewFrom(*this, k.eye, k.yaw, k.pitch, target_, yaw_, pitch_, 0.5f); dist_ = 0.5f; }
            ImGui::SameLine();
            if (wrapui::Button("Quitar")) { C.cam.erase(C.cam.begin() + i); ch = true; ImGui::PopID(); break; }
            ch |= wrapui::SliderFloat("Segundo en que llega", &k.t, 0.f, C.dur, "%.1f");
            ImGui::PopID();
        }
    }

    // --- pistas de objetos
    ImGui::SeparatorText("Objetos que se mueven");
    ImGui::TextDisabled("Elige un objeto en el editor, tócalo en «Añadir», colócalo donde quieras y graba posiciones en distintos segundos.");
    {
        bool hasSel = sel_ >= 0 && sel_ < (int)S.objs.size();
        if (hasSel && wrapui::Button(("Añadir pista del objeto: " + S.objs[sel_].name).c_str())) {
            bool dup = false; for (auto& t : C.tracks) if (t.obj == S.objs[sel_].name) dup = true;
            if (!dup) { CineTrack tr; tr.obj = S.objs[sel_].name; C.tracks.push_back(tr); ch = true; }
        }
        if (!hasSel) ImGui::TextDisabled("(No hay objeto elegido)");
    }
    for (int ti = 0; ti < (int)C.tracks.size(); ti++) {
        CineTrack& tr = C.tracks[ti];
        ImGui::PushID(ti + 9500);
        ImGui::Text("%s  (%d posiciones)", tr.obj.c_str(), (int)tr.keys.size());
        if (wrapui::Button("● Grabar posición actual")) {
            std::string nk = tr.obj;
            for (auto& o : S.objs) if (o.name == nk) {
                CineTrackKey k; k.p = o.pos; k.yaw = o.yaw;
                k.t = tr.keys.empty() ? 0.f : std::min(C.dur, tr.keys.back().t + 1.f);
                tr.keys.push_back(k);
                std::sort(tr.keys.begin(), tr.keys.end(), [](const CineTrackKey& a, const CineTrackKey& b) { return a.t < b.t; });
                ch = true; break;
            }
        }
        ImGui::SameLine();
        if (wrapui::Button("Quitar pista")) { C.tracks.erase(C.tracks.begin() + ti); ch = true; ImGui::PopID(); break; }
        for (int ki = 0; ki < (int)tr.keys.size(); ki++) {
            ImGui::PushID(ki + 100);
            ch |= wrapui::SliderFloat(("Posición " + std::to_string(ki + 1) + ": segundo").c_str(), &tr.keys[ki].t, 0.f, C.dur, "%.1f");
            if (wrapui::Button("Ir a esta posición")) for (auto& o : S.objs) if (o.name == tr.obj) { o.pos = tr.keys[ki].p; o.yaw = tr.keys[ki].yaw; ch = true; }
            ImGui::SameLine();
            if (wrapui::Button("Quitar")) { tr.keys.erase(tr.keys.begin() + ki); ch = true; ImGui::PopID(); break; }
            ImGui::PopID();
        }
        ImGui::PopID();
    }
    ImGui::End();
    if (ch) markDirty();
}

}  // namespace forge
