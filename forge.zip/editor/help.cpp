#include "help.h"
#include <cmath>
#include <cstring>
#include <sstream>

namespace forge {

// ------------------------------------------------------------------ lectura del texto
// Formato:  #F carpeta   ##S subcarpeta   ###G titulo | introduccion   - paso   @ dibujo del paso anterior
static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r"), b = s.find_last_not_of(" \t\r");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

static HelpFolder build() {
    HelpFolder root;
    root.title = "Ayuda";
    std::istringstream in(helpContentText());
    std::string line;
    HelpFolder* f = nullptr;
    HelpFolder* sub = nullptr;
    HelpGuide* g = nullptr;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty()) continue;
        if (line.rfind("###", 0) == 0) {
            std::string t = trim(line.substr(3)), intro;
            size_t bar = t.find('|');
            if (bar != std::string::npos) { intro = trim(t.substr(bar + 1)); t = trim(t.substr(0, bar)); }
            HelpFolder* dst = sub ? sub : f;
            if (!dst) continue;
            dst->guides.push_back({t, intro, {}});
            g = &dst->guides.back();
        } else if (line.rfind("##", 0) == 0) {
            if (!f) continue;
            f->sub.push_back({trim(line.substr(2)), {}, {}});
            sub = &f->sub.back();
            g = nullptr;
        } else if (line[0] == '#') {
            root.sub.push_back({trim(line.substr(1)), {}, {}});
            f = &root.sub.back();
            sub = nullptr;
            g = nullptr;
        } else if (line[0] == '-' && g) {
            g->steps.push_back({trim(line.substr(1)), ""});
        } else if (line[0] == '@' && g && !g->steps.empty()) {
            g->steps.back().pic = trim(line.substr(1));
        }
    }
    return root;
}

const HelpFolder& helpRoot() {
    static HelpFolder r = build();
    return r;
}

// ------------------------------------------------------------------ dibujos
static std::vector<std::string> split(const std::string& s, char c) {
    std::vector<std::string> o;
    std::string cur;
    for (char ch : s) { if (ch == c) { o.push_back(cur); cur.clear(); } else cur += ch; }
    o.push_back(cur);
    return o;
}

static ImU32 blockCol(char k) {
    switch (k) {
        case 'e': return IM_COL32(255, 170, 40, 255);
        case 'c': return IM_COL32(235, 200, 40, 255);
        case 'm': return IM_COL32(70, 130, 230, 255);
        case 's': return IM_COL32(170, 90, 210, 255);
        case 'a': return IM_COL32(60, 180, 90, 255);
        case 'd': return IM_COL32(230, 80, 70, 255);
        default: return IM_COL32(30, 170, 170, 255);
    }
}

static void textC(ImDrawList* dl, ImVec2 c, const std::string& s, float sz, ImU32 col) {
    ImFont* f = ImGui::GetFont();
    ImVec2 ts = f->CalcTextSizeA(sz, 1e9f, 0.f, s.c_str());
    dl->AddText(f, sz, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), col, s.c_str());
}

// dedo que señala: anillo que late y flecha
static void finger(ImDrawList* dl, ImVec2 p, float fs, double t, bool arrow = true) {
    float k = (float)(0.5 + 0.5 * std::sin(t * 5.0));
    dl->AddCircle(p, fs * (0.9f + 0.5f * k), IM_COL32(255, 220, 40, (int)(255 - 120 * k)), 24, 4.f);
    dl->AddCircleFilled(p, fs * 0.35f, IM_COL32(255, 220, 40, 255));
    if (arrow) {
        ImVec2 a{p.x + fs * 2.4f, p.y + fs * 2.4f};
        dl->AddLine(a, ImVec2(p.x + fs * 0.9f, p.y + fs * 0.9f), IM_COL32(255, 220, 40, 255), 5.f);
        dl->AddTriangleFilled(ImVec2(p.x + fs * 0.45f, p.y + fs * 0.45f), ImVec2(p.x + fs * 1.5f, p.y + fs * 0.7f), ImVec2(p.x + fs * 0.7f, p.y + fs * 1.5f), IM_COL32(255, 220, 40, 255));
    }
}

void helpDrawPic(ImDrawList* dl, ImVec2 o, ImVec2 sz, const std::string& spec, float fs, double t) {
    std::vector<std::string> a = split(spec, '|');
    if (a.empty()) return;
    const std::string& kind = a[0];
    auto arg = [&](size_t i) { return i < a.size() ? a[i] : std::string(); };
    ImU32 panel = IM_COL32(24, 30, 44, 255), line = IM_COL32(255, 255, 255, 60), white = IM_COL32(255, 255, 255, 240);
    dl->AddRectFilled(o, ImVec2(o.x + sz.x, o.y + sz.y), IM_COL32(14, 18, 28, 255), 10.f);
    dl->AddRect(o, ImVec2(o.x + sz.x, o.y + sz.y), line, 10.f, 0, 2.f);
    dl->PushClipRect(o, ImVec2(o.x + sz.x, o.y + sz.y), true);
    float pad = fs * 0.6f;

    if (kind == "bar" || kind == "menu") {   // barra de arriba del editor 3D (con menú desplegado opcional)
        static const char* items[6] = {"< Escena", "Proyecto", "Escena: Nivel1", "Añadir", "Ventanas", "JUGAR"};
        std::string hl = kind == "bar" ? arg(1) : arg(1);
        float sc = std::min(1.f, (sz.x - pad * 2) / (fs * 38.f)), f2 = fs * sc;
        float x = o.x + pad, y = o.y + pad, h = f2 * 2.2f;
        dl->AddRectFilled(ImVec2(o.x, o.y), ImVec2(o.x + sz.x, o.y + h + pad * 2), panel);
        ImVec2 target{o.x + sz.x * 0.5f, o.y + h * 0.5f + pad}, dropAt{x, y + h + pad};
        for (auto* it : items) {
            ImVec2 ts = ImGui::GetFont()->CalcTextSizeA(f2, 1e9f, 0.f, it);
            float w = ts.x + f2 * 1.2f;
            bool on = hl == it;
            ImU32 bg = std::strcmp(it, "JUGAR") == 0 ? IM_COL32(30, 150, 80, 255) : on ? IM_COL32(30, 140, 130, 255) : IM_COL32(44, 52, 72, 255);
            dl->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), bg, 6.f);
            dl->AddText(ImGui::GetFont(), f2, ImVec2(x + f2 * 0.6f, y + (h - ts.y) * 0.5f), white, it);
            if (on) { target = ImVec2(x + w * 0.5f, y + h * 0.5f); dropAt = ImVec2(x, y + h + 4.f); }
            x += w + f2 * 0.4f;
        }
        if (kind == "menu") {
            std::vector<std::string> rows = split(arg(2), ';');
            std::string pick = arg(3);
            float rw = 0;
            for (auto& r : rows) rw = std::max(rw, ImGui::GetFont()->CalcTextSizeA(f2, 1e9f, 0.f, r.c_str()).x);
            rw += f2 * 1.6f;
            float ry = dropAt.y, rh = f2 * 1.9f;
            dl->AddRectFilled(dropAt, ImVec2(dropAt.x + rw, ry + rh * rows.size() + 8.f), IM_COL32(22, 26, 38, 255), 8.f);
            dl->AddRect(dropAt, ImVec2(dropAt.x + rw, ry + rh * rows.size() + 8.f), line, 8.f);
            for (size_t i = 0; i < rows.size(); i++) {
                float yy = ry + 4.f + rh * i;
                bool on = rows[i] == pick;
                if (on) { dl->AddRectFilled(ImVec2(dropAt.x + 4, yy), ImVec2(dropAt.x + rw - 4, yy + rh), IM_COL32(30, 140, 130, 255), 5.f); target = ImVec2(dropAt.x + rw * 0.5f, yy + rh * 0.5f); }
                dl->AddText(ImGui::GetFont(), f2, ImVec2(dropAt.x + f2 * 0.7f, yy + (rh - f2) * 0.5f), white, rows[i].c_str());
            }
        }
        // fondo del mundo
        dl->AddRectFilled(ImVec2(o.x + 2, o.y + h + pad * 2 + 2), ImVec2(o.x + sz.x - 2, o.y + sz.y - 2), IM_COL32(40, 90, 50, 70), 6.f);
        if (!hl.empty()) finger(dl, target, fs * 0.7f, t);
    } else if (kind == "btn") {
        std::string txt = arg(1);
        char c = arg(2).empty() ? 'b' : arg(2)[0];
        ImU32 col = c == 'g' ? IM_COL32(30, 160, 90, 255) : c == 'r' ? IM_COL32(200, 60, 60, 255) : c == 'o' ? IM_COL32(230, 140, 40, 255) : c == 'p' ? IM_COL32(130, 90, 210, 255) : IM_COL32(50, 100, 200, 255);
        float w = std::min(sz.x - pad * 2, fs * 16.f), h = std::min(sz.y - pad * 2, fs * 3.4f);
        ImVec2 p0{o.x + (sz.x - w) * 0.5f, o.y + (sz.y - h) * 0.5f};
        dl->AddRectFilled(p0, ImVec2(p0.x + w, p0.y + h), col, 10.f);
        textC(dl, ImVec2(p0.x + w * 0.5f, p0.y + h * 0.5f), txt, fs * 1.15f, white);
        finger(dl, ImVec2(p0.x + w * 0.75f, p0.y + h * 0.5f), fs * 0.8f, t);
    } else if (kind == "tabs") {
        std::vector<std::string> names = split(arg(1), ';');
        int on = atoi(arg(2).c_str());
        float w = (sz.x - pad * 2) / std::max<size_t>(1, names.size()), h = fs * 2.4f;
        ImVec2 target{o.x + sz.x * 0.5f, o.y + pad + h * 0.5f};
        for (size_t i = 0; i < names.size(); i++) {
            ImVec2 p0{o.x + pad + w * i, o.y + pad};
            dl->AddRectFilled(p0, ImVec2(p0.x + w - 4.f, p0.y + h), (int)i == on ? IM_COL32(30, 150, 140, 255) : IM_COL32(44, 52, 72, 255), 6.f);
            textC(dl, ImVec2(p0.x + w * 0.5f - 2.f, p0.y + h * 0.5f), names[i], fs * 0.95f, white);
            if ((int)i == on) target = ImVec2(p0.x + w * 0.5f, p0.y + h * 0.5f);
        }
        dl->AddRectFilled(ImVec2(o.x + pad, o.y + pad * 2 + h), ImVec2(o.x + sz.x - pad, o.y + sz.y - pad), panel, 8.f);
        finger(dl, target, fs * 0.7f, t);
    } else if (kind == "list") {   // ventana con filas
        std::string title = arg(1), hl = arg(3);
        std::vector<std::string> rows = split(arg(2), ';');
        dl->AddRectFilled(ImVec2(o.x + pad, o.y + pad), ImVec2(o.x + sz.x - pad, o.y + sz.y - pad), panel, 8.f);
        dl->AddRectFilled(ImVec2(o.x + pad, o.y + pad), ImVec2(o.x + sz.x - pad, o.y + pad + fs * 2.f), IM_COL32(40, 50, 76, 255), 8.f);
        textC(dl, ImVec2(o.x + sz.x * 0.5f, o.y + pad + fs), title, fs, white);
        float rh = std::min(fs * 2.2f, (sz.y - pad * 2 - fs * 2.4f) / std::max<size_t>(1, rows.size()));
        ImVec2 target{o.x + sz.x * 0.5f, o.y + sz.y * 0.5f};
        bool any = false;
        for (size_t i = 0; i < rows.size(); i++) {
            float yy = o.y + pad + fs * 2.4f + rh * i;
            bool on = rows[i] == hl;
            dl->AddRectFilled(ImVec2(o.x + pad * 2, yy), ImVec2(o.x + sz.x - pad * 2, yy + rh - 4.f), on ? IM_COL32(30, 140, 130, 255) : IM_COL32(36, 44, 64, 255), 6.f);
            dl->AddText(ImGui::GetFont(), fs * 0.95f, ImVec2(o.x + pad * 3, yy + (rh - fs) * 0.5f - 1.f), white, rows[i].c_str());
            if (on) { target = ImVec2(o.x + sz.x * 0.7f, yy + rh * 0.5f); any = true; }
        }
        if (any) finger(dl, target, fs * 0.7f, t);
    } else if (kind == "blocks") {   // pila de bloques: "e:Cuando empieza;m:Mover 10 pasos"
        std::vector<std::string> rows = split(arg(1), ';');
        int hl = arg(2).empty() ? -1 : atoi(arg(2).c_str());
        float rh = std::min(fs * 2.4f, (sz.y - pad * 2) / std::max<size_t>(1, rows.size()));
        float w = std::min(sz.x - pad * 2, fs * 22.f), x0 = o.x + (sz.x - w) * 0.5f;
        ImVec2 target{x0 + w * 0.5f, o.y + sz.y * 0.5f};
        for (size_t i = 0; i < rows.size(); i++) {
            char k = rows[i].size() > 1 && rows[i][1] == ':' ? rows[i][0] : 'f';
            std::string txt = rows[i].size() > 1 && rows[i][1] == ':' ? rows[i].substr(2) : rows[i];
            float yy = o.y + pad + rh * i;
            float ind = k == 'e' ? 0.f : fs * 0.0f;
            dl->AddRectFilled(ImVec2(x0 + ind, yy), ImVec2(x0 + w, yy + rh - 3.f), blockCol(k), 7.f);
            dl->AddText(ImGui::GetFont(), fs * 0.95f, ImVec2(x0 + fs * 0.7f, yy + (rh - fs) * 0.5f - 1.f), IM_COL32(20, 20, 20, 255), txt.c_str());
            if ((int)i == hl) target = ImVec2(x0 + w * 0.8f, yy + rh * 0.5f);
        }
        if (hl >= 0) finger(dl, target, fs * 0.7f, t);
    } else if (kind == "hud") {   // teléfono acostado con botones y barras (el tercer dato resalta)
        std::string hl = ";" + arg(1) + ";";
        float pw = std::min(sz.x - pad * 2, (sz.y - pad * 2) * 2.0f), ph = pw * 0.5f;
        ImVec2 p0{o.x + (sz.x - pw) * 0.5f, o.y + (sz.y - ph) * 0.5f};
        dl->AddRectFilled(p0, ImVec2(p0.x + pw, p0.y + ph), IM_COL32(70, 120, 90, 255), 12.f);
        dl->AddRectFilled(p0, ImVec2(p0.x + pw, p0.y + ph * 0.45f), IM_COL32(110, 160, 210, 255), 12.f, ImDrawFlags_RoundCornersTop);
        dl->AddRect(p0, ImVec2(p0.x + pw, p0.y + ph), IM_COL32(200, 200, 210, 255), 12.f, 0, 3.f);
        auto X = [&](float fx) { return p0.x + pw * fx; };
        auto Y = [&](float fy) { return p0.y + ph * fy; };
        ImVec2 target{X(0.5f), Y(0.5f)};
        auto mark = [&](const char* key, ImVec2 c) { if (hl.find(std::string(";") + key + ";") != std::string::npos) target = c; };
        auto circ = [&](const char* key, float fx, float fy, float r, ImU32 col, const char* lab) {
            ImVec2 c{X(fx), Y(fy)};
            bool on = hl.find(std::string(";") + key + ";") != std::string::npos;
            dl->AddCircleFilled(c, r, col, 24);
            dl->AddCircle(c, r, on ? IM_COL32(255, 220, 40, 255) : IM_COL32(255, 255, 255, 140), 24, on ? 4.f : 2.f);
            textC(dl, c, lab, std::min(fs * 0.7f, r * 0.55f), white);
            mark(key, c);
        };
        circ("stick", 0.14f, 0.72f, ph * 0.17f, IM_COL32(60, 60, 70, 200), "mover");
        circ("shoot", 0.88f, 0.70f, ph * 0.15f, IM_COL32(220, 70, 60, 220), "disparar");
        circ("jump", 0.74f, 0.84f, ph * 0.1f, IM_COL32(60, 140, 230, 220), "saltar");
        circ("run", 0.30f, 0.55f, ph * 0.08f, IM_COL32(230, 190, 50, 220), "correr");
        circ("crouch", 0.9f, 0.43f, ph * 0.08f, IM_COL32(150, 110, 240, 220), "agachar");
        circ("reload", 0.78f, 0.55f, ph * 0.08f, IM_COL32(60, 200, 120, 220), "recargar");
        circ("minimap", 0.1f, 0.2f, ph * 0.14f, IM_COL32(8, 14, 20, 200), "mapa");
        // barras y mira
        auto bar = [&](const char* key, float fx, float fy, float fw, ImU32 col, const char* lab) {
            ImVec2 a{X(fx), Y(fy)};
            bool on = hl.find(std::string(";") + key + ";") != std::string::npos;
            dl->AddRectFilled(a, ImVec2(a.x + pw * fw, a.y + ph * 0.05f), col, 3.f);
            dl->AddRect(a, ImVec2(a.x + pw * fw, a.y + ph * 0.05f), on ? IM_COL32(255, 220, 40, 255) : IM_COL32(255, 255, 255, 120), 3.f, 0, on ? 3.f : 1.f);
            textC(dl, ImVec2(a.x + pw * fw * 0.5f, a.y + ph * 0.025f), lab, std::min(fs * 0.6f, ph * 0.045f), white);
            mark(key, ImVec2(a.x + pw * fw * 0.5f, a.y + ph * 0.025f));
        };
        bar("health", 0.05f, 0.93f, 0.22f, IM_COL32(60, 200, 80, 255), "vida");
        bar("shield", 0.05f, 0.86f, 0.22f, IM_COL32(60, 190, 220, 255), "escudo");
        bar("slots", 0.40f, 0.91f, 0.20f, IM_COL32(90, 90, 110, 255), "armas 1 2 3");
        bar("ammo", 0.44f, 0.82f, 0.12f, IM_COL32(90, 90, 110, 255), "30 / 90");
        bar("compass", 0.35f, 0.04f, 0.30f, IM_COL32(40, 40, 50, 220), "N  E  S  O");
        bar("timer", 0.45f, 0.12f, 0.10f, IM_COL32(40, 40, 50, 220), "01:25");
        circ("speedo", 0.88f, 0.22f, ph * 0.12f, IM_COL32(8, 14, 20, 200), "km/h");
        dl->AddLine(ImVec2(X(0.5f) - 8, Y(0.5f)), ImVec2(X(0.5f) + 8, Y(0.5f)), white, 2.f);
        dl->AddLine(ImVec2(X(0.5f), Y(0.5f) - 8), ImVec2(X(0.5f), Y(0.5f) + 8), white, 2.f);
        mark("cross", ImVec2(X(0.5f), Y(0.5f)));
        if (hl.size() > 2) finger(dl, target, fs * 0.7f, t);
    } else if (kind == "skel") {   // esqueleto de palitos (pose 0 = firme, 1 = caminando)
        int pose = atoi(arg(1).c_str());
        float s = std::min(sz.x, sz.y) * 0.8f;
        ImVec2 c{o.x + sz.x * 0.5f, o.y + sz.y * 0.5f};
        auto P = [&](float x, float y) { return ImVec2(c.x + x * s, c.y + (y - 0.5f) * s); };
        float sw = pose ? 0.12f : 0.f;
        struct J { float x, y; };
        J cad{0, 0.52f}, col{0, 0.38f}, pec{0, 0.28f}, cue{0, 0.18f}, cab{0, 0.10f};
        J hi{-0.15f, 0.26f}, ci{-0.19f - sw, 0.4f}, mi{-0.17f - sw * 1.2f, 0.52f}, hd{0.15f, 0.26f}, cd{0.19f + sw, 0.4f}, md{0.17f + sw * 1.2f, 0.52f};
        J ri{-0.07f - sw, 0.74f}, pi_{-0.07f - sw * 1.5f, 0.96f}, rd{0.07f + sw, 0.74f}, pd{0.07f + sw * 1.5f, 0.96f};
        J mu_i{-0.06f, 0.54f}, mu_d{0.06f, 0.54f};
        auto L = [&](J p, J q) { dl->AddLine(P(p.x, p.y), P(q.x, q.y), IM_COL32(40, 220, 200, 255), 4.f); };
        L(cad, col); L(col, pec); L(pec, cue); L(cue, cab);
        L(pec, hi); L(hi, ci); L(ci, mi); L(pec, hd); L(hd, cd); L(cd, md);
        L(cad, mu_i); L(mu_i, ri); L(ri, pi_); L(cad, mu_d); L(mu_d, rd); L(rd, pd);
        J all[] = {cad, col, pec, cue, cab, hi, ci, mi, hd, cd, md, ri, pi_, rd, pd};
        for (auto& j : all) dl->AddCircleFilled(P(j.x, j.y), fs * 0.45f, IM_COL32(255, 255, 255, 255));
        dl->AddCircle(P(cad.x, cad.y), fs * 0.8f, IM_COL32(255, 90, 90, 255), 0, 2.f);
        textC(dl, ImVec2(o.x + sz.x * 0.5f, o.y + fs), pose ? "Pose: caminando" : "Pose: firme", fs * 0.9f, white);
    } else if (kind == "view") {   // escena 3D con un cubo y flechas
        std::string tool = arg(2);
        ImVec2 a{o.x + pad, o.y + sz.y * 0.45f}, b{o.x + sz.x - pad, o.y + sz.y * 0.45f}, c{o.x + sz.x - pad * 3, o.y + sz.y - pad}, d{o.x + pad * 3, o.y + sz.y - pad};
        dl->AddRectFilled(ImVec2(o.x + 2, o.y + 2), ImVec2(o.x + sz.x - 2, o.y + sz.y * 0.45f), IM_COL32(100, 150, 215, 255), 8.f, ImDrawFlags_RoundCornersTop);
        dl->AddQuadFilled(a, b, c, d, IM_COL32(70, 140, 85, 255));
        ImVec2 m{o.x + sz.x * 0.5f, o.y + sz.y * 0.62f};
        float s = std::min(sz.x, sz.y) * 0.16f;
        dl->AddQuadFilled(ImVec2(m.x - s, m.y - s), ImVec2(m.x + s, m.y - s), ImVec2(m.x + s, m.y + s), ImVec2(m.x - s, m.y + s), IM_COL32(240, 200, 70, 255));
        dl->AddQuadFilled(ImVec2(m.x - s, m.y - s), ImVec2(m.x + s, m.y - s), ImVec2(m.x + s * 1.5f, m.y - s * 1.5f), ImVec2(m.x - s * 0.5f, m.y - s * 1.5f), IM_COL32(255, 225, 120, 255));
        dl->AddQuadFilled(ImVec2(m.x + s, m.y - s), ImVec2(m.x + s * 1.5f, m.y - s * 1.5f), ImVec2(m.x + s * 1.5f, m.y + s * 0.5f), ImVec2(m.x + s, m.y + s), IM_COL32(200, 160, 50, 255));
        if (arg(1) == "sel") dl->AddRect(ImVec2(m.x - s - 4, m.y - s * 1.5f - 4), ImVec2(m.x + s * 1.5f + 4, m.y + s + 4), IM_COL32(255, 220, 40, 255), 4.f, 0, 3.f);
        if (tool == "move") {
            dl->AddLine(m, ImVec2(m.x + s * 2.6f, m.y), IM_COL32(255, 80, 80, 255), 4.f);
            dl->AddLine(m, ImVec2(m.x, m.y - s * 2.4f), IM_COL32(80, 255, 80, 255), 4.f);
            dl->AddLine(m, ImVec2(m.x - s * 1.4f, m.y + s * 1.2f), IM_COL32(90, 140, 255, 255), 4.f);
            textC(dl, ImVec2(o.x + sz.x * 0.5f, o.y + fs), "Arrastra con el dedo: se mueve", fs * 0.9f, white);
        } else if (tool == "tap") finger(dl, m, fs * 0.8f, t);
    } else if (kind == "text") {
        textC(dl, ImVec2(o.x + sz.x * 0.5f, o.y + sz.y * 0.5f), arg(1), fs * 1.4f, white);
    } else if (kind == "car") {   // pista con carro y botones de carreras
        dl->AddRectFilled(ImVec2(o.x + 2, o.y + 2), ImVec2(o.x + sz.x - 2, o.y + sz.y * 0.4f), IM_COL32(110, 160, 215, 255), 8.f, ImDrawFlags_RoundCornersTop);
        dl->AddQuadFilled(ImVec2(o.x + sz.x * 0.4f, o.y + sz.y * 0.4f), ImVec2(o.x + sz.x * 0.6f, o.y + sz.y * 0.4f), ImVec2(o.x + sz.x * 0.9f, o.y + sz.y - 2), ImVec2(o.x + sz.x * 0.1f, o.y + sz.y - 2), IM_COL32(70, 72, 80, 255));
        dl->AddRectFilled(ImVec2(o.x + sz.x * 0.44f, o.y + sz.y * 0.62f), ImVec2(o.x + sz.x * 0.56f, o.y + sz.y * 0.8f), IM_COL32(220, 50, 50, 255), 6.f);
        auto bt = [&](float fx, const char* l, ImU32 c) { ImVec2 p{o.x + sz.x * fx, o.y + sz.y * 0.85f}; dl->AddCircleFilled(p, fs * 1.4f, c); textC(dl, p, l, fs * 0.6f, white); };
        bt(0.08f, "Izq", IM_COL32(60, 120, 220, 230)); bt(0.2f, "Der", IM_COL32(60, 120, 220, 230)); bt(0.88f, "Acelerar", IM_COL32(60, 190, 90, 230)); bt(0.76f, "Frenar", IM_COL32(220, 70, 60, 230));
    }
    dl->PopClipRect();
}

}  // namespace forge
