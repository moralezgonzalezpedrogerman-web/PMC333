#pragma once
#include "scene.h"
namespace forge {
struct TemplateInfo { const char* name; const char* what; int icon; };
int templateCount();
const TemplateInfo& templateInfo(int id);
void buildTemplate(int id, Project& p);  // arma un proyecto inicial listo para probar
}
