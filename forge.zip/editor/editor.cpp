#include "editor.h"
#include "keymap.h"
#include "brand.h"
#include "fsutil.h"
#include "importer.h"
#include "preview.h"
#include "hud.h"
#include "templates.h"
#include "library.h"
#include "defsounds.h"
#include "pack.h"
#include "catrobat.h"
#include "stb_image.h"
#include "stb_image_write.h"

#include "imgui.h"
#include "imgui_internal.h"
#include "wrapui.h"
#include "misc/cpp/imgui_stdlib.h"

#include <cstring>
#include <thread>
#ifndef _WIN32
#include <pthread.h>
#endif
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstdio>

static struct { bool on = false; float x = 0, y = 0, w = 0, h = 0; } gDock;
namespace forge {

// Lee la orientación EXIF de un JPEG (1 = normal). Las fotos del celular la traen y se verían giradas o espejadas.
static int exifOrientation(const std::vector<uint8_t>& d) {
    if (d.size() < 12 || d[0] != 0xFF || d[1] != 0xD8) return 1;
    size_t i = 2;
    while (i + 4 < d.size()) {
        if (d[i] != 0xFF) return 1;
        int mk = d[i + 1];
        size_t len = ((size_t)d[i + 2] << 8) | d[i + 3];
        if (mk == 0xE1 && i + 4 + 14 < d.size() && std::memcmp(&d[i + 4], "Exif\0\0", 6) == 0) {
            const uint8_t* t = &d[i + 10];
            size_t tl = d.size() - (i + 10);
            bool le = t[0] == 'I';
            auto r16 = [&](size_t o) -> unsigned { return o + 2 > tl ? 0u : le ? (unsigned)(t[o] | (t[o + 1] << 8)) : (unsigned)((t[o] << 8) | t[o + 1]); };
            auto r32 = [&](size_t o) -> size_t { return o + 4 > tl ? 0 : le ? (size_t)(t[o] | (t[o + 1] << 8) | (t[o + 2] << 16) | ((size_t)t[o + 3] << 24)) : (size_t)(((size_t)t[o] << 24) | (t[o + 1] << 16) | (t[o + 2] << 8) | t[o + 3]); };
            size_t ifd = r32(4);
            unsigned n = r16(ifd);
            for (unsigned k = 0; k < n && k < 64; k++) {
                size_t e = ifd + 2 + k * 12;
                if (r16(e) == 0x0112) { unsigned v = r16(e + 8); return v >= 1 && v <= 8 ? (int)v : 1; }
            }
            return 1;
        }
        if (mk == 0xDA) return 1;
        i += 2 + len;
    }
    return 1;
}

static void pngAppend(void* ctx, void* data, int size) { auto* v = (std::vector<uint8_t>*)ctx; v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + size); }

// Normaliza una imagen importada: la gira según EXIF y la guarda como PNG (también convierte BMP, GIF, TGA, PSD...).
// Devuelve false si no se pudo leer (formato raro o archivo dañado).
static bool normalizeImage(std::vector<uint8_t>& data, std::string& name, bool& changed) {
    changed = false;
    int w = 0, h = 0, c = 0;
    stbi_set_flip_vertically_on_load(0);
    unsigned char* px = stbi_load_from_memory(data.data(), (int)data.size(), &w, &h, &c, 4);
    if (!px) return false;
    int o = exifOrientation(data);
    std::string low = name;
    for (auto& ch : low) ch = (char)std::tolower((unsigned char)ch);
    (void)low;
    bool isPngJpg = name.size() > 4 && (name.compare(name.size() - 4, 4, ".png") == 0 || name.compare(name.size() - 4, 4, ".jpg") == 0 || name.compare(name.size() - 5, 5, ".jpeg") == 0);
    if (o == 1 && isPngJpg) { stbi_image_free(px); return true; }
    int nw = (o >= 5) ? h : w, nh = (o >= 5) ? w : h;
    std::vector<uint8_t> out((size_t)nw * nh * 4);
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            int dx, dy;   // destino según la orientación EXIF
            switch (o) {
                case 2: dx = w - 1 - x; dy = y; break;
                case 3: dx = w - 1 - x; dy = h - 1 - y; break;
                case 4: dx = x; dy = h - 1 - y; break;
                case 5: dx = y; dy = x; break;
                case 6: dx = h - 1 - y; dy = x; break;
                case 7: dx = h - 1 - y; dy = w - 1 - x; break;
                case 8: dx = y; dy = w - 1 - x; break;
                default: dx = x; dy = y; break;
            }
            std::memcpy(&out[((size_t)dy * nw + dx) * 4], px + ((size_t)y * w + x) * 4, 4);
        }
    stbi_image_free(px);
    std::vector<uint8_t> png;
    stbi_write_png_to_func(pngAppend, &png, nw, nh, 4, out.data(), nw * 4);
    if (png.empty()) return false;
    data = std::move(png);
    size_t dot = name.find_last_of('.');
    name = (dot == std::string::npos ? name : name.substr(0, dot)) + ".png";
    changed = true;
    return true;
}

static bool isVideoName(const std::string& n) {
    std::string l = n;
    for (auto& c : l) c = (char)std::tolower((unsigned char)c);
    for (const char* e : {".mp4", ".3gp", ".webm", ".mkv", ".avi", ".mov", ".m4v", ".mpeg", ".mpg", ".flv", ".wmv", ".ts"})
        if (l.size() > strlen(e) && l.compare(l.size() - strlen(e), strlen(e), e) == 0) return true;
    return false;
}

// ---------------------------------------------------------------- ayudantes de interfaz
namespace {

std::string lower(std::string s) {
    for (auto& c : s) c = (char)tolower((unsigned char)c);
    return s;
}
bool ends(const std::string& s, const char* e) {
    std::string l = lower(s);
    size_t n = strlen(e);
    return l.size() >= n && l.compare(l.size() - n, n, e) == 0;
}
std::string sanitize(const std::string& in) {
    std::string o;
    for (char c : in) {
        if (isalnum((unsigned char)c) || c == '_' || c == '-') o += c;
        else if (c == ' ') o += '_';
    }
    return o;
}

std::string shorten(const std::string& s, size_t n = 22) {
    n *= 4;  // los textos largos continuan en el renglon de abajo; solo se recortan los absurdamente largos
    return s.size() <= n ? s : s.substr(0, n - 1) + "…";
}

bool Combo(const char* label, std::string& cur, const std::vector<std::string>& items, const char* none = nullptr) {
    bool ch = false;
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    if (wrapui::BeginCombo(label, preview)) {
        if (none && wrapui::Selectable(none, cur.empty())) { cur.clear(); ch = true; }
        for (auto& it : items)
            if (wrapui::Selectable(it.c_str(), it == cur)) { cur = it; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

}  // namespace

// [-] valor [+]: los botones dan precision; tocar el numero abre el teclado del telefono.
bool Editor::stepper(const char* label, float& v, float step) {
    bool ch = false;
    ImGui::PushID(label);
    float fs = ImGui::GetFontSize();
    ImGui::AlignTextToFramePadding();
    {   // si el nombre es largo no cabe en la columna: va en su propio renglón (antes se encimaba con el botón "-")
        float lw = ImGui::CalcTextSize(label).x;
        ImGui::TextUnformatted(label);
        if (lw > fs * 4.5f - ImGui::GetStyle().ItemSpacing.x - 4.f) {
            ImGui::AlignTextToFramePadding();
        } else {
            ImGui::SameLine(fs * 4.5f);
        }
    }
    if (wrapui::Button("-")) { v -= step; ch = true; }
    ImGui::SameLine();
    if (host_.prompt) {
        char buf[32];
        snprintf(buf, sizeof buf, "%.2f", v);
        std::string lab = std::string(buf) + "##v";
        if (wrapui::Button(lab.c_str(), ImVec2(fs * 5.f, 0)) && tapped() && !promptActive_) {
            promptNum_ = &v; promptLo_ = -1e9f; promptHi_ = 1e9f;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
    } else {
        ImGui::SetNextItemWidth(fs * 5.f);
        if (wrapui::DragFloat("##v", &v, step * 0.25f, 0, 0, "%.2f")) ch = true;
    }
    wrapui::Next("+");
    if (wrapui::Button("+")) { v += step; ch = true; }
    ImGui::PopID();
    return ch;
}

// v11.5: movimiento automático (NPC que deambulan, rivales con ruta dibujada) y autos que el jugador puede conducir.
bool Editor::autoPanel(Obj& o, Scene& S) {
    bool ch = false;
    ch |= wrapui::Checkbox("Deambular solo por el mapa (NPC)", &o.wander);
    {
        bool on = o.cloneN > 0;
        if (wrapui::Checkbox("Poner clones de este NPC", &on)) { ch = true; o.cloneN = on ? 3 : 0; }
        if (o.cloneN > 0) {
            ch |= wrapui::SliderInt("Cuántos clones", &o.cloneN, 1, 60);
            ch |= wrapui::SliderFloat("Radio donde aparecen (m)", &o.cloneSpread, 1.f, 60.f);
            ch |= wrapui::Checkbox("Si uno muere, aparece otro hasta completar", &o.cloneRespawn);
            if (o.cloneRespawn) {
                int tot = o.cloneTotal > 0 ? o.cloneTotal : o.cloneN;
                if (wrapui::SliderInt("Total de clones que aparecerán", &tot, o.cloneN, 200)) { o.cloneTotal = tot; ch = true; }
            }
        }
    }
    if (o.wander) {
        ch |= wrapui::SliderFloat("Radio donde camina (m)", &o.wanderR, 1.f, 60.f);
        ch |= wrapui::SliderFloat("Velocidad al caminar", &o.wanderSpd, 0.5f, 8.f);
    }
    ch |= wrapui::Checkbox("Seguir una ruta dibujada (carreras)", &o.routeOn);
    if (o.routeOn || !o.route.empty()) {
        char b[80]; snprintf(b, sizeof b, "Dibujar ruta desde arriba (%d puntos)", (int)o.route.size() / 2);
        if (wrapui::Button(b)) { routeOpen_ = true; mvInit_ = false; }
        if (o.routeOn) {
            ch |= wrapui::SliderFloat("Velocidad del auto", &o.routeSpd, 3.f, 80.f);
            ch |= wrapui::SliderInt("Vueltas a la ruta (0 = sin fin)", &o.routeLaps, 0, 20);
            ch |= wrapui::SliderFloat("Ganas de ganar (0 tranquilo, 1 agresivo)", &o.routeAggr, 0.f, 1.f);
            ch |= wrapui::Checkbox("Empuja a los demás y al jugador", &o.routePush);
            ch |= wrapui::Checkbox("Circuito cerrado (da vueltas)", &o.routeLoop);
            static const char* tn[3] = {"No lanza nada", "Lanza al más cercano (rival o jugador)", "Lanza solo al jugador"};
            int t = std::max(0, std::min(2, o.routeThrow));
            if (ImGui::BeginCombo("Lanzar cosas", tn[t])) {
                for (int k = 0; k < 3; k++) if (ImGui::Selectable(tn[k], k == t)) { o.routeThrow = k; ch = true; }
                ImGui::EndCombo();
            }
        }
    }
    if (o.wander || o.routeOn) ch |= wrapui::SliderFloat("Solo se mueve si el jugador está a menos de (m)", &o.actR, 10.f, 200.f);
    if (o.wander || o.routeOn || o.carMode) {
        static const char* fn[4] = {"Atrás es el frente (lo normal en modelos importados)", "Frente normal (hacia delante)", "Frente a la izquierda", "Frente a la derecha"};
        static const float fv[4] = {180.f, 0.f, 90.f, 270.f};
        int fi = 0;
        for (int k = 0; k < 4; k++) if (std::fabs(o.frontOff - fv[k]) < 1.f) fi = k;
        if (ImGui::BeginCombo("Hacia dónde mira el modelo", fn[fi])) {
            for (int k = 0; k < 4; k++) if (ImGui::Selectable(fn[k], k == fi)) { o.frontOff = fv[k]; ch = true; }
            ImGui::EndCombo();
        }
        ch |= wrapui::SliderFloat("Ajuste fino del frente (grados)", &o.frontOff, 0.f, 360.f);
    }
    ch |= wrapui::Checkbox("Modo auto: el jugador puede conducirlo", &o.carMode);
    if (o.carMode) {
        ch |= wrapui::SliderFloat("Distancia a la que sale el botón «Conducir» (m)", &o.carEnterD, 0.2f, 10.f, "%.1f");
        ch |= wrapui::SliderFloat("Vida del auto", &o.carHp, 1.f, 200.f);
        ch |= wrapui::SliderFloat("Velocidad máxima", &o.carTop, 5.f, 80.f);
        ch |= wrapui::SliderFloat("Cámara: distancia al auto", &o.carCamD, 2.f, 15.f);
        ch |= wrapui::SliderFloat("Cámara: altura", &o.carCamH, 0.f, 8.f);
        if (wrapui::Button("Crear llantas...")) openWheels(o);
        ImGui::TextDisabled("Al acercarte sale el botón «Conducir». Dentro, los botones cambian a Izquierda, Derecha, Acelerar, Frenar y Bajar. Si lo destruyen, sigues a pie.");
    }
    if (routeOpen_) ch |= routeWindow(o, S);
    if (wheelsOpen_) ch |= wheelsWindow(o, S);
    return ch;
}

static void safeFill(ImDrawList* dl, std::vector<ImVec2> P, ImU32 col);

// Vista desde arriba del modelo (como un dibujo) para marcar cuál es su punta/frente. Se calcula una vez por modelo.
struct TopImg { int G = 56; std::vector<float> h; bool ok = false; };
static TopImg& topImgOf(const Project& pr, const std::string& name) {
    static std::map<std::string, TopImg> cache;
    auto it = cache.find(name);
    if (it != cache.end()) return it->second;
    TopImg& T = cache[name];
    auto a = pr.assets.find(name);
    ModelData md;
    if (name.empty() || a == pr.assets.end() || !modelRead(a->second.data(), a->second.size(), md) || md.idx.size() < 3) return T;
    float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
    for (size_t t = 0; t < md.idx.size(); t++) { const float* p = &md.v[md.idx[t] * 8]; for (int c = 0; c < 3; c++) { mn[c] = std::min(mn[c], p[c]); mx[c] = std::max(mx[c], p[c]); } }
    if (!(mx[0] > mn[0] && mx[2] > mn[2])) return T;
    T.h.assign((size_t)T.G * T.G, -1.f);
    float hy = std::max(1e-4f, mx[1] - mn[1]);
    auto px = [&](float v, int c) { return (v - mn[c]) / (mx[c] - mn[c]) * (T.G - 1); };
    for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
        const float* P[3] = {&md.v[md.idx[t] * 8], &md.v[md.idx[t + 1] * 8], &md.v[md.idx[t + 2] * 8]};
        float ax = px(P[0][0], 0), az = px(P[0][2], 2), bx = px(P[1][0], 0), bz = px(P[1][2], 2), cx = px(P[2][0], 0), cz = px(P[2][2], 2);
        int x0 = std::max(0, (int)std::floor(std::min(ax, std::min(bx, cx)))), x1 = std::min(T.G - 1, (int)std::ceil(std::max(ax, std::max(bx, cx))));
        int z0 = std::max(0, (int)std::floor(std::min(az, std::min(bz, cz)))), z1 = std::min(T.G - 1, (int)std::ceil(std::max(az, std::max(bz, cz))));
        float den = (bz - cz) * (ax - cx) + (cx - bx) * (az - cz);
        for (int zz = z0; zz <= z1; zz++)
            for (int xx = x0; xx <= x1; xx++) {
                float hh = (P[0][1] + P[1][1] + P[2][1]) / 3.f;
                bool in = false;
                if (std::fabs(den) > 1e-6f) {
                    float l1 = ((bz - cz) * (xx - cx) + (cx - bx) * (zz - cz)) / den, l2 = ((cz - az) * (xx - cx) + (ax - cx) * (zz - cz)) / den, l3 = 1.f - l1 - l2;
                    in = l1 >= -0.15f && l2 >= -0.15f && l3 >= -0.15f;
                    if (in) hh = l1 * P[0][1] + l2 * P[1][1] + l3 * P[2][1];
                } else in = true;   // triángulo muy fino visto desde arriba
                if (in) { float& c = T.h[(size_t)zz * T.G + xx]; c = std::max(c, (hh - mn[1]) / hy); }
            }
    }
    T.ok = true;
    return T;
}

bool Editor::routeWindow(Obj& o, Scene& S) {
    bool ch = false;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ds, ImGuiCond_Appearing);
    if (!ImGui::Begin("Ruta del auto (vista desde arriba)", &routeOpen_, ImGuiWindowFlags_NoCollapse)) { ImGui::End(); return false; }
    ImGui::TextWrapped("Toca el mapa para poner puntos en orden. Arrastra un punto para moverlo. A la derecha: toca la PUNTA del modelo; esa parte irá siempre primero en la ruta.");
    if (wrapui::Button("Deshacer punto") && o.route.size() >= 2) { o.route.pop_back(); o.route.pop_back(); ch = true; }
    ImGui::SameLine();
    if (wrapui::Button("Borrar ruta")) { o.route.clear(); ch = true; }
    ImGui::SameLine();
    if (wrapui::Button("Listo")) routeOpen_ = false;
    {   // frente del modelo: la flecha del mapa muestra hacia dónde mira ahora; el modelo girará hacia donde avanza la ruta
        ImGui::TextUnformatted("Frente del modelo (flecha azul en el mapa):");
        static const char* fl[4] = {"Atrás es frente", "Adelante", "Izquierda", "Derecha"};
        static const float fv[4] = {180.f, 0.f, 90.f, 270.f};
        for (int i = 0; i < 4; i++) {
            ImGui::SameLine();
            bool on = std::fabs(o.frontOff - fv[i]) < 1.f;
            ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.20f, 0.45f, 0.85f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            ImGui::PushID(700 + i);
            if (wrapui::Button(fl[i]) && tapped()) { o.frontOff = fv[i]; ch = true; }
            ImGui::PopID();
            ImGui::PopStyleColor();
        }
    }
    float x0 = 1e9f, x1 = -1e9f, z0 = 1e9f, z1 = -1e9f;
    for (auto& q : S.objs) {
        if (!q.visible || q.kind == Kind::Light) continue;
        float r = std::max(q.scale.x, q.scale.z) * 0.5f;
        if (r > 200.f) r = 200.f;
        x0 = std::min(x0, q.pos.x - r); x1 = std::max(x1, q.pos.x + r); z0 = std::min(z0, q.pos.z - r); z1 = std::max(z1, q.pos.z + r);
    }
    for (size_t k = 0; k + 1 < o.route.size(); k += 2) { x0 = std::min(x0, o.route[k]); x1 = std::max(x1, o.route[k]); z0 = std::min(z0, o.route[k + 1]); z1 = std::max(z1, o.route[k + 1]); }
    if (x1 - x0 < 10.f) { x0 -= 10.f; x1 += 10.f; }
    if (z1 - z0 < 10.f) { z0 -= 10.f; z1 += 10.f; }
    float mg = 3.f; x0 -= mg; x1 += mg; z0 -= mg; z1 += mg;
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(100.f, av.y - 4.f);
    const float panW = std::max(150.f, std::min(av.x * 0.34f, 300.f));   // columna con el dibujo del modelo
    av.x = std::max(120.f, av.x - panW - 8.f);
    float k = std::min(av.x / (x1 - x0), av.y / (z1 - z0));
    {
        float vcx, vcz;
        mapView(k, (x0 + x1) * 0.5f, (z0 + z1) * 0.5f, org, av, false, k, vcx, vcz);
        x0 = vcx - av.x * 0.5f / k; z0 = vcz - av.y * 0.5f / k;
    }
    ImVec2 sz = av;
    auto toS = [&](float x, float z) { return ImVec2(org.x + (x - x0) * k, org.y + (z - z0) * k); };
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(org, ImVec2(org.x + sz.x, org.y + sz.y), true);
    dl->AddRectFilled(org, ImVec2(org.x + sz.x, org.y + sz.y), IM_COL32(22, 26, 34, 255));
    for (auto& q : S.objs) {
        if (!q.visible || q.kind == Kind::Light || q.kind == Kind::Player) continue;
        float a = q.yaw * 0.0174532925f, c = std::cos(a), s2 = std::sin(a), hx = q.scale.x * 0.5f, hz = q.scale.z * 0.5f;
        ImVec2 P[4]; const float cx[4] = {-1, 1, 1, -1}, cz[4] = {-1, -1, 1, 1};
        for (int m = 0; m < 4; m++) { float lx = cx[m] * hx, lz = cz[m] * hz; P[m] = toS(q.pos.x + c * lx + s2 * lz, q.pos.z - s2 * lx + c * lz); }
        ImU32 col = q.kind == Kind::Floor ? IM_COL32(70, 76, 86, 255) : q.kind == Kind::Wall ? IM_COL32(150, 110, 80, 255) : q.kind == Kind::Model ? IM_COL32(90, 150, 220, 255) : IM_COL32(120, 160, 120, 255);
        if (&q == &o) col = IM_COL32(255, 200, 60, 255);
        dl->AddConvexPolyFilled(P, 4, (col & 0x00FFFFFF) | (q.kind == Kind::Floor ? 0xAA000000 : 0xCC000000));
        dl->AddPolyline(P, 4, IM_COL32(255, 255, 255, 60), ImDrawFlags_Closed, 1.f);
    }
    if (S.limMode == 1) dl->AddCircle(toS(S.limCx, S.limCz), S.limR * k, IM_COL32(80, 255, 160, 255), 64, 3.f);
    if (S.limMode == 2) dl->AddRect(toS(S.limCx - S.limR, S.limCz - S.limR), toS(S.limCx + S.limR, S.limCz + S.limR), IM_COL32(80, 255, 160, 255), 0.f, 0, 3.f);
    for (auto& zn : S.zones) {   // zonas prohibidas: rojo rayado (solo en el editor)
        std::vector<ImVec2> P;
        for (size_t m = 0; m + 1 < zn.pts.size(); m += 2) P.push_back(toS(zn.pts[m], zn.pts[m + 1]));
        if (P.size() < 3) continue;
        safeFill(dl, P, IM_COL32(255, 60, 60, 90));
        if (P.size() >= 2 && P.size() <= 2000) dl->AddPolyline(P.data(), (int)P.size(), IM_COL32(255, 90, 90, 255), ImDrawFlags_Closed, 2.f);
    }
    ImVec2 ps = toS(S.start.x, S.start.z);
    dl->AddCircleFilled(ps, 7.f, IM_COL32(60, 255, 120, 255));
    dl->AddText(ImVec2(ps.x + 9, ps.y - 8), IM_COL32(60, 255, 120, 255), "Jugador");
    {   // flecha del frente del modelo
        float h = (-o.yaw - o.frontOff) * 0.0174532925f;
        ImVec2 c0 = toS(o.pos.x, o.pos.z), dir(std::sin(h), -std::cos(h)), side(-dir.y, dir.x);
        float L = std::max(26.f, std::max(o.scale.x, o.scale.z) * k * 0.7f);
        ImVec2 tip(c0.x + dir.x * L, c0.y + dir.y * L), b(c0.x + dir.x * L * 0.65f, c0.y + dir.y * L * 0.65f);
        dl->AddLine(c0, tip, IM_COL32(80, 170, 255, 255), 4.f);
        dl->AddTriangleFilled(tip, ImVec2(b.x + side.x * 9.f, b.y + side.y * 9.f), ImVec2(b.x - side.x * 9.f, b.y - side.y * 9.f), IM_COL32(80, 170, 255, 255));
        dl->AddText(ImVec2(tip.x + 6.f, tip.y - 8.f), IM_COL32(80, 170, 255, 255), "FRENTE");
    }
    ImGui::InvisibleButton("##rcv", sz);
    static int drag = -1; static ImVec2 down;
    ImVec2 mp = ImGui::GetIO().MousePos;
    float rad = 18.f;
    const bool gesture = mvPinch_ || play_.ctl.downCount() >= 2;
    if (ImGui::IsItemActivated()) {
        drag = -1; down = mp;
        for (size_t m = 0; m + 1 < o.route.size(); m += 2) { ImVec2 q = toS(o.route[m], o.route[m + 1]); if ((q.x - mp.x) * (q.x - mp.x) + (q.y - mp.y) * (q.y - mp.y) < rad * rad) { drag = (int)m; break; } }
    }
    if (!gesture && ImGui::IsItemActive() && drag >= 0 && drag + 1 < (int)o.route.size()) { o.route[drag] = x0 + (mp.x - org.x) / k; o.route[drag + 1] = z0 + (mp.y - org.y) / k; ch = true; }
    if (!gesture && !mvPinch_ && ImGui::IsItemDeactivated() && drag < 0 && std::fabs(mp.x - down.x) + std::fabs(mp.y - down.y) < 10.f) {
        o.route.push_back(x0 + (mp.x - org.x) / k); o.route.push_back(z0 + (mp.y - org.y) / k); ch = true;
    }
    size_t n = o.route.size() / 2;
    for (size_t m = 0; m < n; m++) {
        ImVec2 a = toS(o.route[m * 2], o.route[m * 2 + 1]);
        if (m + 1 < n || (o.routeLoop && n > 2)) { ImVec2 b = toS(o.route[((m + 1) % n) * 2], o.route[((m + 1) % n) * 2 + 1]); dl->AddLine(a, b, IM_COL32(255, 80, 80, 255), 4.f); }
    }
    for (size_t m = 0; m < n; m++) {
        ImVec2 a = toS(o.route[m * 2], o.route[m * 2 + 1]);
        dl->AddCircleFilled(a, 11.f, m == 0 ? IM_COL32(60, 255, 120, 255) : IM_COL32(255, 255, 255, 255));
        char nb[8]; snprintf(nb, sizeof nb, "%d", (int)m + 1);
        dl->AddText(ImVec2(a.x - 4.f, a.y - 7.f), IM_COL32(0, 0, 0, 255), nb);
    }
    dl->PopClipRect();
    {   // dibujo del modelo desde arriba: toca o arrastra para marcar la PUNTA (lo que debe ir primero al avanzar)
        ImVec2 po(org.x + sz.x + 8.f, org.y), ps2(panW, av.y);
        ImGui::SetCursorScreenPos(po);
        ImGui::InvisibleButton("##mdlfront", ps2);
        ImDrawList* d2 = ImGui::GetWindowDrawList();
        d2->PushClipRect(po, ImVec2(po.x + ps2.x, po.y + ps2.y), true);
        d2->AddRectFilled(po, ImVec2(po.x + ps2.x, po.y + ps2.y), IM_COL32(30, 34, 46, 255));
        const float fs2 = ImGui::GetFontSize();
        d2->AddText(ImVec2(po.x + 6.f, po.y + 4.f), IM_COL32(230, 235, 245, 255), "Dibujo del modelo");
        d2->AddText(ImVec2(po.x + 6.f, po.y + 4.f + fs2 * 1.2f), IM_COL32(150, 200, 255, 255), "Toca la PUNTA (el frente)");
        float areaTop = po.y + fs2 * 2.8f, availH = ps2.y - fs2 * 2.8f - 6.f, availW = ps2.x - 12.f;
        float sx = std::max(0.1f, std::fabs(o.scale.x)), sz2 = std::max(0.1f, std::fabs(o.scale.z));
        float u = std::max(20.f, std::min(availW / sx, availH / sz2));
        float W = sx * u, H = sz2 * u;
        ImVec2 mc(po.x + ps2.x * 0.5f, areaTop + availH * 0.5f);
        ImVec2 m0(mc.x - W * 0.5f, mc.y - H * 0.5f);
        d2->AddRect(m0, ImVec2(m0.x + W, m0.y + H), IM_COL32(255, 255, 255, 70), 0.f, 0, 1.f);
        static TopImg none;
        TopImg& T = o.kind == Kind::Model ? topImgOf(edit_.proj, o.model) : none;
        if (T.ok) {
            float cw = W / T.G, ch2 = H / T.G;
            for (int zz = 0; zz < T.G; zz++)
                for (int xx = 0; xx < T.G; xx++) {
                    float hv = T.h[(size_t)zz * T.G + xx];
                    if (hv < 0.f) continue;
                    int g = 90 + (int)(hv * 140.f);
                    d2->AddRectFilled(ImVec2(m0.x + xx * cw, m0.y + zz * ch2), ImVec2(m0.x + (xx + 1) * cw + 0.6f, m0.y + (zz + 1) * ch2 + 0.6f), IM_COL32(g, g + 10 > 255 ? 255 : g + 10, 255 > g + 25 ? g + 25 : 255, 255));
                }
        } else d2->AddRectFilled(m0, ImVec2(m0.x + W, m0.y + H), IM_COL32(110, 150, 200, 255));
        // punta marcada: sale del centro hacia el borde del dibujo
        float hf = -o.frontOff * 0.0174532925f;
        ImVec2 dir(std::sin(hf), -std::cos(hf));
        float tmax = 1e9f;
        if (std::fabs(dir.x) > 1e-4f) tmax = std::min(tmax, (W * 0.5f) / std::fabs(dir.x));
        if (std::fabs(dir.y) > 1e-4f) tmax = std::min(tmax, (H * 0.5f) / std::fabs(dir.y));
        ImVec2 tip(mc.x + dir.x * tmax, mc.y + dir.y * tmax);
        d2->AddLine(mc, tip, IM_COL32(255, 70, 70, 255), 3.f);
        d2->AddCircleFilled(tip, 10.f, IM_COL32(255, 70, 70, 255));
        d2->AddCircle(tip, 10.f, IM_COL32(255, 255, 255, 255), 0, 2.f);
        d2->AddText(ImVec2(tip.x + 12.f, tip.y - fs2 * 0.5f), IM_COL32(255, 120, 120, 255), "PUNTA");
        d2->AddCircleFilled(mc, 4.f, IM_COL32(255, 255, 255, 255));
        d2->PopClipRect();
        if (ImGui::IsItemActive() && !mvPinch_) {
            ImVec2 q = ImGui::GetIO().MousePos;
            float dx = q.x - mc.x, dz = q.y - mc.y;
            if (dx * dx + dz * dz > 16.f) {
                float hh = std::atan2(dx, -dz) / 0.0174532925f;   // rumbo del punto tocado respecto al modelo sin girar
                float nf = std::fmod(-hh + 720.f, 360.f);
                if (std::fabs(nf - o.frontOff) > 0.4f) { o.frontOff = std::round(nf); ch = true; }
            }
        }
    }
    ImGui::End();
    return ch;
}

// v11.5: dibujar zonas prohibidas con el dedo o el mouse, vistas desde arriba (se cierran solas al soltar).
// Relleno de un polígono cualquiera sin que pueda trabarse ni fallar (ImGui se detiene con figuras degeneradas).
static void safeFill(ImDrawList* dl, std::vector<ImVec2> P, ImU32 col) {
    std::vector<ImVec2> Q;
    for (auto& p : P) if (std::isfinite(p.x) && std::isfinite(p.y) && (Q.empty() || std::fabs(p.x - Q.back().x) + std::fabs(p.y - Q.back().y) > 0.5f)) Q.push_back(p);
    if (Q.size() > 160) { std::vector<ImVec2> R; float st = (float)Q.size() / 160.f; for (float i = 0; i < (float)Q.size(); i += st) R.push_back(Q[(size_t)i]); Q.swap(R); }
    int n = (int)Q.size();
    if (n < 3) return;
    float area = 0.f;
    for (int i = 0; i < n; i++) { const ImVec2 &a = Q[i], &b = Q[(i + 1) % n]; area += a.x * b.y - b.x * a.y; }
    if (std::fabs(area) < 4.f) return;
    if (area < 0.f) std::reverse(Q.begin(), Q.end());
    std::vector<int> idx(n);
    for (int i = 0; i < n; i++) idx[i] = i;
    auto cross2 = [](ImVec2 a, ImVec2 b, ImVec2 c) { return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x); };
    int guard = n * n + 16;
    while (idx.size() > 3 && guard-- > 0) {
        bool cut = false;
        int m = (int)idx.size();
        for (int i = 0; i < m && !cut; i++) {
            int ia = idx[(i + m - 1) % m], ib = idx[i], ic = idx[(i + 1) % m];
            if (cross2(Q[ia], Q[ib], Q[ic]) <= 1e-4f) continue;
            bool inside = false;
            for (int j = 0; j < m && !inside; j++) {
                int k = idx[j];
                if (k == ia || k == ib || k == ic) continue;
                if (cross2(Q[ia], Q[ib], Q[k]) >= 0.f && cross2(Q[ib], Q[ic], Q[k]) >= 0.f && cross2(Q[ic], Q[ia], Q[k]) >= 0.f) inside = true;
            }
            if (inside) continue;
            dl->AddTriangleFilled(Q[ia], Q[ib], Q[ic], col);
            idx.erase(idx.begin() + i);
            cut = true;
        }
        if (!cut) {   // figura que se cruza: se rellena en abanico y se termina
            for (size_t i = 1; i + 1 < idx.size(); i++) dl->AddTriangleFilled(Q[idx[0]], Q[idx[i]], Q[idx[i + 1]], col);
            return;
        }
    }
    if (idx.size() == 3) dl->AddTriangleFilled(Q[idx[0]], Q[idx[1]], Q[idx[2]], col);
}


// Zona prohibida = una sola máscara (pincel). Estas funciones rellenan o borran figuras sobre esa máscara.
static void maskFillPoly(Scene& S, const std::vector<float>& pts, uint8_t v = 1) {
    if (pts.size() < 6) return;
    float x0 = 1e9f, x1 = -1e9f, z0 = 1e9f, z1 = -1e9f;
    for (size_t m = 0; m + 1 < pts.size(); m += 2) { x0 = std::min(x0, pts[m]); x1 = std::max(x1, pts[m]); z0 = std::min(z0, pts[m + 1]); z1 = std::max(z1, pts[m + 1]); }
    if (S.blk.empty()) S.blk.assign((size_t)Scene::kBlkN * Scene::kBlkN, 0);
    const int H = Scene::kBlkN / 2;
    int c0 = std::max(0, (int)std::floor(x0) + H), c1 = std::min(Scene::kBlkN - 1, (int)std::floor(x1) + H);
    int r0 = std::max(0, (int)std::floor(z0) + H), r1 = std::min(Scene::kBlkN - 1, (int)std::floor(z1) + H);
    size_t n = pts.size() / 2;
    for (int j = r0; j <= r1; j++) for (int i = c0; i <= c1; i++) {
        float x = (float)(i - H) + 0.5f, z = (float)(j - H) + 0.5f; bool in = false;
        for (size_t a = 0, b = n - 1; a < n; b = a++) {
            float xa = pts[a * 2], za = pts[a * 2 + 1], xb = pts[b * 2], zb = pts[b * 2 + 1];
            if ((za > z) != (zb > z) && x < (xb - xa) * (z - za) / (zb - za) + xa) in = !in;
        }
        if (in) S.blk[(size_t)j * Scene::kBlkN + i] = v;
    }
}
static void maskLine(Scene& S, float ax, float az, float bx, float bz, float r, uint8_t v) {   // pincel que se arrastra: círculos a lo largo del trazo
    float L = std::sqrt((bx - ax) * (bx - ax) + (bz - az) * (bz - az));
    int steps = std::max(1, (int)(L / std::max(0.4f, r * 0.5f)));
    for (int k = 0; k <= steps; k++) { float t = (float)k / steps; S.blkDisc(ax + (bx - ax) * t, az + (bz - az) * t, r, v); }
}

bool Editor::zoneWindow(Scene& S) {
    bool ch = false;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ds, ImGuiCond_Appearing);
    if (!ImGui::Begin("Zonas prohibidas (vista desde arriba)", &zoneOpen_, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) { ImGui::End(); return false; }
    const float fs = ImGui::GetFontSize();
    static int tool = 0;   // 0 lápiz, 1 rectángulo, 2 círculo, 3 polígono, 4 borrar con dedo, 5 borrar con rectángulo, 6 borrar con círculo
    static int newWho = 3;
    static std::vector<float> poly;   // polígono en construcción
    static const char* TN[7] = {"Pincel", "Rectángulo", "Círculo", "Polígono", "Borrador", "Borrar (rect.)", "Borrar (círculo)"};
    static float brushR = 3.f;
    static std::vector<uint8_t> undoBlk; static bool undoHas = false;
    {
        float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int per = aw > fs * 46.f ? 7 : 4;
        float bw = (aw - sp * (per - 1)) / per;
        for (int t = 0; t < 7; t++) {
            if (t % per) ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Button, tool == t ? (t >= 4 ? ImVec4(0.8f, 0.3f, 0.25f, 1.f) : ImVec4(0.18f, 0.55f, 0.85f, 1.f)) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
            ImGui::PushID(t + 900);
            if (wrapui::Button(TN[t], ImVec2(bw, fs * 2.2f)) && tapped()) { tool = t; poly.clear(); }
            ImGui::PopID();
            ImGui::PopStyleColor();
        }
        ch |= wrapui::SliderFloat("Grosor del pincel / borrador (m)", &brushR, 0.5f, 25.f);
        if (wrapui::Button("Deshacer") && undoHas) { S.blk = undoBlk; undoHas = false; ch = true; }
        ImGui::SameLine();
        if (wrapui::Button("Borrar todo")) { undoBlk = S.blk; undoHas = true; S.blk.clear(); S.zones.clear(); ch = true; }
        ImGui::SameLine();
        if (tool == 3 && wrapui::Button("Cerrar polígono") && poly.size() >= 6) { undoBlk = S.blk; undoHas = true; maskFillPoly(S, poly); poly.clear(); ch = true; }
        if (tool == 3) ImGui::SameLine();
        if (wrapui::Button("Ver todo")) mvInit_ = false;
        ImGui::SameLine();
        if (wrapui::Button("Listo")) zoneOpen_ = false;
        ImGui::TextDisabled("Pasa el dedo por donde NO quieres que pasen (rojo). Dos dedos: zoom y mover.");
    }
    float x0 = 1e9f, x1 = -1e9f, z0 = 1e9f, z1 = -1e9f;
    for (auto& q : S.objs) {
        if (!q.visible || q.kind == Kind::Light) continue;
        float r = std::min(200.f, std::max(q.scale.x, q.scale.z) * 0.5f);
        x0 = std::min(x0, q.pos.x - r); x1 = std::max(x1, q.pos.x + r); z0 = std::min(z0, q.pos.z - r); z1 = std::max(z1, q.pos.z + r);
    }
    if (S.limMode) { x0 = std::min(x0, S.limCx - S.limR); x1 = std::max(x1, S.limCx + S.limR); z0 = std::min(z0, S.limCz - S.limR); z1 = std::max(z1, S.limCz + S.limR); }
    for (auto& zn : S.zones) for (size_t m = 0; m + 1 < zn.pts.size(); m += 2) { x0 = std::min(x0, zn.pts[m]); x1 = std::max(x1, zn.pts[m]); z0 = std::min(z0, zn.pts[m + 1]); z1 = std::max(z1, zn.pts[m + 1]); }
    if (x1 - x0 < 10.f) { x0 -= 10.f; x1 += 10.f; }
    if (z1 - z0 < 10.f) { z0 -= 10.f; z1 += 10.f; }
    x0 -= 3.f; x1 += 3.f; z0 -= 3.f; z1 += 3.f;
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(100.f, av.y - 2.f);
    float k = std::min(av.x / (x1 - x0), av.y / (z1 - z0)), vcx, vcz;
    {   // la vista base se congela al abrir: así dibujar una figura no mueve ni cambia el zoom del mapa
        static float sK = 1.f, sCx = 0.f, sCz = 0.f;
        if (!mvInit_) { sK = k; sCx = (x0 + x1) * 0.5f; sCz = (z0 + z1) * 0.5f; }
        k = sK;
        mapView(k, sCx, sCz, org, av, false, k, vcx, vcz);
    }
    x0 = vcx - av.x * 0.5f / k; z0 = vcz - av.y * 0.5f / k;
    ImVec2 sz = av;
    auto toS = [&](float x, float z) { return ImVec2(org.x + (x - x0) * k, org.y + (z - z0) * k); };
    auto toW = [&](ImVec2 p) { return ImVec2(x0 + (p.x - org.x) / k, z0 + (p.y - org.y) / k); };
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(org, ImVec2(org.x + sz.x, org.y + sz.y), true);
    dl->AddRectFilled(org, ImVec2(org.x + sz.x, org.y + sz.y), IM_COL32(22, 26, 34, 255));
    for (auto& q : S.objs) {
        if (!q.visible || q.kind == Kind::Light || q.kind == Kind::Player) continue;
        float a = q.yaw * 0.0174532925f, c = std::cos(a), s2 = std::sin(a), hx = q.scale.x * 0.5f, hz = q.scale.z * 0.5f;
        ImVec2 P[4]; const float cx[4] = {-1, 1, 1, -1}, cz[4] = {-1, -1, 1, 1};
        for (int m = 0; m < 4; m++) { float lx = cx[m] * hx, lz = cz[m] * hz; P[m] = toS(q.pos.x + c * lx + s2 * lz, q.pos.z - s2 * lx + c * lz); }
        ImU32 col = q.kind == Kind::Floor ? IM_COL32(70, 76, 86, 170) : q.kind == Kind::Wall ? IM_COL32(150, 110, 80, 200) : q.kind == Kind::Model ? IM_COL32(90, 150, 220, 200) : IM_COL32(120, 160, 120, 200);
        dl->AddConvexPolyFilled(P, 4, col);
    }
    if (S.limMode == 1) dl->AddCircle(toS(S.limCx, S.limCz), S.limR * k, IM_COL32(80, 255, 160, 255), 96, 3.f);
    if (S.limMode == 2) dl->AddRect(toS(S.limCx - S.limR, S.limCz - S.limR), toS(S.limCx + S.limR, S.limCz + S.limR), IM_COL32(80, 255, 160, 255), 0.f, 0, 3.f);
    if (!S.blk.empty()) {   // máscara pintada (un solo objeto): se dibuja por bloques para que no pese
        const int H = Scene::kBlkN / 2, N = Scene::kBlkN;
        int ci0 = std::max(0, (int)std::floor(x0) + H), ci1 = std::min(N - 1, (int)std::floor(x0 + sz.x / k) + H);
        int cj0 = std::max(0, (int)std::floor(z0) + H), cj1 = std::min(N - 1, (int)std::floor(z0 + sz.y / k) + H);
        int st = std::max(1, (int)std::ceil(std::max(ci1 - ci0, cj1 - cj0) / 110.f));
        for (int j = cj0; j <= cj1; j += st) for (int i = ci0; i <= ci1; i += st) {
            bool any = false;
            for (int b = 0; b < st && !any; b++) for (int a = 0; a < st; a++) { int ii = i + a, jj = j + b; if (ii < N && jj < N && S.blk[(size_t)jj * N + ii]) { any = true; break; } }
            if (any) dl->AddRectFilled(toS((float)(i - H), (float)(j - H)), toS((float)(i - H + st), (float)(j - H + st)), IM_COL32(255, 60, 60, 140));
        }
    }
    for (auto& z : S.zones) {
        std::vector<ImVec2> P;
        for (size_t m = 0; m + 1 < z.pts.size(); m += 2) P.push_back(toS(z.pts[m], z.pts[m + 1]));
        safeFill(dl, P, IM_COL32(255, 60, 60, 110));
        dl->AddPolyline(P.data(), (int)P.size(), IM_COL32(255, 90, 90, 255), ImDrawFlags_Closed, 2.f);
    }
    ImVec2 ps = toS(S.start.x, S.start.z);
    dl->AddCircleFilled(ps, 7.f, IM_COL32(60, 255, 120, 255));
    ImGui::InvisibleButton("##zcv", sz);
    static std::vector<float> stroke;
    static ImVec2 p0, pdown;
    static bool pinchedNow = false;
    ImVec2 mp = ImGui::GetIO().MousePos;
    const bool gesture = mvPinch_ || play_.ctl.downCount() >= 2;
    // En pantallas táctiles, al soltar el dedo la posición del puntero se vuelve inválida (valor enorme):
    // por eso las figuras se iban lejos. Se usa siempre la última posición válida mientras estaba presionado.
    static ImVec2 lastMp; static bool needP0 = false;
    const bool mpOk = std::isfinite(mp.x) && std::isfinite(mp.y) && std::fabs(mp.x) < 1e6f && std::fabs(mp.y) < 1e6f;
    if (ImGui::IsItemActivated()) { stroke.clear(); pinchedNow = false; needP0 = true; }
    if (ImGui::IsItemActive() && mpOk) { lastMp = mp; if (needP0) { p0 = toW(mp); pdown = mp; needP0 = false; } }
    else if (ImGui::IsItemDeactivated() || !mpOk) mp = lastMp;
    if (gesture) pinchedNow = true;
    auto pointInPoly = [&](const std::vector<float>& pts, float x, float z) {
        if (pts.size() < 6) return false;
        bool in = false; size_t n = pts.size() / 2;
        for (size_t a = 0, b = n - 1; a < n; b = a++) {
            float xa = pts[a * 2], za = pts[a * 2 + 1], xb = pts[b * 2], zb = pts[b * 2 + 1];
            if ((za > z) != (zb > z) && x < (xb - xa) * (z - za) / (zb - za) + xa) in = !in;
        }
        return in;
    };
    // ¿la zona toca el círculo (cx,cz,r)? (vértices, puntos de las aristas o el centro dentro)
    auto zoneTouchesCircle = [&](const Scene::Zone& z, float cx, float cz, float r) {
        size_t n = z.pts.size() / 2;
        if (pointInPoly(z.pts, cx, cz)) return true;
        for (size_t a = 0; a < n; a++) {
            size_t b = (a + 1) % n;
            float ax = z.pts[a * 2], az = z.pts[a * 2 + 1], bx = z.pts[b * 2], bz = z.pts[b * 2 + 1];
            float L = std::sqrt((bx - ax) * (bx - ax) + (bz - az) * (bz - az));
            int steps = std::max(1, (int)(L / std::max(0.2f, r * 0.5f)));
            for (int s = 0; s <= steps; s++) { float t = (float)s / steps, px = ax + (bx - ax) * t, pz = az + (bz - az) * t; if ((px - cx) * (px - cx) + (pz - cz) * (pz - cz) <= r * r) return true; }
        }
        return false;
    };
    auto zoneTouchesRect = [&](const Scene::Zone& z, float rx0, float rz0, float rx1, float rz1) {
        size_t n = z.pts.size() / 2;
        if (pointInPoly(z.pts, (rx0 + rx1) * 0.5f, (rz0 + rz1) * 0.5f)) return true;
        for (size_t a = 0; a < n; a++) {
            size_t b = (a + 1) % n;
            float ax = z.pts[a * 2], az = z.pts[a * 2 + 1], bx = z.pts[b * 2], bz = z.pts[b * 2 + 1];
            float L = std::sqrt((bx - ax) * (bx - ax) + (bz - az) * (bz - az));
            int steps = std::max(1, (int)(L / 0.4f));
            for (int s = 0; s <= steps; s++) { float t = (float)s / steps, px = ax + (bx - ax) * t, pz = az + (bz - az) * t; if (px >= rx0 && px <= rx1 && pz >= rz0 && pz <= rz1) return true; }
        }
        return false;
    };
    ImVec2 w = toW(mp);
    static ImVec2 lastW; static bool hasLastW = false;
    if (!gesture && ImGui::IsItemActive()) {
        if (ImGui::IsItemActivated() || !hasLastW) { undoBlk = S.blk; undoHas = true; }
        ImVec2 from = hasLastW ? lastW : w;
        if (tool == 0 || tool == 4) {   // pincel / borrador: desliza el dedo
            uint8_t v = tool == 0 ? 1 : 0;
            maskLine(S, from.x, from.y, w.x, w.y, brushR, v);
            if (tool == 4) for (int zi = (int)S.zones.size() - 1; zi >= 0; zi--) if (zoneTouchesCircle(S.zones[zi], w.x, w.y, brushR)) { S.zones.erase(S.zones.begin() + zi); }
            ch = true;
            dl->AddCircle(mp, brushR * k, tool == 0 ? IM_COL32(255, 220, 80, 255) : IM_COL32(255, 120, 120, 255), 32, 2.f);
        } else if (tool == 1 || tool == 5) {
            ImU32 col = tool == 1 ? IM_COL32(255, 220, 80, 255) : IM_COL32(255, 120, 120, 255);
            dl->AddRect(toS(p0.x, p0.y), mp, col, 0.f, 0, 3.f);
        } else if (tool == 2 || tool == 6) {
            ImU32 col = tool == 2 ? IM_COL32(255, 220, 80, 255) : IM_COL32(255, 120, 120, 255);
            ImVec2 c = toS(p0.x, p0.y);
            dl->AddCircle(c, std::sqrt((mp.x - c.x) * (mp.x - c.x) + (mp.y - c.y) * (mp.y - c.y)), col, 64, 3.f);
        }
        lastW = w; hasLastW = true;
    }
    if (ImGui::IsItemDeactivated()) hasLastW = false;
    if (ImGui::IsItemDeactivated() && !pinchedNow) {
        float moved = std::fabs(mp.x - pdown.x) + std::fabs(mp.y - pdown.y);
        float ax = std::min(p0.x, w.x), bx = std::max(p0.x, w.x), az = std::min(p0.y, w.y), bz = std::max(p0.y, w.y);
        if (tool == 1 && moved > 12.f) { undoBlk = S.blk; undoHas = true; maskFillPoly(S, {ax, az, bx, az, bx, bz, ax, bz}); ch = true; }
        else if (tool == 5 && moved > 12.f) { undoBlk = S.blk; undoHas = true; maskFillPoly(S, {ax, az, bx, az, bx, bz, ax, bz}, 0); ch = true; }
        else if ((tool == 2 || tool == 6) && moved > 12.f) {
            float r = std::sqrt((w.x - p0.x) * (w.x - p0.x) + (w.y - p0.y) * (w.y - p0.y));
            undoBlk = S.blk; undoHas = true; S.blkDisc(p0.x, p0.y, r, tool == 2 ? 1 : 0); ch = true;
        } else if (tool == 3 && moved < 10.f) {
            if (poly.size() >= 6) {   // tocar cerca del primer punto cierra el polígono
                ImVec2 f = toS(poly[0], poly[1]);
                if ((f.x - mp.x) * (f.x - mp.x) + (f.y - mp.y) * (f.y - mp.y) < 18.f * 18.f) { undoBlk = S.blk; undoHas = true; maskFillPoly(S, poly); poly.clear(); ch = true; }
                else { poly.push_back(w.x); poly.push_back(w.y); }
            } else { poly.push_back(w.x); poly.push_back(w.y); }
        }
    }
    if (ImGui::IsItemDeactivated()) stroke.clear();
    if (tool == 3 && !poly.empty()) {   // polígono en construcción
        for (size_t m = 0; m + 3 < poly.size(); m += 2) dl->AddLine(toS(poly[m], poly[m + 1]), toS(poly[m + 2], poly[m + 3]), IM_COL32(255, 220, 80, 255), 3.f);
        for (size_t m = 0; m + 1 < poly.size(); m += 2) dl->AddCircleFilled(toS(poly[m], poly[m + 1]), m == 0 ? 9.f : 6.f, IM_COL32(255, 220, 80, 255));
    }
    dl->PopClipRect();
    ImGui::End();
    return ch;
}

// v11.5j: 2D — controles virtuales, imágenes por acción y Meta (en Propiedades del objeto).
bool Editor::vctlPanel(Obj& o, Scene& S) {
    bool ch = false;
    static const char* vn[3] = {"No", "Libre (sin física)", "Plataforma (con física)"};
    int v = std::max(0, std::min(2, o.vctl));
    if (ImGui::BeginCombo("Movimiento por controles virtuales", vn[v])) {
        for (int k = 0; k < 3; k++) if (ImGui::Selectable(vn[k], k == v)) { o.vctl = k; ch = true; if (k && o.vctlSpd < 10.f) o.vctlSpd = 300.f; if (k == 2 && o.phys == Phys::None) o.phys = Phys::Dynamic; }
        ImGui::EndCombo();
    }
    if (o.vctl) {
        ch |= wrapui::SliderFloat("Velocidad del control", &o.vctlSpd, 30.f, 1500.f);
        if (o.vctl == 2) {
            static const char* jn[4] = {"Un solo salto", "Doble salto", "Triple salto", "Propulsor (jetpack: mantén el botón)"};
            int jm = std::max(0, std::min(3, o.jumpMode));
            if (ImGui::BeginCombo("Tipo de salto", jn[jm])) { for (int k = 0; k < 4; k++) if (ImGui::Selectable(jn[k], k == jm)) { o.jumpMode = k; ch = true; } ImGui::EndCombo(); }
            ch |= wrapui::SliderFloat("Fuerza del salto", &o.vctlJump, 150.f, 1200.f);
            ImGui::TextDisabled("Los saltos extra solo se recuperan al tocar el suelo u otro objeto sólido.");
        }
        ImGui::TextDisabled(o.vctl == 1 ? "Se mueve con la palanca / flechas / WASD, sin caer." : "Palanca o flechas: de lado. Botón Saltar (A) o arriba: saltar. Botón B / Atacar: ataque.");
        if (ImGui::TreeNode("Imágenes por acción (opcional)")) {
            static const char* an[7] = {"Quieto", "Camina a la izquierda", "Camina a la derecha", "Salta (izquierda)", "Salta (derecha)", "Ataca a la izquierda", "Ataca a la derecha"};
            for (int k = 0; k < 7; k++) { ImGui::PushID(900 + k); ch |= assetCombo(an[k], o.act[k], 0, "(la imagen normal)"); ImGui::PopID(); }
            ImGui::TextDisabled("En un mapa 2D, «izquierda/derecha» es hacia dónde se mueve el nivel.");
            ImGui::TreePop();
        }
    }
    ch |= wrapui::Checkbox("Es una Meta (al tocarla el héroe cambia de escena)", &o.goal);
    if (o.goal) {
        if (ImGui::BeginCombo("Ir a la escena", o.goalScene.empty() ? "(elige una)" : o.goalScene.c_str())) {
            for (auto& sc2 : edit_.proj.scenes) if (&sc2 != &S && ImGui::Selectable(sc2.name.c_str(), sc2.name == o.goalScene)) { o.goalScene = sc2.name; ch = true; }
            ImGui::EndCombo();
        }
    }
    return ch;
}

// v11.5: 2D — ruta dibujada con lápiz sobre un dibujo de la pantalla y estela de colores.
bool Editor::route2DPanel(Obj& o, Scene& S) {
    bool ch = false;
    if (wrapui::Checkbox("Seguir una ruta dibujada", &o.routeOn)) { ch = true; if (o.routeOn && o.routeSpd < 30.f) o.routeSpd = 250.f; }
    if (o.routeOn || !o.route.empty()) {
        char b[96]; snprintf(b, sizeof b, "Dibujar la ruta con lápiz (%d puntos)", (int)o.route.size() / 2);
        if (wrapui::Button(b)) { route2DOpen_ = true; strokes_.clear(); mvInit_ = false; }
        ch |= wrapui::SliderFloat("Velocidad (pasos por segundo)", &o.routeSpd, 20.f, 1500.f);
        if (wrapui::Checkbox("En bucle (vuelve al inicio)", &o.routeLoop)) { ch = true; if (o.routeLoop) o.routeLaps = 0; }
        if (o.routeLoop) { ch |= wrapui::SliderInt("Vueltas (0 = sin fin)", &o.routeLaps, 0, 50); }
        ImGui::TextDisabled("Empieza sola al iniciar. Con bloques: 'Seguir su ruta' (1/0) y vueltas.");
        ch |= wrapui::Checkbox("Gira hacia donde va", &o.routeFace);
    }
    ch |= wrapui::Checkbox("Dejar estela de copias de colores que se desvanecen", &o.trail);
    if (o.trail) {
        static const char* tn[3] = {"Arcoíris", "Un solo color", "Copias sin color"};
        int t = std::max(0, std::min(2, o.trailStyle));
        if (ImGui::BeginCombo("Estilo de la estela", tn[t])) {
            for (int k = 0; k < 3; k++) if (ImGui::Selectable(tn[k], k == t)) { o.trailStyle = k; ch = true; }
            ImGui::EndCombo();
        }
        if (o.trailStyle == 1) ch |= wrapui::ColorEdit3("Color de la estela", o.trailCol);
        ch |= wrapui::SliderFloat("Cuánto dura la estela (s)", &o.trailLife, 0.1f, 2.f);
        ImGui::TextDisabled("La estela también funciona si el objeto se mueve con bloques, pero con ruta se ve más fluida.");
    }
    if (route2DOpen_) ch |= route2DWindow(o, S);
    return ch;
}

bool Editor::route2DWindow(Obj& o, Scene& S, std::vector<float>* tgt, bool rel, bool* openFlag) {
    bool ch = false;
    std::vector<float>& R = tgt ? *tgt : o.route;
    const float ox = rel ? o.pos.x : 0.f, oy = rel ? o.pos.y : 0.f;
    bool* op = openFlag ? openFlag : &route2DOpen_;
    ImVec2 ds = ImGui::GetIO().DisplaySize;
    ImGui::SetNextWindowPos(ImVec2(0.f, 0.f), ImGuiCond_Appearing);
    ImGui::SetNextWindowSize(ds, ImGuiCond_Appearing);
    if (!ImGui::Begin(tgt ? "Ruta de la bala (empieza en el enemigo)" : "Ruta con lápiz (dibuja sobre la pantalla)", op, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse)) { ImGui::End(); return false; }
    ImGui::TextWrapped("Dibuja con el dedo o el mouse el camino. Varios trazos seguidos. Dos dedos o rueda: zoom.");
    if (wrapui::Button("Deshacer trazo") && !strokes_.empty()) { size_t st = (size_t)strokes_.back(); strokes_.pop_back(); if (st < R.size()) R.resize(st); ch = true; }
    ImGui::SameLine();
    if (wrapui::Button("Borrar ruta")) { R.clear(); strokes_.clear(); ch = true; }
    ImGui::SameLine();
    if (wrapui::Button("Ver todo")) mvInit_ = false;
    ImGui::SameLine();
    if (wrapui::Button("Listo")) *op = false;
    float W = edit_.stageW(), H = kView2DHeight;
    ImVec2 org = ImGui::GetCursorScreenPos(), av = ImGui::GetContentRegionAvail();
    av.y = std::max(100.f, av.y - 2.f);
    const float ext = 2.4f;   // el lienzo abarca más que la pantalla para poder salir de ella
    float k = std::min(av.x / (W * ext), av.y / (H * ext)), vcx, vcy;
    mapView(k, 0.f, 0.f, org, av, true, k, vcx, vcy);
    ImVec2 sz = av;
    auto toS = [&](float x, float y) { return ImVec2(org.x + av.x * 0.5f + (x - vcx) * k, org.y + av.y * 0.5f + (vcy - y) * k); };
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->PushClipRect(org, ImVec2(org.x + sz.x, org.y + sz.y), true);
    dl->AddRectFilled(org, ImVec2(org.x + sz.x, org.y + sz.y), IM_COL32(30, 34, 44, 255));
    dl->AddRectFilled(toS(-W * 0.5f, H * 0.5f), toS(W * 0.5f, -H * 0.5f), IM_COL32(48, 54, 70, 255));
    dl->AddRect(toS(-W * 0.5f, H * 0.5f), toS(W * 0.5f, -H * 0.5f), IM_COL32(255, 255, 255, 160), 0.f, 0, 2.f);
    dl->AddText(toS(-W * 0.5f, H * 0.5f), IM_COL32(255, 255, 255, 160), " Pantalla del juego");
    std::vector<int> order;
    for (int i = 0; i < (int)S.objs.size(); i++) order.push_back(i);
    std::stable_sort(order.begin(), order.end(), [&](int a, int b) { int la = S.objs[a].bg ? -1000000 : S.objs[a].layer, lb = S.objs[b].bg ? -1000000 : S.objs[b].layer; return la < lb; });
    for (int i : order) {
        const Obj& q = S.objs[i];
        if (!q.visible || q.kind == Kind::Light) continue;
        ImVec2 a, b;
        if (q.bg) { a = toS(-W * 0.5f, H * 0.5f); b = toS(W * 0.5f, -H * 0.5f); }
        else { a = toS(q.pos.x - q.scale.x * 0.5f, q.pos.y + q.scale.y * 0.5f); b = toS(q.pos.x + q.scale.x * 0.5f, q.pos.y - q.scale.y * 0.5f); }
        unsigned id = 0; int tw = 1, th = 1;
        if (rend_ && !q.tex.empty()) id = rend_->textureId(edit_, q.tex, &tw, &th);
        if (id) dl->AddImage((ImTextureID)(intptr_t)id, a, b, ImVec2(q.flipX ? 1.f : 0.f, q.flipY ? 0.f : 1.f), ImVec2(q.flipX ? 0.f : 1.f, q.flipY ? 1.f : 0.f), (&q == &o) ? IM_COL32(255, 255, 255, 255) : IM_COL32(255, 255, 255, 220));
        else if (!q.noColor) dl->AddRectFilled(a, b, IM_COL32((int)(q.color[0] * 255), (int)(q.color[1] * 255), (int)(q.color[2] * 255), q.bg ? 255 : 200));
        if (&q == &o) dl->AddRect(a, b, IM_COL32(255, 220, 60, 255), 0.f, 0, 3.f);
    }
    ImGui::InvisibleButton("##r2cv", sz);
    ImVec2 mp = ImGui::GetIO().MousePos;
    if (ImGui::IsItemActivated()) strokes_.push_back((int)R.size());
    if (ImGui::IsItemActive() && !mvPinch_ && play_.ctl.downCount() < 2) {
        float wx = vcx + (mp.x - org.x - av.x * 0.5f) / k, wy = vcy - (mp.y - org.y - av.y * 0.5f) / k;
        size_t n = R.size();
        if (n < 2 || std::fabs(wx - ox - R[n - 2]) * k + std::fabs(wy - oy - R[n - 1]) * k > 10.f) { R.push_back(wx - ox); R.push_back(wy - oy); ch = true; }
    }
    size_t n = R.size() / 2;
    for (size_t m = 0; m + 1 < n; m++) dl->AddLine(toS(R[m * 2] + ox, R[m * 2 + 1] + oy), toS(R[m * 2 + 2] + ox, R[m * 2 + 3] + oy), IM_COL32(255, 80, 80, 255), 4.f);
    if (n) { dl->AddCircleFilled(toS(R[0] + ox, R[1] + oy), 9.f, IM_COL32(60, 255, 120, 255)); dl->AddCircleFilled(toS(R[n * 2 - 2] + ox, R[n * 2 - 1] + oy), 7.f, IM_COL32(255, 255, 255, 255)); }
    dl->PopClipRect();
    ImGui::End();
    return ch;
}

// v11.5: zoom y desplazamiento de los mapas de dibujo (dos dedos, rueda del mouse, arrastrar con botón derecho/medio).
void Editor::mapView(float k0, float bcx, float bcz, ImVec2 org, ImVec2 av, bool flipY, float& k, float& cx, float& cz) {
    if (!mvInit_) { mvInit_ = true; mvZoom_ = 1.f; mvCx_ = bcx; mvCz_ = bcz; }
    float sc = k0 * mvZoom_;
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ctr(org.x + av.x * 0.5f, org.y + av.y * 0.5f);
    auto zoomAt = [&](ImVec2 p, float f) {   // el punto bajo los dedos se queda en su lugar
        float wx = mvCx_ + (p.x - ctr.x) / sc, wz = mvCz_ + (flipY ? -1.f : 1.f) * (p.y - ctr.y) / sc;
        mvZoom_ = std::max(0.3f, std::min(40.f, mvZoom_ * f));
        sc = k0 * mvZoom_;
        mvCx_ = wx - (p.x - ctr.x) / sc; mvCz_ = wz - (flipY ? -1.f : 1.f) * (p.y - ctr.y) / sc;
    };
    bool hov = ImGui::IsMouseHoveringRect(org, ImVec2(org.x + av.x, org.y + av.y));
    if (hov && io.MouseWheel != 0.f) zoomAt(io.MousePos, io.MouseWheel > 0 ? 1.2f : 1.f / 1.2f);
    if (hov && (ImGui::IsMouseDragging(ImGuiMouseButton_Right, 0.f) || ImGui::IsMouseDragging(ImGuiMouseButton_Middle, 0.f))) {
        mvCx_ -= io.MouseDelta.x / sc; mvCz_ -= (flipY ? -1.f : 1.f) * io.MouseDelta.y / sc;
    }
    auto& Pt = play_.ctl.p;
    int ids[2], n = 0;
    for (int i = 0; i < 10 && n < 2; i++) if (Pt[i].down) ids[n++] = i;
    if (n == 2 && play_.ctl.downCount() == 2) {
        ImVec2 m((Pt[ids[0]].lx + Pt[ids[1]].lx) * 0.5f, (Pt[ids[0]].ly + Pt[ids[1]].ly) * 0.5f);
        float dd = std::sqrt((Pt[ids[0]].lx - Pt[ids[1]].lx) * (Pt[ids[0]].lx - Pt[ids[1]].lx) + (Pt[ids[0]].ly - Pt[ids[1]].ly) * (Pt[ids[0]].ly - Pt[ids[1]].ly));
        bool inside = m.x >= org.x && m.x <= org.x + av.x && m.y >= org.y && m.y <= org.y + av.y;
        if (mvPinch_ || inside) {
            if (mvPinch_ && mvPD_ > 1.f && dd > 1.f) {
                mvCx_ -= (m.x - mvPX_) / sc; mvCz_ -= (flipY ? -1.f : 1.f) * (m.y - mvPY_) / sc;
                zoomAt(m, dd / mvPD_);
            }
            mvPinch_ = true; mvPD_ = dd; mvPX_ = m.x; mvPY_ = m.y;
        }
    } else if (play_.ctl.downCount() == 0) mvPinch_ = false;
    k = k0 * mvZoom_; cx = mvCx_; cz = mvCz_;
}

bool Editor::resetBtn(const char* key, const char* label) {
    bool armed = armedReset_ == key;
    ImGui::PushStyleColor(ImGuiCol_Button, armed ? ImVec4(0.78f, 0.25f, 0.2f, 1.f) : ImVec4(0.32f, 0.2f, 0.22f, 1.f));
    std::string lab = armed ? std::string("¿Seguro? Toca otra vez para restablecer") : std::string(label);
    lab += std::string("##rs") + key;
    bool hit = wrapui::Button(lab.c_str()) && tapped();
    ImGui::PopStyleColor();
    if (hit) { if (armed) { armedReset_.clear(); return true; } armedReset_ = key; }
    return false;
}

// Barra deslizante + boton "123" para escribir el valor con el teclado.
bool Editor::numField(const char* label, float& v, float mn, float mx, const char* fmt) {
    wrapui::head(label);
    ImGui::SetNextItemWidth(host_.prompt ? -ImGui::GetFontSize() * 3.4f : -1.f);
    bool ch = ImGui::SliderFloat(wrapui::hid(label).c_str(), &v, mn, mx, fmt);
    if (host_.prompt) {
        ImGui::PushID(label);
        wrapui::Next("123");
        if (wrapui::Button("123") && tapped() && !promptActive_) {
            char buf[32];
            snprintf(buf, sizeof buf, "%g", v);
            promptNum_ = &v; promptLo_ = mn; promptHi_ = mx;
            numBuf_ = buf;
            promptDst_ = &numBuf_;
            promptActive_ = true;
            host_.prompt(label, numBuf_);
        }
        ImGui::PopID();
    }
    return ch;
}

// Una sola ventana flotante a la vez: al abrir una, las demas se cierran.
void Editor::enforceOneWindow() {
    bool* f[5] = {&showObjs, &showProps, &showWorld, &showHud, &showAssets};
    int newest = -1, first = -1;
    for (int i = 0; i < 5; i++) {
        if (*f[i] && !prevW_[i]) newest = i;
        if (*f[i] && first < 0) first = i;
    }
    int keep = newest >= 0 ? newest : first;
    for (int i = 0; i < 5; i++) if (i != keep) *f[i] = false;
    for (int i = 0; i < 5; i++) prevW_[i] = *f[i];
}

void applyTheme() {
    ImGuiStyle& st = ImGui::GetStyle();
    ImGui::StyleColorsDark(&st);
    st.WindowRounding = 14.f;  st.ChildRounding = 10.f;  st.FrameRounding = 9.f;  st.PopupRounding = 12.f;
    st.GrabRounding = 9.f;     st.ScrollbarRounding = 9.f; st.TabRounding = 9.f;
    st.WindowBorderSize = 0.f; st.FrameBorderSize = 1.f; st.PopupBorderSize = 1.f; st.ChildBorderSize = 0.f;
    st.WindowPadding = ImVec2(14, 12);
    st.FramePadding = ImVec2(12, 10);
    st.ItemSpacing = ImVec2(10, 9);
    st.ItemInnerSpacing = ImVec2(8, 6);
    st.ScrollbarSize = 10.f;
#ifdef _WIN32
    st.ScrollbarSize = 17.f;
#endif
    st.GrabMinSize = 16.f;
    st.WindowTitleAlign = ImVec2(0.5f, 0.5f);
    st.SeparatorTextBorderSize = 2.f;
    st.SeparatorTextPadding = ImVec2(20, 6);
    auto C = [&](ImGuiCol i, float r, float g, float b, float a = 1.f) { st.Colors[i] = ImVec4(r, g, b, a); };
    // grafito azulado con un acento turquesa
    C(ImGuiCol_Text, 0.93f, 0.95f, 0.98f);
    C(ImGuiCol_TextDisabled, 0.52f, 0.58f, 0.67f);
    C(ImGuiCol_WindowBg, 0.075f, 0.085f, 0.115f, 0.97f);
    C(ImGuiCol_ChildBg, 0.10f, 0.115f, 0.15f, 0.9f);
    C(ImGuiCol_PopupBg, 0.095f, 0.11f, 0.145f, 0.98f);
    C(ImGuiCol_Border, 0.24f, 0.40f, 0.72f, 0.55f);
    C(ImGuiCol_FrameBg, 0.13f, 0.15f, 0.20f);
    C(ImGuiCol_FrameBgHovered, 0.17f, 0.20f, 0.27f);
    C(ImGuiCol_FrameBgActive, 0.20f, 0.24f, 0.32f);
    C(ImGuiCol_TitleBg, 0.075f, 0.085f, 0.115f);
    C(ImGuiCol_TitleBgActive, 0.10f, 0.12f, 0.16f);
    C(ImGuiCol_TitleBgCollapsed, 0.075f, 0.085f, 0.115f, 0.8f);
    C(ImGuiCol_MenuBarBg, 0.09f, 0.10f, 0.14f);
    C(ImGuiCol_ScrollbarBg, 0.f, 0.f, 0.f, 0.f);
    C(ImGuiCol_ScrollbarGrab, 0.28f, 0.33f, 0.42f);
    C(ImGuiCol_ScrollbarGrabHovered, 0.36f, 0.42f, 0.52f);
    C(ImGuiCol_ScrollbarGrabActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_CheckMark, 0.18f, 0.85f, 0.74f);
    C(ImGuiCol_SliderGrab, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SliderGrabActive, 0.30f, 0.92f, 0.82f);
    C(ImGuiCol_Button, 0.18f, 0.24f, 0.36f);
    C(ImGuiCol_ButtonHovered, 0.24f, 0.34f, 0.50f);
    C(ImGuiCol_ButtonActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Header, 0.15f, 0.40f, 0.40f, 0.65f);
    C(ImGuiCol_HeaderHovered, 0.17f, 0.50f, 0.48f, 0.80f);
    C(ImGuiCol_HeaderActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_Separator, 0.22f, 0.26f, 0.33f);
    C(ImGuiCol_SeparatorHovered, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_SeparatorActive, 0.18f, 0.78f, 0.68f);
    C(ImGuiCol_ResizeGrip, 0.18f, 0.78f, 0.68f, 0.25f);
    C(ImGuiCol_ResizeGripHovered, 0.18f, 0.78f, 0.68f, 0.6f);
    C(ImGuiCol_ResizeGripActive, 0.18f, 0.78f, 0.68f, 0.9f);
    C(ImGuiCol_Tab, 0.13f, 0.16f, 0.22f);
    C(ImGuiCol_TabHovered, 0.17f, 0.50f, 0.48f);
    C(ImGuiCol_TabActive, 0.16f, 0.62f, 0.55f);
    C(ImGuiCol_TextSelectedBg, 0.18f, 0.78f, 0.68f, 0.35f);
    C(ImGuiCol_ModalWindowDimBg, 0.f, 0.f, 0.f, 0.55f);
}

// ---------------------------------------------------------------- general
void Editor::init(Audio* audio) {
    audio_ = audio;
    listProjects();
}

void Editor::listProjects() { projList_ = fs::list(host_.dataDir + "/projects", true); }

Obj* Editor::selObj() {
    if (!hasScene() || sel_ < 0 || sel_ >= (int)scene().objs.size()) return nullptr;
    return &scene().objs[sel_];
}

std::string Editor::uniqueName(const std::string& base) {
    Scene& S = scene();
    auto used = [&](const std::string& n) { for (auto& o : S.objs) if (o.name == n) return true; return false; };
    if (!used(base)) return base;
    for (int i = 2;; i++) {
        std::string n = base + "_" + std::to_string(i);
        if (!used(n)) return n;
    }
}

void Editor::resetView() {
    if (!hasScene()) return;
    Scene& S = scene();
    if (S.is3d) { target_ = V3{S.start.x, 0.f, S.start.z}; dist_ = 14.f; yaw_ = 0.6f; pitch_ = 0.55f; }
    else { cx_ = cy_ = 0; h2d_ = kView2DHeight; }
}

void Editor::setScene(int i) {
    if (i < 0 || i >= (int)edit_.proj.scenes.size()) return;
    sceneIdx_ = i;
    sel_ = -1;
    edit_.bindScene(i);
    resetView();
}

std::vector<std::string> Editor::assetsOf(int kind) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        bool img = ends(a.first, ".png") || ends(a.first, ".jpg") || ends(a.first, ".jpeg");
        bool snd = Audio::isAudioFile(a.first);
        bool mdl = ends(a.first, ".fmdl");
        if ((kind == 0 && img) || (kind == 1 && snd) || (kind == 2 && mdl)) v.push_back(a.first);
    }
    return v;
}

std::vector<std::string> Editor::soundList() const {
    std::vector<std::string> v = assetsOf(1);
    for (auto& d : defaultSoundNames()) {
        std::string n = d + ".wav";
        if (std::find(v.begin(), v.end(), n) == v.end()) v.push_back(n);
    }
    return v;
}

// Sonidos del juego: cada uno usa el de por defecto o el que tu elijas.
bool Editor::soundPanel() {
    bool ch = false;
    static const char* nm[8] = {"Pasos", "Salto", "Aterrizaje", "Disparo", "Recarga", "Golpe cuerpo a cuerpo", "Recibir daño", "Explosión"};
    ImGui::SeparatorText("Sonidos del juego");
    ImGui::TextWrapped("Ya traen sonidos por defecto (estilo militar). Elige otro audio para cambiarlo.");
    auto list = soundList();
    for (int k = 0; k < 8; k++) {
        std::string& cur = edit_.proj.snd[k];
        std::string lab = std::string(nm[k]) + ": " + (cur.empty() ? "(por defecto)" : cur);
        ImGui::PushID(3000 + k);
        if (ImGui::BeginCombo(("##snd" + std::to_string(k)).c_str(), lab.c_str())) {
            if (wrapui::Selectable("(por defecto)", cur.empty())) { cur.clear(); ch = true; }
            for (auto& a : list) if (wrapui::Selectable(a.c_str(), cur == a)) { cur = a; ch = true; }
            ImGui::EndCombo();
        }
        ImGui::PopID();
    }
    return ch;
}

// Linterna del jugador (para juegos de terror).
bool Editor::flashPanel() {
    bool ch = false;
    PlayerCfg& pc = edit_.proj.player;
    ImGui::SeparatorText("Linterna");
    ch |= wrapui::Checkbox("El jugador tiene linterna (botón LUZ / tecla F)", &pc.flashlight);
    if (!pc.flashlight) return ch;
    ch |= wrapui::Checkbox("Empieza encendida", &pc.flashOnStart);
    ch |= wrapui::Checkbox("Parpadea (terror)", &pc.flashFlicker);
    ch |= numField("Alcance (qué tan lejos llega la luz, en metros)", pc.flashRange, 3.f, 400.f);
    ch |= numField("Apertura / dispersión (grados: chico = haz fino, grande = abierto)", pc.flashAngle, 8.f, 70.f);
    ch |= numField("Potencia (brillo de la luz)", pc.flashInt, 0.2f, 12.f);
    ch |= wrapui::ColorEdit3("Color de la luz", pc.flashCol);
    ch |= assetCombo("Dibujo de la luz (opcional)", pc.flashTex, 0, "(sin dibujo: solo el efecto)");
    return ch;
}

// ---------------------------------------------------------------- proyectos
// Al cambiar de proyecto no debe quedar abierta ninguna ventana del anterior.
void Editor::closeAllWindows() {
    showObjs = false; showProps = true; showWorld = false; showHud = false; showAssets = false;
    helpOpen_ = showExport_ = codeOpen_ = newVarOpen_ = plusOpen_ = projMenu_ = false;
    routeOpen_ = wheelsOpen_ = mapOpen_ = orientOpen_ = zoneOpen_ = false;
    bpathOpen_ = false;
    animOpen_ = voxOpen_ = animGridOpen_ = paintOpen_ = musicOpen_ = false;
    wheelNew_.clear(); terrainPaint_ = gndPaint_ = vegPaint_ = false;
    sel_ = -1;
}

bool Editor::newProject(const std::string& nm, bool demo) {
    std::string n = sanitize(nm);
    if (n.empty()) { toast("Escribe un nombre válido (letras, números, _ o -)"); return false; }
    if (fs::exists(host_.dataDir + "/projects/" + n)) { toast("Ya existe un proyecto con ese nombre"); return false; }
    Project p;
    int tmpl = newTemplate_;
    newTemplate_ = -1;
    if (tmpl >= 0) {
        buildTemplate(tmpl, p);
    } else if (demo) {
        loadDemo(p);
    } else {
        Scene s;
        s.name = "Nivel1";
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        Obj lt; lt.kind = Kind::Light; lt.name = "Luz"; lt.pos = {0, 3, 0}; lt.scale = {12, 1, 1}; lt.solid = false;
        lt.color[0] = 1.f; lt.color[1] = 0.8f; lt.color[2] = 0.6f;
        s.objs = {fl, lt};
        s.start = {0, 0.05f, 6};
        p.scenes.push_back(s);
    }
    p.name = n;
    closeAllWindows();
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = n;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    for (auto& a : edit_.proj.assets) assetDirty_.insert(a.first);
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    dirty_ = true;
    saveProject();
    listProjects();
    return true;
}

bool Editor::openProject(const std::string& nm) {
    std::string dir = host_.dataDir + "/projects/" + nm;
    Files files;
    std::vector<uint8_t> b;
    if (!fs::read(dir + "/project.forge", b)) { toast("No se pudo abrir el proyecto"); return false; }
    files["project.forge"] = b;
    for (auto& f : fs::list(dir + "/assets", false)) {
        std::vector<uint8_t> d;
        if (fs::read(dir + "/assets/" + f, d)) files[f] = std::move(d);
    }
    Project p;
    std::string err;
    if (!loadProject(files, p, err)) { toast("Proyecto dañado: " + err); return false; }
    closeAllWindows();
    edit_ = Game();
    edit_.proj = std::move(p);
    name_ = nm;
    sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(0);
    resetView();
    assetDirty_.clear();
    dirty_ = false;
    if (audio_) audio_->setAssets(edit_.proj.assets);
    screen_ = Screen::Edit;
    page_ = Page::Scenes;
    return true;
}

bool Editor::saveProject(bool quiet) {
    if (name_.empty()) return false;
    std::string dir = host_.dataDir + "/projects/" + name_;
    if (!fs::mkdirs(dir + "/assets")) { toast("No se pudo crear la carpeta del proyecto"); return false; }
    std::string t = writeProject(edit_.proj);
    if (!fs::write(dir + "/project.forge", (const uint8_t*)t.data(), t.size())) { toast("No se pudo guardar"); return false; }
    for (auto& a : edit_.proj.assets) {
        std::string path = dir + "/assets/" + a.first;
        if (assetDirty_.count(a.first) || !fs::exists(path)) fs::write(path, a.second.data(), a.second.size());
    }
    for (auto& f : fs::list(dir + "/assets", false))  // quitar los borrados
        if (!edit_.proj.assets.count(f)) fs::remove(dir + "/assets/" + f);
    assetDirty_.clear();
    dirty_ = false;
    if (!quiet) toast("Guardado");
    return true;
}

// Instantánea cuando el proyecto cambió y ya nada se está arrastrando; el estado de antes se guarda para deshacer.
void Editor::undoTick(float dt) {
    if (!hasScene() || screen_ != Screen::Edit) { undoReady_ = false; return; }
    if (!undoReady_) { undoCur_ = writeProject(edit_.proj); undo_.clear(); redo_.clear(); undoReady_ = true; undoSettle_ = 0.f; autoSaveT_ = 0.f; return; }
    bool busy = play_.ctl.downCount() > 0 || ImGui::IsAnyItemActive() || ImGui::GetIO().MouseDown[0];
    if (dirty_ && !busy) {
        undoSettle_ += dt;
        if (undoSettle_ > 0.35f) {
            undoSettle_ = 0.f;
            std::string now = writeProject(edit_.proj);
            if (now != undoCur_) {
                undo_.push_back(undoCur_);
                size_t tot = 0; for (auto& s : undo_) tot += s.size();
                while (undo_.size() > 60 || (tot > 48u * 1024 * 1024 && undo_.size() > 2)) { tot -= undo_.front().size(); undo_.erase(undo_.begin()); }
                undoCur_ = now; redo_.clear();
            }
        }
    } else if (!dirty_) undoSettle_ = 0.f;
    if (dirty_ && !busy) {   // autoguardado cada 45 s
        autoSaveT_ += dt;
        if (autoSaveT_ > 45.f) { autoSaveT_ = 0.f; if (!name_.empty()) saveProject(true); }
    } else if (!dirty_) autoSaveT_ = 0.f;
    ImGuiIO& io = ImGui::GetIO();
    if (!io.WantTextInput && io.KeyCtrl) {
        if (ImGui::IsKeyPressed(ImGuiKey_Z, false)) doUndo(io.KeyShift);
        else if (ImGui::IsKeyPressed(ImGuiKey_Y, false)) doUndo(true);
    }
}

void Editor::doUndo(bool redo) {
    auto& from = redo ? redo_ : undo_;
    auto& to = redo ? undo_ : redo_;
    if (from.empty()) { toast(redo ? "Nada que rehacer" : "Nada que deshacer"); return; }
    std::string target = from.back();
    Files fl;
    fl["project.forge"] = std::vector<uint8_t>(target.begin(), target.end());
    Project np; std::string err;
    if (!loadProject(fl, np, err)) { toast("No se pudo deshacer"); return; }
    from.pop_back();
    to.push_back(undoCur_);
    np.assets = std::move(edit_.proj.assets);
    edit_.proj = std::move(np);
    undoCur_ = target;
    if (sceneIdx_ >= (int)edit_.proj.scenes.size()) sceneIdx_ = (int)edit_.proj.scenes.size() - 1;
    if (sceneIdx_ < 0) sceneIdx_ = 0;
    sel_ = -1;
    edit_.bindScene(sceneIdx_);   // el puntero de escena cambió al recargar
    dirty_ = true; undoSettle_ = 0.f;
    toast(redo ? "Rehecho" : "Deshecho");
}

bool Editor::handleBack() {
    if (helpOpen_ && screen_ != Screen::Play) {   // igual que el botón "< Atrás" de la ayuda
        if (helpGuide_ >= 0) helpGuide_ = -1;
        else if (!helpPath_.empty()) helpPath_.pop_back();
        else helpOpen_ = false;
        helpStep_ = 0;
        return true;
    }
    if (screen_ == Screen::Play) { stopPlay(); return true; }
    if (screen_ != Screen::Edit) return false;
    if (showExport_ || codeOpen_ || newVarOpen_ || plusOpen_ || projMenu_ || wheelsOpen_ || orientOpen_ || mapOpen_ || routeOpen_ || route2DOpen_) { closeAllWindows(); return true; }
    if (page_ == Page::Viewport || page_ == Page::Object) { page_ = Page::SceneHome; return true; }
    if (page_ == Page::SceneHome) { page_ = Page::Scenes; return true; }
    closeProject();
    return true;
}

void Editor::closeProject() {
    if (dirty_) saveProject();
    if (audio_) audio_->stopMusic();
    screen_ = Screen::Projects;
    page_ = Page::Scenes;
    name_.clear();
    listProjects();
}

bool Editor::buildPack(std::vector<uint8_t>& out) {
    Files f = edit_.proj.assets;
    std::string t = writeProject(edit_.proj);
    libraryPrune(f, t);  // la biblioteca solo viaja con lo que el juego usa
    f["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
    return packWrite(f, out);
}

bool Editor::buildExe(std::vector<uint8_t>& out, std::string& err) {
    std::vector<uint8_t> rt, pk;
    if (!host_.loadRuntime || !host_.loadRuntime(rt)) {
        err = "Esta app no incluye el runtime de Windows: compílala con GitHub Actions";
        return false;
    }
    buildPack(pk);
    if (!forge::exportExe(rt, pk, out)) { err = "El runtime incluido no es un .exe válido"; return false; }
    return true;
}

void Editor::doExportExe() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    std::string err;
    if (!buildExe(out, err)) { toast(err); return; }
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string exeBase = exportSlug(edit_.proj.exportCfg.exeName.empty() ? name_ : edit_.proj.exportCfg.exeName);
    std::string path = dir + "/" + exeBase + ".exe";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el .exe"); return; }
    if (host_.saveOut) host_.saveOut(exeBase + ".exe", path);
    toast("Elige dónde guardar el .exe");
}

void Editor::doExportPack() {
    if (dirty_) saveProject();
    std::vector<uint8_t> out;
    buildPack(out);
    std::string dir = host_.dataDir + "/export";
    fs::mkdirs(dir);
    std::string path = dir + "/" + name_ + ".pack";
    if (!fs::write(path, out.data(), out.size())) { toast("No se pudo escribir el paquete"); return; }
    if (host_.saveOut) host_.saveOut(name_ + ".pack", path);
    toast("Elige dónde guardar el paquete (.pack)");
}

// Importa un proyecto exportado (.pack): lo guarda como un proyecto nuevo con nombre libre.
bool Editor::importPack(const std::string& fileName, const std::vector<uint8_t>& data) {
    Files files;
    if (!packRead(data.data(), data.size(), files) || !files.count("project.forge")) {
        toast("Ese archivo no es un paquete de P-Maker (.pack)");
        return false;
    }
    Project test;
    std::string err;
    if (!loadProject(files, test, err)) { toast("El paquete está dañado: " + err); return false; }
    std::string base = fileName;
    size_t sl = base.find_last_of("/\\");
    if (sl != std::string::npos) base = base.substr(sl + 1);
    size_t dot = base.find_last_of('.');
    if (dot != std::string::npos) base = base.substr(0, dot);
    return saveImported(base, files);
}

bool Editor::saveImported(const std::string& baseIn, Files& files) {
    std::string base = sanitize(baseIn);
    if (base.empty()) base = "importado";
    std::string n = base;
    for (int i = 2; fs::exists(host_.dataDir + "/projects/" + n); i++) n = base + "_" + std::to_string(i);
    std::string dir = host_.dataDir + "/projects/" + n;
    fs::mkdirs(dir + "/assets");
    const auto& pf = files["project.forge"];
    if (!fs::write(dir + "/project.forge", pf.data(), pf.size())) { toast("No se pudo guardar el proyecto"); return false; }
    for (auto& f : files)
        if (f.first != "project.forge") fs::write(dir + "/assets/" + f.first, f.second.data(), f.second.size());
    listProjects();
    toast("Proyecto importado: " + n);
    return true;
}

bool Editor::importCatrobat(const std::string& fileName, const ResMap& res) {
    Project P;
    int nb = 0, ns = 0;
    std::string err;
    if (!catrobatConvert(res, P, nb, ns, err)) { toast("No se pudo leer el juego de Pocket Code: " + err); return false; }
    Files files = P.assets;
    std::string txt = writeProject(P);
    files["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
    std::string base = P.name.empty() ? fileName : P.name;
    size_t sl = base.find_last_of("/\\");
    if (sl != std::string::npos) base = base.substr(sl + 1);
    if (!saveImported(base, files)) return false;
    toast("Pocket Code importado: " + std::to_string(P.scenes.size()) + " escena(s), " + std::to_string(nb) + " bloques" +
          (ns ? " (" + std::to_string(ns) + " sin equivalente, omitidos)" : ""));
    return true;
}

bool Editor::importRar(const std::string& fileName, const std::vector<uint8_t>& data) {
    ResMap res;
    int unsup = 0;
    std::string err;
    if (!rarRead(data, res, unsup, err)) { toast("No se pudo abrir el .rar: " + err); return false; }
    if (res.empty()) {
        toast("Ese .rar usa compresión y aquí solo se leen .rar sin comprimir. Guárdalo como .zip o con compresión «Almacenar».");
        return false;
    }
    if (res.count("code.xml")) return importCatrobat(fileName, res);
    if (unsup) toast(std::to_string(unsup) + " archivo(s) comprimido(s) del .rar no se pudieron leer");
    for (auto& f : res) onFile(f.first, f.second);
    return true;
}

void Editor::onFile(const std::string& rawName, std::vector<uint8_t> data) {
    if (!rawName.empty() && rawName[0] == '\x01') {  // avisos del selector de archivos
        if (rawName.compare(1, 5, "START") == 0) { reading_ = true; readingT_ = 0.f; }
        else { reading_ = false; toast(std::string(data.begin(), data.end())); }
        return;
    }
    reading_ = false;
    if (ends(rawName, ".pack")) { importPack(rawName, data); return; }
    if (ends(rawName, ".rar")) { importRar(rawName, data); return; }
    if (ends(rawName, ".catrobat") || ends(rawName, ".zip")) {
        ResMap res;
        std::string zerr;
        if (unzipAll(data, res, zerr) && res.count("code.xml")) { importCatrobat(rawName, res); return; }
    }
    if (screen_ != Screen::Edit) { toast("Abre un proyecto para importar archivos"); return; }
    std::string name = rawName;
    size_t sl = name.find_last_of("/\\");
    if (sl != std::string::npos) name = name.substr(sl + 1);
    for (auto& c : name) if (c == ' ') c = '_';
    Files& A = edit_.proj.assets;
    {   // otros formatos de imagen se convierten a PNG; la orientación de las fotos se corrige
        std::string lo = name; for (auto& ch : lo) ch = (char)std::tolower((unsigned char)ch);
        static const char* ex[] = {".bmp", ".gif", ".tga", ".psd", ".webp", ".pnm", ".ppm"};
        bool other = false; for (auto e : ex) if (ends(lo, e)) other = true;
        if (other || ends(lo, ".png") || ends(lo, ".jpg") || ends(lo, ".jpeg")) {
            bool chg = false;
            if (!normalizeImage(data, name, chg)) { toast("No pude leer esa imagen (formato no compatible). Prueba con PNG o JPG."); return; }
            if (!ends(lo, ".png") && !ends(lo, ".jpg") && !ends(lo, ".jpeg")) lo = name;
        }
    }
    if (ends(name, ".png") || ends(name, ".jpg") || ends(name, ".jpeg")) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Imagen importada: " + name);
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->tex = name;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                n->name = uniqueName(name.substr(0, name.find_last_of('.')));
            }
        } else if (page_ == Page::Object && tab_ == 1) {
            if (Obj* n = selObj()) n->looks.push_back(name);
        }
    } else if (Audio::isAudioFile(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        if (audio_) audio_->setAssets(A);
        toast("Audio importado: " + name);
        if (page_ == Page::Object && tab_ == 2) {
            if (Obj* n = selObj()) n->sounds.push_back(name);
        }
    } else if (isVideoName(name)) {
        A[name] = std::move(data);
        assetDirty_.insert(name);
        toast("Video importado: " + name + " (ponlo en un objeto: Propiedades → Video)");
        if (pendingNewObj_ && hasScene()) {
            pendingNewObj_ = false;
            addObject(Kind::Cube);
            if (Obj* n = selObj()) {
                n->video = name; n->videoAuto = true; n->noColor = false;
                n->color[0] = n->color[1] = n->color[2] = 1.f;
                if (!scene().is3d) n->scale = V3{320, 180, 1};
                n->name = uniqueName("Video");
            }
        }
    } else if (ends(name, ".blend") || ends(name, ".blend1")) {
        pendingNewModel_ = false;
        toast("Los .blend no se pueden leer directo. En Blender: Archivo > Exportar > glTF 2.0 (.glb) y elige ese archivo.");
        return;
    } else if (ends(name, ".7z")) {
        pendingNewModel_ = false;
        toast("Los .7z no se pueden abrir aquí. Conviértelo a .zip o .rar (o descomprímelo y elige el .glb/.obj).");
        return;
    } else if (animImportPending_ && (ends(name, ".glb") || ends(name, ".gltf") || ends(name, ".fbx"))) {
        animImportPending_ = false;
        int added = 0;
        std::string err;
        if (animRig_.bones.empty()) {  // sin esqueleto todavía: si el archivo trae modelo y esqueleto, se crea
            if (!importAnimations(name, data, animRig_.model, animRig_, added, err)) { toast("No se pudo: " + err); return; }
            animFixSizes();
        } else if (!importAnimations(name, data, animRig_.model, animRig_, added, err)) { toast("No se pudo: " + err); return; }
        animFixSizes();
        toast("Animaciones importadas: " + std::to_string(added));
        return;
    } else if (ends(name, ".blend") || ends(name, ".3ds") || ends(name, ".max") || ends(name, ".c4d") || ends(name, ".ma") || ends(name, ".mb")) {
        pendingNewModel_ = false;
        toast("Ese formato no se puede abrir directo. En tu programa 3D exporta a .glb (o .fbx, .obj, .dae) y sube ese archivo.");
        return;
    } else if (isModelFile(name) || ends(name, ".zip")) {
        if (imp_) { impQ_.emplace_back(name, std::move(data)); toast("En cola: " + name + " (" + std::to_string(impQ_.size()) + " esperando)"); return; }
        startModelImport(name, std::move(data));
        return;
    } else {
        toast("Formato no compatible. Usa png, jpg, mp3, wav, flac, obj, glb, gltf, fbx, dae, stl o ply");
        return;
    }
    markDirty();
}

// ---------------------------------------------------------------- objetos y escenas
void Editor::addObject(Kind k, const std::string& modelName) {
    if (!hasScene()) return;
    Scene& S = scene();
    Obj o;
    o.kind = k;
    float gx = std::round(target_.x), gz = std::round(target_.z);
    V3 at = S.is3d ? V3{gx, 0, gz} : V3{std::round(cx_), std::round(cy_), 0};
    std::string base = "Objeto";
    switch (k) {
        case Kind::Cube:
            base = S.is3d ? "Cubo" : "Objeto";
            o.pos = S.is3d ? V3{at.x, 0.5f, at.z} : V3{at.x, at.y, 0};
            o.scale = S.is3d ? V3{1, 1, 1} : V3{200, 200, 1};
            if (!S.is3d) { o.color[0] = o.color[1] = o.color[2] = 1.f; o.noColor = true; o.solid = false; o.yaw = 90; }
            break;
        case Kind::Floor:
            base = "Suelo"; o.pos = {at.x, -0.1f, at.z}; o.scale = {10, 0.2f, 10}; o.texTile = true;
            o.color[0] = 0.45f; o.color[1] = 0.62f; o.color[2] = 0.40f;
            break;
        case Kind::Wall:
            base = "Pared"; o.pos = {at.x, 1.5f, at.z}; o.scale = {4, 3, 0.5f};
            o.color[0] = o.color[1] = 0.8f; o.color[2] = 0.86f;
            break;
        case Kind::Item:
            base = "Item"; o.pos = {at.x, 1.f, at.z}; o.scale = {0.5f, 0.5f, 0.5f}; o.solid = false; o.spin = true;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.1f;
            break;
        case Kind::Light:
            base = "Luz"; o.pos = {at.x, 3.f, at.z}; o.scale = {12, 1, 1}; o.solid = false;
            o.color[0] = 1.f; o.color[1] = 0.8f; o.color[2] = 0.6f;
            break;
        case Kind::Model:
            base = "Modelo"; o.pos = {at.x, 1.f, at.z}; o.scale = {2, 2, 2}; o.model = modelName;
            if (!S.is3d) { o.pos = {at.x, at.y, 0}; o.scale = {300, 300, 300}; o.solid = false; }   // en 2D el modelo se ve de frente
            break;
        case Kind::Player: return;
    }
    o.name = uniqueName(base);
    S.objs.push_back(o);
    sel_ = (int)S.objs.size() - 1;
    markDirty();
}

void Editor::addScene(bool is3d) {
    Scene s;
    s.is3d = is3d;
    int n = (int)edit_.proj.scenes.size() + 1;
    auto taken = [&](const std::string& nm) { for (auto& x : edit_.proj.scenes) if (x.name == nm) return true; return false; };
    std::string base = is3d ? "Nivel" : "Menu";
    std::string nm = base + std::to_string(n);
    for (int i = n; taken(nm); i++) nm = base + std::to_string(i + 1);
    s.name = nm;
    if (is3d) {
        Obj fl; fl.kind = Kind::Floor; fl.name = "Suelo"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40};
        fl.color[0] = 0.45f; fl.color[1] = 0.62f; fl.color[2] = 0.40f;
        s.objs.push_back(fl);
        s.start = {0, 0.05f, 6};
        for (const char* g : {"vida", "municion", "puntos", "llave"})
            if (std::find(edit_.proj.globalVars.begin(), edit_.proj.globalVars.end(), g) == edit_.proj.globalVars.end())
                edit_.proj.globalVars.push_back(g);
        auto mk = [](Op op, const char* t, const char* a, const char* b2, const char* c) {
            Block b; b.op = op; b.t = t; b.f[0] = a; b.f[1] = b2; b.f[2] = c; return b;
        };
        s.objs[0].blocks = {mk(Op::WhenStart, "", "", "", ""), mk(Op::ShowVar, "vida", "-420", "440", ""),
                            mk(Op::ShowVar, "municion", "420", "440", ""),
                            mk(Op::WhenTrue, "", "\"vida\" <= 0", "", ""), mk(Op::Say, "", "Has muerto", "", ""),
                            mk(Op::SetVar, "vida", "100", "", ""), mk(Op::TeleportPlayer, "", "0", "0.05", "6")};
    } else {
        s.skyTop[0] = 0.10f; s.skyTop[1] = 0.12f; s.skyTop[2] = 0.25f;
        s.skyBot[0] = 0.20f; s.skyBot[1] = 0.25f; s.skyBot[2] = 0.45f;
        Obj bg; bg.name = "Fondo"; bg.bg = true; bg.solid = false; bg.layer = -1000; bg.yaw = 90;
        bg.color[0] = 0.20f; bg.color[1] = 0.25f; bg.color[2] = 0.45f;
        s.objs.push_back(bg);
    }
    ensurePlayer(s);
    edit_.proj.scenes.push_back(s);
    setScene((int)edit_.proj.scenes.size() - 1);
    markDirty();
}

void Editor::startPlay(bool current) {
    if (edit_.proj.scenes.empty()) return;
    if (dirty_) saveProject();
    Project pcopy = edit_.proj;   // el juego no altera lo que estás editando
    if (current && sceneIdx_ > 0 && sceneIdx_ < (int)pcopy.scenes.size()) std::swap(pcopy.scenes[0], pcopy.scenes[sceneIdx_]);   // «Jugar escena actual»
    play_.audio = audio_;
    play_.showButtons = true;
    play_.useRes = true;  // la resolución del proyecto solo se aplica al jugar (no en el editor)
#ifdef _WIN32
    play_.keys = true;    // WASD / mouse (remapeables en Proyecto > Controles)
    play_.showButtons = !hideVirtTest_;
#else
    play_.keys = false;   // Android: palanca y botones virtuales
#endif
    play_.onVibrate = host_.vibrate;
    play_.onSpeak = host_.speak;
    play_.onFlash = host_.flash;
    play_.devPath = host_.dataDir + "/devvars_" + name_ + ".txt";
    play_.telemPath = edit_.proj.perf.telem ? host_.dataDir + "/rendimiento_" + name_ + ".txt" : std::string();
    play_.start(std::move(pcopy));
    screen_ = Screen::Play;
}

void Editor::stopPlay() {
    if (audio_) { audio_->stopMusic(); audio_->setAssets(edit_.proj.assets); }
    play_.flushTelemetry();
    play_.ctl.hud = nullptr;
    play_.ctl.reset();
    play_.game.carIdx = play_.game.nearCar = -1; play_.hud.mode = 0;
    screen_ = Screen::Edit;
}

// ---------------------------------------------------------------- camara y seleccion
EditorView Editor::view() const {
    EditorView ev;
    ev.sel = sel_;
    ev.target = target_;
    ev.cx = cx_; ev.cy = cy_; ev.h2d = h2d_;
    V3 dir{std::sin(yaw_) * std::cos(pitch_), std::sin(pitch_), std::cos(yaw_) * std::cos(pitch_)};
    ev.eye = target_ + dir * dist_;
    ev.fwd = norm(target_ - ev.eye);
    return ev;
}

void Editor::rayAt(float x, float y, const EditorView& ev, V3& o, V3& d) const {
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float ty = std::tan(1.2217f * 0.5f), tx = ty * aspect;
    float nx = (x / (float)w_) * 2.f - 1.f, ny = 1.f - (y / (float)h_) * 2.f;
    V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
    o = ev.eye;
    d = norm(ev.fwd + r * (nx * tx) + u * (ny * ty));
}

int Editor::pick(float x, float y, const EditorView& ev) {
    if (!hasScene()) return -1;
    Scene& S = scene();
    if (S.is3d) {
        V3 o, d;
        rayAt(x, y, ev, o, d);
        float best = 1e9f;
        int hit = -1;
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& ob = S.objs[i];
            if (!ob.visible || !ob.alive || ob.locked) continue;
            V3 half = ob.kind == Kind::Light ? V3{0.25f, 0.25f, 0.25f} : ob.scale * 0.5f;
            float t;
            if (ob.kind == Kind::Floor && ob.tn >= 2) { if (rayTerrain(ob, o, d, 400.f, t) && t < best) { best = t; hit = i; } continue; }
            if (rayBoxYaw(o, d, ob.pos, half, ob.kind == Kind::Light ? 0.f : ob.yaw, t) && t < best) { best = t; hit = i; }
        }
        return hit;
    }
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
    for (int i = (int)S.objs.size() - 1; i >= 0; i--) {
        const Obj& ob = S.objs[i];
        if (!ob.visible || ob.locked || ob.mapPart) continue;   // lo del «Crear mapa 2D» solo se edita desde ese editor
        float ra = -(ob.yaw - 90.f) * 0.0174532925f, cs = std::cos(ra), sn = std::sin(ra);
        float ddx = wx - ob.pos.x, ddy = wy - ob.pos.y;
        if (std::fabs(cs * ddx + sn * ddy) <= ob.scale.x * 0.5f && std::fabs(-sn * ddx + cs * ddy) <= ob.scale.y * 0.5f) return i;
    }
    return -1;
}

bool Editor::toScreen(const EditorView& ev, V3 p, float& sx, float& sy) const {
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
    float ty = std::tan(1.2217f * 0.5f), tx = ty * aspect;
    V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd), rel = p - ev.eye;
    float z = dot(rel, ev.fwd);
    if (z < 0.1f) return false;
    float nx = dot(rel, r) / (z * tx), ny = dot(rel, u) / (z * ty);
    sx = (nx + 1.f) * 0.5f * (float)w_;
    sy = (1.f - ny) * 0.5f * (float)h_;
    return true;
}

// Largo de las asas: crece con el tamaño del modelo y con la distancia de la cámara (cómodo en teléfono).
float Editor::gizmoLen(const Obj& o) const {
    float m = std::max(o.scale.x, std::max(o.scale.y, o.scale.z)) * 0.7f;
    float L = std::max(dist_ * 0.2f, std::min(m, dist_ * 0.5f));
    return L;
}
// 2D: puntos (en pantalla) de las asas de tamaño del objeto elegido: 4 lados y 4 esquinas.
bool Editor::handles2D(Obj* o, ImVec2* pts, int* masks, int& n) const {
    n = 0;
    if (!o || o->bg || o->locked || o->kind == Kind::Light || h2d_ <= 0.f || h_ <= 0 || w_ <= 0) return false;
    float aspect = (float)w_ / (float)h_;
    auto S2 = [&](float wx, float wy) { return ImVec2(((wx - cx_) / (h2d_ * aspect) + 0.5f) * (float)w_, (0.5f - (wy - cy_) / h2d_) * (float)h_); };
    float l = o->pos.x - o->scale.x * 0.5f, r = o->pos.x + o->scale.x * 0.5f, t = o->pos.y + o->scale.y * 0.5f, b = o->pos.y - o->scale.y * 0.5f;
    const float mx = o->pos.x, my = o->pos.y;
    const float X[8] = {r, l, mx, mx, r, l, r, l}, Y[8] = {my, my, t, b, b, t, t, b};
    const int M[8] = {2, 1, 4, 8, 2 | 8, 1 | 4, 2 | 4, 1 | 8};
    for (int k = 0; k < 8; k++) { pts[k] = S2(X[k], Y[k]); masks[k] = M[k]; }
    n = 8;
    return true;
}

void Editor::drawGizmo() {
    if (hasScene() && !scene().is3d && page_ == Page::Viewport && !terrainPaint_ && !gndPaint_ && !vegPaint_) {   // 2D: asas para agrandar con el dedo
        ImVec2 pts[8]; int ms[8], n = 0;
        if (handles2D(selObj(), pts, ms, n)) {
            ImDrawList* dl = ImGui::GetBackgroundDrawList();
            float rad = std::max(13.f, h_ * 0.022f);
            for (int k = 0; k < n; k++) {
                bool corner = ms[k] == 10 || ms[k] == 5 || ms[k] == 6 || ms[k] == 9;
                ImU32 col = corner ? IM_COL32(255, 200, 40, 255) : IM_COL32(80, 200, 255, 255);
                if (corner) dl->AddRectFilled(ImVec2(pts[k].x - rad, pts[k].y - rad), ImVec2(pts[k].x + rad, pts[k].y + rad), col, 4.f);
                else dl->AddCircleFilled(pts[k], rad, col);
                dl->AddCircle(pts[k], rad + 1.5f, IM_COL32(0, 0, 0, 200), 0, 2.f);
            }
        }
        return;
    }
    if (!hasScene() || !scene().is3d || page_ != Page::Viewport) return;
    Obj* o = selObj();
    if (!o || terrainPaint_ || gndPaint_ || vegPaint_) return;
    EditorView ev = view();
    float cx, cy;
    if (!toScreen(ev, o->pos, cx, cy)) return;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();   // debajo de las ventanas
    float L = gizmoLen(*o), rad = std::max(17.f, h_ * 0.028f);
    const ImU32 cols[3] = {IM_COL32(235, 70, 70, 255), IM_COL32(90, 220, 90, 255), IM_COL32(80, 140, 255, 255)};
    const char* nm[3] = {"X", "Y", "Z"};
    if (gHyb_) {   // Unity: flechas de mover con punta, aros de girar y cubitos de estirar
        const float K = 0.0174532925f;
        for (int a = 0; a < 3; a++) {
            V3 D = a == 0 ? V3{1, 0, 0} : a == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
            bool act = gAxis_ == a;
            ImU32 col = cols[a];
            if (o->kind != Kind::Light && gRings_) {   // aro alrededor del eje
                V3 u = a == 0 ? V3{0, 1, 0} : V3{1, 0, 0}, v = a == 2 ? V3{0, 1, 0} : V3{0, 0, 1};
                ImVec2 prev; bool hp = false;
                for (int s = 0; s <= 40; s++) {
                    float t = s * 6.2831853f / 40;
                    V3 p = o->pos + (u * std::cos(t) + v * std::sin(t)) * (L * 0.72f);
                    float qx, qy;
                    bool okp = toScreen(ev, p, qx, qy);
                    if (okp && hp) dl->AddLine(prev, ImVec2(qx, qy), (col & 0x00FFFFFF) | (act && gHk_ == 1 ? 0xFF000000 : 0xB0000000), act && gHk_ == 1 ? 5.f : 2.5f);
                    prev = ImVec2(qx, qy); hp = okp;
                }
            }
            float sx, sy;
            if (!toScreen(ev, o->pos + D * L, sx, sy)) continue;
            ImVec2 c0(cx, cy), dir(sx - cx, sy - cy);
            float ln = std::sqrt(dir.x * dir.x + dir.y * dir.y);
            if (ln < 1.f) continue;
            dir.x /= ln; dir.y /= ln;
            float hl = rad * 1.5f;
            ImVec2 b(sx - dir.x * hl, sy - dir.y * hl), sd(-dir.y * rad * 0.6f, dir.x * rad * 0.6f);
            dl->AddLine(c0, b, col, act && gHk_ == 0 ? 5.f : 3.f);
            dl->AddTriangleFilled(ImVec2(sx, sy), ImVec2(b.x + sd.x, b.y + sd.y), ImVec2(b.x - sd.x, b.y - sd.y), col);
            ImVec2 ts = ImGui::CalcTextSize(nm[a]);
            dl->AddText(ImVec2(b.x - dir.x * rad * 1.6f - ts.x * 0.5f, b.y - dir.y * rad * 1.6f - ts.y * 0.5f), IM_COL32(255, 255, 255, 255), nm[a]);
            if (o->kind != Kind::Light) {   // asa de tamaño de ESE eje: después de la punta, lejos de las demás asas
                float hx, hy;
                if (toScreen(ev, o->pos + D * (L * 1.3f), hx, hy)) {
                    float r2 = rad * 0.9f; bool on = gAxis_ == a && gHk_ == 2;
                    dl->AddRectFilled(ImVec2(hx - r2, hy - r2), ImVec2(hx + r2, hy + r2), on ? IM_COL32(255, 255, 255, 255) : IM_COL32(235, 235, 235, 215), 5.f);
                    dl->AddRect(ImVec2(hx - r2, hy - r2), ImVec2(hx + r2, hy + r2), IM_COL32(30, 30, 30, 255), 5.f, 0, 2.f);
                    dl->AddRect(ImVec2(hx - r2 * 0.45f, hy - r2 * 0.45f), ImVec2(hx + r2 * 0.45f, hy + r2 * 0.45f), col, 2.f, 0, 2.5f);
                }
            }
        }
        return;
    }
    for (int a = 0; a < 3; a++) {
        V3 e = o->pos; if (a == 0) e.x += L; else if (a == 1) e.y += L; else e.z += L;
        float sx, sy;
        if (!toScreen(ev, e, sx, sy)) continue;
        bool on = gAxis_ == a;
        dl->AddLine(ImVec2(cx, cy), ImVec2(sx, sy), cols[a], on ? 5.f : 3.f);
        float rr2 = on ? rad * 1.3f : rad;
        if (gRotate_ && o->kind != Kind::Light) { dl->AddCircle(ImVec2(sx, sy), rr2 * 1.25f, cols[a], 0, 3.5f); dl->AddCircleFilled(ImVec2(sx, sy), rr2 * 0.55f, IM_COL32(255, 255, 255, 235)); }
        else if (gStretch_ && o->kind != Kind::Light) { dl->AddRectFilled(ImVec2(sx - rr2, sy - rr2), ImVec2(sx + rr2, sy + rr2), cols[a], 3.f); dl->AddRect(ImVec2(sx - rr2, sy - rr2), ImVec2(sx + rr2, sy + rr2), IM_COL32(255, 255, 255, 230), 3.f, 0, 2.f); }
        else { dl->AddCircleFilled(ImVec2(sx, sy), rr2, cols[a]); dl->AddCircle(ImVec2(sx, sy), rr2, IM_COL32(255, 255, 255, 230), 0, 2.f); }
        ImVec2 ts = ImGui::CalcTextSize(nm[a]);
        dl->AddText(ImVec2(sx - ts.x * 0.5f, sy - ts.y * 0.5f), IM_COL32(255, 255, 255, 255), nm[a]);
    }
    dl->AddCircleFilled(ImVec2(cx, cy), 5.f, IM_COL32(255, 255, 255, 230));
}

// Gestos sobre la vista: 1 dedo gira la camara (o arrastra el objeto seleccionado),
// 2 dedos acercan y desplazan, toque corto selecciona.
static bool gSnapRot(float& d) { d = std::round(d / 5.f) * 5.f; return true; }   // giros de 5° en 5°

// Palanca virtual del editor 3D (mover la cámara adelante/atrás/de lado) + teclas WASD/QE y clic derecho en Windows.
void Editor::gestures() {
    ImGuiIO& io = ImGui::GetIO();
    auto& P = play_.ctl.p;
    bool active3d = hasScene() && scene().is3d && page_ == Page::Viewport && !terrainPaint_ && !gndPaint_ && !vegPaint_;
    if (!active3d) { joyId_ = -1; gesturesCore(); return; }
    EditorView ev = view();
    V3 fh = norm(V3{ev.fwd.x, 0, ev.fwd.z}), rt = norm(cross(ev.fwd, V3{0, 1, 0}));
    float R = h_ * 0.11f, jx = R * 1.5f + h_ * 0.02f, jy = (float)h_ - R * 1.8f;
    static bool prevDown[10] = {};
    for (int i = 0; i < 10; i++) {
        if (P[i].down && !prevDown[i] && joyId_ < 0 && !io.WantCaptureMouse) {
            float dx = P[i].lx - jx, dy = P[i].ly - jy;
            if (dx * dx + dy * dy < R * R * 1.3f) joyId_ = i;
        }
        prevDown[i] = P[i].down;
    }
    if (joyId_ >= 0 && !P[joyId_].down) joyId_ = -1;
    float kx = 0.f, ky = 0.f, up = 0.f;
    if (joyId_ >= 0) {
        float dx = (P[joyId_].lx - jx) / R, dy = (P[joyId_].ly - jy) / R, l = std::sqrt(dx * dx + dy * dy);
        if (l > 1.f) { dx /= l; dy /= l; }
        kx = dx; ky = -dy;
    }
    if (!io.WantTextInput) {   // Windows: teclado
        if (ImGui::IsKeyDown(ImGuiKey_W)) ky += 1.f;
        if (ImGui::IsKeyDown(ImGuiKey_S)) ky -= 1.f;
        if (ImGui::IsKeyDown(ImGuiKey_D)) kx += 1.f;
        if (ImGui::IsKeyDown(ImGuiKey_A)) kx -= 1.f;
        if (ImGui::IsKeyDown(ImGuiKey_E)) up += 1.f;
        if (ImGui::IsKeyDown(ImGuiKey_Q)) up -= 1.f;
    }
    if (kx != 0.f || ky != 0.f || up != 0.f) {
        float sp = std::max(2.f, dist_) * 0.9f * io.DeltaTime * (ImGui::IsKeyDown(ImGuiKey_LeftShift) ? 3.f : 1.f);
        target_ = target_ + fh * (ky * sp) + rt * (kx * sp) + V3{0, up * sp, 0};
    }
    if (!io.WantCaptureMouse && ImGui::IsMouseDown(ImGuiMouseButton_Right)) {   // Windows: clic derecho gira la vista
        yaw_ -= io.MouseDelta.x * 0.006f;
        pitch_ = std::max(-1.4f, std::min(1.45f, pitch_ + io.MouseDelta.y * 0.006f));
    }
    // dibujo de la palanca (debajo de las ventanas)
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    bool on = joyId_ >= 0;
    dl->AddCircleFilled(ImVec2(jx, jy), R, IM_COL32(20, 28, 44, on ? 150 : 100));
    dl->AddCircle(ImVec2(jx, jy), R, IM_COL32(150, 180, 235, on ? 230 : 150), 0, 2.5f);
    float kx2 = jx, ky2 = jy;
    if (on) { float dx = P[joyId_].lx - jx, dy = P[joyId_].ly - jy, l = std::sqrt(dx * dx + dy * dy); if (l > R) { dx *= R / l; dy *= R / l; } kx2 += dx; ky2 += dy; }
    dl->AddCircleFilled(ImVec2(kx2, ky2), R * 0.42f, IM_COL32(200, 220, 255, on ? 230 : 150));
    if (joyId_ >= 0) { bool sv = P[joyId_].down; P[joyId_].down = false; gesturesCore(); P[joyId_].down = sv; }
    else gesturesCore();
}

void Editor::posPickUI() {
    if (!hasScene() || posPick_.obj < 0 || posPick_.obj >= (int)scene().objs.size() || page_ != Page::Viewport) { posPick_.on = false; return; }
    showObjs = showProps = showWorld = showHud = showAssets = false;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, fs * 0.6f), ImGuiCond_Always, ImVec2(0.5f, 0.f));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.07f, 0.45f, 0.42f, 0.95f));
    if (ImGui::Begin("##pospick", nullptr, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoTitleBar | kNoSB)) {
        ImGui::TextUnformatted("Toca en la escena el lugar elegido");
        if (wrapui::Button("Cancelar") && tapped()) { int o = posPick_.obj; posPick_.on = false; openObject(o); }
    }
    ImGui::End();
    ImGui::PopStyleColor();
}

void Editor::gesturesCore() {
    ImGuiIO& io = ImGui::GetIO();
    auto& P = play_.ctl.p;
    int ids[2], n = 0;
    for (int i = 0; i < 10 && n < 2; i++) if (P[i].down) ids[n++] = i;
    int total = play_.ctl.downCount();
    if (hasScene() && io.MouseWheel != 0.f && !io.WantCaptureMouse) {   // rueda del mouse = acercar / alejar
        float k = io.MouseWheel > 0 ? 0.88f : 1.14f;
        if (scene().is3d) dist_ = std::max(2.f, std::min(120.f, dist_ * k));
        else h2d_ = std::max(kView2DHeight * 0.2f, std::min(kView2DHeight * 6.f, h2d_ * k));   // 2D: zoom (el marco blanco marca lo que se ve en el juego)
    }

    if (total == 0) {
        gAxis_ = -1;
        if (prevN_ == 1 && gestOk_ && moveAcc_ < 20.f && hasScene() && posPick_.on) {   // elegir posición para un bloque
            Scene& S = scene();
            int oi = posPick_.obj, bi = posPick_.blk;
            if (oi >= 0 && oi < (int)S.objs.size() && bi >= 0 && bi < (int)S.objs[oi].blocks.size()) {
                Obj& o = S.objs[oi];
                Block& b = o.blocks[bi];
                auto fmtN = [](float v) { char t[32]; snprintf(t, sizeof t, "%.2f", v); std::string s = t; while (!s.empty() && s.back() == '0') s.pop_back(); if (!s.empty() && s.back() == '.') s.pop_back(); return s.empty() ? std::string("0") : s; };
                bool done = false;
                if (S.is3d) {
                    EditorView ev = view();
                    V3 ro, rd;
                    rayAt(lastX_, lastY_, ev, ro, rd);
                    int hit = pick(lastX_, lastY_, ev);
                    float plane = hit >= 0 && hit != oi ? S.objs[hit].pos.y + S.objs[hit].scale.y * 0.5f : 0.f;
                    if (rd.y < -1e-4f) {
                        float t = (plane - ro.y) / rd.y;
                        if (t > 0) {
                            V3 p = ro + rd * t;
                            b.f[0] = fmtN(std::round(p.x * 2.f) / 2.f); b.f[1] = fmtN(plane + o.scale.y * 0.5f); b.f[2] = fmtN(std::round(p.z * 2.f) / 2.f);
                            done = true;
                        }
                    }
                } else {
                    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;
                    float wx = cx_ + (lastX_ / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - lastY_ / (float)h_) * h2d_;
                    int fx = b.op == Op::GlideTo ? 1 : 0;
                    b.f[fx] = fmtN(std::round(wx)); b.f[fx + 1] = fmtN(std::round(wy));
                    done = true;
                }
                if (done) { posPick_.on = false; markDirty(); toast("Posición puesta en el bloque"); openObject(oi); }
            } else posPick_.on = false;
            prevN_ = 0; dragObj_ = false;
            return;
        }
        if (prevN_ == 1 && gestOk_ && moveAcc_ < 20.f && hasScene()) {
            int hit = pick(lastX_, lastY_, view());
            double now = ImGui::GetTime();
            static double lastTap = -10; static int lastHit = -2;
            if (hit >= 0 && hit == lastHit && now - lastTap < 0.45) {  // doble toque: abrir propiedades del objeto
                sel_ = hit; showProps = true; showObjs = false;
                if (host_.vibrate) host_.vibrate(0.02f);
                lastTap = -10;
            } else { lastTap = now; lastHit = hit; }
            sel_ = hit;
        }
        prevN_ = 0;
        dragObj_ = false;
        g2h_ = -1;
        return;
    }
    if (prevN_ == 0) { gestOk_ = !io.WantCaptureMouse; moveAcc_ = 0; dragObj_ = false; }
    if (!gestOk_ || !hasScene()) { prevN_ = n; return; }

    EditorView ev = view();
    Scene& S = scene();
    float aspect = h_ > 0 ? (float)w_ / (float)h_ : 1.f;

    if (!S.is3d && total == 1 && n == 1 && selObj() && !terrainPaint_ && !gndPaint_ && !vegPaint_) {   // 2D: asas de tamaño (lados = estirar, esquinas = agrandar parejo)
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        Obj* so = selObj();
        if (prevN_ == 0 && g2h_ < 0) {
            ImVec2 pts[8]; int ms[8], hn = 0;
            if (handles2D(so, pts, ms, hn)) {
                float best = std::max(40.f, h_ * 0.06f);
                for (int k = hn - 1; k >= 0; k--) {
                    float d = std::sqrt((pts[k].x - x) * (pts[k].x - x) + (pts[k].y - y) * (pts[k].y - y));
                    if (d < best) { best = d; g2h_ = ms[k]; }
                }
                if (g2h_ >= 0) { g2p_ = so->pos; g2s_ = so->scale; moveAcc_ = 1000.f; }
            }
        }
        if (g2h_ >= 0) {
            float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
            float l = g2p_.x - g2s_.x * 0.5f, r = g2p_.x + g2s_.x * 0.5f, t = g2p_.y + g2s_.y * 0.5f, b = g2p_.y - g2s_.y * 0.5f;
            const float mn = 10.f;
            float nl = l, nr = r, nt = t, nb = b;
            bool corner = g2h_ == 10 || g2h_ == 5 || g2h_ == 6 || g2h_ == 9;
            if (corner) {   // la esquina contraria queda fija y se mantiene la forma
                float fx = (g2h_ & 2) ? l : r, fy = (g2h_ & 4) ? b : t;
                float w0 = std::max(mn, g2s_.x), h0 = std::max(mn, g2s_.y);
                float k = std::max(std::fabs(wx - fx) / w0, std::fabs(wy - fy) / h0);
                k = std::max(mn / std::min(w0, h0), k);
                float nw = w0 * k, nh = h0 * k;
                nl = (g2h_ & 2) ? fx : fx - nw; nr = (g2h_ & 2) ? fx + nw : fx;
                nb = (g2h_ & 4) ? fy : fy - nh; nt = (g2h_ & 4) ? fy + nh : fy;
            } else {
                if (g2h_ & 2) nr = std::max(l + mn, wx);
                if (g2h_ & 1) nl = std::min(r - mn, wx);
                if (g2h_ & 4) nt = std::max(b + mn, wy);
                if (g2h_ & 8) nb = std::min(t - mn, wy);
            }
            so->scale.x = nr - nl; so->scale.y = nt - nb;
            so->pos.x = (nl + nr) * 0.5f; so->pos.y = (nb + nt) * 0.5f;
            markDirty();
            prevN_ = 1;
            return;
        }
    }
    if (S.is3d && total == 1 && n == 1 && selObj() && !terrainPaint_ && !gndPaint_ && !vegPaint_) {   // asas de mover (X / Y / Z)
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        Obj* so = selObj();
        float sn3 = snap_;
        if (prevN_ == 0 && gAxis_ < 0 && gHyb_) {   // asas híbridas: flecha, aro, cubito o centro
            float L = gizmoLen(*so), thr = std::max(46.f, h_ * 0.065f), best = thr;
            int bk = -1, ba = -1;
            float cx0, cy0;
            bool hasC = toScreen(ev, so->pos, cx0, cy0);
            for (int a = 0; a < 3; a++) {
                V3 D = a == 0 ? V3{1, 0, 0} : a == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
                float sx, sy;
                if (toScreen(ev, so->pos + D * L, sx, sy)) { float d = std::sqrt((sx - x) * (sx - x) + (sy - y) * (sy - y)); if (d < best) { best = d; bk = 0; ba = a; } }
                if (so->kind == Kind::Light || !gRings_) continue;
                V3 u = a == 0 ? V3{0, 1, 0} : V3{1, 0, 0}, v = a == 2 ? V3{0, 1, 0} : V3{0, 0, 1};
                float px = 0, py = 0; bool hp = false;
                for (int s = 0; s <= 40; s++) {
                    float t = s * 6.2831853f / 40, qx, qy;
                    bool okp = toScreen(ev, so->pos + (u * std::cos(t) + v * std::sin(t)) * (L * 0.72f), qx, qy);
                    if (okp && hp) {
                        float ex = qx - px, ey = qy - py, l2 = ex * ex + ey * ey, tt = l2 > 1e-4f ? std::max(0.f, std::min(1.f, ((x - px) * ex + (y - py) * ey) / l2)) : 0.f;
                        float dx = px + ex * tt - x, dy = py + ey * tt - y, d = std::sqrt(dx * dx + dy * dy) * 1.25f;
                        if (d < best) { best = d; bk = 1; ba = a; }
                    }
                    px = qx; py = qy; hp = okp;
                }
            }
            if (so->kind != Kind::Light)   // asas de tamaño general, más allá de las puntas
                for (int a = 0; a < 3; a++) {
                    V3 D = a == 0 ? V3{1, 0, 0} : a == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
                    float hx, hy;
                    if (toScreen(ev, so->pos + D * (L * 1.3f), hx, hy)) { float d = std::sqrt((hx - x) * (hx - x) + (hy - y) * (hy - y)) * 0.7f; if (d < best) { best = d; bk = 2; ba = a; } }
                }
            if (bk >= 0) {
                gHk_ = bk; gAxis_ = ba;
                gPos0_ = so->pos; gScale0_ = so->scale; gRot0_ = V3{so->pitch, so->yaw, so->roll}; moveAcc_ = 1000.f;
                gAcc_ = 0.f; gY0_ = y; gUni0_ = 1.f;
                if (hasC) gAng0_ = std::atan2(y - cy0, x - cx0);
                if (bk != 1 && bk != 3) {
                    V3 ro, rd; rayAt(x, y, ev, ro, rd);
                    V3 D = gAxis_ == 0 ? V3{1, 0, 0} : gAxis_ == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
                    V3 w0 = gPos0_ - ro; float b = dot(D, rd), dd = dot(D, w0), e2 = dot(rd, w0), den = 1.f - b * b;
                    gT0_ = std::fabs(den) > 1e-4f ? (b * e2 - dd) / den : 0.f;
                }
            }
        }
        if (prevN_ == 0 && gAxis_ < 0 && !gHyb_) {
            float L = gizmoLen(*so), best = std::max(46.f, h_ * 0.065f);
            for (int a = 0; a < 3; a++) {
                V3 e = so->pos; if (a == 0) e.x += L; else if (a == 1) e.y += L; else e.z += L;
                float sx, sy;
                if (!toScreen(ev, e, sx, sy)) continue;
                float d = std::sqrt((sx - x) * (sx - x) + (sy - y) * (sy - y));
                if (d < best) { best = d; gAxis_ = a; }
            }
            if (gAxis_ >= 0) {
                gPos0_ = so->pos; gScale0_ = so->scale; gRot0_ = V3{so->pitch, so->yaw, so->roll}; moveAcc_ = 1000.f;
                V3 ro, rd; rayAt(x, y, ev, ro, rd);
                V3 D = gAxis_ == 0 ? V3{1, 0, 0} : gAxis_ == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
                V3 w0 = gPos0_ - ro; float b = dot(D, rd), dd = dot(D, w0), e2 = dot(rd, w0), den = 1.f - b * b;
                gT0_ = std::fabs(den) > 1e-4f ? (b * e2 - dd) / den : 0.f;
            }
        }
        if (gAxis_ >= 0 && gHyb_ && (gHk_ == 1 || gHk_ == 3)) {
            if (gHk_ == 3) {   // centro: tamaño general sin deformar (arrastrar hacia arriba = más grande)
                float k = std::exp((gY0_ - y) * 0.006f);
                so->scale = V3{std::max(0.02f, gScale0_.x * k), std::max(0.02f, gScale0_.y * k), std::max(0.02f, gScale0_.z * k)};
                markDirty();
            } else {
                float cx0, cy0;
                if (toScreen(ev, so->pos, cx0, cy0)) {
                    float ang = std::atan2(y - cy0, x - cx0), dlt = ang - gAng0_;
                    while (dlt > 3.14159265f) dlt -= 6.2831853f;
                    while (dlt < -3.14159265f) dlt += 6.2831853f;
                    gAng0_ = ang; gAcc_ += dlt;
                    V3 D = gAxis_ == 0 ? V3{1, 0, 0} : gAxis_ == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
                    float sg = dot(D, ev.fwd) < 0.f ? -1.f : 1.f;
                    float d = sg * gAcc_ * 57.29578f;
                    d = std::round(d / 5.f) * 5.f;
                    if (gAxis_ == 0) so->pitch = gRot0_.x + d; else if (gAxis_ == 1) so->yaw = gRot0_.y + d; else so->roll = gRot0_.z + d;
                    markDirty();
                }
            }
            prevN_ = 1;
            return;
        }
        if (gAxis_ >= 0) {
            V3 ro, rd; rayAt(x, y, ev, ro, rd);
            V3 D = gAxis_ == 0 ? V3{1, 0, 0} : gAxis_ == 1 ? V3{0, 1, 0} : V3{0, 0, 1};
            V3 w0 = gPos0_ - ro; float b = dot(D, rd), dd = dot(D, w0), e2 = dot(rd, w0), den = 1.f - b * b;
            if (std::fabs(den) > 1e-4f) {
                float t = (b * e2 - dd) / den, mv = t - gT0_;
                if (sn3 > 0.f) mv = std::round(mv / sn3) * sn3;
                if (gRotate_ && !gHyb_ && so->kind != Kind::Light) {   // girar con las asas (45° por unidad arrastrada)
                    float d = mv * 45.f;
                    if (gSnapRot(d)) {}
                    if (gAxis_ == 0) so->pitch = gRot0_.x + d; else if (gAxis_ == 1) so->yaw = gRot0_.y + d; else so->roll = gRot0_.z + d;
                    markDirty();
                } else if ((gStretch_ || (gHyb_ && gHk_ == 2)) && so->kind != Kind::Light) {   // estirar desde la cara contraria (queda fija)
                    float s0 = gAxis_ == 0 ? gScale0_.x : gAxis_ == 1 ? gScale0_.y : gScale0_.z;
                    float ns = std::max(0.1f, s0 + mv);
                    float real = ns - s0;
                    V3 sc2 = gScale0_;
                    if (gAxis_ == 0) sc2.x = ns; else if (gAxis_ == 1) sc2.y = ns; else sc2.z = ns;
                    so->scale = sc2;
                    so->pos = gPos0_ + D * (real * 0.5f);
                    markDirty();
                } else {
                V3 np = gPos0_ + D * mv;
                if (gAxis_ == 1) np.y = std::max(-50.f, np.y);
                so->pos = np; markDirty();
                }
            }
            prevN_ = 1;
            return;
        }
    } else if (total == 0) gAxis_ = -1;

    if (n == 1) {
        float x = P[ids[0]].lx, y = P[ids[0]].ly;
        if (terrainPaint_ && S.is3d) {  // esculpir el terreno seleccionado
            Obj* tr = selObj();
            if (tr && tr->kind == Kind::Floor && tr->tn >= 2) {
                V3 ro, rd;
                rayAt(x, y, ev, ro, rd);
                float tt;
                if (rayTerrain(*tr, ro, rd, 400.f, tt)) {
                    V3 hit = ro + rd * tt;
                    if (prevN_ != 1) terrTarget_ = terrainSurface(*tr, hit.x, hit.z) - (tr->pos.y + tr->scale.y * 0.5f);
                    terrainBrush(*tr, hit.x, hit.z, terrRadius_, terrStrength_ * std::min(0.05f, io.DeltaTime), terrMode_, terrTarget_);
                    markDirty();
                }
                lastX_ = x; lastY_ = y;
                moveAcc_ = 1000.f;
                prevN_ = 1;
                return;
            }
        }
        bool gOn = gndPaint_ && S.is3d && gndSel_ >= 0 && gndSel_ < (int)S.gnd.size();
        bool vOn = vegPaint_ && S.is3d && vegSel_ >= 0 && vegSel_ < (int)S.veg.size();
        if (gOn || vOn) {  // pintar vegetacion o texturas del suelo
            V3 ro, rd, hit;
            rayAt(x, y, ev, ro, rd);
            if (groundHit(S, ro, rd, hit)) {
                float dx = hit.x - vegLastX_, dz = hit.z - vegLastZ_, rr = gOn ? gndRadius_ : vegRadius_;
                if (prevN_ != 1 || dx * dx + dz * dz > rr * rr * 0.4f) { if (gOn) gndStamp(S, hit); else vegStamp(S, hit); vegLastX_ = hit.x; vegLastZ_ = hit.z; }
            }
            if (prevN_ != 1) { vegLastX_ = 1e9f; }
            lastX_ = x; lastY_ = y;
            moveAcc_ = 1000.f;
            prevN_ = 1;
            return;
        }
        if (prevN_ != 1) {
            lastX_ = x; lastY_ = y;
            Obj* o = selObj();
            if (prevN_ == 0 && !S.is3d) {   // 2D: tocar un objeto y arrastrar lo selecciona y lo mueve de una vez
                int ph = pick(x, y, ev);
                if (ph >= 0 && ph != sel_ && ph < (int)S.objs.size() && !S.objs[ph].bg) { sel_ = ph; o = selObj(); }
            }
            if (prevN_ == 0 && o && pick(x, y, ev) == sel_) {  // el dedo empieza sobre el objeto seleccionado
                dragObj_ = true;
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        V3 hit = ro + rd * t;
                        grab_ = V3{hit.x - o->pos.x, 0, hit.z - o->pos.z};
                    } else grab_ = V3();
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    grab_ = V3{wx - o->pos.x, wy - o->pos.y, 0};
                }
            }
        }
        float dx = x - lastX_, dy = y - lastY_;
        lastX_ = x; lastY_ = y;
        moveAcc_ += std::fabs(dx) + std::fabs(dy);
        float sn = S.is3d ? snap_ : (snap_ > 0.f ? snap_ * 40.f : 0.f);
        auto snapv = [&](float v) { return sn > 0.f ? std::round(v / sn) * sn : v; };
        if (dragObj_) {
            Obj* o = selObj();
            if (o && moveAcc_ > 14.f) {
                if (S.is3d) {
                    V3 ro, rd;
                    rayAt(x, y, ev, ro, rd);
                    if (std::fabs(rd.y) > 1e-4f) {
                        float t = (o->pos.y - ro.y) / rd.y;
                        if (t > 0) {
                            V3 hit = ro + rd * t;
                            o->pos.x = snapv(hit.x - grab_.x);
                            o->pos.z = snapv(hit.z - grab_.z);
                            markDirty();
                        }
                    }
                } else {
                    float wx = cx_ + (x / (float)w_ - 0.5f) * h2d_ * aspect, wy = cy_ + (0.5f - y / (float)h_) * h2d_;
                    o->pos.x = snapv(wx - grab_.x);
                    o->pos.y = snapv(wy - grab_.y);
                    markDirty();
                }
            }
        } else if (S.is3d) {
            yaw_ -= dx * 0.006f;
            pitch_ = std::max(-1.4f, std::min(1.45f, pitch_ + dy * 0.006f));
        } else {
            float k = h2d_ / (float)h_;
            cx_ -= dx * k;
            cy_ += dy * k;
        }
    } else if (n == 2) {
        Ptr &a = P[ids[0]], &b = P[ids[1]];
        float mx = (a.lx + b.lx) * 0.5f, my = (a.ly + b.ly) * 0.5f;
        float dist = std::sqrt((a.lx - b.lx) * (a.lx - b.lx) + (a.ly - b.ly) * (a.ly - b.ly));
        if (prevN_ != 2) {
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
            moveAcc_ = 1000.f;  // ya no es un toque
        } else {
            if (lastDist_ > 1.f && dist > 1.f) {
                float k = lastDist_ / dist;
                if (S.is3d) dist_ = std::max(2.f, std::min(120.f, dist_ * k));
                else h2d_ = std::max(kView2DHeight * 0.2f, std::min(kView2DHeight * 6.f, h2d_ * k));
            }
            float dx = mx - lastX_, dy = my - lastY_;
            if (S.is3d) {
                V3 r = norm(cross(ev.fwd, V3{0, 1, 0})), u = cross(r, ev.fwd);
                target_ = target_ - r * (dx * dist_ * 0.0016f) + u * (dy * dist_ * 0.0016f);
            } else {
                float k = h2d_ / (float)h_;
                cx_ -= dx * k;
                cy_ += dy * k;
            }
            lastX_ = mx; lastY_ = my; lastDist_ = dist;
        }
    }
    prevN_ = n;
}

// ---------------------------------------------------------------- frame
void Editor::frame(Renderer* r, int w, int h, float dt) {
    if (!wheelNew_.empty()) {
        if (hasScene()) for (auto& wo : wheelNew_) { wo.name = uniqueName(wo.name); scene().objs.push_back(wo); }
        wheelNew_.clear(); markDirty();
    }
    w_ = w; h_ = h;
    play_.ctl.w = w;
    play_.ctl.h = h;
    if (toastT_ > 0) toastT_ -= dt;
    if (helpOpen_ && screen_ != Screen::Play) { helpUI(r); return; }
    switch (screen_) {
        case Screen::Projects: projectsUI(r); break;
        case Screen::Edit: editFrame(r, dt); break;
        case Screen::Play: playFrame(r, dt); break;
    }
    if (screen_ != Screen::Projects) pollImport();  // en todas las páginas, no solo en el editor 3D
    if (!imp_ && !impQ_.empty() && screen_ == Screen::Edit) { auto q = std::move(impQ_.front()); impQ_.pop_front(); startModelImport(q.first, std::move(q.second)); }   // importar varios a la vez
    importOverlay();
    toastUI();
}

// ---------------------------------------------------------------- importar modelos (otro hilo + pantalla de carga)
struct ImpJob {
    std::string name, model, err, rigText;
    std::vector<uint8_t> data;
    Files out;
    Rig rg;
    int added = 0;
    bool ok = false, hasRig = false;
    std::atomic<bool> done{false};
};

void Editor::startModelImport(const std::string& name, std::vector<uint8_t> data) {
    auto job = std::make_shared<ImpJob>();
    job->name = name;
    job->data = std::move(data);
    imp_ = job;
    gImportProgress = 0.f;
    auto work = [](std::shared_ptr<ImpJob> job) {
        try {
            const std::string& nm = job->name;
            job->ok = ends(nm, ".zip") ? importModelZip(job->data, job->out, job->model, job->err)
                                       : importModel(nm, job->data, job->out, job->model, job->err);
            if (job->ok && (ends(nm, ".glb") || ends(nm, ".gltf") || ends(nm, ".fbx"))) {
                std::string e2;
                job->hasRig = importAnimations(nm, job->data, job->model, job->rg, job->added, e2) && job->added > 0;
            }
        } catch (const std::exception& ex) {
            job->ok = false;
            job->err = std::string("falta memoria o el archivo es demasiado pesado (") + ex.what() + ")";
        } catch (...) {
            job->ok = false;
            job->err = "falta memoria o el archivo es demasiado pesado";
        }
        gImportProgress = 1.f;
        job->done = true;
    };
#ifdef _WIN32
    std::thread(work, job).detach();
#else
    {   // hilo con pila grande: los modelos pesados necesitan mas pila que el hilo normal
        struct Arg { std::shared_ptr<ImpJob> job; void (*fn)(std::shared_ptr<ImpJob>); };
        Arg* arg = new Arg{job, +work};
        pthread_attr_t at;
        pthread_attr_init(&at);
        pthread_attr_setstacksize(&at, 64u * 1024 * 1024);
        pthread_attr_setdetachstate(&at, PTHREAD_CREATE_DETACHED);
        pthread_t th;
        int rc = pthread_create(&th, &at, [](void* p) -> void* {
            Arg* a = (Arg*)p;
            a->fn(a->job);
            delete a;
            return nullptr;
        }, arg);
        pthread_attr_destroy(&at);
        if (rc != 0) { delete arg; std::thread(work, job).detach(); }
    }
#endif
}

void Editor::pollImport() {
    if (!imp_ || !imp_->done) return;
    std::shared_ptr<ImpJob> job = imp_;
    imp_.reset();
    if (!job->ok) { toast("No se pudo importar: " + job->err); return; }
    Files& A = edit_.proj.assets;
    std::string model = job->model;
    if (A.count(model)) {  // nombre ya usado: se busca uno libre
        std::string base = model.substr(0, model.size() - 5);
        std::string nn;
        for (int i = 2;; i++) { nn = base + "_" + std::to_string(i) + ".fmdl"; if (!A.count(nn)) break; }
        job->out[nn] = std::move(job->out[model]);
        job->out.erase(model);
        model = nn;
    }
    for (auto& kv : job->out) {
        const std::string& key = kv.first == job->model ? model : kv.first;
        A[key] = std::move(kv.second);
        assetDirty_.insert(key);
    }
    if (job->hasRig) {
        job->rg.model = model;
        std::string rn = model.substr(0, model.size() - 5) + ".fanim", txt = rigWrite(job->rg);
        A[rn] = std::vector<uint8_t>(txt.begin(), txt.end());
        assetDirty_.insert(rn);
        toast("Modelo importado con " + std::to_string(job->added) + " animaciones: " + rn);
    }
    if (pendingNewModel_ && hasScene() && scene().is3d) {
        pendingNewModel_ = false;
        addObject(Kind::Model, model);
        toast("Modelo importado y añadido: " + model);
    } else if (!job->hasRig) {
        toast("Modelo importado: " + model + " (Objeto nuevo > Modelo 3D)");
    }
    markDirty();
}

void Editor::importOverlay() {
    if (reading_) readingT_ += ImGui::GetIO().DeltaTime;
    if (reading_ && readingT_ > 180.f) reading_ = false;
    if (!imp_ && !reading_) return;
    float fs = ImGui::GetFontSize();
    ImGui::GetForegroundDrawList()->AddRectFilled(ImVec2(0, 0), ImVec2((float)w_, (float)h_), IM_COL32(0, 0, 0, 170));
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min((float)w_ * 0.9f, fs * 26.f), 0));
    ImGui::SetNextWindowFocus();
    ImGui::Begin("##importando", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    float p = imp_ ? std::max(0.02f, std::min(1.f, gImportProgress.load())) : 0.f;
    if (!imp_) {
        ImGui::TextUnformatted("Leyendo el archivo…");
        float t = (float)std::fmod(ImGui::GetTime() * 0.6, 1.0);
        ImGui::ProgressBar(t, ImVec2(-1, fs * 2.2f), "");
        ImGui::TextDisabled("Los archivos grandes tardan unos segundos.");
        ImGui::End();
        return;
    }
    ImGui::Text("Importando %s…", shorten(imp_->name, 28).c_str());
    ImGui::Spacing();
    char buf[32];
    snprintf(buf, sizeof buf, "%d%%", (int)(p * 100.f));
    ImGui::ProgressBar(p, ImVec2(-1, fs * 2.2f), buf);
    ImGui::TextDisabled("Los modelos pesados tardan un poco. No cierres la app.");
    ImGui::End();
}

void Editor::toastUI() {
    if (toastT_ <= 0 || toast_.empty()) return;
    float fs = ImGui::GetFontSize();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, h_ - fs * 2.f), ImGuiCond_Always, ImVec2(0.5f, 1.f));
    ImGui::SetNextWindowBgAlpha(0.85f);
    ImGui::Begin("##toast", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_AlwaysAutoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoFocusOnAppearing);
    ImGui::TextUnformatted(toast_.c_str());
    ImGui::End();
}

void Editor::projectsUI(Renderer* r) {
    if (r) r->clear(w_, h_, 0.08f, 0.09f, 0.13f);
    float fs = ImGui::GetFontSize();
    drawMenuBackdrop(ImGui::GetBackgroundDrawList(), r, w_, h_, 1 + menuBg_ % 2, (float)ImGui::GetTime());
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2((float)w_, (float)h_));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    wrapui::Begin("Proyectos", nullptr,
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBringToFrontOnFocus | kNoSB);
    dragScroll();  // se desliza con el dedo en cualquier parte
    {
        int lw = 0, lh = 0;
        unsigned lid = brandTexture(r, 0, &lw, &lh);
        ImVec2 hp = ImGui::GetCursorScreenPos();
        float hh = fs * 4.6f;
        ImGui::GetWindowDrawList()->AddRectFilledMultiColor(ImVec2(0, hp.y - 12.f), ImVec2((float)w_, hp.y + hh), IM_COL32(20, 150, 140, 255), IM_COL32(40, 90, 190, 255), IM_COL32(30, 60, 150, 255), IM_COL32(16, 100, 110, 255));
        ImGui::SetCursorScreenPos(ImVec2(hp.x + fs * 0.3f, hp.y + fs * 0.35f));
        if (lid) {
            ImGui::Image((ImTextureID)(intptr_t)lid, ImVec2(fs * 3.4f, fs * 3.4f));
            ImGui::SameLine();
        }
        ImGui::BeginGroup();
        ImGui::SetWindowFontScale(1.7f);
        ImGui::TextUnformatted("P-Maker code333");
        ImGui::SetWindowFontScale(1.f);
        ImGui::TextUnformatted("Crea tus propios juegos");
        ImGui::EndGroup();
        ImGui::SetCursorScreenPos(ImVec2(hp.x, hp.y + hh + fs * 0.5f));
    }
    // ---- v11.5: inicio a la izquierda (nombre + mosaicos), "Mis juegos" y "Plantillas" a la derecha (en vertical, una debajo de otra)
    std::string openName;
    const bool wide = (float)w_ > (float)h_ * 1.15f;
    auto startPanel = [&](bool compact) {
        ImGui::TextDisabled("Inicio");
        ImGui::SetNextItemWidth(-1.f);
        textInput("##pn", "Nombre del proyecto", newName_, "nombre del proyecto");
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        int cols = 2;
        float tw = (avail - sp) / 2.f, th = compact ? std::max(fs * 4.6f, tw * 0.55f) : std::max(fs * 6.f, tw * 0.75f);
        if (th > fs * 7.5f) th = fs * 7.5f;
        if (wrapui::Tile("##nv", "Nuevo vacío", wrapui::IcPlus, ImVec4(0.12f, 0.62f, 0.55f, 1.f), ImVec2(tw, th)) && tapped()) newProject(newName_, false);
        ImGui::SameLine();
        if (wrapui::Tile("##nd", "Nuevo con la demo", wrapui::IcCube, ImVec4(0.45f, 0.35f, 0.82f, 1.f), ImVec2(tw, th)) && tapped()) newProject(newName_, true);
        if (host_.pickFile) {
            if (wrapui::Tile("##im", "Importar (.pack, .zip, .rar)", wrapui::IcFolder, ImVec4(0.22f, 0.48f, 0.85f, 1.f), ImVec2(tw, th)) && tapped()) host_.pickFile();
            ImGui::SameLine();
        }
        if (wrapui::Tile("##hl", "Ayuda: guías paso a paso", wrapui::IcBolt, ImVec4(0.85f, 0.55f, 0.15f, 1.f), ImVec2(tw, th)) && tapped()) openHelp();
        (void)cols;
    };
    auto tabs = [&]() {
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x, bw = (avail - sp) / 2.f;
        for (int t = 0; t < 2; t++) {
            if (t) ImGui::SameLine();
            bool on = startTab_ == t;
            ImGui::PushStyleColor(ImGuiCol_Button, on ? ImVec4(0.18f, 0.55f, 0.85f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
            if (wrapui::Button(t ? "Plantillas" : "Mis Juegos", ImVec2(bw, fs * 2.4f)) && tapped()) startTab_ = t;
            ImGui::PopStyleColor();
        }
        ImGui::Spacing();
    };
    auto content = [&]() {
        if (startTab_ == 0) {
            if (projList_.empty()) ImGui::TextDisabled("Todavía no tienes proyectos. Crea el primero con «Nuevo vacío» o elige una plantilla.");
    std::string del;
    for (auto& n : projList_) {
        ImGui::PushID(n.c_str());
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        float ch = fs * 3.6f, delW = fs * 5.2f;
        ImVec2 p0 = ImGui::GetCursorScreenPos();
        bool open = ImGui::InvisibleButton("##open", ImVec2(avail - delW - sp, ch)) && tapped();
        bool hov = ImGui::IsItemHovered();
        unsigned hsh = 0;
        for (unsigned char c : n) hsh = hsh * 131u + c;
        static const ImU32 pal[6] = {IM_COL32(30, 170, 150, 255), IM_COL32(90, 110, 230, 255), IM_COL32(220, 120, 60, 255), IM_COL32(170, 90, 210, 255), IM_COL32(60, 160, 90, 255), IM_COL32(210, 80, 120, 255)};
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 p1(p0.x + avail - delW - sp, p0.y + ch);
        dl->AddRectFilled(p0, p1, hov ? IM_COL32(48, 66, 108, 255) : IM_COL32(32, 46, 80, 255), fs * 0.7f);
        float is = ch * 0.72f;
        ImVec2 ic0(p0.x + ch * 0.14f, p0.y + (ch - is) * 0.5f);
        dl->AddRectFilled(ic0, ImVec2(ic0.x + is, ic0.y + is), pal[hsh % 6], fs * 0.5f);
        wrapui::drawIcon(dl, wrapui::IcPlay, ImVec2(ic0.x + is * 0.5f, ic0.y + is * 0.5f), is * 0.55f, IM_COL32(255, 255, 255, 255));
        float tx = ic0.x + is + fs * 0.6f, ww = std::max(fs * 3.f, p1.x - tx - fs * 0.4f);
        ImVec2 ts = ImGui::CalcTextSize(n.c_str(), nullptr, false, ww);
        dl->AddText(ImGui::GetFont(), fs * 1.15f, ImVec2(tx, p0.y + std::max(2.f, (ch - ts.y * 1.15f) * 0.5f)), IM_COL32(255, 255, 255, 255), n.c_str(), nullptr, ww);
        ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.62f, 0.22f, 0.24f, 1.f));
        bool ask = wrapui::Button("Borrar", ImVec2(delW, ch)) && tapped();
        ImGui::PopStyleColor();
        if (ask) ImGui::OpenPopup("del");
        if (open) openName = n;
        if (ImGui::BeginPopup("del")) {
            ImGui::Text("¿Borrar \"%s\" para siempre?", n.c_str());
            if (wrapui::Button("Sí, borrar")) { del = n; ImGui::CloseCurrentPopup(); }
            wrapui::Next("Cancelar");
            if (wrapui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        ImGui::PopID();
    }
            if (!del.empty()) { fs::removeTree(host_.dataDir + "/projects/" + del); listProjects(); }
        } else {
            struct Cat { const char* name; std::vector<int> ids; };
            static const Cat cats[] = {{"3D y acción", {0, 1, 3, 2, 14}}, {"2D arcade y aventura", {4, 5, 6, 7, 15}}, {"Terror", {8, 9}}, {"Móvil (toque)", {10, 11, 12, 13}}};
            float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
            int cols = avail > fs * 40.f ? 5 : avail > fs * 26.f ? 3 : 2;
            float tw = (avail - sp * (cols - 1)) / cols, th = std::max(fs * 4.6f, tw * 0.75f);
            static const int icons[10] = {wrapui::IcBolt, wrapui::IcBolt, wrapui::IcPlay, wrapui::IcUp, wrapui::IcUp, wrapui::IcBolt, wrapui::IcHome, wrapui::IcPen, wrapui::IcEye, wrapui::IcEye};
            static const ImVec4 cs[5] = {ImVec4(0.8f, 0.35f, 0.25f, 1), ImVec4(0.25f, 0.55f, 0.85f, 1), ImVec4(0.3f, 0.65f, 0.4f, 1), ImVec4(0.6f, 0.4f, 0.8f, 1), ImVec4(0.85f, 0.6f, 0.2f, 1)};
            for (auto& c : cats) {
                ImGui::SeparatorText(c.name);
                int k = 0;
                for (int i : c.ids) {
                    if (i >= templateCount()) continue;
                    if (k % cols) ImGui::SameLine();
                    k++;
                    ImGui::PushID(i);
                    if (wrapui::Tile("##t", templateInfo(i).name, icons[i % 10], cs[i % 5], ImVec2(tw, th)) && tapped()) { newTemplate_ = i; newProject(newName_.empty() ? sanitize(templateInfo(i).name) : newName_, false); }
                    ImGui::PopID();
                }
            }
            ImGui::TextDisabled("Cada plantilla es un punto de partida: cámbiale modelos, texturas y bloques.");
        }
    };
    if (wide) {
        float avail = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x;
        float lw = std::max(fs * 16.f, avail * 0.38f), ch = std::max(100.f, ImGui::GetContentRegionAvail().y - fs * 2.2f);
        wrapui::BeginChild("##home_l", ImVec2(lw, ch), false, kNoSB);
        dragScroll();
        startPanel(true);
        ImGui::EndChild();
        ImGui::SameLine();
        wrapui::BeginChild("##home_r", ImVec2(avail - lw - sp, ch), false, kNoSB);
        dragScroll();
        tabs();
        content();
        ImGui::EndChild();
    } else {
        startPanel(false);
        ImGui::Spacing();
        tabs();
        content();
    }
    if (!openName.empty()) { ImGui::End(); ImGui::PopStyleColor(); openProject(openName); return; }
    ImGui::Spacing();
    ImGui::TextDisabled("Los juegos que exportaste como .pack se pueden volver a abrir aquí.");
    ImGui::End();
    ImGui::PopStyleColor();
}

void Editor::keymapUI(bool& ch) {
    Project& P = edit_.proj;
    ImGui::SeparatorText("Teclas y mouse (Windows y control)");
    ImGui::TextDisabled("Por defecto: WASD mover, Espacio saltar, Shift correr, Ctrl agacharse, R recargar, Q arma, E interactuar, F linterna, clic = disparar. El control (gamepad) se mapea solo. En Android se mantiene la palanca y los botones en pantalla.");
    if (rebindAct_ >= 0) {
        ImGui::TextColored(ImVec4(1.f, 0.8f, 0.3f, 1.f), "Presiona la tecla para \"%s\" (Esc = cancelar)", keyActLabel(rebindAct_));
        int k = keyCaptureNext();
        if (k == ImGuiKey_Escape || (k == 0 && ImGui::IsKeyPressed(ImGuiKey_Escape, false))) rebindAct_ = -1;
        else if (k) { const char* n = keyToName(k); if (n) { P.keys[rebindAct_] = n; ch = true; } rebindAct_ = -1; }
    }
    for (int a = 0; a < KA_Count; a++) {
        ImGui::PushID(a + 900);
        std::string cur = keyEffective(P, a);
        ImGui::Text("%s: %s%s", keyActLabel(a), cur.c_str(), P.keys[a].empty() ? " (por defecto)" : "");
        ImGui::SameLine();
        if (wrapui::Button("Cambiar")) rebindAct_ = a;
        if (!P.keys[a].empty()) { ImGui::SameLine(); if (wrapui::Button("Restaurar")) { P.keys[a].clear(); ch = true; } }
        ImGui::PopID();
    }
}

void Editor::playFrame(Renderer* r, float dt) {
    play_.frame(r, w_, h_, dt);
    ImGui::SetNextWindowPos(ImVec2(10, 10));
    ImGui::SetNextWindowBgAlpha(0.5f);
    ImGui::Begin("##play", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                     ImGuiWindowFlags_NoSavedSettings);
    if (wrapui::Button("Detener", ImVec2(ImGui::GetFontSize() * 6.f, 0))) stopPlay();
#ifdef _WIN32
    if (ImGui::Checkbox("Ocultar botones virtuales", &hideVirtTest_)) play_.showButtons = !hideVirtTest_;
#endif
    ImGui::End();
}

static bool gAddModelReq = false;
static float gBarH = 0.f;
static float gBarTop() { return (gBarH > 0.f ? gBarH : ImGui::GetFrameHeight()) + 6.f; }

void Editor::editFrame(Renderer* r, float dt) {
    if (!hasScene() && !edit_.proj.scenes.empty()) setScene(0);
    play_.ctl.hud = nullptr;
    edit_.time += dt;
    undoTick(dt);
    if (ImGui::IsMouseClicked(0)) dragAcc_ = 0;
    if (ImGui::IsMouseDown(0)) dragAcc_ += std::fabs(ImGui::GetIO().MouseDelta.x) + std::fabs(ImGui::GetIO().MouseDelta.y);
    {   // Si el dedo se deslizó (scroll/arrastre) y se suelta sobre un botón, NO debe activarlo:
        // en el cuadro de la suelta se saca el puntero de la pantalla para que ningún botón lo reciba.
        static bool pressOnUi = false;
        ImGuiIO& io = ImGui::GetIO();
        if (io.MouseClicked[0]) pressOnUi = io.WantCaptureMouse;
        if (io.MouseReleased[0]) {
            float th = ImGui::GetFontSize() * 0.6f;
            if (pressOnUi && !ImGui::GetDragDropPayload() && io.MouseDragMaxDistanceSqr[0] > th * th) io.MousePos = ImVec2(-FLT_MAX, -FLT_MAX);
            pressOnUi = false;
        }
    }
    if (posPick_.on) posPickUI();
    enforceOneWindow();
    rend_ = r;
    if (layerPreview_ && page_ == Page::Viewport && hasScene() && r) drawCameraLayer(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_);
    if (hasScene() && scene().is3d) ensurePlayer(scene());
    if (page_ == Page::Scenes) { pageScenes(r); return; }
    if (page_ == Page::SceneHome) { pageSceneHome(r); return; }
    if (page_ == Page::Object) { pageObject(r); return; }
    menuBar();
    if (screen_ != Screen::Edit) return;  // el menu pudo cerrar el proyecto o iniciar el juego
    gestures();
    if (r && hasScene()) {
        EditorView ev = view();
        r->render(edit_, w_, h_, &ev);
        drawGizmo();
        if (page_ == Page::Viewport && (terrainPaint_ || gndPaint_ || vegPaint_)) {   // modo pintar activo: avisa y deja salir (si no, el gizmo desaparece y parece que nada responde)
            float fs2 = ImGui::GetFontSize();
            ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f, gBarTop() + fs2 * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.f));
            ImGui::SetNextWindowBgAlpha(0.85f);
            if (ImGui::Begin("##paintmode", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
                ImGui::TextUnformatted("MODO PINTAR ACTIVO (el dedo pinta, no mueve objetos)");
                if (ImGui::Button("Salir del modo pintar", ImVec2(0, fs2 * 2.4f))) { terrainPaint_ = gndPaint_ = vegPaint_ = false; }
            }
            ImGui::End();
        }
    }
    if (showHud && hasScene()) {
        Hud preview;
        preview.setup(edit_.proj);
        preview.draw(ImGui::GetBackgroundDrawList(), edit_, r, w_, h_, true);
    }
    {   // telefono: ventanas fijas, una a la vez, en la mitad de la pantalla
        gDock.on = (bool)host_.prompt;
        if (gDock.on) {
            float top = gBarTop();
            bool wide = w_ >= h_;
            gDock.x = wide ? w_ * 0.46f : 0.f;
            gDock.y = wide ? top : h_ * 0.46f;
            gDock.w = wide ? w_ * 0.54f : (float)w_;
            gDock.h = wide ? h_ - top : h_ * 0.54f;
            bool now[4] = {showObjs, showProps, showWorld, showHud};
            static bool prev[4] = {false, false, false, false};
            int keep = -1;
            for (int i = 0; i < 4; i++) if (now[i] && !prev[i]) keep = i;
            if (keep >= 0) {
                showObjs = keep == 0; showProps = keep == 1; showWorld = keep == 2; showHud = keep == 3;
                now[0] = showObjs; now[1] = showProps; now[2] = showWorld; now[3] = showHud;
            }
            for (int i = 0; i < 4; i++) prev[i] = now[i];
        }
    }
    objectsWin();
    propsWin();
    worldWin();
    mapWindow();
    orientWindow();
    hudWin(r);
    assetsWin();

    if (page_ == Page::Viewport && hasScene()) {   // botones rápidos de deshacer / rehacer
        float fs = ImGui::GetFontSize();
        ImGui::SetNextWindowPos(ImVec2(w_ * 0.5f - fs * 5.4f, h_ - fs * 3.2f), ImGuiCond_Always);
        ImGui::SetNextWindowBgAlpha(0.f);
        if (ImGui::Begin("##undo", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground)) {
            ImGui::BeginDisabled(undo_.empty());
            if (ImGui::Button("Deshacer", ImVec2(fs * 5.2f, fs * 2.1f))) doUndo(false);
            ImGui::EndDisabled();
            ImGui::SameLine();
            ImGui::BeginDisabled(redo_.empty());
            if (ImGui::Button("Rehacer", ImVec2(fs * 5.2f, fs * 2.1f))) doUndo(true);
            ImGui::EndDisabled();
        }
        ImGui::End();
    }
    if (!selObj()) {
        float fs = ImGui::GetFontSize();
        ImGui::GetBackgroundDrawList()->AddText(ImVec2(fs * 0.6f, h_ - fs * 1.6f), IM_COL32(255, 255, 255, 160),
                                                "Arrastra para girar - dos dedos: zoom y mover - toca un objeto para seleccionarlo - doble toque: sus propiedades");
    }
}

// ---------------------------------------------------------------- menu
// Barra superior flotante (estilo de las capturas de referencia): botones redondeados sobre la escena y JUGAR grande.
void Editor::menuBar() {
    float fs = ImGui::GetFontSize();
    float bh = fs * 2.6f, pad = fs * 0.5f;
    gBarH = bh + pad * 2.f - 6.f;
    bool doPlay = false, doPlayCur = false, doClose = false, doBack = false;
    const ImGuiWindowFlags wf = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove |
                                ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoBackground;
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.5f);
    ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, fs * 0.7f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(fs * 0.5f, 0));
    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.09f, 0.11f, 0.17f, 0.92f));
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.14f, 0.20f, 0.32f, 0.95f));
    ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.30f, 0.45f, 0.75f, 0.55f));
    auto sym = [&](const char* id, int kind, ImVec2 size) {  // boton con un icono dibujado (sin fuentes de iconos)
        bool hit = wrapui::Button(id, size);
        ImVec2 a = ImGui::GetItemRectMin(), b2 = ImGui::GetItemRectMax(), c((a.x + b2.x) * 0.5f, (a.y + b2.y) * 0.5f);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImU32 col = IM_COL32(235, 240, 250, 255);
        float r = fs * 0.55f;
        if (kind == 0) { dl->AddLine(ImVec2(c.x + r * 0.4f, c.y - r), ImVec2(c.x - r * 0.4f, c.y), col, 2.5f); dl->AddLine(ImVec2(c.x - r * 0.4f, c.y), ImVec2(c.x + r * 0.4f, c.y + r), col, 2.5f); }
        else if (kind == 1) {  // carpeta
            dl->AddRectFilled(ImVec2(c.x - r, c.y - r * 0.6f), ImVec2(c.x + r, c.y + r * 0.7f), IM_COL32(245, 190, 70, 255), 3.f);
            dl->AddRectFilled(ImVec2(c.x - r, c.y - r * 0.85f), ImVec2(c.x - r * 0.1f, c.y - r * 0.5f), IM_COL32(245, 190, 70, 255), 2.f);
        }
        return hit;
    };
    // ---- estilo común de los menús emergentes (mismo diseño que "Ventanas")
    auto pushPop = [&]() {
        ImGui::PushStyleVar(ImGuiStyleVar_PopupRounding, fs * 1.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(fs * 0.5f, fs * 0.5f));
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(fs * 0.5f, fs * 0.55f));
        ImGui::PushStyleVar(ImGuiStyleVar_PopupBorderSize, 1.5f);
        ImGui::PushStyleColor(ImGuiCol_PopupBg, ImVec4(0.12f, 0.20f, 0.14f, 0.90f));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.55f, 0.65f, 0.55f, 0.45f));
        ImGui::SetNextWindowSizeConstraints(ImVec2(fs * 13.f, 0.f), ImVec2(1e9f, 1e9f));
    };
    auto popPop = [&]() { ImGui::PopStyleColor(2); ImGui::PopStyleVar(4); };
    // ---- izquierda: volver, proyecto, escena
    ImGui::SetNextWindowPos(ImVec2(pad, pad));
    ImGui::Begin("##tbL", nullptr, wf);
    {
        ImGui::BeginGroup();
        if (sym("##back", 0, ImVec2(bh, bh))) doBack = true;
        ImGui::SameLine();
        if (sym("##proj", 1, ImVec2(bh, bh))) ImGui::OpenPopup("##pmenu");
        ImGui::SameLine();
        if (hasScene() && wrapui::Button(("Escena: " + shorten(scene().name, 16)).c_str(), ImVec2(0, bh))) ImGui::OpenPopup("##smenu");
        ImGui::EndGroup();
        ImGui::BeginGroup();
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8f, 0.85f, 0.95f, 0.9f));
        ImGui::SetCursorPosX(ImGui::GetCursorPosX() + fs * 0.4f);
        ImGui::TextUnformatted("Escena");
        ImGui::SameLine(bh + fs * 0.5f + fs * 0.1f);
        ImGui::TextUnformatted("Proyecto");
        ImGui::PopStyleColor();
        ImGui::EndGroup();
        ImGui::SetNextWindowPos(ImGui::GetItemRectMin(), ImGuiCond_Appearing);
        pushPop();
        bool pmOpen = ImGui::BeginPopup("##pmenu");
        if (pmOpen) {
            if (ImGui::MenuItem("Guardar")) saveProject();
            if (ImGui::MenuItem("Deshacer (Ctrl+Z)", nullptr, false, !undo_.empty())) doUndo(false);
            if (ImGui::MenuItem("Rehacer (Ctrl+Y)", nullptr, false, !redo_.empty())) doUndo(true);
            if (ImGui::MenuItem("Ayuda: guías paso a paso")) openHelp();
            if (ImGui::MenuItem("Exportar juego (APK, EXE, paquete)...")) showExport_ = true;
            if (ImGui::MenuItem("Editor de modelos 3D (crear y pintar)")) openVoxEditor();
            ImGui::Separator();
            if (ImGui::MenuItem("Cerrar proyecto")) doClose = true;
            ImGui::EndPopup();
        }
        popPop();
        pushPop();
        bool smOpen = hasScene() && ImGui::BeginPopup("##smenu");
        if (smOpen) {
            for (int i = 0; i < (int)edit_.proj.scenes.size(); i++) {
                auto& sc = edit_.proj.scenes[i];
                if (ImGui::MenuItem((sc.name + (sc.is3d ? (sc.side25 ? "  (2.5D)" : "  (3D)") : "  (2D)")).c_str(), nullptr, i == sceneIdx_)) { setScene(i); break; }
            }
            ImGui::Separator();
            if (ImGui::MenuItem("Nueva escena 3D")) addScene(true);
            if (ImGui::MenuItem("Nueva escena 2.5D (de lado)")) { addScene(true); scene().side25 = true; edit_.proj.player.sideView = true; markDirty(); }
            if (ImGui::MenuItem("Nueva escena 2D")) addScene(false);
            ImGui::EndPopup();
        }
        popPop();
    }
    ImGui::End();
    // ---- derecha: Añadir | Ventanas y JUGAR
    ImGui::SetNextWindowPos(ImVec2((float)w_ - pad, pad), ImGuiCond_Always, ImVec2(1.f, 0.f));
    ImGui::Begin("##tbR", nullptr, wf);
    {
        // Píldora con dos segmentos (+ Añadir | Ventanas) y JUGAR cuadrado al lado, como en la referencia.
        {
            float w1 = ImGui::CalcTextSize("Añadir").x + fs * 3.0f, w2 = ImGui::CalcTextSize("Ventanas").x + fs * 2.2f;
            ImVec2 p0 = ImGui::GetCursorScreenPos();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            float rr = fs * 1.0f;
            dl->AddRectFilled(p0, ImVec2(p0.x + w1 + w2, p0.y + bh), IM_COL32(22, 28, 44, 235), rr);
            dl->AddRect(p0, ImVec2(p0.x + w1 + w2, p0.y + bh), IM_COL32(110, 140, 200, 120), rr, 0, 1.5f);
            bool openW = ImGui::IsPopupOpen("##winmenu"), openA = ImGui::IsPopupOpen("##addmenu");
            if (openW) dl->AddRectFilled(ImVec2(p0.x + w1, p0.y + 2), ImVec2(p0.x + w1 + w2 - 2, p0.y + bh - 2), IM_COL32(255, 255, 255, 45), rr - 2, ImDrawFlags_RoundCornersRight);
            if (openA) dl->AddRectFilled(ImVec2(p0.x + 2, p0.y + 2), ImVec2(p0.x + w1, p0.y + bh - 2), IM_COL32(255, 255, 255, 45), rr - 2, ImDrawFlags_RoundCornersLeft);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1, 1, 1, 0.08f));
            ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0, 0, 0, 0));
            ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(0, 0));
            if (ImGui::Button("##addb", ImVec2(w1, bh))) ImGui::OpenPopup("##addmenu");
            ImVec2 a1 = ImGui::GetItemRectMin();
            ImGui::SameLine();
            if (ImGui::Button("##winb", ImVec2(w2, bh))) ImGui::OpenPopup("##winmenu");
            ImVec2 a2 = ImGui::GetItemRectMin();
            ImGui::PopStyleVar();
            ImGui::PopStyleColor(3);
            ImU32 tc = IM_COL32(240, 244, 252, 255);
            float cy = p0.y + bh * 0.5f, pr = fs * 0.5f;
            dl->AddLine(ImVec2(a1.x + fs * 0.6f, cy), ImVec2(a1.x + fs * 0.6f + pr * 2, cy), tc, 2.5f);
            dl->AddLine(ImVec2(a1.x + fs * 0.6f + pr, cy - pr), ImVec2(a1.x + fs * 0.6f + pr, cy + pr), tc, 2.5f);
            dl->AddText(ImVec2(a1.x + fs * 2.2f, cy - fs * 0.5f), tc, "Añadir");
            dl->AddText(ImVec2(a2.x + fs * 1.1f, cy - fs * 0.5f), tc, "Ventanas");
            ImGui::SameLine(0, fs * 0.6f);
        }
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.12f, 0.50f, 0.48f, 0.98f));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.16f, 0.62f, 0.58f, 1.f));
        ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.55f, 0.95f, 0.85f, 0.5f));
        if (ImGui::Button("##jugar", ImVec2(bh * 1.55f, bh * 1.2f))) doPlay = true;
        {   // triángulo de "play" arriba y la palabra JUGAR abajo
            ImVec2 a = ImGui::GetItemRectMin(), b2 = ImGui::GetItemRectMax();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            float cx = (a.x + b2.x) * 0.5f, cy = a.y + (b2.y - a.y) * 0.34f, r = fs * 0.62f;
            dl->AddTriangleFilled(ImVec2(cx - r * 0.7f, cy - r), ImVec2(cx - r * 0.7f, cy + r), ImVec2(cx + r, cy), IM_COL32(255, 255, 255, 245));
            ImVec2 ts = ImGui::CalcTextSize("JUGAR");
            dl->AddText(ImVec2(cx - ts.x * 0.5f, b2.y - ts.y - fs * 0.45f), IM_COL32(255, 255, 255, 255), "JUGAR");
        }
        ImGui::PopStyleColor(3);
        ImGui::SameLine(0, fs * 0.3f);
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.14f, 0.38f, 0.62f, 0.98f));
        if (ImGui::Button("##jugaresc", ImVec2(bh * 1.55f, bh * 1.2f))) doPlayCur = true;
        {
            ImVec2 a = ImGui::GetItemRectMin(), b2 = ImGui::GetItemRectMax();
            ImDrawList* dl = ImGui::GetWindowDrawList();
            float cx = (a.x + b2.x) * 0.5f, cy = a.y + (b2.y - a.y) * 0.34f, r = fs * 0.5f;
            dl->AddTriangleFilled(ImVec2(cx - r * 0.7f, cy - r), ImVec2(cx - r * 0.7f, cy + r), ImVec2(cx + r, cy), IM_COL32(255, 255, 255, 245));
            const char* t1 = "Jugar escena", *t2 = "actual";
            float y0 = b2.y - fs * 2.05f;
            ImVec2 s1 = ImGui::CalcTextSize(t1), s2 = ImGui::CalcTextSize(t2);
            dl->AddText(ImVec2(cx - s1.x * 0.5f, y0), IM_COL32(255, 255, 255, 255), t1);
            dl->AddText(ImVec2(cx - s2.x * 0.5f, y0 + fs * 0.95f), IM_COL32(255, 255, 255, 255), t2);
        }
        ImGui::PopStyleColor();
        if (dirty_) { ImGui::SameLine(); ImGui::TextDisabled("*"); }
        ImVec2 anchor(ImGui::GetWindowPos().x + ImGui::GetWindowSize().x - fs * 0.2f, ImGui::GetWindowPos().y + bh + fs * 0.4f);
        ImGui::SetNextWindowPos(anchor, ImGuiCond_Always, ImVec2(1.f, 0.f));
        pushPop();
        bool addOpen = ImGui::BeginPopup("##addmenu");
        if (addOpen) {
            bool is3d = hasScene() && scene().is3d;
            if (ImGui::MenuItem(is3d ? "Cubo" : "Cuadro / botón")) addObject(Kind::Cube);
            if (!is3d) {
                if (ImGui::BeginMenu("Objetos listos (editables)")) {
                    static const struct { int id; const char* n; } L2[] = {{100, "Plataforma"}, {101, "Moneda (toca y suma)"}, {102, "Botón con mensaje"},
                        {103, "Personaje con gravedad"}, {104, "Enemigo que patrulla"}, {107, "Enemigo que dispara"}, {108, "Enemigo cuerpo a cuerpo"}, {105, "Pelota que rebota"}, {106, "Meta (cambia de escena)"}};
                    for (auto& it : L2) if (ImGui::MenuItem(it.n)) addPreset(it.id);
                    ImGui::EndMenu();
                }
                if (ImGui::MenuItem("Modelo 3D...")) gAddModelReq = true;
            }
            if (is3d) {
                if (ImGui::BeginMenu("Objetos de juego")) {
                    static const struct { int id; const char* n; } L[] = {{10, "Enemigo"}, {11, "Monstruo"}, {12, "Arma"}, {13, "Munición"},
                        {14, "Botiquín"}, {15, "Llave"}, {16, "Interruptor"}, {24, "Cartel"}, {17, "Puerta horizontal"}, {18, "Puerta vertical"},
                        {19, "Destruible horizontal"}, {20, "Destruible vertical"}, {21, "Fin de nivel"}, {22, "Teleport inicio"},
                        {23, "Teleport fin"}, {25, "Inicio del jugador"}};
                    for (auto& it : L) if (ImGui::MenuItem(it.n)) addPreset(it.id);
                    ImGui::EndMenu();
                }
                if (ImGui::MenuItem("Suelo")) addObject(Kind::Floor);
                if (ImGui::MenuItem("Pared")) addObject(Kind::Wall);
                if (ImGui::MenuItem("Item")) addObject(Kind::Item);
                if (ImGui::MenuItem("Luz")) addObject(Kind::Light);
                if (ImGui::MenuItem("Modelo 3D...")) gAddModelReq = true;
                if (ImGui::MenuItem("Crear modelo 3D (editor)")) openVoxEditor();
            }
            ImGui::EndPopup();
        }
        popPop();
        ImGui::SetNextWindowPos(anchor, ImGuiCond_Always, ImVec2(1.f, 0.f));
        pushPop();
        bool winOpen = ImGui::BeginPopup("##winmenu");
        if (winOpen) {
            auto item = [&](int kind, const char* label, bool* v) {
                float h = fs * 2.5f;
                if (ImGui::Selectable((std::string("##wi") + label).c_str(), *v, 0, ImVec2(fs * 13.f, h))) *v = !*v;
                ImVec2 a = ImGui::GetItemRectMin();
                ImDrawList* dl = ImGui::GetWindowDrawList();
                ImVec2 c(a.x + fs * 1.4f, a.y + h * 0.5f);
                ImU32 col = IM_COL32(225, 230, 240, 255);
                float r = fs * 0.7f;
                if (kind == 0) {  // cubo
                    dl->AddLine(ImVec2(c.x, c.y - r), ImVec2(c.x + r, c.y - r * 0.45f), col, 2.f); dl->AddLine(ImVec2(c.x + r, c.y - r * 0.45f), ImVec2(c.x + r, c.y + r * 0.45f), col, 2.f);
                    dl->AddLine(ImVec2(c.x + r, c.y + r * 0.45f), ImVec2(c.x, c.y + r), col, 2.f); dl->AddLine(ImVec2(c.x, c.y + r), ImVec2(c.x - r, c.y + r * 0.45f), col, 2.f);
                    dl->AddLine(ImVec2(c.x - r, c.y + r * 0.45f), ImVec2(c.x - r, c.y - r * 0.45f), col, 2.f); dl->AddLine(ImVec2(c.x - r, c.y - r * 0.45f), ImVec2(c.x, c.y - r), col, 2.f);
                    dl->AddLine(ImVec2(c.x - r, c.y - r * 0.45f), ImVec2(c.x, c.y), col, 2.f); dl->AddLine(ImVec2(c.x + r, c.y - r * 0.45f), ImVec2(c.x, c.y), col, 2.f); dl->AddLine(ImVec2(c.x, c.y), ImVec2(c.x, c.y + r), col, 2.f);
                } else if (kind == 1) {  // engranaje
                    for (int k = 0; k < 8; k++) { float t = k * 0.7854f; dl->AddLine(ImVec2(c.x + std::cos(t) * r * 0.75f, c.y + std::sin(t) * r * 0.75f), ImVec2(c.x + std::cos(t) * r * 1.05f, c.y + std::sin(t) * r * 1.05f), col, 3.5f); }
                    dl->AddCircleFilled(c, r * 0.85f, col); dl->AddCircleFilled(c, r * 0.35f, IM_COL32(40, 55, 40, 255));
                } else if (kind == 2) {  // sol y nube
                    dl->AddCircleFilled(ImVec2(c.x - r * 0.3f, c.y - r * 0.3f), r * 0.5f, IM_COL32(255, 205, 80, 255));
                    dl->AddCircleFilled(ImVec2(c.x + r * 0.2f, c.y + r * 0.35f), r * 0.5f, col); dl->AddCircleFilled(ImVec2(c.x - r * 0.35f, c.y + r * 0.5f), r * 0.4f, col);
                    dl->AddRectFilled(ImVec2(c.x - r * 0.35f, c.y + r * 0.35f), ImVec2(c.x + r * 0.2f, c.y + r * 0.9f), col);
                } else if (kind == 3) {  // teclado
                    dl->AddRect(ImVec2(c.x - r * 1.1f, c.y - r * 0.6f), ImVec2(c.x + r * 1.1f, c.y + r * 0.6f), col, 3.f, 0, 2.f);
                    for (int k = 0; k < 3; k++) for (int m = 0; m < 4; m++) dl->AddRectFilled(ImVec2(c.x - r * 0.85f + m * r * 0.5f, c.y - r * 0.35f + k * r * 0.35f), ImVec2(c.x - r * 0.7f + m * r * 0.5f, c.y - r * 0.25f + k * r * 0.35f), col);
                } else {  // archivo
                    dl->AddRectFilled(ImVec2(c.x - r * 0.7f, c.y - r), ImVec2(c.x + r * 0.7f, c.y + r), col, 3.f);
                    dl->AddTriangleFilled(ImVec2(c.x + r * 0.1f, c.y - r), ImVec2(c.x + r * 0.7f, c.y - r * 0.4f), ImVec2(c.x + r * 0.1f, c.y - r * 0.4f), IM_COL32(120, 130, 150, 255));
                }
                dl->AddText(ImVec2(a.x + fs * 2.8f, a.y + h * 0.5f - fs * 0.5f), IM_COL32(240, 244, 252, 255), label);
            };
            item(0, "Objetos", &showObjs);
            item(1, "Propiedades", &showProps);
            item(2, "Mundo (cielo y luz)", &showWorld);
            item(3, "Botones y arma", &showHud);
            item(4, "Archivos", &showAssets);
            ImGui::EndPopup();
        }
        popPop();
    }
    ImGui::End();
    ImGui::PopStyleColor(3);
    ImGui::PopStyleVar(4);
    {
        static std::string pickedModel;
        bool got = gridPicker("##addmodelpick", pickedModel, 2, nullptr, gAddModelReq);
        gAddModelReq = false;
        if (got && !pickedModel.empty()) { addObject(Kind::Model, pickedModel); pickedModel.clear(); }
    }
    if (doBack) { page_ = Page::SceneHome; return; }
    if (doClose) closeProject();
    else if (doPlay) startPlay(false);
    else if (doPlayCur) startPlay(true);
}

// ---------------------------------------------------------------- ventanas
// En el telefono las ventanas van fijas (no se arrastran por accidente) y se desliza el dedo para ver todo.
static void placeWindow(float x, float y, float w, float h) {
    if (gDock.on) {
        ImGui::SetNextWindowPos(ImVec2(gDock.x, gDock.y), ImGuiCond_Always);
        ImGui::SetNextWindowSize(ImVec2(gDock.w, gDock.h), ImGuiCond_Always);
        return;
    }
    ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(w, h), ImGuiCond_FirstUseEver);
}
static ImGuiWindowFlags dockFlags() { return gDock.on ? (ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSW | ImGuiWindowFlags_NoCollapse) : 0; }

void Editor::objectsWin() {
    if (!showObjs || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = gBarTop();
    placeWindow(6, top, fs * 14.f, h_ * 0.5f);
    if (wrapui::Begin("Objetos", &showObjs, dockFlags())) {
        wrapui::CloseBar(&showObjs);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        for (int i = 0; i < (int)S.objs.size(); i++) {
            const Obj& o = S.objs[i];
            static const char tags[] = {'C', 'S', 'P', 'I', 'M', 'L', 'J'};
            std::string lab = std::string("[") + tags[(int)o.kind] + "] " + o.name + (o.visible ? "" : " (oculto)");
            ImGui::PushID(i);
            bool lk = o.locked;
            ImGui::PushStyleColor(ImGuiCol_Button, lk ? ImVec4(0.85f, 0.55f, 0.15f, 1.f) : ImVec4(0.25f, 0.30f, 0.38f, 1.f));
            if (ImGui::SmallButton(lk ? "Bloq" : "Libre") && tapped()) { scene().objs[i].locked = !lk; markDirty(); }
            ImGui::PopStyleColor();
            ImGui::SameLine();
            if (wrapui::Selectable(lab.c_str(), sel_ == i)) sel_ = i;
            ImGui::PopID();
        }
        if (S.objs.empty()) ImGui::TextDisabled("Escena vacía. Usa el menú Añadir.");
        ImGui::Separator();
        ImGui::SetNextItemWidth(fs * 5.f);
        numField("Rejilla", snap_, 0.f, 2.f);
        if (Obj* so = selObj()) {   // transformar rápido el objeto elegido: tamaño, medidas, giro e inclinación
            ImGui::Separator();
            ImGui::TextDisabled("Transformar: %s", so->name.c_str());
            bool ch = false;
            if (so->kind != Kind::Light) {
                ch |= stepper(S.is3d ? "Ancho" : "Ancho", so->scale.x, S.is3d ? 0.5f : 10.f);
                ch |= stepper(S.is3d ? "Alto" : "Alto", so->scale.y, S.is3d ? 0.5f : 10.f);
                if (S.is3d) ch |= stepper("Fondo", so->scale.z, 0.5f);
                ch |= stepper(S.is3d ? "Girar (horizontal)" : "Girar", so->yaw, 15.f);
                ch |= sizeTiltPanel(*so, S.is3d);
            }
            if (ch) markDirty();
        }
    }
    ImGui::End();
}

// Miniatura de una imagen (kind 0) o de un modelo 3D (kind 2) en el lugar del cursor.
void Editor::assetThumb(const std::string& name, int kind, float size) {
    auto fs0 = []() { return ImGui::GetFontSize(); };
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImGui::Dummy(ImVec2(size, size));
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + size, p.y + size), IM_COL32(28, 33, 45, 255), 6.f);
    unsigned id = 0;
    int tw = 1, th = 1;
    if (rend_ && !name.empty()) {
        if (kind == 0) {
            id = rend_->textureId(edit_, name, &tw, &th);
        } else {
            auto a = edit_.proj.assets.find(name);
            if (a != edit_.proj.assets.end()) {
                int pxs = size > fs0() * 4.f ? 192 : 96;
                std::string key = "prev:" + name + ":" + std::to_string(a->second.size()) + ":" + std::to_string(pxs);
                if (rend_->hasTexture(key)) {
                    id = rend_->uploadRGBA(key, 0, 0, nullptr);
                } else {
                    static int lastFrame = -1, made = 0;
                    if (lastFrame != ImGui::GetFrameCount()) { lastFrame = ImGui::GetFrameCount(); made = 0; }
                    // solo se generan las miniaturas visibles y pocas por cuadro (la pantalla no se traba al abrir el selector)
                    if (ImGui::IsRectVisible(p, ImVec2(p.x + size, p.y + size)) && made < 2) {
                        made++;
                        std::vector<uint8_t> px;
                        if (modelPreviewRGBA(a->second, edit_.proj.assets, pxs, px)) id = rend_->uploadRGBA(key, pxs, pxs, px.data());
                    }
                }
                tw = th = 1;
            }
        }
    }
    if (id) {
        float k = kind == 0 ? std::min(size / tw, size / th) : size;
        float iw = kind == 0 ? tw * k : size, ih = kind == 0 ? th * k : size;
        ImVec2 a(p.x + (size - iw) * 0.5f, p.y + (size - ih) * 0.5f);
        dl->AddImage((ImTextureID)(intptr_t)id, a, ImVec2(a.x + iw, a.y + ih), ImVec2(0, kind == 0 ? 1 : 0), ImVec2(1, kind == 0 ? 0 : 1));
    } else if (!name.empty()) {
        dl->AddText(ImVec2(p.x + size * 0.3f, p.y + size * 0.2f), IM_COL32(150, 160, 180, 255), kind == 0 ? "IMG" : "3D");
    }
}

// Cuadrícula grande de miniaturas (ventana casi a pantalla completa). Devuelve true si se eligió algo.
// Apartados de los modelos que ya trae el sistema (se clasifican por su nombre).
static const char* const kLibCatNames[] = {"Todos", "Personajes", "Árboles y vegetación", "Rocas", "Casas y estructuras", "Carros", "Muebles", "Electrodomésticos", "Comida y bebida", "Cocina y hogar", "Limpieza y baño", "Armas", "Juego (bolas, estrellas...)", "Otros"};
static const int kLibCatCount = 14;
static int libCat(const std::string& full) {
    std::string n = full.compare(0, 4, "lib_") == 0 ? full.substr(4) : full;
    auto has = [&](std::initializer_list<const char*> ws) { for (auto w : ws) if (n.find(w) != std::string::npos) return true; return false; };
    auto pre = [&](const char* p) { return n.compare(0, strlen(p), p) == 0; };
    if (pre("pj_") || pre("maniqui")) return 1;
    if (pre("bosque_rock")) return 3;
    if (pre("bosque_")) return 2;
    if (pre("auto_") || pre("veh_")) return 5;
    if (pre("kn_blaster") || pre("kn_clip") || pre("kn_foam")) return 11;
    if (pre("kn_")) return 12;
    if (pre("kk_")) return has({"platform", "arch", "barrier", "railing", "pipe", "signage", "button", "lever", "hoop"}) ? 4 : 12;
    if (has({"plants"})) return 2;
    if (has({"door", "window", "plane_"})) return 4;
    if (has({"stove", "refrigerator", "microwave", "toaster", "blender", "tv", "radio", "video", "washing", "machine", "coffee", "maker", "control"})) return 7;
    if (has({"armchair", "chair", "table", "bed", "shelf", "cajonera", "cabinet", "lamps", "paintings", "carrier"})) return 6;
    if (has({"soap", "toilet", "washbasin", "shampoo", "toothpaste", "toothbrush", "broom", "mop", "trash", "dirty", "softener", "chemical", "watering", "bathroom", "powder", "paper", "magazine", "book"})) return 10;
    if (has({"frying", "pot", "sarten", "knife", "spoon", "fork", "dish", "bowl", "cup", "vaso", "basket", "tapa", "manija", "wrapper", "oil", "cylinder", "bote", "holder", "box", "hand"})) return 9;
    if (has({"cookies", "food", "soda", "canned", "can", "cereal", "meat", "bread", "pizza", "burger", "donut", "beet", "potato", "coconut", "cucumber", "eggplant", "papaya", "pineapple", "rice", "roast", "sauce", "yam", "banana", "flour", "sliced", "water", "zucchini", "apple", "artichoke", "avocado", "brussel", "cabbage", "cantaloupe", "cauliflower", "egg", "fried", "chicken", "garlic", "grape", "hot", "kiwi", "lemon", "mango", "mushroom", "onion", "orange", "pear", "chips", "strawberry", "turnip", "asparagus", "broccoli", "celery", "lettuce", "popcorn", "pumpkin", "spinach", "waffle", "frozen", "milk", "rolls", "raw", "coffee"})) return 8;
    return 13;
}

bool Editor::gridPicker(const char* id, std::string& cur, int kind, const char* none, bool open) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    if (open) {
        ImGui::OpenPopup(id);
        for (auto& li : libraryItems())  // biblioteca de P-Maker: modelos, texturas y sonidos listos para elegir
            if (li.kind == kind && !edit_.proj.assets.count(li.name) && libraryAdd(li.name, edit_.proj.assets)) assetDirty_.insert(li.name);
        if (kind == 2 && edit_.proj.assets.count("lib_paleta.png")) assetDirty_.insert("lib_paleta.png");
    }
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.02f, h_ * 0.02f));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.96f, h_ * 0.96f));
    if (ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | kNoSB |
                                                kNoSW | ImGuiWindowFlags_NoSavedSettings)) {
        // barra fija arriba
        ImGui::AlignTextToFramePadding();
        ImGui::TextUnformatted(kind == 0 ? "Elige una textura" : kind == 2 ? "Elige un modelo 3D" : "Elige un sonido");
        wrapui::Next("Cerrar");
        if (wrapui::Button("Cerrar", ImVec2(fs * 6.f, fs * 2.2f)) && tapped()) ImGui::CloseCurrentPopup();
        if (none) {
            ImGui::SameLine();
            if (wrapui::Button(none, ImVec2(0, fs * 2.2f)) && tapped()) { cur.clear(); ch = true; ImGui::CloseCurrentPopup(); }
        }
        if (host_.pickFile) {
            wrapui::Next("Importar desde archivos...");
            if (wrapui::Button("Importar desde archivos...", ImVec2(0, fs * 2.2f)) && tapped()) host_.pickFile();
        }
        if (kind == 0) {
            wrapui::Next("Dibujar una nueva");
            if (wrapui::Button("Dibujar una nueva", ImVec2(0, fs * 2.2f)) && tapped()) { ImGui::CloseCurrentPopup(); openPaint(""); }
        }
        ImGui::Separator();
        wrapui::BeginChild("##grid", ImVec2(0, 0), false, kNoSB);
        dragScroll();
        float cell = fs * (kind == 1 ? 9.f : 8.f), gap = fs * 0.6f;
        int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + gap) / (cell + gap)));
        auto items = assetsOf(kind);
        if (items.empty()) ImGui::TextDisabled("No hay archivos de este tipo todavía. Usa \"Importar desde archivos\".");
        // 3 apartados: importados, creados (dibujados / hechos en el editor) y por defecto del sistema
        std::vector<std::string> sec[3];
        for (auto& it : items) {
            bool sys = it.compare(0, 4, "lib_") == 0;
            bool made = !sys && ((kind == 0 && it.compare(0, 6, "dibujo") == 0) || (kind == 2 && it.compare(0, 6, "voxel_") == 0));
            sec[sys ? 2 : made ? 1 : 0].push_back(it);
        }
        static const char* secName[3] = {"Importadas", "Creadas", "Por defecto"};
        static const char* secNameM[3] = {"Importados", "Creados", "Por defecto"};
        static int tabSel = -1; static std::string tabId;
        if (open || tabId != id) { tabSel = -1; tabId = id; }
        if (tabSel < 0) {   // abre en el apartado del elegido; si no hay, en el primero con cosas
            for (int si = 0; si < 3 && tabSel < 0; si++) for (auto& it : sec[si]) if (it == cur) { tabSel = si; break; }
            for (int si = 2; si >= 0 && tabSel < 0; si--) if (!sec[si].empty()) tabSel = si;
            if (tabSel < 0) tabSel = 2;
        }
        {   // 3 botones: según el que toques salen los modelos, texturas o sonidos de ese apartado
            float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x, bw = (aw - sp * 2.f) / 3.f;
            for (int si = 0; si < 3; si++) {
                if (si) ImGui::SameLine();
                char lb[64]; snprintf(lb, sizeof lb, "%s (%d)", (kind == 2 ? secNameM : secName)[si], (int)sec[si].size());
                ImGui::PushStyleColor(ImGuiCol_Button, tabSel == si ? ImVec4(0.18f, 0.55f, 0.85f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
                ImGui::PushID(si + 700);
                if (wrapui::Button(lb, ImVec2(bw, fs * 2.4f)) && tapped()) tabSel = si;
                ImGui::PopID();
                ImGui::PopStyleColor();
            }
            ImGui::Spacing();
        }
        static int catSel = 0;
        std::vector<std::string> shown;
        if (kind == 2 && tabSel == 2) {   // dentro de «Por defecto»: sub-apartados (personajes, árboles, carros, comida, armas...)
            int cnt[kLibCatCount] = {0};
            for (auto& it : sec[2]) { cnt[0]++; cnt[libCat(it)]++; }
            if (catSel >= kLibCatCount || (catSel > 0 && cnt[catSel] == 0)) catSel = 0;
            float x0 = ImGui::GetCursorPosX(), maxX = ImGui::GetContentRegionAvail().x + x0, curX = x0;
            for (int c = 0; c < kLibCatCount; c++) {
                if (c > 0 && cnt[c] == 0) continue;
                char lb[96]; snprintf(lb, sizeof lb, "%s (%d)", kLibCatNames[c], cnt[c]);
                float bw2 = ImGui::CalcTextSize(lb).x + fs * 1.6f;
                if (c > 0 && curX + bw2 > maxX) { curX = x0; } else if (c > 0) ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Button, catSel == c ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
                ImGui::PushID(c + 900);
                if (wrapui::Button(lb, ImVec2(bw2, fs * 1.9f)) && tapped()) catSel = c;
                ImGui::PopID();
                ImGui::PopStyleColor();
                curX += bw2 + ImGui::GetStyle().ItemSpacing.x;
            }
            ImGui::Spacing();
            for (auto& it : sec[2]) if (catSel == 0 || libCat(it) == catSel) shown.push_back(it);
        } else shown = sec[tabSel];
        if (shown.empty()) ImGui::TextDisabled("Aquí no hay nada todavía.");
        for (int si = tabSel; si == tabSel; si++) {
            int n = 0;
            for (auto& it : shown) {
                if (n % cols) ImGui::SameLine(0, gap);
                n++;
                ImGui::PushID(it.c_str());
                ImGui::BeginGroup();
                ImVec2 p = ImGui::GetCursorScreenPos();
                bool sel = it == cur;
                if (kind != 1) assetThumb(it, kind, cell);
                else ImGui::Dummy(ImVec2(cell, cell * 0.6f));
                ImVec2 pe(p.x + cell, p.y + (kind == 1 ? cell * 0.6f : cell));
                ImGui::SetCursorScreenPos(p);
                bool hit = ImGui::InvisibleButton("##pick", ImVec2(cell, pe.y - p.y)) && tapped();
                ImDrawList* dl = ImGui::GetWindowDrawList();
                if (kind == 1) dl->AddRectFilled(p, pe, IM_COL32(40, 48, 66, 255), 8.f);
                if (sel) dl->AddRect(p, pe, IM_COL32(30, 220, 190, 255), 8.f, 0, 3.f);
                else if (ImGui::IsItemHovered()) dl->AddRect(p, pe, IM_COL32(255, 255, 255, 90), 8.f, 0, 2.f);
                if (kind == 1) dl->AddText(ImVec2(p.x + fs * 0.6f, p.y + cell * 0.2f), IM_COL32(220, 230, 250, 255), "SONIDO");
                ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + cell);
                ImGui::TextUnformatted(shorten(it, 22).c_str());
                ImGui::PopTextWrapPos();
                ImGui::EndGroup();
                if (hit) { cur = it; ch = true; ImGui::CloseCurrentPopup(); }
                ImGui::PopID();
            }
        }
        ImGui::Dummy(ImVec2(1, fs * 2.f));
        ImGui::EndChild();
        ImGui::EndPopup();
    }
    return ch;
}

// Selector con previsualizacion: muestra la miniatura del elegido; al tocarlo abre la cuadrícula grande.
bool Editor::assetCombo(const char* label, std::string& cur, int kind, const char* none) {
    float fs = ImGui::GetFontSize();
    ImGui::PushID(label);
    assetThumb(cur, kind, fs * 3.2f);
    ImGui::SameLine();
    ImGui::BeginGroup();
    ImGui::TextUnformatted(label);
    const char* preview = cur.empty() ? (none ? none : "(ninguno)") : cur.c_str();
    bool open = wrapui::Button((shorten(preview, 24) + "  [cambiar]").c_str()) && tapped();
    ImGui::EndGroup();
    bool ch = gridPicker("##gridpick", cur, kind, none, open);
    ImGui::PopID();
    return ch;
}

// Suelo deformable: montañas y hoyos que también cambian la colisión.
bool Editor::terrainPanel(Obj& o) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Terreno (montañas)");
    if (o.tn < 2) {
        ImGui::TextWrapped("Convierte este suelo en terreno para subirlo y bajarlo con el dedo. Más puntos = más detalle (y más lento).");
        static const int sizes[3] = {24, 48, 80};
        static const char* nm[3] = {"Básico (24)", "Medio (48)", "Fino (80)"};
        for (int i = 0; i < 3; i++) {
            if (i) ImGui::SameLine();
            if (wrapui::Button(nm[i], ImVec2(0, fs * 2.2f)) && tapped()) { terrainInit(o, sizes[i]); ch = true; }
        }
        return ch;
    }
    wrapui::Checkbox("Modo esculpir (tocar y arrastrar sobre el terreno)", &terrainPaint_);
    if (terrainPaint_) ImGui::TextDisabled("Con este modo activo, un dedo esculpe; dos dedos mueven y acercan la cámara.");
    static const char* modes[4] = {"Subir montaña", "Bajar / quitar", "Aplanar", "Suavizar"};
    for (int i = 0; i < 4; i++) {
        bool sel = terrMode_ == i;
        if (i % 2) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, sel ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(modes[i], ImVec2(ImGui::GetContentRegionAvail().x * (i % 2 ? 1.f : 0.5f) - (i % 2 ? 0.f : 4.f), fs * 2.2f)) && tapped()) terrMode_ = i;
        ImGui::PopStyleColor();
    }
    numField("Tamaño del pincel", terrRadius_, 0.5f, 20.f);
    numField("Fuerza", terrStrength_, 0.5f, 20.f);
    if (wrapui::Button("Dejar plano", ImVec2(0, fs * 2.2f)) && tapped()) { std::fill(o.heights.begin(), o.heights.end(), 0.f); o.terrVer++; ch = true; }
    wrapui::Next("Volver a suelo normal");
    if (wrapui::Button("Volver a suelo normal", ImVec2(0, fs * 2.2f)) && tapped()) { o.tn = 0; o.heights.clear(); terrainPaint_ = false; ch = true; }
    ImGui::TextDisabled("La colisión sigue la forma: se pueden subir laderas suaves; las muy empinadas bloquean.");
    return ch;
}

// Datos de un esqueleto (.fanim) ya leídos: se vuelven a leer solo si el archivo cambió. Antes se leían TODOS los esqueletos en cada cuadro
// (más de 1 MB de texto cada uno) y por eso el menú del objeto iba muy lento.
struct RigInfo { std::string model; std::vector<std::string> clips; bool ok = false; };
static const RigInfo& rigInfoOf(const std::string& name, const std::vector<uint8_t>& d) {
    struct Ent { size_t size = 0; unsigned long long h = 0; RigInfo info; };
    static std::map<std::string, Ent> cache;
    unsigned long long h = 1469598103934665603ULL;
    for (size_t i = 0; i < d.size(); i += 251) { h ^= d[i]; h *= 1099511628211ULL; }
    if (!d.empty()) { h ^= d.back(); h *= 1099511628211ULL; }
    Ent& e = cache[name];
    if (e.size == d.size() && e.h == h && (e.info.ok || e.size != 0)) return e.info;
    e.size = d.size(); e.h = h; e.info = RigInfo();
    Rig r;
    if (rigRead(std::string(d.begin(), d.end()), r)) {
        e.info.ok = true; e.info.model = r.model;
        for (auto& c : r.clips) e.info.clips.push_back(c.name);
    }
    return e.info;
}

// Nombres de las animaciones de esqueleto que sirven para este objeto (las de su esqueleto, o las de su modelo).
std::vector<std::string> Editor::clipsFor(const Obj& o) const {
    std::vector<std::string> v;
    for (auto& a : edit_.proj.assets) {
        if (!ends(a.first, ".fanim")) continue;
        const RigInfo& r = rigInfoOf(a.first, a.second);
        if (!r.ok) continue;
        if (!o.rig.empty() ? a.first != o.rig : r.model != o.model) continue;
        for (auto& c : r.clips) v.push_back(c);
    }
    return v;
}

bool Editor::clipCombo(const char* label, const Obj& o, std::string& clip) {
    bool ch = false;
    if (wrapui::BeginCombo(label, clip.empty() ? "(ninguna)" : clip.c_str())) {
        if (wrapui::Selectable("(ninguna)", clip.empty())) { clip.clear(); ch = true; }
        for (auto& n : clipsFor(o)) if (wrapui::Selectable(n.c_str(), n == clip)) { clip = n; ch = true; }
        ImGui::EndCombo();
    }
    return ch;
}

// Animación con esqueleto: archivo de esqueleto del objeto y animación que se reproduce.
bool Editor::skelPanel(Obj& o) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Animación con esqueleto");
    std::string curRig = o.rig.empty() ? "(el de su modelo)" : o.rig;
    if (wrapui::BeginCombo("Esqueleto", curRig.c_str())) {
        if (wrapui::Selectable("(el de su modelo)", o.rig.empty())) { o.rig.clear(); ch = true; }
        for (auto& a : edit_.proj.assets) if (ends(a.first, ".fanim") && wrapui::Selectable(a.first.c_str(), a.first == o.rig)) { o.rig = a.first; ch = true; }
        ImGui::EndCombo();
    }
    ch |= clipCombo("Animación inicial", o, o.clip);
    if (wrapui::Button("Abrir editor de animación", ImVec2(0, fs * 2.2f)) && tapped()) openAnimEditor(o.rig);
    ImGui::TextDisabled("Con el bloque \"Reproducir animación de esqueleto\" puedes cambiarla jugando.");
    return ch;
}

bool Editor::fxPanel(Obj& o) {
    FxCfg& f = o.fx;
    bool ch = wrapui::Checkbox("Lanza partículas", &f.on);
    if (!f.on && f.rate <= 0) return ch;
    ImGui::TextDisabled("Elige un efecto y luego cámbialo como quieras:");
    static const char* names[5] = {"Humo", "Fuego", "Chispas", "Nieve", "Energía"};
    for (int i = 0; i < 5; i++) {
        if (i) ImGui::SameLine();
        if (ImGui::SmallButton(names[i])) { fxPreset(f, i); ch = true; }
    }
    if (f.on) {
        ch |= wrapui::ColorEdit3("Color al nacer", f.c0);
        ch |= wrapui::ColorEdit3("Color al desaparecer", f.c1);
        ch |= numField("Cuántas por segundo", f.rate, 1.f, 200.f, "%.0f");
        ch |= numField("Cuánto duran (s)", f.life, 0.1f, 10.f);
        ch |= numField("Tamaño", f.size, 0.02f, 3.f);
        ch |= numField("Crecen o se encogen", f.grow, -1.f, 4.f);
        ch |= numField("Velocidad", f.speed, 0.f, 15.f);
        ch |= numField("Se abren hacia los lados", f.spread, 0.f, 8.f);
        ch |= numField("Caen (+) o suben (-)", f.gravity, -10.f, 20.f);
        ch |= numField("Transparencia inicial", f.a0, 0.05f, 1.f);
        ch |= wrapui::Checkbox("Brillan (fuego, luz)", &f.glow);
        ch |= assetCombo("Imagen propia", f.tex, 0, "(punto suave)");
    }
    return ch;
}

bool Editor::layerPanel(Scene& S) {
    bool ch = false;
    ch |= wrapui::Checkbox("Verla aquí en el editor", &layerPreview_);
    ImGui::TextDisabled("Efecto de pantalla:");
    static const char* names[5] = {"Ninguno", "VHS", "Cámara de video", "Visión nocturna", "Película vieja"};
    for (int i = 0; i < 5; i++) {
        if (wrapui::Button(names[i])) { sfxPreset(S.sfx, i); ch = true; }
        if (i % 2 == 0 && i < 4) ImGui::SameLine();
    }
    ScreenFx& f = S.sfx;
    ImGui::TextDisabled("O crea el tuyo:");
    ch |= numField("Líneas de barrido", f.scan, 0.f, 1.f);
    ch |= numField("Grano / ruido", f.noise, 0.f, 1.f);
    ch |= numField("Bordes oscuros", f.vignette, 0.f, 1.f);
    ch |= numField("Banda de interferencia", f.track, 0.f, 1.f);
    ch |= numField("Cantidad de tinte", f.tint, 0.f, 1.f);
    if (f.tint > 0) ch |= wrapui::ColorEdit3("Color del tinte", f.tintC);
    ch |= wrapui::Checkbox("Visor de cámara (REC)", &f.rec);
    ImGui::SeparatorText("Imágenes fijas en la pantalla");
    int del = -1;
    for (int i = 0; i < (int)S.overlays.size(); i++) {
        Overlay& o = S.overlays[i];
        ImGui::PushID(i);
        ImGui::Text("Imagen %d", i + 1);
        ch |= assetCombo("Imagen", o.tex, 0, "(elige una)");
        ch |= numField("Posición izquierda-derecha", o.x, 0.f, 1.f);
        ch |= numField("Posición arriba-abajo", o.y, 0.f, 1.f);
        ch |= numField("Ancho", o.w, 0.02f, 1.f);
        ch |= numField("Alto", o.h, 0.02f, 1.f);
        ch |= numField("Opacidad", o.alpha, 0.f, 1.f);
        if (ImGui::SmallButton("Quitar esta imagen")) del = i;
        ImGui::Separator();
        ImGui::PopID();
    }
    if (del >= 0) { S.overlays.erase(S.overlays.begin() + del); ch = true; }
    if (wrapui::Button("+ Añadir imagen fija")) { S.overlays.push_back(Overlay()); ch = true; }
    return ch;
}

bool Editor::weaponFields(Weapon& w, bool primary) {
    bool ch = false;
    if (!primary) {
        char nm[64];
        snprintf(nm, sizeof nm, "%s", w.name.c_str());
        if (ImGui::InputText("Nombre del arma", nm, sizeof nm)) { w.name = nm; ch = true; }
    }
    ImGui::TextUnformatted("Tipo de arma:");
    for (int k = 0; k < 4; k++) {
        if (k == 2) {} else if (k) ImGui::SameLine();
        if (wrapui::RadioButton(kWeaponTypeNames[k], w.type == k)) {
            w.type = k; ch = true;
            if (k == 1) { w.projSpeed = 0; w.rate = std::max(w.rate, 0.5f); }
            if (k == 2 && w.projSpeed < 1.f) w.projSpeed = 16.f;
            if (k == 3) { w.projSpeed = 14.f; w.projShape = 0; w.rate = std::max(w.rate, 1.5f); }
        }
    }
    ch |= wrapui::Checkbox("Arma activada (se puede usar)", &w.enabled);
    {
        int sw = w.startWith ? 0 : 1;
        ch |= wrapui::RadioButton("Empezar con esta arma", &sw, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Recogerla del suelo", &sw, 1);
        w.startWith = sw == 0;
        if (sw == 1) ImGui::TextDisabled("En un objeto: Propiedades → \"Da esta arma\" con el nombre del arma.");
    }
    ImGui::TextDisabled("Cómo se ve el arma en tu mano:");
    ch |= assetCombo("Imagen (2D)", w.tex, 0, "(arma básica)");
    ch |= assetCombo("o Modelo 3D", w.model, 2, "(ninguno)");
    ch |= numField("Tamaño", w.scale, 0.1f, 1.2f);
    if (!w.model.empty()) {
        ch |= wrapui::Checkbox("Ponerla en la mano del modelo del jugador (sigue su esqueleto)", &w.inHand);
        if (w.inHand) ch |= handFields(w.handSide, w.hrot, w.hoff, w.hscale);
    }
    ch |= numField("Mover a los lados", w.ox, -0.5f, 0.5f);
    ch |= numField("Mover arriba/abajo", w.oy, -0.3f, 0.5f);
    ch |= numField("Segundos entre usos", w.rate, 0.05f, 3.f);
    ch |= numField("Daño", w.damage, 0.f, 100.f);
    ch |= numField("Retroceso (0 = ninguno)", w.recoilAmt, 0.f, 3.f);
    if (w.type == 0) {
        ch |= numField("Alcance", w.range, 5.f, 200.f);
        ImGui::SeparatorText("Balas");
        ch |= wrapui::Checkbox("Disparo infinito", &w.infinite);
        if (!w.infinite) {
            ch |= numFieldI("Balas por cargador (0 = sin recarga)", w.magSize, 0, 200);
            ch |= numFieldI("Balas con las que empiezas", w.startAmmo, 0, 999);
            if (w.magSize > 0) ch |= numField("Segundos para recargar", w.reloadTime, 0.2f, 6.f);
        }
    } else if (w.type == 1) {
        ch |= numField("Alcance del golpe (metros)", w.meleeRange, 0.5f, 8.f);
    } else {
        ch |= wrapui::Checkbox("Cantidad limitada", &w.infinite); ImGui::SameLine(); ImGui::TextDisabled("(marcado = infinita)");
        if (!w.infinite) ch |= numFieldI("Cantidad con la que empiezas", w.startAmmo, 0, 999);
        ch |= numField("Fuerza del lanzamiento", w.projSpeed, 3.f, 40.f, "%.1f");
        if (w.type == 3) {
            ch |= numField("Segundos para explotar", w.fuse, 0.5f, 8.f);
            ch |= numField("Radio de la explosión", w.blast, 1.f, 20.f);
        }
    }
    if (w.type != 1) {
        ImGui::SeparatorText(w.type == 0 ? "Proyectil (lo que sale al disparar)" : "Lo que se lanza");
        int shape = w.projShape;
        ch |= wrapui::RadioButton("Bala", &shape, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Imagen", &shape, 1); ImGui::SameLine();
        ch |= wrapui::RadioButton("Modelo 3D", &shape, 2);
        w.projShape = shape;
        if (shape == 1) ch |= assetCombo("Imagen del proyectil", w.projTex, 0, "(elige una)");
        if (shape == 2) ch |= assetCombo("Modelo del proyectil", w.projModel, 2, "(elige uno)");
        if (shape == 0) ch |= wrapui::ColorEdit3("Color de la bala", w.projColor);
        ch |= numField("Tamaño del proyectil", w.projSize, 0.05f, 3.f);
        if (w.type == 0) ch |= numField("Velocidad (0 = instantáneo)", w.projSpeed, 0.f, 120.f, "%.1f");
    }
    return ch;
}

bool Editor::weaponPanel() {
    Project& P = edit_.proj;
    bool ch = false;
    ImGui::TextDisabled("Arma principal (la que ya tenías):");
    ch |= weaponFields(P.weapon, true);
    int del = -1;
    for (size_t i = 0; i < P.extraWeapons.size(); i++) {
        ImGui::PushID((int)i + 5000);
        ImGui::Separator();
        std::string hd = "Arma extra: " + P.extraWeapons[i].name + " (" + kWeaponTypeNames[std::max(0, std::min(3, P.extraWeapons[i].type))] + ")";
        if (ImGui::CollapsingHeader(hd.c_str())) {
            ch |= weaponFields(P.extraWeapons[i], false);
            if (wrapui::Button("Borrar esta arma")) del = (int)i;
        }
        ImGui::PopID();
    }
    if (del >= 0) { P.extraWeapons.erase(P.extraWeapons.begin() + del); ch = true; }
    ImGui::Separator();
    ImGui::TextDisabled("Armas extra (opcionales): se cambian con el botón ARMA o la tecla Q.");
    const char* nn[3] = {"+ Arma cuerpo a cuerpo", "+ Arma arrojadiza", "+ Granada"};
    for (int k = 0; k < 3; k++) {
        if (wrapui::Button(nn[k])) {
            Weapon w;
            w.type = k + 1;
            w.name = k == 0 ? "Cuchillo" : k == 1 ? "Lanza" : "Granada";
            if (P.extraWeapons.size() > 0) w.name += std::to_string(P.extraWeapons.size() + 1);
            if (k == 0) { w.projSpeed = 0; w.rate = 0.5f; w.damage = 3.f; }
            if (k == 1) { w.projSpeed = 16.f; w.rate = 0.8f; w.damage = 3.f; w.infinite = false; w.startAmmo = 5; }
            if (k == 2) { w.projSpeed = 14.f; w.rate = 1.5f; w.damage = 8.f; w.infinite = false; w.startAmmo = 3; }
            w.startWith = false;
            P.extraWeapons.push_back(w);
            ch = true;
        }
        if (k < 2) ImGui::SameLine();
    }
    return ch;
}

bool Editor::playerPanel(Scene& S, Obj& o) {
    Project& P = edit_.proj;
    bool ch = false;
    if (resetBtn("player", "Restablecer ajustes del jugador (cámara, linterna, sonidos...)")) {
        std::string md = P.player.model;
        P.player = PlayerCfg();
        P.player.model = md;
        ch = true;
    }
    ImGui::SeparatorText("Cámara del juego");
    int cm = P.player.cam;
    ch |= wrapui::RadioButton("Primera persona", &cm, kFirstPerson);
    ch |= wrapui::RadioButton("Cámara al hombro", &cm, kShoulder);
    ch |= wrapui::RadioButton("Cámara fija (tercera persona)", &cm, kFixed);
    P.player.cam = cm;
    ch |= flashPanel();
    ch |= soundPanel();
    ch |= wrapui::Checkbox("Balanceo de cámara al caminar (primera persona)", &P.player.headBob);
    if (P.player.headBob) ch |= wrapui::SliderFloat("Fuerza del balanceo", &P.player.bobAmt, 0.2f, 3.f);
    if (cm == kFixed) {
        ImGui::TextDisabled("La cámara azul se coloca donde tú quieras:");
        ch |= stepper("Cámara X", S.cam.x, 1.f);
        ch |= stepper("Cámara Y", S.cam.y, 1.f);
        ch |= stepper("Cámara Z", S.cam.z, 1.f);
        if (wrapui::Button("Poner la cámara donde estoy mirando")) { S.cam = view().eye; ch = true; }
        ImGui::TextUnformatted("¿Cómo se comporta la cámara?");
        int fm = P.player.fixedMode;
        ch |= wrapui::RadioButton("Se queda en su lugar y gira para seguir al jugador", &fm, 0);
        ch |= wrapui::RadioButton("Se mueve junto al jugador (mantiene la distancia)", &fm, 1);
        ch |= wrapui::RadioButton("Totalmente fija (no se mueve ni gira)", &fm, 2);
        P.player.fixedMode = fm;
    }
    if (cm == kShoulder) {
        ch |= numField("Distancia de la cámara", P.player.shoulderDist, 1.f, 8.f, "%.1f");
        ch |= numField("Altura de la cámara", P.player.shoulderH, -1.f, 5.f, "%.1f");
    }
    ImGui::SeparatorText("Cuerpo y movimiento");
    ch |= assetCombo("Modelo del jugador", P.player.model, 2, "(muñeco básico)");
    {
        int lk = P.player.lockOn;
        ImGui::TextUnformatted("Fijar al enemigo (apuntar solo)");
        ch |= wrapui::RadioButton("No##lk", &lk, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Al atacar##lk", &lk, 1); ImGui::SameLine();
        ch |= wrapui::RadioButton("Siempre##lk", &lk, 2);
        P.player.lockOn = lk;
        if (lk) ch |= numField("Distancia para fijar", P.player.lockRange, 2.f, 30.f, "%.0f");
        ch |= wrapui::Checkbox("Vista lateral 2.5D (solo caminar de lado, como pelea)", &P.player.sideView);
        ch |= wrapui::Checkbox("Deslizar el dedo = botones «Deslizar izquierda/derecha/arriba/abajo»", &P.player.swipe);
        ch |= wrapui::Checkbox("Corredor infinito de 3 carriles (avanza solo; deslizar = carril / saltar / agacharse)", &P.player.runner);
    }
    if (wrapui::Checkbox("Modo vehículo (carro): acelerar y girar con botones", &P.player.vehicle)) {
        ch = true;
        if (P.player.vehicle) {   // los botones cambian solos a los de carreras (Izquierda, Derecha, Acelerar, Frenar)
            P.hudDefault = false; P.hud.clear();
            auto add = [&](const char* l, float x, float y, float r, float cr, float cg, float cb) { HudBtn b; b.label = l; b.x = x; b.y = y; b.r = r; b.act = HudAct::Hold; b.color[0] = cr; b.color[1] = cg; b.color[2] = cb; P.hud.push_back(b); };
            add("Izquierda", 0.10f, 0.78f, 0.10f, 0.5f, 0.7f, 1.f); add("Derecha", 0.29f, 0.78f, 0.10f, 0.5f, 0.7f, 1.f);
            add("Acelerar", 0.89f, 0.76f, 0.12f, 0.3f, 1.f, 0.4f); add("Frenar", 0.72f, 0.86f, 0.08f, 1.f, 0.4f, 0.35f);
        } else { P.hudDefault = true; P.hud.clear(); }
        if (P.player.vehicle && !P.player.model.empty()) orientOpen_ = true;   // pantalla para marcar frente y atrás del modelo
    }
    if (P.player.vehicle && !P.player.model.empty() && wrapui::Button("Orientar el modelo (marcar frente y atrás)")) orientOpen_ = true;
    if (P.player.vehicle) ImGui::TextDisabled("Crea botones con acción «Mantener presionado» llamados Izquierda, Derecha, Acelerar y Frenar (las teclas A/D/W/S también sirven).");
    {
        int fm = P.player.faceExtra == 3 ? 3 : P.player.faceExtra == 2 ? 2 : (P.player.faceMove ? 0 : 1);
        ImGui::TextUnformatted("¿Hacia dónde mira el cuerpo?");
        ch |= wrapui::RadioButton("Gira hacia donde camina", &fm, 0);
        ch |= wrapui::RadioButton("Siempre mira al frente", &fm, 1);
        ch |= wrapui::RadioButton("Mira al contrario de donde camina", &fm, 2);
        ch |= wrapui::RadioButton("Siempre mira hacia atrás", &fm, 3);
        P.player.faceMove = fm == 0 || fm == 2;
        P.player.faceExtra = fm >= 2 ? fm : 0;
        if (ImGui::TreeNode("Ajustar el modelo (posición, giro, tamaño)")) {
            ch |= numField("Mover a los lados", P.player.mox, -2.f, 2.f);
            ch |= numField("Mover arriba/abajo", P.player.moy, -2.f, 2.f);
            ch |= numField("Mover adelante/atrás", P.player.moz, -2.f, 2.f);
            ch |= numField("Girar el modelo (grados)", P.player.myaw, -180.f, 180.f, "%.0f");
            ch |= numField("Tamaño del modelo", P.player.mscale, 0.2f, 3.f);
            ImGui::TreePop();
        }
        ch |= wrapui::Checkbox("El modelo cabe parejo en la colisión (sin deformarse)", &P.player.fit);
        if (wrapui::Button("Adaptar la colisión al modelo") && tapped()) {   // la caja toma las proporciones del modelo, con la altura actual
            int pi2 = playerIndex(S);
            auto ai = edit_.proj.assets.find(P.player.model);
            ModelData md2;
            if (pi2 >= 0 && ai != edit_.proj.assets.end() && modelRead(ai->second.data(), ai->second.size(), md2) && md2.v.size() >= 8) {
                float mn[3] = {1e30f, 1e30f, 1e30f}, mx[3] = {-1e30f, -1e30f, -1e30f};
                for (size_t i = 0; i + 7 < md2.v.size(); i += 8) for (int c = 0; c < 3; c++) { mn[c] = std::min(mn[c], md2.v[i + c]); mx[c] = std::max(mx[c], md2.v[i + c]); }
                float ey = std::max(0.001f, mx[1] - mn[1]), hh = std::max(0.3f, S.objs[pi2].scale.y);
                S.objs[pi2].scale = V3{std::max(0.2f, (mx[0] - mn[0]) * hh / ey), hh, std::max(0.2f, (mx[2] - mn[2]) * hh / ey)};
                P.player.fit = true; P.player.mscale = 1.f; ch = true;
                toast("Colisión adaptada al modelo");
            } else toast("No se pudo leer el modelo");
        }
    }
    ch |= numField("Altura de la cámara en primera persona (m)", P.player.eyeH, -1.f, 1.5f);
    ch |= wrapui::Checkbox("Primera persona: ver el cuerpo y las manos del modelo", &P.player.fpBody);
    ImGui::TextDisabled("Se ve en cámara al hombro y fija. Usa Ancho/Alto de arriba para su tamaño.");
    {
        int sp = o.ai.sprite ? 1 : 0;
        ImGui::TextUnformatted("¿Cómo se ve el jugador?");
        ch |= wrapui::RadioButton("Modelo 3D / muñeco", &sp, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Imágenes planas (sprites)", &sp, 1);
        o.ai.sprite = sp == 1;
        ch |= animPanel(o);
    }
    ch |= numField("Velocidad al caminar", P.player.speed, 0.5f, 60.f, "%.1f");
    ch |= numField("Fuerza de salto", P.player.jump, 0.f, 20.f, "%.1f");
    ImGui::SeparatorText("Arma del jugador");
    ch |= weaponPanel();
    return ch;
}

// Enemigo 2D: elige cómo ataca (proyectiles o cuerpo a cuerpo) y los dibujos de cada movimiento.
bool Editor::enemy2dPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    static const char* tn[3] = {"No es enemigo", "Dispara proyectiles", "Ataca cuerpo a cuerpo"};
    int ti = a.type == AiType::Shooter ? 1 : a.type == AiType::Melee ? 2 : 0;
    if (ImGui::BeginCombo("Tipo de enemigo", tn[ti])) {
        for (int k = 0; k < 3; k++) if (ImGui::Selectable(tn[k], k == ti)) {
            a.type = k == 1 ? AiType::Shooter : k == 2 ? AiType::Melee : AiType::None; a.sprite = true; ch = true;
            if (k == 1 && a.projSpeed < 2.f) a.projSpeed = 14.f;
        }
        ImGui::EndCombo();
    }
    if (a.type == AiType::None) { ImGui::TextDisabled("Elige un tipo para convertir este objeto en enemigo."); return ch; }
    ch |= wrapui::SliderFloat("Vida (golpes que aguanta)", &a.hp, 1.f, 50.f, "%.0f");
    ch |= wrapui::SliderFloat("Distancia a la que te ve (m)", &a.sight, 2.f, 40.f, "%.0f");
    ch |= wrapui::SliderFloat("Daño que te hace", &a.dmg, 0.5f, 50.f, "%.1f");
    ch |= wrapui::SliderFloat(a.type == AiType::Shooter ? "Tiempo entre cada disparo (s)" : "Segundos entre golpes", &a.rate, 0.1f, 6.f, "%.2f");
    if (a.type == AiType::Melee) {
        ch |= wrapui::SliderFloat("Velocidad al caminar", &a.speed, 0.5f, 12.f, "%.1f");
        ch |= wrapui::SliderFloat("Alcance del golpe (m)", &a.reach, 0.3f, 6.f, "%.1f");
        ch |= assetCombo("Dibujo del golpe (sale a su lado)", a.meleeTex, 1, "(ninguno)");
    } else {
        static const char* dn[5] = {"Hacia donde mira", "Derecha (x)", "Izquierda (-x)", "Arriba (y)", "Abajo (-y)"};
        int di = std::max(0, std::min(4, a.bdir));
        if (ImGui::BeginCombo("La bala va hacia", dn[di])) { for (int k = 0; k < 5; k++) if (ImGui::Selectable(dn[k], k == di)) { a.bdir = k; ch = true; } ImGui::EndCombo(); }
        ch |= wrapui::SliderFloat("Velocidad de la bala (lenta ← → rápida)", &a.projSpeed, 0.5f, 60.f, "%.1f");
        ch |= wrapui::SliderFloat("Tamaño de la bala", &a.projSize, 0.1f, 3.f, "%.2f");
        ch |= assetCombo("Dibujo de la bala", a.projTex, 1, "(círculo de color)");
        ch |= wrapui::Checkbox("Desaparece al salir de la pantalla", &a.boff);
        ch |= wrapui::SliderFloat("Desaparece después de (s, 0 = nunca)", &a.blife, 0.f, 20.f, "%.1f");
        ImGui::SeparatorText("Ruta de la bala (dibujada)");
        char rb[96]; snprintf(rb, sizeof rb, "+ Dibujar una ruta nueva (%d guardadas)", (int)a.bpaths.size());
        if (wrapui::Button(rb) && tapped()) { a.bpaths.emplace_back(); bpathIdx_ = (int)a.bpaths.size() - 1; bpathOpen_ = true; strokes_.clear(); mvInit_ = false; ch = true; }
        for (int q = 0; q < (int)a.bpaths.size(); q++) {
            ImGui::PushID(1300 + q);
            ImGui::AlignTextToFramePadding();
            ImGui::Text("Ruta %d (%d puntos)", q + 1, (int)a.bpaths[q].size() / 2);
            ImGui::SameLine();
            if (ImGui::SmallButton("Editar")) { bpathIdx_ = q; bpathOpen_ = true; strokes_.clear(); mvInit_ = false; }
            ImGui::SameLine();
            if (ImGui::SmallButton("Borrar")) { a.bpaths.erase(a.bpaths.begin() + q); ch = true; ImGui::PopID(); break; }
            ImGui::PopID();
        }
        if (!a.bpaths.empty()) {
            static const char* mn[2] = {"En orden (1, 2, 3...)", "Al azar"};
            int mi = std::max(0, std::min(1, a.bpathMode));
            if (ImGui::BeginCombo("Qué ruta usa cada bala", mn[mi])) { for (int k = 0; k < 2; k++) if (ImGui::Selectable(mn[k], k == mi)) { a.bpathMode = k; ch = true; } ImGui::EndCombo(); }
            ImGui::TextDisabled("Con ruta dibujada, la bala ignora la dirección y sigue tu dibujo.");
        }
        if (bpathOpen_ && bpathIdx_ >= 0 && bpathIdx_ < (int)a.bpaths.size()) {
            Scene& SS = scene();
            ch |= route2DWindow(o, SS, &a.bpaths[bpathIdx_], true, &bpathOpen_);
        } else bpathOpen_ = false;
    }
    if (ImGui::TreeNode("Dibujos de cada movimiento")) {
        static const char* an[7] = {"Quieto / fijo", "Se mueve a la izquierda", "Se mueve a la derecha", "Salta (izquierda)", "Salta (derecha)", "Ataca / dispara a la izquierda", "Ataca / dispara a la derecha"};
        for (int k = 0; k < 7; k++) { ImGui::PushID(950 + k); ch |= assetCombo(an[k], o.act[k], 0, "(la imagen normal)"); ImGui::PopID(); }
        ImGui::TextDisabled("Si dejas uno vacío usa «Quieto». Cada enemigo mira hacia ti.");
        ImGui::TreePop();
    }
    return ch;
}

bool Editor::aiPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    int t = a.type == AiType::Shooter ? 1 : a.type == AiType::Melee ? 2 : 0;
    ImGui::TextUnformatted("¿Es un enemigo?");
    ch |= wrapui::RadioButton("No", &t, 0); ImGui::SameLine();
    ch |= wrapui::RadioButton("Enemigo (dispara)", &t, 1); ImGui::SameLine();
    ch |= wrapui::RadioButton("Monstruo (cuerpo a cuerpo)", &t, 2);
    a.type = t == 1 ? AiType::Shooter : t == 2 ? AiType::Melee : AiType::None;
    if (a.type == AiType::None) {   // cualquier objeto (cubos, modelos...) puede tener animaciones
        if (o.kind != Kind::Light && o.kind != Kind::Floor && ImGui::CollapsingHeader("Animaciones del objeto (opcional)")) {
            ImGui::TextWrapped("«Quieto» se reproduce siempre. Las demás se activan con el bloque «Reproducir animación» (escribe: caminar, atacar, correr, saltar...).");
            ch |= animPanel(o);
        }
        return ch;
    }
    int sp = a.sprite ? 1 : 0;
    ImGui::TextUnformatted("¿Cómo se ve?");
    ch |= wrapui::RadioButton("Modelo 3D / cubo", &sp, 0); ImGui::SameLine();
    ch |= wrapui::RadioButton("Imágenes planas (sprites)", &sp, 1);
    a.sprite = sp == 1;
    if (a.sprite) ImGui::TextDisabled("La imagen siempre mira al jugador. Pon una imagen distinta para cada acción abajo.");
    else if (o.kind != Kind::Model) {
        ImGui::TextDisabled("Para usar un modelo 3D importado, cambia el objeto a tipo Modelo o añade modelos en las animaciones.");
    }
    {
        int fc = a.face;
        ImGui::TextUnformatted("¿Hacia dónde mira?");
        ch |= wrapui::RadioButton("Gira hacia donde va", &fc, 0); ImGui::SameLine();
        ch |= wrapui::RadioButton("Siempre mira al frente", &fc, 1);
        a.face = fc;
    }
    ch |= numField("Vida", a.hp, 1.f, 500.f, "%.0f");
    ch |= numField("Velocidad", a.speed, 0.f, 15.f, "%.1f");
    ch |= numField("Distancia a la que te ve", a.sight, 2.f, 80.f, "%.0f");
    ch |= numField("Daño al jugador", a.dmg, 0.f, 100.f, "%.0f");
    ch |= numField("Segundos entre ataques", a.rate, 0.1f, 10.f);
    if (a.type == AiType::Melee) ch |= numField("Alcance del golpe", a.reach, 0.5f, 6.f);
    if (a.type == AiType::Shooter) {
        ImGui::SeparatorText("Proyectil del enemigo");
        ch |= assetCombo("Imagen", a.projTex, 0, "(bola de color)");
        ch |= assetCombo("o Modelo 3D", a.projModel, 2, "(ninguno)");
        ch |= wrapui::ColorEdit3("Color de la bola", a.projColor);
        ch |= numField("Tamaño", a.projSize, 0.05f, 3.f);
        ch |= numField("Velocidad", a.projSpeed, 1.f, 60.f, "%.1f");
    }
    return ch | animPanel(o);
}

// v10.9d: tamaño general (más grande / más chico sin deformar), estirar con asas e inclinación en cualquier posición.
bool Editor::sizeTiltPanel(Obj& o, bool tilt) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::TextDisabled("Tamaño general (sin deformar)");
    auto mul = [&](float k) { o.scale.x = std::max(0.02f, o.scale.x * k); o.scale.y = std::max(0.02f, o.scale.y * k); o.scale.z = std::max(0.02f, o.scale.z * k); ch = true; };
    if (wrapui::Button("  -  Más chico", ImVec2(0, fs * 2.3f)) && tapped()) mul(0.9f);
    wrapui::Next("  +  Más grande", 0.f);
    if (wrapui::Button("  +  Más grande", ImVec2(0, fs * 2.3f)) && tapped()) mul(1.1f);
    wrapui::Next("Mitad", 0.f);
    if (wrapui::Button("Mitad", ImVec2(0, fs * 2.3f)) && tapped()) mul(0.5f);
    wrapui::Next("Doble", 0.f);
    if (wrapui::Button("Doble", ImVec2(0, fs * 2.3f)) && tapped()) mul(2.f);
    if (tilt) {
        if (ImGui::Checkbox("Híbrido: flechas + cuadros (mover y estirar)", &gHyb_) && gHyb_) { gStretch_ = false; gRotate_ = false; }
        ImGui::Checkbox("Mostrar aros para girar con el dedo (puede girar sin querer)", &gRings_);
        if (ImGui::Checkbox("Estirar con las asas de la vista (cuadros)", &gStretch_) && gStretch_) { gRotate_ = false; gHyb_ = false; }
        if (ImGui::Checkbox("Girar con las asas de la vista (aros)", &gRotate_) && gRotate_) { gStretch_ = false; gHyb_ = false; }
        ImGui::TextDisabled("Inclinación (gira en cualquier posición)");
        ch |= stepper("Inclinar adelante/atrás", o.pitch, 15.f);
        ch |= stepper("Inclinar de lado", o.roll, 15.f);
        if (wrapui::Button("De cabeza (180°)", ImVec2(0, fs * 2.3f)) && tapped()) { o.roll = std::fmod(o.roll + 180.f, 360.f); ch = true; }
        wrapui::Next("Acostar (90°)", 0.f);
        if (wrapui::Button("Acostar (90°)", ImVec2(0, fs * 2.3f)) && tapped()) { o.pitch = std::fmod(o.pitch + 90.f, 360.f); ch = true; }
        wrapui::Next("Enderezar", 0.f);
        if (wrapui::Button("Enderezar", ImVec2(0, fs * 2.3f)) && tapped()) { o.pitch = 0; o.roll = 0; ch = true; }
        if (o.pitch != 0.f || o.roll != 0.f) ImGui::TextDisabled("Nota: al inclinar, el choque sigue siendo una caja recta.");
    }
    return ch;
}

// Animaciones por acción: UNA sola lista. Cada acción tiene su animación (de esqueleto para modelos 3D, o imágenes para sprites).
bool Editor::animPanel(Obj& o) {
    AiCfg& a = o.ai;
    bool ch = false;
    ImGui::SeparatorText("Animaciones por acción");
    const float fs = ImGui::GetFontSize();
    std::string mdl = o.kind == Kind::Player ? edit_.proj.player.model : o.model;
    for (int k = 0; k < kAnimCount && mdl.empty(); k++) for (auto& fr : a.anim[k].frames) if (ends(fr, ".fmdl")) { mdl = fr; break; }
    std::vector<std::string> cl;
    std::string rigName;
    if (!a.sprite) {
        for (auto& ast : edit_.proj.assets) {
            if (!ends(ast.first, ".fanim")) continue;
            const RigInfo& rr = rigInfoOf(ast.first, ast.second);
            if (!rr.ok) continue;
            if (!o.rig.empty() ? ast.first != o.rig : (!mdl.empty() && rr.model != mdl)) continue;
            if (rigName.empty()) rigName = ast.first;
            for (auto& c : rr.clips) if (std::find(cl.begin(), cl.end(), c) == cl.end()) cl.push_back(c);
        }
        if (mdl.empty()) ImGui::TextDisabled("Primero elige un modelo 3D para este objeto.");
        if (wrapui::Button("Crear animación nueva", ImVec2(0, fs * 2.2f)) && tapped()) openAnimEditor("", mdl);
        if (!rigName.empty()) {
            wrapui::Next("Editar animaciones");
            if (wrapui::Button("Editar animaciones", ImVec2(0, fs * 2.2f)) && tapped()) openAnimEditor(rigName);
        }
    }
    ImGui::TextDisabled("Elige qué animación hace en cada acción. Las que dejes vacías usan la parecida (por ejemplo, agacharse usa caminar).");
    ImGui::TextDisabled("\"Acción personalizada\": se activa con el bloque Reproducir animación (por ejemplo después de Difundir mensaje).");
    for (int k = 0; k < kAnimCount; k++) {
        ImGui::PushID(k + 700);
        AnimState& as = a.anim[k];
        if (k != kIdle) ch |= wrapui::Checkbox((std::string("No reproducir: ") + animActionName(k)).c_str(), &as.off);
        if (!a.sprite && !as.off) {
            std::string cur = as.clip.empty() ? "(ninguna)" : as.clip;
            if (wrapui::BeginCombo(animActionName(k), cur.c_str())) {
                if (wrapui::Selectable("(ninguna)", as.clip.empty())) { as.clip.clear(); ch = true; }
                for (auto& n : cl) if (wrapui::Selectable(n.c_str(), n == as.clip)) { as.clip = n; ch = true; }
                ImGui::EndCombo();
            }
        } else if (a.sprite && !as.off) {   // sprites: imágenes que se alternan
            std::string head = std::string(animActionName(k)) + " (" + std::to_string(as.frames.size()) + " imágenes)";
            if (ImGui::CollapsingHeader(head.c_str())) {
                for (size_t i = 0; i < as.frames.size(); i++) {
                    ImGui::PushID((int)i);
                    assetThumb(as.frames[i], 0, fs * 2.2f);
                    ImGui::SameLine();
                    ImGui::AlignTextToFramePadding();
                    ImGui::Text("%zu. %s", i + 1, shorten(as.frames[i], 22).c_str());
                    ImGui::SameLine();
                    if (ImGui::SmallButton("Quitar")) { as.frames.erase(as.frames.begin() + i); ch = true; ImGui::PopID(); break; }
                    ImGui::PopID();
                }
                static std::string pickTmp;
                bool oi = wrapui::Button("+ Imagen") && tapped();
                pickTmp.clear();
                if (gridPicker("##addimgpick", pickTmp, 0, nullptr, oi) && !pickTmp.empty()) { as.frames.push_back(pickTmp); ch = true; }
                if (as.frames.size() > 1) ch |= numField("Cuadros por segundo", as.fps, 1.f, 30.f, "%.0f");
            }
        }
        ImGui::PopID();
    }
    return ch;
}

void Editor::propsWin() {
    if (!showProps || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = gBarTop();
    placeWindow(w_ - fs * 21.f - 6.f, top, fs * 21.f, h_ * 0.75f);
    if (wrapui::Begin("Propiedades", &showProps, dockFlags())) {
        wrapui::CloseBar(&showProps);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        Obj* o = selObj();
        if (!o) {
            ImGui::TextDisabled("Toca un objeto en la escena o en la lista.");
        } else {
            bool ch = false;
            ch |= textInput("##on", "Nombre del objeto", o->name, "nombre");
            const char* kinds[] = {"Cubo", "Suelo", "Pared", "Item", "Modelo", "Luz", "Jugador"};
            ImGui::Text("Tipo: %s", kinds[(int)o->kind]);
            {   // pestañas grandes: cada una muestra solo lo de su tema, sin salir del panel
                static const char* TL[4] = {"Mover", "Aspecto", "Choque", "Acciones"};
                float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x, bw = (aw - sp * 3) / 4.f;
                for (int t = 0; t < 4; t++) {
                    if (t) ImGui::SameLine();
                    ImGui::PushStyleColor(ImGuiCol_Button, propTab_ == t ? ImVec4(0.18f, 0.55f, 0.85f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
                    ImGui::PushID(t + 4400);
                    if (wrapui::Button(TL[t], ImVec2(bw, fs * 2.4f)) && tapped()) propTab_ = t;
                    ImGui::PopID();
                    ImGui::PopStyleColor();
                }
            }
            const int pt = propTab_;
            const bool adv = !easy_;   // opciones avanzadas (se ocultan en modo fácil)
            if (pt == 0) ch |= wrapui::Checkbox("Modo fácil (solo lo básico)", &easy_);
            if (pt == 0 && adv) ch |= wrapui::Checkbox("Bloqueado (no se mueve ni se selecciona tocando la escena)", &o->locked);
            if (pt == 1 && adv && scene().is3d) ch |= wrapui::Checkbox("Reflejos (brillo del cielo y el sol)", &o->reflect);
            if (pt == 1 && adv && scene().is3d) ch |= wrapui::Checkbox("Metálico (mismos colores con brillo de metal)", &o->metal);
            if (pt == 1 && adv && scene().is3d && (o->reflect || o->metal)) {
                ch |= wrapui::SliderFloat("Desenfoque del reflejo (0 nítido, 1 muy borroso)", &o->reflBlur, 0.f, 1.f);
                ImGui::TextDisabled("Más borroso se ve suave y cuesta menos; menos borroso es un espejo más nítido.");
            }
            if (pt == 1 && adv) {
                std::vector<std::string> vids;
                for (auto& as : edit_.proj.assets) if (isVideoName(as.first)) vids.push_back(as.first);
                ImGui::SeparatorText("Video en este objeto");
                if (wrapui::BeginCombo("Video", o->video.empty() ? "(ninguno)" : o->video.c_str())) {
                    if (wrapui::Selectable("(ninguno)", o->video.empty())) { o->video.clear(); ch = true; }
                    for (auto& v : vids) if (wrapui::Selectable(v.c_str(), v == o->video)) { o->video = v; o->noColor = false; ch = true; }
                    ImGui::EndCombo();
                }
                if (vids.empty()) ImGui::TextDisabled("Importa un video en Archivos → Videos (o con Importar archivo).");
                if (!o->video.empty()) {
                    ch |= wrapui::Checkbox("Reproducir al empezar", &o->videoAuto);
                    ch |= wrapui::Checkbox("Repetir siempre (ciclo)", &o->videoLoop);
                    ImGui::TextDisabled("Bloques: reproducir, pausar, reanudar, ciclo, N veces, reiniciar, detener.");
                }
            }
            if (pt == 3 && scene().is3d && !edit_.proj.extraWeapons.empty()) {
                const char* cur = o->giveWeapon.empty() ? "(ninguna)" : o->giveWeapon.c_str();
                if (wrapui::BeginCombo("Da esta arma al tocarlo", cur)) {
                    if (wrapui::Selectable("(ninguna)", o->giveWeapon.empty())) { o->giveWeapon.clear(); ch = true; }
                    std::vector<std::string> nm = {edit_.proj.weapon.name};
                    for (auto& w : edit_.proj.extraWeapons) nm.push_back(w.name);
                    for (auto& n : nm) if (wrapui::Selectable(n.c_str(), o->giveWeapon == n)) { o->giveWeapon = n; ch = true; }
                    ImGui::EndCombo();
                }
            }
            if (pt == 1 && adv && o->kind == Kind::Floor && scene().is3d) ch |= terrainPanel(*o);
            if (pt == 3 && scene().is3d && (o->kind == Kind::Model || o->kind == Kind::Player)) ch |= skelPanel(*o);
            if (pt == 0 && adv && resetBtn("obj", o->kind == Kind::Player ? "Restablecer ajustes del jugador (este objeto)" : "Restablecer ajustes de este objeto")) {
                Obj f;   // se conserva lo que lo identifica y dónde está; todo lo demás vuelve a su valor original
                f.name = o->name; f.kind = o->kind; f.pos = o->pos; f.scale = o->scale; f.yaw = o->yaw;
                f.tex = o->tex; f.model = o->model; f.looks = o->looks; f.sounds = o->sounds; f.blocks = o->blocks; f.localVars = o->localVars;
                f.layer = o->layer; f.bg = o->bg; f.tn = o->tn; f.heights = o->heights; f.terrVer = o->terrVer + 1; f.rig = o->rig;
                f.locked = o->locked; f.clone = o->clone; f.alive = o->alive;
                *o = f;
                ch = true;
            }
            float st = S.is3d ? 0.5f : 10.f;
            if (pt == 0) {
                ImGui::SeparatorText("Posición");
                ch |= stepper("X", o->pos.x, st);
                ch |= stepper("Y", o->pos.y, st);
                if (S.is3d) ch |= stepper("Z", o->pos.z, 0.5f);
            }
            if (o->kind == Kind::Player) {
                if (pt == 0) {
                    ImGui::SeparatorText("Tamaño y giro");
                    ch |= stepper("Ancho", o->scale.x, 0.1f);
                    ch |= stepper("Alto", o->scale.y, 0.1f);
                    ch |= stepper("Fondo", o->scale.z, 0.1f);
                    ch |= stepper("Hacia dónde mira", o->yaw, 15.f);
                    if (adv) ch |= sizeTiltPanel(*o, false);
                }
                if (pt == 3) ch |= playerPanel(S, *o);
            } else if (o->kind == Kind::Light) {
                if (pt == 0) {
                    ImGui::SeparatorText("Luz");
                    ch |= stepper("Alcance", o->scale.x, 1.f);
                    ch |= wrapui::ColorEdit3("Color de luz", o->color);
                }
            } else {
                if (pt == 0) {
                    ImGui::SeparatorText("Tamaño y giro");
                    ch |= stepper("Ancho", o->scale.x, st);
                    ch |= stepper("Alto", o->scale.y, st);
                    if (!S.is3d) {   // negativo = voltear (así el objeto sigue respondiendo a toques y bloques)
                        if (o->scale.x < 0.f) { o->scale.x = -o->scale.x; o->flipX = !o->flipX; ch = true; }
                        if (o->scale.y < 0.f) { o->scale.y = -o->scale.y; o->flipY = !o->flipY; ch = true; }
                    }
                    if (S.is3d) ch |= stepper("Fondo", o->scale.z, 0.5f);
                    ch |= stepper(S.is3d ? "Giro" : "Dirección", o->yaw, 15.f);
                    if (adv) ch |= sizeTiltPanel(*o, S.is3d);
                    ch |= wrapui::Checkbox("Visible al empezar", &o->visible);
                }
                if (pt == 1) {
                ImGui::SeparatorText("Apariencia");
                ch |= wrapui::Checkbox("Sin color (transparente)", &o->noColor);
                if (!o->noColor) ch |= wrapui::ColorEdit3("Color", o->color);
                ch |= assetCombo("Textura", o->tex, 0, "(sin textura)");
                if (wrapui::Button("Dibujar una textura nueva")) openPaint("");
                if (!o->tex.empty()) { wrapui::Next("Editar esta"); if (wrapui::Button("Editar esta")) openPaint(o->tex); }
                if (!S.is3d && !o->tex.empty()) {   // arreglar imágenes que se importaron volteadas (sin usar tamaño negativo)
                    ch |= wrapui::Checkbox("Arreglar importación: voltear de lado", &o->flipX);
                    ch |= wrapui::Checkbox("Arreglar importación: voltear arriba-abajo", &o->flipY);
                    int tw0 = 0, th0 = 0;
                    if (rend_) rend_->textureId(edit_, o->tex, &tw0, &th0);
                    if (tw0 > 0 && th0 > 0 && wrapui::Button("Ajustar la forma a la de la imagen (sin deformar)")) { o->scale.y = o->scale.x * (float)th0 / (float)tw0; ch = true; }
                }
                if (!o->tex.empty()) {
                    bool stretch = !o->texTile;
                    if (wrapui::Checkbox("Estirar la imagen a toda la cara", &stretch)) { o->texTile = !stretch; ch = true; }
                }
                if (o->kind == Kind::Model) ch |= assetCombo("Modelo", o->model, 2, "(cubo)");
                if (adv) ch |= wrapui::Checkbox("Gira sobre sí mismo", &o->spin);
                if (adv) { ImGui::SeparatorText("Partículas (humo, fuego...)");
                ch |= fxPanel(*o); }
                }
                if (pt == 2) ch |= wrapui::Checkbox("Sólido (se puede chocar)", &o->solid);
                if (pt == 2 && adv) {
                    ImGui::SeparatorText("Física");
                    int ph = (int)o->phys;
                    static const char* pn[3] = {"Sin física", "Dinámico (cae y rebota)", "Estático (firme)"};
                    int idx = o->phys == Phys::None ? 0 : o->phys == Phys::Dynamic ? 1 : 2;
                    for (int i = 0; i < 3; i++) {
                        if (wrapui::RadioButton(pn[i], idx == i)) { o->phys = i == 0 ? Phys::None : i == 1 ? Phys::Dynamic : Phys::Static; ch = true; }
                    }
                    (void)ph;
                    if (o->phys != Phys::None) {
                        ch |= wrapui::SliderFloat("Masa (kg)", &o->mass, 0.1f, 50.f, "%.1f");
                        ch |= wrapui::SliderFloat("Rebote", &o->bounce, 0.f, 1.2f);
                        ch |= wrapui::SliderFloat("Fricción", &o->friction, 0.f, 1.f);
                    }
                    if (o->phys == Phys::Dynamic) {
                        ch |= wrapui::SliderFloat("Gravedad del objeto", &o->gravScale, 0.f, 3.f);
                        ch |= wrapui::SliderFloat("Resistencia del aire", &o->drag, 0.f, 10.f);
                        ch |= wrapui::Checkbox("El jugador lo puede empujar al caminar", &o->pushable);
                        ch |= wrapui::Checkbox("Las balas y golpes lo empujan", &o->bulletPush);
                        ImGui::TextDisabled("También hay bloques: empujón, explosión de fuerza, gravedad y resistencia del aire.");
                    }
                }
                if (pt == 2 && adv && S.is3d && o->kind == Kind::Model) {
                    ch |= wrapui::Checkbox("Pegarse al suelo o montaña al empezar", &o->snapGround);
                    if (wrapui::Button("Apoyar en el suelo ahora")) {
                        int oi = (int)(o - &S.objs[0]);
                        float sy = edit_.supportY(oi);
                        if (sy > -1e8f) { float cx, cy, cz, hx, hy, hz; edit_.effBoxPub(*o, cx, cy, cz, hx, hy, hz); o->pos.y += sy - (cy - hy); ch = true; }
                    }
                    ch |= wrapui::Checkbox("Deformar por golpes (balas, choques, explosiones)", &o->deform);
                    if (o->deform) {
                        ch |= wrapui::SliderFloat("Cuánto se abolla", &o->deformAmt, 0.1f, 1.f);
                        ImGui::TextDisabled("Se hunde la malla donde recibe el golpe. No se mezcla con animaciones de esqueleto.");
                    }
                }
                if (pt == 3 && adv && S.is3d && o->kind == Kind::Model) {
                    ImGui::SeparatorText("Movimiento automático y autos");
                    ch |= autoPanel(*o, S);
                } else if (pt != 3) routeOpen_ = false;
                if (pt == 3 && adv && S.is3d && o->kind == Kind::Model) {
                    ImGui::SeparatorText("Objeto en la mano (arma, herramienta...)");
                    ch |= assetCombo("Modelo que sostiene", o->handItem, 2, "(nada)");
                    if (!o->handItem.empty()) ch |= handFields(o->handSide, o->hrot, o->hoff, o->hscale);
                    ImGui::TextDisabled("Necesita un modelo con esqueleto (mano_d / mano_i); si no, no se muestra.");
                }
                if (pt == 3 && !S.is3d && !o->bg && o->kind != Kind::Player) {
                    ImGui::SeparatorText("Controles virtuales y Meta");
                    ch |= vctlPanel(*o, S);
                    if (adv) { ImGui::SeparatorText("Ruta dibujada y estela");
                    ch |= route2DPanel(*o, S); }
                    ImGui::SeparatorText("Enemigo (dispara o golpea)");
                    ch |= enemy2dPanel(*o);
                } else if (pt != 3) route2DOpen_ = false;
                if (pt == 2 && S.is3d && o->ai.type == AiType::None) ch |= wrapui::Checkbox("Mostrar la marca roja de acierto al dispararle", &o->hitMark);
                if (pt == 3 && S.is3d) {
                    ImGui::SeparatorText("Enemigo o monstruo");
                    ch |= aiPanel(*o);
                }
            }
            if (ch) markDirty();
            ImGui::Separator();
            if (wrapui::Button("Programar (bloques)")) { page_ = Page::Object; tab_ = 0; }
            ImGui::SameLine();
            if (o->kind != Kind::Player && wrapui::Button("Duplicar")) {
                Obj c = *o;
                c.name = uniqueName(o->name);
                c.pos.x += 1.f;
                S.objs.push_back(c);
                sel_ = (int)S.objs.size() - 1;
                markDirty();
                o = nullptr;
            }
            if (o && o->kind != Kind::Player) {
                wrapui::Next("Eliminar");
                if (wrapui::Button("Eliminar")) {
                    S.objs.erase(S.objs.begin() + sel_);
                    sel_ = -1;
                    markDirty();
                    o = nullptr;
                }
            }
            if (o && !S.is3d) {  // en 2D el orden de la lista es el orden de capas
                if (wrapui::Button("Subir capa") && sel_ + 1 < (int)S.objs.size()) { std::swap(S.objs[sel_], S.objs[sel_ + 1]); sel_++; markDirty(); }
                wrapui::Next("Bajar capa");
                if (wrapui::Button("Bajar capa") && sel_ > 0) { std::swap(S.objs[sel_], S.objs[sel_ - 1]); sel_--; markDirty(); }
            }
        }
    }
    ImGui::End();
}

// Punto donde un rayo toca el suelo (terreno, suelos o el plano y=0).
bool Editor::groundHit(Scene& S, V3 ro, V3 rd, V3& hit) {
    float best = 1e9f;
    for (auto& o : S.objs) {
        if (!o.alive || o.kind != Kind::Floor) continue;
        float t;
        if (o.tn >= 2) {
            if (rayTerrain(o, ro, rd, 400.f, t) && t < best) best = t;
        } else if (std::fabs(rd.y) > 1e-5f) {
            float ty = o.pos.y + o.scale.y * 0.5f;
            t = (ty - ro.y) / rd.y;
            if (t > 0 && t < best) {
                V3 q = ro + rd * t;
                if (std::fabs(q.x - o.pos.x) <= o.scale.x * 0.5f && std::fabs(q.z - o.pos.z) <= o.scale.z * 0.5f) best = t;
            }
        }
    }
    if (best >= 1e8f && std::fabs(rd.y) > 1e-5f) {
        float t = -ro.y / rd.y;
        if (t > 0 && t < 400.f) best = t;
    }
    if (best >= 1e8f) return false;
    hit = ro + rd * best;
    return true;
}

void Editor::vegStamp(Scene& S, V3 hit) {
    VegLayer& L = S.veg[vegSel_];
    if (vegErase_) {
        float r2 = vegRadius_ * vegRadius_;
        std::vector<float> keep;
        keep.reserve(L.pts.size());
        for (size_t i = 0; i + 4 < L.pts.size(); i += 5) {
            float dx = L.pts[i] - hit.x, dz = L.pts[i + 2] - hit.z;
            if (dx * dx + dz * dz > r2) keep.insert(keep.end(), L.pts.begin() + i, L.pts.begin() + i + 5);
        }
        if (keep.size() != L.pts.size()) { L.pts.swap(keep); L.ver++; markDirty(); }
        return;
    }
    int n = std::max(1, std::min(14, (int)(vegRadius_ * vegRadius_ * 1.2f * vegDensity_)));
    if (L.pts.size() / 5 + n > 20000) { toast("Esta capa ya tiene muchas matas (20000)"); return; }
    static unsigned st = 2463534242u;
    auto rnd = [&]() { st ^= st << 13; st ^= st >> 17; st ^= st << 5; return (float)(st & 0xFFFFFF) / 16777215.f; };
    Obj* tr = nullptr;
    for (auto& o : S.objs) if (o.alive && o.kind == Kind::Floor && o.tn >= 2) { float lx = std::fabs(hit.x - o.pos.x), lz = std::fabs(hit.z - o.pos.z); if (lx <= o.scale.x * 0.5f && lz <= o.scale.z * 0.5f) { tr = &o; break; } }
    for (int i = 0; i < n; i++) {
        float a = rnd() * 6.2831853f, d = std::sqrt(rnd()) * vegRadius_;
        float x = hit.x + std::cos(a) * d, z = hit.z + std::sin(a) * d;
        float y = hit.y;
        if (tr) y = terrainSurface(*tr, x, z);
        L.pts.insert(L.pts.end(), {x, y, z, 0.75f + 0.5f * rnd(), rnd() * 180.f});
    }
    L.ver++;
    markDirty();
}

void Editor::gndStamp(Scene& S, V3 hit) {
    GroundLayer& L = S.gnd[gndSel_];
    if (gndErase_) {
        float r2 = gndRadius_ * gndRadius_;
        std::vector<float> keep;
        for (size_t i = 0; i + 3 < L.pts.size(); i += 4) {
            float dx = L.pts[i] - hit.x, dz = L.pts[i + 2] - hit.z;
            if (dx * dx + dz * dz > r2) keep.insert(keep.end(), L.pts.begin() + i, L.pts.begin() + i + 4);
        }
        if (keep.size() != L.pts.size()) { L.pts.swap(keep); L.ver++; markDirty(); }
        return;
    }
    if (L.pts.size() / 4 + 6 > 4000) { toast("Esta capa ya tiene muchas pinceladas (4000)"); return; }
    static unsigned st = 88172645u;
    auto rnd = [&]() { st ^= st << 13; st ^= st >> 17; st ^= st << 5; return (float)(st & 0xFFFFFF) / 16777215.f; };
    int n = std::max(1, std::min(4, (int)(gndRadius_ * gndRadius_ * 0.06f)));
    for (int i = 0; i < n; i++) {
        float a = rnd() * 6.2831853f, d = std::sqrt(rnd()) * gndRadius_ * 0.6f;
        L.pts.insert(L.pts.end(), {hit.x + std::cos(a) * d, hit.y, hit.z + std::sin(a) * d, gndRadius_ * (0.55f + 0.4f * rnd())});
    }
    L.ver++;
    markDirty();
}

// Lapiz de texturas: arena, pasto, roca, nieve, tierra o una imagen tuya.
bool Editor::gndPanel(Scene& S) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Pintar el suelo (lápiz de texturas)");
    if (S.gnd.empty()) ImGui::TextWrapped("Crea una capa, elige la textura (arena, pasto, roca...) y pasa el dedo por el suelo.");
    for (int i = 0; i < (int)S.gnd.size(); i++) {
        ImGui::PushID(1000 + i);
        ImGui::PushStyleColor(ImGuiCol_Button, gndSel_ == i ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        std::string lab = S.gnd[i].name + " (" + std::to_string(S.gnd[i].pts.size() / 4) + ")";
        if (wrapui::Button(lab.c_str(), ImVec2(ImGui::GetContentRegionAvail().x, fs * 2.2f)) && tapped()) gndSel_ = i;
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    if (wrapui::Button("+ Capa nueva de suelo", ImVec2(0, fs * 2.2f)) && tapped()) {
        GroundLayer L;
        L.name = "Suelo " + std::to_string(S.gnd.size() + 1);
        S.gnd.push_back(L);
        gndSel_ = (int)S.gnd.size() - 1;
        ch = true;
    }
    if (gndSel_ < 0 || gndSel_ >= (int)S.gnd.size()) { gndSel_ = S.gnd.empty() ? -1 : 0; if (gndSel_ < 0) return ch; }
    GroundLayer& L = S.gnd[gndSel_];
    ch |= textInput("##gn", "Nombre de la capa", L.name, "nombre");
    wrapui::Checkbox("Pintar el suelo (un dedo pinta, dos dedos mueven la cámara)", &gndPaint_);
    if (gndPaint_) vegPaint_ = false;
    {
        int m = gndErase_ ? 1 : 0;
        wrapui::RadioButton("Pintar##g", &m, 0); ImGui::SameLine();
        wrapui::RadioButton("Borrar##g", &m, 1);
        gndErase_ = m == 1;
    }
    numField("Tamaño del lápiz", gndRadius_, 0.5f, 15.f);
    static const char* nm[6] = {"Arena", "Pasto", "Roca", "Nieve", "Tierra", "Mi textura"};
    ImGui::TextUnformatted("Textura");
    for (int k = 0; k < 6; k++) {
        if (k % 3) ImGui::SameLine();
        ImGui::PushStyleColor(ImGuiCol_Button, L.preset == k ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        ImGui::PushID(2000 + k);
        if (wrapui::Button(nm[k], ImVec2(ImGui::GetContentRegionAvail().x / (3 - k % 3) - 4.f, fs * 2.2f)) && tapped()) { L.preset = k; L.ver++; ch = true; }
        ImGui::PopID();
        ImGui::PopStyleColor();
    }
    if (L.preset == 5) ch |= assetCombo("Imagen del suelo", L.tex, 0, "(elige una imagen)");
    ch |= numField("Repetición de la textura", L.scale, 0.02f, 2.f);
    if (wrapui::Button("Borrar toda la capa##g", ImVec2(0, fs * 2.2f)) && tapped()) {
        S.gnd.erase(S.gnd.begin() + gndSel_);
        gndSel_ = std::min(gndSel_, (int)S.gnd.size() - 1);
        if (S.gnd.empty()) gndPaint_ = false;
        ch = true;
    }
    return ch;
}

// Panel para pintar pasto y plantas sobre el suelo.
bool Editor::vegPanel(Scene& S) {
    bool ch = false;
    float fs = ImGui::GetFontSize();
    ImGui::SeparatorText("Vegetación (pintar pasto con el dedo)");
    if (S.veg.empty()) ImGui::TextWrapped("Crea una capa de pasto, activa \"Pintar\" y pasa el dedo por el suelo.");
    for (int i = 0; i < (int)S.veg.size(); i++) {
        ImGui::PushID(i);
        bool sel = vegSel_ == i;
        ImGui::PushStyleColor(ImGuiCol_Button, sel ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        std::string lab = S.veg[i].name + " (" + std::to_string(S.veg[i].pts.size() / 5) + ")";
        if (wrapui::Button(lab.c_str(), ImVec2(ImGui::GetContentRegionAvail().x, fs * 2.2f)) && tapped()) vegSel_ = i;
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    if (wrapui::Button("+ Capa nueva de pasto", ImVec2(0, fs * 2.2f)) && tapped()) {
        VegLayer L;
        L.name = "Pasto " + std::to_string(S.veg.size() + 1);
        S.veg.push_back(L);
        vegSel_ = (int)S.veg.size() - 1;
        ch = true;
    }
    if (vegSel_ < 0 || vegSel_ >= (int)S.veg.size()) { vegSel_ = S.veg.empty() ? -1 : 0; if (vegSel_ < 0) return ch; }
    VegLayer& L = S.veg[vegSel_];
    ch |= textInput("##vn", "Nombre de la capa", L.name, "nombre");
    wrapui::Checkbox("Pintar (un dedo pinta, dos dedos mueven la cámara)", &vegPaint_);
    if (vegPaint_) gndPaint_ = false;
    {
        int m = vegErase_ ? 1 : 0;
        wrapui::RadioButton("Pintar matas", &m, 0); ImGui::SameLine();
        wrapui::RadioButton("Borrar matas", &m, 1);
        vegErase_ = m == 1;
    }
    numField("Tamaño del pincel", vegRadius_, 0.5f, 12.f);
    numField("Cantidad (densidad)", vegDensity_, 0.2f, 4.f);
    static const char* st[12] = {"Realista", "Animado (dibujo)", "Lowpoly", "Mi textura", "Pradera con flores", "Flores silvestres", "Helecho", "Arbusto frondoso", "Pasto seco / paja", "Cañas y juncos", "Trébol (césped bajo)", "Hongos"};
    // preajustes de los estilos a color (el color de la textura se conserva con tinte blanco): altura, ancho, viento
    static const float VP[12][3] = {{0.6f, 0.5f, 0.5f}, {0.6f, 0.5f, 0.5f}, {0.6f, 0.5f, 0.5f}, {0.6f, 0.5f, 0.5f}, {0.7f, 0.8f, 0.5f}, {1.0f, 0.9f, 0.4f}, {0.8f, 1.2f, 0.3f}, {0.9f, 1.3f, 0.15f}, {0.8f, 0.7f, 0.6f}, {1.6f, 0.8f, 0.5f}, {0.25f, 0.6f, 0.1f}, {0.35f, 0.5f, 0.f}};
    ImGui::TextUnformatted("Tipo de pasto / vegetación");
    for (int k = 0; k < 12; k++) {
        if (k % 2) ImGui::SameLine();
        ImGui::PushID(8000 + k);
        ImGui::PushStyleColor(ImGuiCol_Button, L.style == k ? ImVec4(0.12f, 0.62f, 0.3f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
        if (wrapui::Button(st[k], ImVec2(ImGui::GetContentRegionAvail().x * (k % 2 ? 1.f : 0.5f) - (k % 2 ? 0.f : 4.f), fs * 2.2f)) && tapped()) {
            L.style = k;
            if (k >= 3) { for (int q = 0; q < 3; q++) L.col[q] = L.col2[q] = 1.f; }
            else if (k == 1) { float a[3] = {0.20f, 0.65f, 0.25f}, b[3] = {0.55f, 0.92f, 0.30f}; for (int q = 0; q < 3; q++) { L.col[q] = a[q]; L.col2[q] = b[q]; } }
            else { float a[3] = {0.28f, 0.50f, 0.16f}, b[3] = {0.62f, 0.78f, 0.30f}; for (int q = 0; q < 3; q++) { L.col[q] = a[q]; L.col2[q] = b[q]; } }
            if (k >= 4) { L.h = VP[k][0]; L.w = VP[k][1]; L.sway = VP[k][2]; }
            L.ver++;
            ch = true;
        }
        ImGui::PopStyleColor();
        ImGui::PopID();
    }
    if (L.style == 3) ch |= assetCombo("Textura del pasto (con transparencia)", L.tex, 0, "(elige una imagen png)");
    ch |= wrapui::ColorEdit3(L.style >= 3 ? "Tinte base (blanco = colores originales)" : "Color de la base", L.col);
    ch |= wrapui::ColorEdit3(L.style >= 3 ? "Tinte punta (blanco = colores originales)" : "Color de la punta", L.col2);
    bool g2 = false;
    g2 |= numField("Altura", L.h, 0.1f, 3.f);
    g2 |= numField("Ancho", L.w, 0.1f, 2.f);
    ch |= numField("Movimiento con el viento", L.sway, 0.f, 2.f);
    if (g2) { L.ver++; ch = true; }
    if (wrapui::Button("Borrar toda la capa", ImVec2(0, fs * 2.2f)) && tapped()) {
        S.veg.erase(S.veg.begin() + vegSel_);
        vegSel_ = std::min(vegSel_, (int)S.veg.size() - 1);
        if (S.veg.empty()) vegPaint_ = false;
        ch = true;
    }
    return ch;
}

void Editor::worldWin() {
    if (!showWorld || !hasScene()) return;
    float fs = ImGui::GetFontSize(), top = gBarTop();
    placeWindow(w_ - fs * 22.f - 6.f, top, fs * 22.f, h_ * 0.8f);
    if (wrapui::Begin("Mundo", &showWorld, dockFlags())) {
        wrapui::CloseBar(&showWorld);
        if (gDock.on) dragScroll();
        Scene& S = scene();
        bool ch = false;
        ch |= textInput("##sn", "Nombre de la escena", S.name, "nombre de la escena");
        bool was3d = S.is3d;
        if (wrapui::Checkbox("Escena 3D (si no, es 2D)", &S.is3d)) {
            ch = true;
            if (!S.is3d)  // en 2D no hay jugador
                S.objs.erase(std::remove_if(S.objs.begin(), S.objs.end(), [](const Obj& x) { return x.kind == Kind::Player; }), S.objs.end());
            sel_ = -1;
            if (was3d != S.is3d) resetView();
        }
        if (!S.is3d) {
            ImGui::SeparatorText("Mapa 2D");
            if (wrapui::Button("Crear mapa 2D...")) openMap();
            ImGui::TextDisabled("Nivel largo donde la pantalla sigue al personaje. Aparte del editor 2D normal.");
        }
        ImGuiWindow* wwin = ImGui::GetCurrentWindow();
        const int wt = S.is3d ? worldTab_ : 3;
        auto worldSec = [&](const char* name, int tab) {
            wwin->SkipItems = false;
            if (tab == wt) ImGui::SeparatorText(name);
            wwin->SkipItems = (tab != wt);
        };
        if (S.is3d) {   // pestañas grandes: cada una muestra solo lo de su tema
            static const char* WL[4] = {"Cielo y luz", "Ambiente", "Gráficos", "Juego"};
            float aw = ImGui::GetContentRegionAvail().x, sp = ImGui::GetStyle().ItemSpacing.x, bw = (aw - sp * 3) / 4.f;
            for (int t = 0; t < 4; t++) {
                if (t) ImGui::SameLine();
                ImGui::PushStyleColor(ImGuiCol_Button, worldTab_ == t ? ImVec4(0.18f, 0.55f, 0.85f, 1.f) : ImVec4(0.16f, 0.2f, 0.3f, 1.f));
                ImGui::PushID(t + 4800);
                if (wrapui::Button(WL[t], ImVec2(bw, fs * 2.4f)) && tapped()) worldTab_ = t;
                ImGui::PopID();
                ImGui::PopStyleColor();
            }
        }
        if (S.is3d) {
            worldSec("Cielo", 0);
            if (resetBtn("sky", "Restablecer cielo, nubes y astro")) {
                Scene f;
                S.skyStyle = f.skyStyle; S.skyTex = f.skyTex; S.cloudStyle = f.cloudStyle; S.cloudAmt = f.cloudAmt; S.cloudWind = f.cloudWind; S.cloudTex = f.cloudTex;
                S.sunBody = f.sunBody; S.sunSize = f.sunSize; S.flare = f.flare; S.sunDir = f.sunDir; S.ambient = f.ambient;
                for (int q = 0; q < 3; q++) { S.sun[q] = f.sun[q]; S.skyTop[q] = f.skyTop[q]; S.skyBot[q] = f.skyBot[q]; }
                ch = true;
            }
            ch |= wrapui::ColorEdit3("Arriba", S.skyTop);
            ch |= wrapui::ColorEdit3("Horizonte y niebla", S.skyBot);
            worldSec("Diseño del cielo", 0);
            {
                struct Sk { const char* n; float top[3], bot[3], sun[3], dir[3]; float amb; };
                static const Sk K[] = {
                    {"Degradado (simple)", {0.25f, 0.45f, 0.8f}, {0.75f, 0.85f, 0.95f}, {1.f, 0.95f, 0.85f}, {-0.4f, -1.f, -0.3f}, 0.35f},
                    {"Día con nubes", {0.2f, 0.42f, 0.85f}, {0.7f, 0.82f, 0.95f}, {1.f, 0.96f, 0.88f}, {-0.4f, -0.8f, -0.4f}, 0.4f},
                    {"Nublado suave", {0.55f, 0.6f, 0.68f}, {0.8f, 0.83f, 0.87f}, {0.9f, 0.92f, 0.95f}, {-0.3f, -0.9f, -0.3f}, 0.5f},
                    {"Noche con luna", {0.04f, 0.08f, 0.2f}, {0.12f, 0.18f, 0.33f}, {0.55f, 0.65f, 0.95f}, {0.3f, -0.55f, -0.6f}, 0.18f},
                    {"Noche estrellada", {0.01f, 0.01f, 0.05f}, {0.04f, 0.04f, 0.12f}, {0.35f, 0.4f, 0.7f}, {0.3f, -0.7f, 0.3f}, 0.14f},
                    {"Nebulosa violeta", {0.03f, 0.02f, 0.12f}, {0.08f, 0.05f, 0.25f}, {0.5f, 0.45f, 0.9f}, {0.3f, -0.7f, 0.3f}, 0.16f},
                    {"Nebulosa azul", {0.01f, 0.05f, 0.14f}, {0.03f, 0.15f, 0.3f}, {0.35f, 0.7f, 1.f}, {0.3f, -0.7f, 0.3f}, 0.18f},
                    {"Atardecer dorado", {0.3f, 0.3f, 0.5f}, {1.f, 0.62f, 0.3f}, {1.f, 0.7f, 0.35f}, {-0.8f, -0.18f, -0.4f}, 0.32f},
                    {"Amanecer rosa", {0.55f, 0.3f, 0.6f}, {1.f, 0.7f, 0.65f}, {1.f, 0.85f, 0.7f}, {-0.8f, -0.14f, 0.5f}, 0.34f},
                    {"Crepúsculo violeta", {0.12f, 0.1f, 0.35f}, {0.65f, 0.4f, 0.55f}, {0.9f, 0.55f, 0.6f}, {-0.8f, -0.12f, -0.4f}, 0.22f},
                    {"Cumulonimbo", {0.08f, 0.2f, 0.32f}, {0.55f, 0.7f, 0.8f}, {0.9f, 0.95f, 1.f}, {-0.4f, -0.8f, -0.4f}, 0.4f},
                };
                float bw = (ImGui::GetContentRegionAvail().x - 8.f) * 0.5f;
                for (int k = 0; k < (int)(sizeof(K) / sizeof(K[0])); k++) {
                    if (k % 2) ImGui::SameLine();
                    bool sel = S.skyStyle == k && S.skyTex.empty();
                    const Sk& a = K[k];
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(a.top[0] * 0.5f + 0.08f, a.top[1] * 0.5f + 0.08f, a.top[2] * 0.5f + 0.1f, 1.f));
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                    if (sel) { ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.12f, 0.9f, 0.75f, 1.f)); ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 3.f); }
                    bool hit = wrapui::Button(a.n, ImVec2(bw, ImGui::GetFontSize() * 2.4f)) && tapped();
                    if (sel) { ImGui::PopStyleVar(); ImGui::PopStyleColor(); }
                    ImGui::PopStyleColor(2);
                    if (hit) {
                        S.skyStyle = k; S.skyTex.clear();
                        for (int c = 0; c < 3; c++) { S.skyTop[c] = a.top[c]; S.skyBot[c] = a.bot[c]; S.sun[c] = a.sun[c]; }
                        S.sunDir = norm(V3{a.dir[0], a.dir[1], a.dir[2]});
                        S.ambient = a.amb;
                        ch = true;
                    }
                }
                ImGui::TextDisabled("Cada diseño cambia colores y luz; después puedes retocar los colores de arriba.");
                ch |= assetCombo("Cielo con tu imagen (panorama o foto)", S.skyTex, 0, "(sin imagen: usar el diseño)");
                if (S.skyTex.empty() && S.skyStyle == 0) ImGui::TextDisabled("Para elegir el tipo de nubes, escoge arriba un diseño de cielo con nubes.");
                if (S.skyTex.empty() && S.skyStyle > 0) {
                    worldSec("Nubes", 0);
                    static const char* CN[9] = {"Actuales", "Realistas (volumen y luz)", "Con mi imagen (solo las nubes)", "Cúmulos esponjosos", "Tormenta", "Cirros (finas y altas)", "Estratos (capas)", "Caricatura", "Atardecer (nubes de color)"};
                    for (int k = 0; k < 9; k++) {
                        ImGui::PushID(7100 + k);
                        if (wrapui::RadioButton(CN[k], S.cloudStyle == k)) { S.cloudStyle = k; ch = true; }
                        ImGui::PopID();
                    }
                    if (S.cloudStyle == 2) {
                        ch |= assetCombo("Imagen de nubes (foto con nubes, mejor si tiene fondo transparente)", S.cloudTex, 0, "(elige una imagen)");
                        ImGui::TextDisabled("Lo claro de la imagen se vuelve nube; lo oscuro o transparente es cielo.");
                    }
                    ch |= wrapui::SliderFloat("Cantidad de nubes", &S.cloudAmt, 0.f, 1.f);
                    ch |= wrapui::SliderFloat("Velocidad del viento", &S.cloudWind, 0.f, 5.f);
                }
            }
            worldSec("Sol y luz", 0);
            V3 d = norm(S.sunDir);
            float el = std::asin(std::max(-1.f, std::min(1.f, -d.y))), az = std::atan2(-d.x, -d.z);
            bool sc = false;
            sc |= ImGui::SliderAngle("Altura del sol", &el, 5.f, 89.f);
            sc |= ImGui::SliderAngle("Dirección", &az, -180.f, 180.f);
            if (sc) {
                S.sunDir = V3{-std::cos(el) * std::sin(az), -std::sin(el), -std::cos(el) * std::cos(az)};
                ch = true;
            }
            {
                static const char* BN[10] = {"Sol actual", "Sol nítido", "Sol con rayos", "Luna llena", "Luna creciente", "Planeta con anillos (Saturno)", "Planeta rojo (Marte)", "Planeta gaseoso (Júpiter)", "Gigante roja", "Planeta Tierra"};
                static const float BC[10][3] = {{1.f, 0.95f, 0.85f}, {1.f, 0.97f, 0.85f}, {1.f, 0.9f, 0.7f}, {0.6f, 0.68f, 0.9f}, {0.6f, 0.68f, 0.9f}, {1.f, 0.9f, 0.7f}, {1.f, 0.8f, 0.7f}, {1.f, 0.92f, 0.8f}, {1.f, 0.55f, 0.35f}, {0.85f, 0.9f, 1.f}};
                ImGui::TextUnformatted("Astro del cielo:");
                for (int k = 0; k < 10; k++) {
                    if (k % 2) ImGui::SameLine();
                    ImGui::PushID(8100 + k);
                    ImGui::PushStyleColor(ImGuiCol_Button, S.sunBody == k ? ImVec4(0.12f, 0.55f, 0.75f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
                    if (wrapui::Button(BN[k], ImVec2(ImGui::GetContentRegionAvail().x * (k % 2 ? 1.f : 0.5f) - (k % 2 ? 0.f : 4.f), ImGui::GetFontSize() * 2.2f)) && tapped()) {
                        S.sunBody = k;
                        { static const float BS[10] = {1.f, 1.f, 1.5f, 1.6f, 1.6f, 4.f, 2.2f, 2.6f, 2.f, 2.6f}; S.sunSize = BS[k]; }
                        for (int q = 0; q < 3; q++) S.sun[q] = BC[k][q];
                        ch = true;
                    }
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
                ch |= wrapui::SliderFloat("Tamaño del astro (pequeño ... enorme)", &S.sunSize, 0.1f, 30.f);
            }
            ch |= wrapui::ColorEdit3("Color del sol", S.sun);
            ch |= wrapui::Checkbox("Destellos de luz (círculos) al mirar al Sol", &S.flare);
            ch |= numField("Luz ambiente", S.ambient, 0.f, 1.f);
            ch |= wrapui::SliderFloat("Oscuridad de las sombras (izq = claras, der = oscuras)", &S.shadowAmt, 0.f, 1.6f);
            {
                bool lim = S.drawDist > 0.f;
                if (wrapui::Checkbox("Limitar la distancia de dibujado (mapas grandes, más rendimiento)", &lim)) { S.drawDist = lim ? 120.f : 0.f; ch = true; }
                if (lim) ch |= wrapui::SliderFloat("Distancia a la que se ve el mapa (metros)", &S.drawDist, 15.f, 600.f, "%.0f");
            }
            ch |= numField("Niebla", S.fog, 0.f, 0.15f, "%.3f");
            {
                bool own = S.fogMode == 1;
                if (wrapui::Checkbox("Color propio para la niebla", &own)) { S.fogMode = own ? 1 : 0; ch = true; }
                if (own) ch |= wrapui::ColorEdit3("Color de la niebla", S.fogCol);
            }
            worldSec("Motor gráfico (ajusta a tu teléfono o PC)", 2);
            if (resetBtn("gfx", "Restablecer motor gráfico, filtro y desenfoque")) {
                Project f;
                Project& P2 = edit_.proj;
                P2.gfxShadow = f.gfxShadow; P2.gfxSoft = f.gfxSoft; P2.gfxSpec = f.gfxSpec; P2.gfxTone = f.gfxTone; P2.gfxEv = f.gfxEv; P2.gfxAniso = f.gfxAniso;
                P2.gfxFilter = f.gfxFilter; P2.gfxFilterAmt = f.gfxFilterAmt; P2.gfxPreset = f.gfxPreset; P2.mblur = f.mblur; P2.rtx = f.rtx; P2.quality = f.quality;
                ch = true;
            }
            {
                Project& P = edit_.proj;
                static const char* pn[4] = {"Ahorro (gama baja)", "Equilibrado", "Alto", "Ultra (PC / gama alta)"};
                for (int k = 0; k < 4; k++) {
                    if (k % 2) ImGui::SameLine();
                    bool sel = P.gfxPreset == k;
                    ImGui::PushStyleColor(ImGuiCol_Button, sel ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
                    bool hit = wrapui::Button(pn[k], ImVec2((ImGui::GetContentRegionAvail().x - 8.f) * (k % 2 ? 1.f : 0.5f) + (k % 2 ? 8.f : 0.f), ImGui::GetFontSize() * 2.4f)) && tapped();
                    ImGui::PopStyleColor();
                    if (hit) {
                        static const struct { int q, sh, soft; float spec, tone, ev; int an; float gi; bool rtx; } PR[4] = {
                            {0, 1, 0, 0.f, 0.f, 0.f, 1, 0.f, false}, {1, 2, 1, 0.4f, 0.4f, 0.f, 4, 0.6f, false},
                            {2, 3, 1, 0.6f, 0.6f, 0.f, 8, 1.f, false}, {2, 4, 2, 0.8f, 0.8f, 0.f, 16, 1.2f, true}};
                        P.gfxPreset = k; P.quality = PR[k].q; P.gfxShadow = PR[k].sh; P.gfxSoft = PR[k].soft; P.gfxSpec = PR[k].spec;
                        P.gfxTone = PR[k].tone; P.gfxEv = PR[k].ev; P.gfxAniso = PR[k].an; P.gi = PR[k].gi; P.rtx = PR[k].rtx;
                        ch = true;
                    }
                }
                ImGui::TextDisabled("Un toque ajusta todo. Abajo puedes cambiar cada opción por separado.");
                static const char* shn[5] = {"Auto", "512", "1024", "2048", "4096"};
                ImGui::TextUnformatted("Resolución de sombras (más alto = más nítido y más pesado)");
                for (int k = 0; k < 5; k++) {
                    if (k) ImGui::SameLine();
                    if (wrapui::RadioButton(shn[k], P.gfxShadow == k)) { P.gfxShadow = k; P.gfxPreset = -1; ch = true; }
                }
                static const char* sfn[3] = {"Normal", "Suaves", "Muy suaves"};
                ImGui::TextUnformatted("Bordes de sombras");
                for (int k = 0; k < 3; k++) {
                    if (k) ImGui::SameLine();
                    if (wrapui::RadioButton(sfn[k], P.gfxSoft == k)) { P.gfxSoft = k; P.gfxPreset = -1; ch = true; }
                }
                static const int an[4] = {1, 4, 8, 16};
                ImGui::TextUnformatted("Nitidez de texturas lejanas (anisotrópico)");
                for (int k = 0; k < 4; k++) {
                    if (k) ImGui::SameLine();
                    char b[8]; snprintf(b, sizeof b, k ? "%dx" : "Apagado", an[k]);
                    if (wrapui::RadioButton(b, P.gfxAniso == an[k])) { P.gfxAniso = an[k]; P.gfxPreset = -1; ch = true; }
                }
                ch |= wrapui::SliderFloat("Brillo del sol en materiales", &P.gfxSpec, 0.f, 1.f);
                ch |= wrapui::SliderFloat("Tono de cine (colores como película)", &P.gfxTone, 0.f, 1.f);
                ch |= wrapui::SliderFloat("Exposición (luz de la cámara)", &P.gfxEv, -1.f, 1.f);
                ImGui::TextDisabled("Estas opciones se guardan en el juego. Pruébalo en tu teléfono: si va lento, baja sombras y suavidad.");
            }
            worldSec("Filtro de pantalla (se ve al jugar)", 2);
            {
                Project& P = edit_.proj;
                static const char* fnm[10] = {"Ninguno", "Blanco y negro", "Bandas de color", "Caricatura (bordes)", "Explosión de contraste", "Texturas realzadas", "Borroso", "Pixelado", "Retro (líneas)", "Sepia"};
                float bw = (ImGui::GetContentRegionAvail().x - 8.f) * 0.5f;
                for (int k = 0; k < 10; k++) {
                    if (k % 2) ImGui::SameLine();
                    ImGui::PushID(1000 + k);
                    ImGui::PushStyleColor(ImGuiCol_Button, P.gfxFilter == k ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
                    if (wrapui::Button(fnm[k], ImVec2(bw, ImGui::GetFontSize() * 2.2f)) && tapped()) { P.gfxFilter = k; ch = true; }
                    ImGui::PopStyleColor();
                    ImGui::PopID();
                }
                if (P.gfxFilter) ch |= wrapui::SliderFloat("Intensidad del filtro", &P.gfxFilterAmt, 0.f, 1.f);
            }
            worldSec("Calidad general", 2);
            for (int k = 0; k < 3; k++) {
                if (k) ImGui::SameLine();
                if (wrapui::RadioButton(kQualityNames[k], edit_.proj.quality == k)) { edit_.proj.quality = k; ch = true; }
            }
            worldSec("Ambientes listos (un toque)", 1);
            {
                struct Amb { const char* n; float top[3], bot[3], sun[3]; float amb, fog; int tone, atmo; float amt; int sfx; };
                static const Amb A[] = {
                    {"Terror oscuro", {0.02f, 0.03f, 0.06f}, {0.05f, 0.06f, 0.1f}, {0.5f, 0.55f, 0.8f}, 0.12f, 0.05f, 2, 1, 0.8f, 1},
                    {"Noche con lluvia", {0.03f, 0.05f, 0.12f}, {0.1f, 0.13f, 0.22f}, {0.5f, 0.6f, 0.9f}, 0.2f, 0.03f, 2, 2, 1.2f, 0},
                    {"Atardecer cálido", {0.35f, 0.3f, 0.6f}, {1.0f, 0.55f, 0.3f}, {1.f, 0.65f, 0.4f}, 0.35f, 0.012f, 1, 0, 0.f, 0},
                    {"Desierto con polvo", {0.5f, 0.65f, 0.9f}, {0.95f, 0.85f, 0.65f}, {1.f, 0.92f, 0.75f}, 0.45f, 0.02f, 1, 3, 0.5f, 0},
                    {"Nieve y frío", {0.55f, 0.65f, 0.8f}, {0.85f, 0.9f, 0.95f}, {0.85f, 0.92f, 1.f}, 0.5f, 0.02f, 2, 4, 1.f, 0},
                    {"Ciudad neón", {0.05f, 0.02f, 0.12f}, {0.25f, 0.08f, 0.3f}, {0.8f, 0.4f, 1.f}, 0.22f, 0.02f, 2, 0, 0.f, 0},
                    {"Día soleado", {0.25f, 0.5f, 0.9f}, {0.75f, 0.88f, 0.98f}, {1.f, 0.96f, 0.88f}, 0.42f, 0.008f, 0, 0, 0.f, 0},
                    {"Niebla misteriosa", {0.3f, 0.34f, 0.4f}, {0.55f, 0.58f, 0.62f}, {0.75f, 0.78f, 0.85f}, 0.3f, 0.04f, 2, 1, 1.4f, 0},
                };
                for (int k = 0; k < (int)(sizeof(A) / sizeof(A[0])); k++) {
                    if (k % 2) ImGui::SameLine();
                    if (wrapui::Button(A[k].n)) {
                        const Amb& a = A[k];
                        for (int c = 0; c < 3; c++) { S.skyTop[c] = a.top[c]; S.skyBot[c] = a.bot[c]; S.sun[c] = a.sun[c]; }
                        S.ambient = a.amb; S.fog = a.fog; S.tone = a.tone; S.atmo = a.atmo;
                        if (a.atmo) { float dummy; atmoDefaults(a.atmo, S.atmoCol, dummy); S.atmoAmt = a.amt; }
                        sfxPreset(S.sfx, a.sfx); if (a.sfx == 1) { S.sfx.noise = 0.15f; S.sfx.scan = 0.1f; S.sfx.track = 0.05f; }
                        ch = true;
                    }
                }
                ImGui::TextDisabled("Cambia cielo, luz, niebla, clima y color. Luego puedes ajustar cada cosa abajo.");
            }
            worldSec("Ambientación (color del mundo)", 1);
            if (resetBtn("amb", "Restablecer ambientación, clima y niebla")) {
                Scene f;
                S.tone = f.tone; S.atmo = f.atmo; S.atmoAmt = f.atmoAmt; S.atmoStyle = f.atmoStyle; S.fog = f.fog; S.fogMode = f.fogMode;
                S.drawDist = f.drawDist; S.shadowAmt = f.shadowAmt;
                for (int q = 0; q < 3; q++) { S.atmoCol[q] = f.atmoCol[q]; S.fogCol[q] = f.fogCol[q]; }
                ch = true;
            }
            for (int k = 0; k < 3; k++) {
                if (k) ImGui::SameLine();
                if (wrapui::RadioButton(kToneNames[k], S.tone == k)) { S.tone = k; ch = true; }
            }
            worldSec("Clima y niebla del mundo", 1);
            for (int k = 0; k < 6; k++) {
                if (k % 3) ImGui::SameLine();
                if (wrapui::RadioButton(kAtmoNames[k], S.atmo == k)) {
                    S.atmo = k;
                    float a;
                    atmoDefaults(k, S.atmoCol, a);
                    if (k) S.atmoAmt = a;
                    ch = true;
                }
            }
            if (S.atmo > 0) {
                ch |= wrapui::SliderFloat("Cantidad (hasta 3 = muchísimo)", &S.atmoAmt, 0.f, 3.f);
                ch |= wrapui::ColorEdit3("Color", S.atmoCol);
                ImGui::TextUnformatted("Diseño");
                if (wrapui::RadioButton("Clásico", S.atmoStyle == 0)) { S.atmoStyle = 0; ch = true; }
                ImGui::SameLine();
                if (wrapui::RadioButton("Realista", S.atmoStyle == 1)) { S.atmoStyle = 1; ch = true; }
            }
            worldSec("Pruebas y sonido", 3);
            ch |= wrapui::Checkbox("Ver FPS y milisegundos (rendimiento)", &edit_.proj.showFps);
            ch |= wrapui::Checkbox("Sonido por distancia (volumen y lado izquierdo/derecho)", &edit_.proj.spatial);
            if (edit_.proj.spatial) ch |= wrapui::SliderFloat("Se oye hasta (m)", &edit_.proj.spatialR, 5.f, 200.f, "%.0f");
            worldSec("Explosión (bombas y bloque «Explosión aquí»)", 3);
            {
                auto& B = edit_.proj.boom;
                if (wrapui::RadioButton("Por defecto (fuego, chispas y humo)", B.mode == 0)) { B.mode = 0; ch = true; }
                if (wrapui::RadioButton("Mis imágenes (sprites en orden)", B.mode == 1)) { B.mode = 1; ch = true; }
                if (wrapui::RadioButton("Mi modelo 3D (crece y se desvanece)", B.mode == 2)) { B.mode = 2; ch = true; }
                ch |= wrapui::SliderFloat("Tamaño del efecto", &B.size, 0.2f, 4.f, "%.1f");
                ch |= wrapui::SliderFloat("Duración (s)", &B.time, 0.2f, 3.f, "%.1f");
                if (B.mode == 1) {
                    for (size_t fi = 0; fi < B.frames.size(); fi++) {
                        ImGui::PushID((int)fi + 7000);
                        ImGui::Text("%d. %s", (int)fi + 1, B.frames[fi].c_str());
                        ImGui::SameLine();
                        if (wrapui::Button("Quitar") && tapped()) { B.frames.erase(B.frames.begin() + fi); ch = true; ImGui::PopID(); break; }
                        ImGui::PopID();
                    }
                    static std::string addF;
                    if (assetCombo("Agregar imagen", addF, 1, "(elegir)") && !addF.empty()) { B.frames.push_back(addF); addF.clear(); ch = true; }
                    ImGui::TextDisabled("Cada imagen es un cuadro de la animación; se muestran en orden durante la duración.");
                } else if (B.mode == 2) ch |= assetCombo("Modelo de la explosión", B.model, 2, "(elegir)");
            }
            worldSec("Rendimiento", 2);
            {
                auto& P = edit_.proj.perf;
                ch |= wrapui::Checkbox("Solo dibujar lo que ve la cámara", &P.cull);
                ch |= wrapui::Checkbox("No dibujar lo muy lejano", &P.distOn);
                if (P.distOn) ch |= wrapui::SliderFloat("Distancia", &P.dist, 20.f, 400.f, "%.0f m");
                ch |= wrapui::Checkbox("Límite de FPS", &P.fpsOn);
                if (P.fpsOn) {
                    if (wrapui::RadioButton("30", P.fps == 30)) { P.fps = 30; ch = true; }
                    ImGui::SameLine();
                    if (wrapui::RadioButton("60", P.fps == 60)) { P.fps = 60; ch = true; }
                    ImGui::SameLine();
                    if (wrapui::RadioButton("120", P.fps == 120)) { P.fps = 120; ch = true; }
                }
                ch |= wrapui::Checkbox("Máximo de partículas", &P.partOn);
                if (P.partOn) ch |= wrapui::SliderInt("Partículas", &P.part, 20, 900);
                ch |= wrapui::Checkbox("Máximo de luces", &P.lightOn);
                if (P.lightOn) ch |= wrapui::SliderInt("Luces", &P.light, 1, 4);
                ch |= wrapui::Checkbox("Ahorrar memoria de imágenes", &P.texOn);
                if (P.texOn) ch |= wrapui::SliderInt("Nivel (1 suave - 3 fuerte)", &P.tex, 1, 3);
                ch |= wrapui::Checkbox("Máximo de personajes clonados vivos", &P.aliveOn);
                if (P.aliveOn) ch |= wrapui::SliderInt("Vivos", &P.alive, 1, 200);
                ch |= wrapui::Checkbox("Modelos pesados más simples al alejarse (LOD)", &P.lod);
                ch |= wrapui::Checkbox("Resolución dinámica (baja sola si los FPS caen)", &P.dynRes);
                if (P.dynRes) ch |= wrapui::SliderInt("FPS que quieres mantener", &P.dynTarget, 20, 120);
                ch |= wrapui::Checkbox("Modo ahorro de batería y calor (30 FPS, resolución máx. 80 %)", &P.saver);
                ch |= wrapui::Checkbox("Precargar modelos e imágenes de la escena (evita tirones)", &P.warm);
#if defined(__ANDROID__)
                ch |= wrapui::Checkbox("Simulación liviana de trazado de rayos (sombras más nítidas, no es ray tracing real)", &P.rt);
#else
                ch |= wrapui::Checkbox("Trazado de rayos (Windows): sombras y filtrado al máximo; aproximación, no ray tracing real", &P.rt);
#endif
                ch |= wrapui::Checkbox("Guardar resumen de rendimiento de cada partida (archivo local)", &P.telem);
                ImGui::TextDisabled("No lee el sensor de temperatura del teléfono: el ahorro se basa en los FPS y en el límite que elijas.");
            }
            worldSec("Escenas", 3);
            ch |= wrapui::Checkbox("Mantener variables y música al cambiar de escena", &edit_.proj.keepAcrossScenes);
            ImGui::TextDisabled("Apagado (recomendado): cada escena empieza de cero. Las variables guardadas en el dispositivo siempre se conservan.");
            worldSec("Límites del mapa", 3);
            {
                static const char* LN[3] = {"Sin límite", "Círculo (radio)", "Cuadro"};
                int lm = std::max(0, std::min(2, S.limMode));
                if (ImGui::BeginCombo("Límite exterior", LN[lm])) {
                    for (int k = 0; k < 3; k++) if (ImGui::Selectable(LN[k], k == lm)) { S.limMode = k; ch = true; }
                    ImGui::EndCombo();
                }
                if (S.limMode) {
                    ch |= wrapui::SliderFloat("Radio / mitad del lado (m)", &S.limR, 5.f, 500.f);
                    ch |= wrapui::SliderFloat("Centro X", &S.limCx, -500.f, 500.f);
                    ch |= wrapui::SliderFloat("Centro Z", &S.limCz, -500.f, 500.f);
                    if (wrapui::Button("Centrar donde empieza el jugador")) { S.limCx = S.start.x; S.limCz = S.start.z; ch = true; }
                }
                char zb[80]; snprintf(zb, sizeof zb, "Dibujar zona prohibida (%d)", (int)S.zones.size());
                if (wrapui::Button(zb)) { zoneOpen_ = true; mvInit_ = false; }
                for (size_t zi = 0; zi < S.zones.size(); zi++) {
                    ImGui::PushID((int)zi + 5000);
                    Scene::Zone& z = S.zones[zi];
                    ImGui::Text("Zona %d:", (int)zi + 1);
                    ImGui::SameLine();
                    bool a = z.who & 1, b = z.who & 2, c = z.who & 4;
                    if (ImGui::Checkbox("Jugador", &a)) { z.who = (a ? 1 : 0) | (z.who & 6); ch = true; }
                    ImGui::SameLine();
                    if (ImGui::Checkbox("Enemigos/NPC", &b)) { z.who = (b ? 2 : 0) | (z.who & 5); ch = true; }
                    ImGui::SameLine();
                    if (ImGui::Checkbox("Autos con ruta", &c)) { z.who = (c ? 4 : 0) | (z.who & 3); ch = true; }
                    if (textInput("##zonly", "Solo para este objeto (nombre, opcional)", z.only, "nombre del objeto")) ch = true;
                    if (wrapui::Button("Borrar zona")) { S.zones.erase(S.zones.begin() + zi); ch = true; ImGui::PopID(); break; }
                    ImGui::PopID();
                }
                if (zoneOpen_) ch |= zoneWindow(S);
            }
            worldSec("Mar / agua (opcional)", 1);
            if (resetBtn("sea", "Restablecer agua")) {
                Scene f;
                S.sea = f.sea; S.seaStyle = f.seaStyle; S.seaY = f.seaY; S.seaAlpha = f.seaAlpha;
                for (int q = 0; q < 3; q++) S.seaCol[q] = f.seaCol[q];
                ch = true;
            }
            ch |= wrapui::Checkbox("Poner agua en la escena", &S.sea);
            if (S.sea) {
                {
                    static const char* WN[] = {"Actual", "Caricatura (anime)", "Realista", "Oscuro cinematográfico", "Cristal transparente", "Tropical (turquesa)", "Pantano turbio"};
                    static const float WC[7][3] = {{0.08f, 0.32f, 0.45f}, {0.2f, 0.6f, 0.95f}, {0.05f, 0.25f, 0.35f}, {0.06f, 0.14f, 0.18f}, {0.5f, 0.8f, 0.9f}, {0.1f, 0.8f, 0.8f}, {0.22f, 0.3f, 0.12f}};
                    ImGui::TextUnformatted("Diseño del agua:");
                    for (int k = 0; k < 7; k++) {
                        ImGui::PushID(7000 + k);
                        if (wrapui::RadioButton(WN[k], S.seaStyle == k)) {
                            S.seaStyle = k;
                            for (int q = 0; q < 3; q++) S.seaCol[q] = WC[k][q];
                            if (k == 4) S.seaAlpha = 0.6f; else if (k == 6) S.seaAlpha = 1.f; else if (k >= 1) S.seaAlpha = 0.8f;
                            ch = true;
                        }
                        ImGui::PopID();
                    }
                    ImGui::TextDisabled("Al elegir un diseño se ajustan sus colores; después puedes cambiarlos abajo.");
                }
                ch |= stepper("Altura del agua", S.seaY, 0.5f);
                ch |= wrapui::SliderFloat("Transparencia", &S.seaAlpha, 0.2f, 1.f);
                ch |= wrapui::ColorEdit3("Color del agua", S.seaCol);
            }
            ch |= gndPanel(S);
            ch |= vegPanel(S);
            worldSec("Modo RTX (opcional)", 2);
            ch |= wrapui::Checkbox("Activar RTX (sombras suaves, brillos y reflejos extra)", &edit_.proj.rtx);
            ImGui::TextDisabled("Es una imitación visual: pide más al teléfono. Desactivado por defecto.");
            worldSec("Iluminación global y gráficos pro", 2);
            {
                bool on = edit_.proj.gi > 0.f;
                if (wrapui::Checkbox("Luz rebotada, oclusión y colores de cine", &on)) { edit_.proj.gi = on ? 1.f : 0.f; ch = true; }
                if (on) ch |= wrapui::SliderFloat("Intensidad", &edit_.proj.gi, 0.2f, 1.5f);
                ImGui::TextDisabled("Rebote del suelo, relleno en el lado sombra, sombras con color de cielo, base de paredes más oscura y tono de película. Casi no pesa.");
            }
            worldSec("Desenfoque de movimiento", 2);
            {
                bool on = edit_.proj.mblur > 0.f;
                if (wrapui::Checkbox("Desenfocar la vista al mover la cámara", &on)) { edit_.proj.mblur = on ? 0.5f : 0.f; ch = true; }
                if (on) ch |= wrapui::SliderFloat("Cantidad de desenfoque", &edit_.proj.mblur, 0.05f, 3.f);
                ImGui::TextDisabled("Solo se nota en el juego (no en el editor) y solo cuando la cámara se mueve o gira.");
            }
            worldSec("Jugador", 3);
            ImGui::TextWrapped("El jugador es el objeto verde \"Jugador\": tócalo en la escena y arrástralo para moverlo; sus opciones (cámara, arma, proyectil) salen en Propiedades.");
            if (wrapui::Button("Seleccionar al jugador")) { sel_ = playerIndex(S); showProps = true; }
            wrapui::Next("Jugador = centro de la vista");
            if (wrapui::Button("Jugador = centro de la vista")) {
                int pi = playerIndex(S);
                if (pi >= 0) { S.objs[pi].pos = V3{target_.x, 0.9f, target_.z}; ch = true; }
            }
        } else {
            ch |= wrapui::ColorEdit3("Fondo", S.skyBot);
        }
        worldSec("Capa de la cámara (efectos e imágenes fijas)", 3);
        ch |= layerPanel(S);
        wwin->SkipItems = false;
        ImGui::Separator();
        if (edit_.proj.scenes.size() > 1 && wrapui::Button("Borrar esta escena")) ImGui::OpenPopup("delscene");
        if (ImGui::BeginPopup("delscene")) {
            ImGui::TextUnformatted("¿Borrar la escena y todos sus objetos?");
            if (wrapui::Button("Sí, borrar")) {
                edit_.proj.scenes.erase(edit_.proj.scenes.begin() + sceneIdx_);
                setScene(std::min(sceneIdx_, (int)edit_.proj.scenes.size() - 1));
                ch = true;
                ImGui::CloseCurrentPopup();
            }
            wrapui::Next("Cancelar");
            if (wrapui::Button("Cancelar")) ImGui::CloseCurrentPopup();
            ImGui::EndPopup();
        }
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::hudWin(Renderer*) {
    if (!showHud) return;
    Project& P = edit_.proj;
    float fs = ImGui::GetFontSize(), top = gBarTop();
    placeWindow(w_ - fs * 23.f - 6.f, top, fs * 23.f, h_ * 0.85f);
    if (wrapui::Begin("Botones y arma", &showHud, dockFlags())) {
        wrapui::CloseBar(&showHud);
        if (gDock.on) dragScroll();
        bool ch = false;
        ImGui::SeparatorText("Orientación del juego");
        {
            int o0 = P.exportCfg.orient, o1 = o0;
            wrapui::RadioButton("Horizontal (acostado)", &o1, 0);
            wrapui::RadioButton("Vertical (de pie)", &o1, 1);
            wrapui::RadioButton("Automática (según cómo gires el teléfono)", &o1, 2);
            if (o1 != o0) { P.exportCfg.orient = o1; ch = true; }
        }
        ImGui::SeparatorText("Pantalla del juego (HUD) lista para usar");
        {
            GameUi& U = P.ui;
            ch |= wrapui::Checkbox("Activar pantalla de juego profesional", &U.on);
            ImGui::TextDisabled("Barras, minimapa, brújula, mira y más, sin programar. Usa las variables vida, escudo, municion, puntos, tiempo y objetivo.");
            if (U.on) {
                ImGui::TextWrapped("Estilos rápidos (un toque):");
                auto preset = [&](const char* n, bool he, bool sh, bool am, bool sl, bool mm, bool co, bool sp, bool ti, bool sc, int cr, int gr) {
                    if (wrapui::Button(n)) {
                        U.health = he; U.shield = sh; U.ammo = am; U.slots = sl; U.minimap = mm; U.compass = co; U.speedo = sp; U.timer = ti; U.score = sc;
                        U.crosshair = cr; U.grade = gr; ch = true;
                    }
                };
                preset("Disparos (Doom / Call of Duty)", true, true, true, true, true, false, false, false, false, 4, 0);
                preset("Mundo abierto (Watch Dogs / Fortnite)", true, true, true, true, true, true, false, false, true, 3, 4);
                preset("Carreras (Need for Speed)", false, false, false, false, true, false, true, true, false, 0, 4);
                preset("Aventura / terror", true, false, false, false, false, false, false, false, false, 1, 1);
                ImGui::Separator();
                ch |= wrapui::Checkbox("Barras de pelea arriba (jugador y rival, reloj, combos)", &U.fight);
                ch |= wrapui::Checkbox("Barra de vida", &U.health);
                ch |= wrapui::Checkbox("Barra de escudo (absorbe el daño primero)", &U.shield);
                ch |= wrapui::Checkbox("Munición", &U.ammo);
                ch |= wrapui::Checkbox("Barra de armas numeradas", &U.slots);
                ch |= wrapui::Checkbox("Minimapa (enemigos rojos, objetos amarillos)", &U.minimap);
                if (U.minimap) {
                    ch |= ImGui::Combo("Estilo del minimapa", &U.mapStyle, "Círculo (Vice City / San Andreas)\0Óvalo (GTA III)\0Rectángulo (GTA V)\0Cuadrado\0Teléfono vertical (Watch Dogs 2)\0Anillo transparente (RDR / GTA IV)\0");
                    ch |= wrapui::SliderFloat("Alcance del minimapa (cuánto se ve)", &U.mapRange, 6.f, 120.f);
                    ch |= wrapui::SliderFloat("Tamaño del minimapa", &U.mapSize, 0.5f, 2.f);
                    if (scene().is3d) ch |= wrapui::Checkbox("El minimapa gira con la cámara", &U.mapRotate);
                    ImGui::TextDisabled("Dibuja lo que hay en tu escena: pisos claros, paredes oscuras, enemigos rojos y objetos amarillos.");
                }
                ch |= wrapui::Checkbox("Brújula", &U.compass);
                ch |= wrapui::Checkbox("Velocímetro (modo vehículo)", &U.speedo);
                ch |= wrapui::Checkbox("Reloj (cuenta hacia arriba solo; es la variable tiempo)", &U.timer);
                ch |= wrapui::Checkbox("Puntos (variable puntos)", &U.score);
                ch |= wrapui::Checkbox("Objetivo (texto de la variable objetivo)", &U.objective);
                ch |= wrapui::Checkbox("Marcador rojo al acertar un disparo", &U.hitmark);
                ch |= wrapui::Checkbox("Pantalla roja pulsando con poca vida", &U.lowHp);
                ch |= ImGui::Combo("Mira", &U.crosshair, "Ninguna\0Punto\0Cruz\0Círculo\0Cruz con hueco\0");
                ch |= ImGui::Combo("Estilo de color", &U.grade, "Normal\0Cine (barras negras)\0Noche\0Frío\0Atardecer\0Retro\0");
                ch |= wrapui::SliderFloat("Oscurecer bordes", &U.vignette, 0.f, 1.f);
                ch |= ImGui::ColorEdit3("Color de las barras", U.accent);
                ImGui::TextDisabled("El estilo de color es un tinte sobre la pantalla (barato para el teléfono), no corrección de color real.");
                if (wrapui::Button("Agregar botones de móvil: Correr, Agacharse y Recargar")) {
                    if (P.hudDefault) { P.hud = defaultHud(); P.hudDefault = false; }
                    auto add = [&](const char* l, float x, float y, float r, HudAct a, float cr, float cg, float cb) {
                        HudBtn b; b.label = l; b.x = x; b.y = y; b.r = r; b.act = a; b.color[0] = cr; b.color[1] = cg; b.color[2] = cb; P.hud.push_back(b);
                    };
                    add("CORRER", 0.14f, 0.52f, 0.07f, HudAct::Sprint, 0.95f, 0.8f, 0.2f);
                    add("AGACHAR", 0.89f, 0.40f, 0.07f, HudAct::Crouch, 0.6f, 0.5f, 1.f);
                    add("RECARGAR", 0.77f, 0.60f, 0.07f, HudAct::Reload, 0.3f, 0.9f, 0.5f);
                    ch = true;
                }
            }
        }
        ImGui::SeparatorText("Controles en escenas 2D (táctiles y teclado)");
        {
            int c0 = P.ctl2d, c1 = c0;
            wrapui::RadioButton("Ninguno", &c1, 0);
            wrapui::RadioButton("Cruceta (4 flechas) + botones A y B", &c1, 1);
            wrapui::RadioButton("Palanca + botones A y B", &c1, 2);
            wrapui::RadioButton("Plataformas: izquierda, derecha y saltar (A)", &c1, 3);
            if (c1 != c0) { P.ctl2d = c1; ch = true; }
            if (P.ctl2d > 0) {
                ImGui::TextDisabled("Se programan con el bloque \"Cuando se presione el botón\" y el nombre: Izquierda, Derecha, Arriba, Abajo, A o B. En Windows: flechas o WASD, Espacio/Z = A, X = B.");
            }
        }
        ImGui::SeparatorText("Resolución del juego (solo al jugar y en el juego exportado)");
        {
            static const int kRes[] = {550, 720, 900, 1080, 1440, 2160, 2880, 4320, 0};
            static const char* kResN[] = {"550p (básica)", "720p (HD)", "900p", "1080p (Full HD, por defecto)", "1440p (2K)", "2160p (4K)", "2880p (5K)", "4320p (8K, solo equipos muy potentes)", "Nativa (la de la pantalla)"};
            int cur = 3;
            for (int i = 0; i < 9; i++) if (kRes[i] == P.resH) cur = i;
            if (ImGui::BeginCombo("Resolución", kResN[cur])) {
                for (int i = 0; i < 9; i++) if (ImGui::Selectable(kResN[i], i == cur)) { P.resH = kRes[i]; ch = true; }
                ImGui::EndCombo();
            }
            ImGui::TextDisabled("El editor siempre se ve a la resolución de tu pantalla para ir fluido; el cambio se nota al presionar Jugar y en el juego exportado.");
        }
        keymapUI(ch);
        ImGui::SeparatorText("Botones en pantalla (escenas 3D)");
        int mode = P.hudDefault ? 0 : (P.hud.empty() ? 2 : 1);
        int nm = mode;
        wrapui::RadioButton("Por defecto: saltar y disparar", &nm, 0);
        wrapui::RadioButton("Personalizados", &nm, 1);
        wrapui::RadioButton("Ninguno (en blanco)", &nm, 2);
        if (nm != mode) {
            if (nm == 0) P.hudDefault = true;
            else if (nm == 1) { P.hudDefault = false; if (P.hud.empty()) P.hud = defaultHud(); }
            else { P.hudDefault = false; P.hud.clear(); }
            ch = true;
        }
        if (!P.hudDefault && !P.hud.empty()) {
            int del = -1;
            for (int i = 0; i < (int)P.hud.size(); i++) {
                HudBtn& b = P.hud[i];
                ImGui::PushID(i);
                if (ImGui::TreeNodeEx(b.label.c_str(), ImGuiTreeNodeFlags_DefaultOpen)) {
                    ch |= textInput("##bl", "Texto del botón", b.label, "texto");
                    int a = (int)b.act;
                    if (ImGui::Combo("Acción", &a, "Nada\0Saltar\0Disparar\0Interactuar\0Solo bloques (programable)\0Siguiente arma\0Recargar\0Linterna\0Mantener presionado (bloques)\0Correr (mantener)\0Agacharse (mantener)\0")) { b.act = (HudAct)a; ch = true; }
                    ch |= numField("Posición X", b.x, 0.f, 1.f);
                    ch |= numField("Posición Y", b.y, 0.f, 1.f);
                    ch |= numField("Tamaño", b.r, 0.03f, 0.25f);
                    ch |= wrapui::ColorEdit3("Color", b.color);
                    if (wrapui::Button("Quitar botón")) del = i;
                    ImGui::TreePop();
                }
                ImGui::PopID();
            }
            if (del >= 0) { P.hud.erase(P.hud.begin() + del); ch = true; }
        }
        if (!P.hudDefault) {
            if (wrapui::Button("+ Añadir botón")) {
                HudBtn b;
                b.label = "Botón";
                b.act = HudAct::Script;
                P.hud.push_back(b);
                ch = true;
            }
            wrapui::Next("Copiar los de por defecto");
            if (wrapui::Button("Copiar los de por defecto")) { P.hud = defaultHud(); ch = true; }
        }
        ImGui::SeparatorText("Arma del jugador");
        ch |= weaponPanel();
        ImGui::SeparatorText("Pantalla");
        ch |= wrapui::Checkbox("Mostrar variables (contadores)", &P.showVars);
        ImGui::TextDisabled("Para programar un botón: Acción \"Solo bloques\" y en un objeto usa el evento \"Cuando se presione el botón\" con su texto.");
        ImGui::TextDisabled("La vista previa se ve sobre la escena 3D. Los disparos activan el evento \"Al recibir un disparo\".");
        if (ch) markDirty();
    }
    ImGui::End();
}

void Editor::assetsWin() {
    paintWin();
    musicWin();
    animWin();
    animGridWin();
    voxWin();
    exportWin();
    if (!showAssets) return;
    float fs = ImGui::GetFontSize(), top = gBarTop();
    ImGui::SetNextWindowPos(ImVec2(w_ * 0.01f, top));
    ImGui::SetNextWindowSize(ImVec2(w_ * 0.98f, h_ - top - h_ * 0.01f));
    if (wrapui::Begin("Archivos", &showAssets, ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | kNoSB |
                                                  kNoSW | ImGuiWindowFlags_NoSavedSettings)) {
        // ---- parte fija: acciones y pestañas
        wrapui::CloseBar(&showAssets);
        if (wrapui::Button("Importar archivo...", ImVec2(0, fs * 2.2f))) { if (host_.pickFile) host_.pickFile(); }
        wrapui::Next("Dibujar textura");
        if (wrapui::Button("Dibujar textura", ImVec2(0, fs * 2.2f))) openPaint("");
        size_t total = 0;
        for (auto& a : edit_.proj.assets) total += a.second.size();
        ImGui::SameLine();
        ImGui::Text("Total: %.1f MB", total / (1024.0 * 1024.0));
        static int tab = 0;
        const char* names[5] = {"Imágenes", "Modelos 3D", "Sonidos", "Animaciones", "Videos"};
        float tw = ImGui::GetContentRegionAvail().x / 5.f;
        for (int i = 0; i < 5; i++) {
            if (i) ImGui::SameLine(0, 0);
            ImGui::PushStyleColor(ImGuiCol_Button, tab == i ? ImVec4(0.12f, 0.62f, 0.56f, 1.f) : ImVec4(0.18f, 0.20f, 0.28f, 1.f));
            if (wrapui::Button(names[i], ImVec2(tw, fs * 2.4f)) && tapped()) tab = i;
            ImGui::PopStyleColor();
        }
        // ---- contenido que se desliza con el dedo
        wrapui::BeginChild("##assetgrid", ImVec2(0, 0), false, kNoSB);
        dragScroll();
        std::string del;
        std::vector<std::string> items;
        if (tab == 3) {
            for (auto& a : edit_.proj.assets) if (ends(a.first, ".fanim") || ends(a.first, ".frig")) items.push_back(a.first);
        } else if (tab == 4) {
            for (auto& a : edit_.proj.assets) if (isVideoName(a.first)) items.push_back(a.first);
        } else items = assetsOf(tab == 0 ? 0 : tab == 1 ? 2 : 1);
        float cell = fs * 8.f, gap = fs * 0.7f;
        int cols = std::max(1, (int)((ImGui::GetContentRegionAvail().x + gap) / (cell + gap)));
        int n = 0;
        for (auto& it : items) {
            if (n % cols) ImGui::SameLine(0, gap);
            n++;
            ImGui::PushID(it.c_str());
            ImGui::BeginGroup();
            if (tab == 0 || tab == 1) assetThumb(it, tab == 0 ? 0 : 2, cell);
            else {
                ImVec2 p = ImGui::GetCursorScreenPos();
                ImGui::Dummy(ImVec2(cell, cell));
                ImGui::GetWindowDrawList()->AddRectFilled(p, ImVec2(p.x + cell, p.y + cell), IM_COL32(40, 48, 66, 255), 8.f);
                ImGui::GetWindowDrawList()->AddText(ImVec2(p.x + fs, p.y + cell * 0.4f), IM_COL32(220, 230, 250, 255), tab == 2 ? "SONIDO" : tab == 4 ? "VIDEO" : "ANIM");
            }
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + cell);
            ImGui::TextUnformatted(shorten(it, 22).c_str());
            ImGui::PopTextWrapPos();
            ImGui::TextDisabled("%.0f KB", edit_.proj.assets[it].size() / 1024.0);
            if (tab == 0 && ImGui::SmallButton("Dibujar")) openPaint(it);
            if (tab == 2 && audio_) { if (ImGui::SmallButton("Probar")) audio_->play(it); }
            if (tab == 3 && ends(it, ".fanim") && ImGui::SmallButton("Editar")) openAnimEditor(it);
            if ((tab == 0 && true) || tab == 2 || tab == 3) ImGui::SameLine();
            if (ImGui::SmallButton("Borrar")) del = it;
            ImGui::EndGroup();
            ImGui::PopID();
        }
        if (tab == 3) {
            ImGui::NewLine();
            if (wrapui::Button("Abrir editor de animación", ImVec2(0, fs * 2.4f))) openAnimEditor("");
            ImGui::TextDisabled("También puedes importar animaciones de archivos .glb/.gltf/.fbx con \"Importar archivo\".");
        }
        if (items.empty()) ImGui::TextDisabled("Nada en esta pestaña todavía.");
        ImGui::Dummy(ImVec2(1, fs * 3.f));
        ImGui::EndChild();
        if (!del.empty()) {
            edit_.proj.assets.erase(del);
            if (rend_) rend_->forget(del);
            if (audio_) audio_->setAssets(edit_.proj.assets);
            markDirty();
        }
    }
    ImGui::End();
}

}  // namespace forge
