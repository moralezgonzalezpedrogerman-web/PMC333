#include "library.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "defsounds.h"
#include "model.h"
#include "stb_image_write.h"

namespace forge {
namespace {

// ------------------------------------------------------------ paleta (32 colores) para los modelos
const int kPal = 32;
const unsigned char kColors[kPal][3] = {
    {235, 235, 235}, {40, 40, 44},   {120, 120, 130}, {200, 40, 40},  {230, 120, 40}, {240, 210, 60}, {70, 170, 70},  {40, 110, 60},
    {60, 120, 220},  {30, 60, 140},  {150, 80, 190},  {240, 130, 190}, {130, 85, 50},  {90, 55, 30},   {200, 160, 110}, {235, 200, 170},
    {85, 100, 70},   {60, 70, 50},   {170, 175, 185}, {255, 255, 120}, {20, 20, 20},   {110, 20, 20},  {90, 140, 90},   {150, 60, 20},
    {70, 70, 90},    {255, 240, 200}, {40, 140, 160}, {190, 190, 60},  {120, 60, 60},  {245, 245, 120}, {10, 10, 10},   {255, 90, 90}};
enum C { WHITE, BLACK, GREY, RED, ORANGE, YELLOW, GREEN, DGREEN, BLUE, DBLUE, PURPLE, PINK, BROWN, DBROWN, TAN, SKIN, OLIVE, DOLIVE, STEEL, LYELLOW, VBLACK, BLOOD, ZOMB, RUST, SLATE, CREAM, TEAL, MUSTARD, DRED, GLOW, PITCH, BRIGHT };

struct Part { float x, y, z, w, h, d; int c; };

void pngSink(void* ctx, void* data, int size) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + size);
}
std::vector<uint8_t> toPng(const std::vector<uint8_t>& rgba, int w, int h) {
    std::vector<uint8_t> o;
    stbi_write_png_to_func(pngSink, &o, w, h, 4, rgba.data(), w * 4);
    return o;
}
std::vector<uint8_t> paletteTex() {
    const int W = 256, H = 8;
    std::vector<uint8_t> px(W * H * 4);
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            int c = x / 8;
            for (int k = 0; k < 3; k++) px[(y * W + x) * 4 + k] = kColors[c][k];
            px[(y * W + x) * 4 + 3] = 255;
        }
    return toPng(px, W, H);
}

bool buildModel(const std::vector<Part>& parts, std::vector<uint8_t>& out) {
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    for (auto& p : parts) {
        float c[3] = {p.x, p.y, p.z}, s[3] = {p.w, p.h, p.d};
        for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], c[k] - s[k] / 2); mx[k] = std::max(mx[k], c[k] + s[k] / 2); }
    }
    float ext = std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    if (ext < 1e-6f) return false;
    float ce[3] = {(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2}, sc = 1.f / ext;
    ModelData m;
    m.tex = "lib_paleta.png";
    static const float nrm[6][3] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    for (auto& p : parts) {
        float u = (p.c * 8 + 4) / 256.f;
        for (int f = 0; f < 6; f++) {
            const float* n = nrm[f];
            int a = f / 2;                  // eje de la cara
            int b = (a + 1) % 3, c2 = (a + 2) % 3;
            float cen[3] = {p.x, p.y, p.z}, half[3] = {p.w / 2, p.h / 2, p.d / 2};
            uint32_t base = (uint32_t)(m.v.size() / 8);
            for (int q = 0; q < 4; q++) {
                float sb = (q == 0 || q == 3) ? -1.f : 1.f, sc2 = (q < 2) ? -1.f : 1.f;
                float pos[3];
                pos[a] = cen[a] + n[a] * half[a];
                pos[b] = cen[b] + sb * half[b];
                pos[c2] = cen[c2] + sc2 * half[c2];
                float v8[8] = {(pos[0] - ce[0]) * sc, (pos[1] - ce[1]) * sc, (pos[2] - ce[2]) * sc, n[0], n[1], n[2], u, 0.5f};
                m.v.insert(m.v.end(), v8, v8 + 8);
            }
            const float *p0 = &m.v[(base + 0) * 8], *p1 = &m.v[(base + 1) * 8], *p2 = &m.v[(base + 2) * 8];
            float ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
            float dot = (uy * vz - uz * vy) * n[0] + (uz * vx - ux * vz) * n[1] + (ux * vy - uy * vx) * n[2];
            if (dot > 0) { uint32_t t[6] = {0, 1, 2, 0, 2, 3}; for (auto i : t) m.idx.push_back(base + i); }
            else { uint32_t t[6] = {0, 2, 1, 0, 3, 2}; for (auto i : t) m.idx.push_back(base + i); }
        }
    }
    return modelWrite(m, out);
}

// ------------------------------------------------------------ modelos
std::vector<Part> carro() {
    return {{0, 0.35f, 0, 1.8f, 0.5f, 4.0f, RED}, {0, 0.8f, -0.2f, 1.5f, 0.45f, 2.0f, DRED}, {0, 0.82f, -0.2f, 1.52f, 0.3f, 1.8f, TEAL},
            {-0.95f, 0.22f, 1.3f, 0.3f, 0.5f, 0.6f, VBLACK}, {0.95f, 0.22f, 1.3f, 0.3f, 0.5f, 0.6f, VBLACK},
            {-0.95f, 0.22f, -1.3f, 0.3f, 0.5f, 0.6f, VBLACK}, {0.95f, 0.22f, -1.3f, 0.3f, 0.5f, 0.6f, VBLACK},
            {-0.6f, 0.4f, 2.02f, 0.4f, 0.2f, 0.05f, LYELLOW}, {0.6f, 0.4f, 2.02f, 0.4f, 0.2f, 0.05f, LYELLOW},
            {-0.6f, 0.4f, -2.02f, 0.4f, 0.2f, 0.05f, BRIGHT}, {0.6f, 0.4f, -2.02f, 0.4f, 0.2f, 0.05f, BRIGHT}, {0, 0.62f, -2.0f, 1.9f, 0.1f, 0.3f, BLACK}};
}
std::vector<Part> humano(int shirt, int pants, int skin, bool armed, bool torn) {
    std::vector<Part> p = {{0, 1.0f, 0, 0.55f, 0.7f, 0.3f, shirt}, {0, 1.55f, 0, 0.35f, 0.35f, 0.35f, skin}, {-0.15f, 0.35f, 0, 0.2f, 0.7f, 0.22f, pants}, {0.15f, 0.35f, 0, 0.2f, 0.7f, 0.22f, pants},
                           {-0.4f, 1.0f, 0, 0.18f, 0.65f, 0.2f, shirt}, {0.4f, 1.0f, 0, 0.18f, 0.65f, 0.2f, shirt}, {-0.4f, 0.62f, 0, 0.16f, 0.14f, 0.18f, skin}, {0.4f, 0.62f, 0, 0.16f, 0.14f, 0.18f, skin},
                           {-0.08f, 1.58f, 0.18f, 0.07f, 0.07f, 0.02f, VBLACK}, {0.08f, 1.58f, 0.18f, 0.07f, 0.07f, 0.02f, VBLACK}};
    if (armed) { p.push_back({0.4f, 0.75f, 0.35f, 0.1f, 0.12f, 0.6f, VBLACK}); p[5].z = 0.2f; }
    if (torn) { p.push_back({0, 1.0f, 0.16f, 0.3f, 0.3f, 0.02f, BLOOD}); p[4].y = 1.15f; p[4].h = 0.5f; p[4].z = 0.25f; p[5].y = 1.15f; p[5].h = 0.5f; p[5].z = 0.25f; }
    return p;
}
std::vector<Part> soldado() {
    auto p = humano(OLIVE, DOLIVE, SKIN, true, false);
    p.push_back({0, 1.78f, 0, 0.42f, 0.18f, 0.42f, DOLIVE});  // casco
    return p;
}
std::vector<Part> monstruo() {
    return {{0, 1.1f, 0, 1.1f, 1.3f, 0.8f, DGREEN}, {0, 2.0f, 0.1f, 0.8f, 0.7f, 0.7f, GREEN}, {-0.3f, 2.5f, 0.1f, 0.12f, 0.4f, 0.12f, TAN}, {0.3f, 2.5f, 0.1f, 0.12f, 0.4f, 0.12f, TAN},
            {-0.2f, 2.05f, 0.47f, 0.15f, 0.15f, 0.05f, BRIGHT}, {0.2f, 2.05f, 0.47f, 0.15f, 0.15f, 0.05f, BRIGHT}, {0, 1.8f, 0.45f, 0.5f, 0.12f, 0.1f, WHITE},
            {-0.45f, 0.4f, 0, 0.4f, 0.8f, 0.4f, DGREEN}, {0.45f, 0.4f, 0, 0.4f, 0.8f, 0.4f, DGREEN},
            {-0.85f, 1.2f, 0.2f, 0.35f, 1.1f, 0.35f, GREEN}, {0.85f, 1.2f, 0.2f, 0.35f, 1.1f, 0.35f, GREEN}, {-0.85f, 0.55f, 0.3f, 0.45f, 0.3f, 0.45f, TAN}, {0.85f, 0.55f, 0.3f, 0.45f, 0.3f, 0.45f, TAN}};
}
std::vector<Part> animatronico(int body, int belly) {  // oso / conejo de pizzeria (terror)
    return {{0, 1.0f, 0, 0.9f, 1.2f, 0.55f, body}, {0, 0.95f, 0.28f, 0.6f, 0.7f, 0.05f, belly}, {0, 1.95f, 0, 0.8f, 0.7f, 0.65f, body},
            {-0.28f, 2.42f, 0, 0.25f, 0.25f, 0.15f, body}, {0.28f, 2.42f, 0, 0.25f, 0.25f, 0.15f, body}, {0, 1.8f, 0.4f, 0.4f, 0.28f, 0.2f, belly},
            {-0.2f, 2.05f, 0.34f, 0.16f, 0.16f, 0.04f, WHITE}, {0.2f, 2.05f, 0.34f, 0.16f, 0.16f, 0.04f, WHITE},
            {-0.2f, 2.05f, 0.37f, 0.06f, 0.06f, 0.03f, VBLACK}, {0.2f, 2.05f, 0.37f, 0.06f, 0.06f, 0.03f, VBLACK}, {0, 1.5f, 0.3f, 0.5f, 0.14f, 0.1f, BLUE},
            {-0.65f, 1.0f, 0, 0.28f, 0.95f, 0.3f, body}, {0.65f, 1.0f, 0, 0.28f, 0.95f, 0.3f, body}, {-0.25f, 0.2f, 0, 0.3f, 0.5f, 0.35f, body}, {0.25f, 0.2f, 0, 0.3f, 0.5f, 0.35f, body},
            {0, 2.85f, 0, 0.35f, 0.15f, 0.35f, VBLACK}};
}
std::vector<Part> pistola() { return {{0, 0, 0.1f, 0.12f, 0.2f, 0.5f, STEEL}, {0, -0.2f, -0.12f, 0.12f, 0.35f, 0.14f, VBLACK}, {0, 0.14f, 0.1f, 0.08f, 0.05f, 0.45f, GREY}}; }
std::vector<Part> rifle() { return {{0, 0, 0, 0.14f, 0.2f, 1.1f, VBLACK}, {0, -0.2f, 0.1f, 0.1f, 0.3f, 0.18f, VBLACK}, {0, 0, 0.8f, 0.07f, 0.07f, 0.5f, GREY}, {0, 0.05f, -0.7f, 0.14f, 0.28f, 0.35f, DBROWN}, {0, 0.15f, 0.1f, 0.08f, 0.08f, 0.3f, GREY}}; }
std::vector<Part> espada() { return {{0, 0.7f, 0, 0.1f, 1.3f, 0.03f, STEEL}, {0, 0, 0, 0.5f, 0.1f, 0.1f, BROWN}, {0, -0.25f, 0, 0.08f, 0.4f, 0.08f, DBROWN}, {0, -0.5f, 0, 0.15f, 0.12f, 0.15f, YELLOW}}; }
std::vector<Part> arbol() { return {{0, 1.0f, 0, 0.4f, 2.0f, 0.4f, DBROWN}, {0, 2.6f, 0, 2.0f, 1.6f, 2.0f, DGREEN}, {0, 3.6f, 0, 1.3f, 1.2f, 1.3f, GREEN}}; }
std::vector<Part> caja() { return {{0, 0.5f, 0, 1.f, 1.f, 1.f, BROWN}, {0, 0.5f, 0.51f, 1.02f, 0.12f, 0.02f, DBROWN}, {0, 0.5f, -0.51f, 1.02f, 0.12f, 0.02f, DBROWN}, {0.51f, 0.5f, 0, 0.02f, 0.12f, 1.02f, DBROWN}, {-0.51f, 0.5f, 0, 0.02f, 0.12f, 1.02f, DBROWN}}; }
std::vector<Part> barril() { return {{0, 0.5f, 0, 0.7f, 1.0f, 0.7f, RUST}, {0, 0.25f, 0, 0.74f, 0.08f, 0.74f, DBROWN}, {0, 0.75f, 0, 0.74f, 0.08f, 0.74f, DBROWN}}; }
std::vector<Part> casa() { return {{0, 1.5f, 0, 6.f, 3.f, 5.f, CREAM}, {0, 3.4f, 0, 6.6f, 0.8f, 5.6f, DRED}, {0, 4.0f, 0, 4.4f, 0.6f, 4.0f, DRED}, {0, 1.0f, 2.52f, 1.0f, 2.0f, 0.06f, DBROWN}, {-1.8f, 1.8f, 2.52f, 1.0f, 1.0f, 0.06f, TEAL}, {1.8f, 1.8f, 2.52f, 1.0f, 1.0f, 0.06f, TEAL}}; }
std::vector<Part> farola() { return {{0, 2.0f, 0, 0.15f, 4.f, 0.15f, SLATE}, {0, 4.1f, 0, 0.5f, 0.3f, 0.5f, GLOW}}; }
std::vector<Part> lapida() { return {{0, 0.5f, 0, 0.8f, 1.0f, 0.2f, GREY}, {0, 1.05f, 0, 0.6f, 0.2f, 0.2f, GREY}}; }
std::vector<Part> moneda() { return {{0, 0, 0, 0.8f, 0.8f, 0.12f, YELLOW}, {0, 0, 0, 0.5f, 0.5f, 0.14f, MUSTARD}}; }
std::vector<Part> cofre() { return {{0, 0.3f, 0, 1.0f, 0.6f, 0.6f, BROWN}, {0, 0.7f, 0, 1.0f, 0.2f, 0.6f, DBROWN}, {0, 0.55f, 0.31f, 0.15f, 0.2f, 0.04f, YELLOW}}; }
std::vector<Part> puerta() { return {{0, 1.0f, 0, 1.0f, 2.0f, 0.12f, BROWN}, {0.35f, 1.0f, 0.08f, 0.1f, 0.1f, 0.06f, YELLOW}}; }
std::vector<Part> escritorio() { return {{0, 0.75f, 0, 1.8f, 0.1f, 0.9f, BROWN}, {-0.8f, 0.37f, 0, 0.1f, 0.75f, 0.8f, DBROWN}, {0.8f, 0.37f, 0, 0.1f, 0.75f, 0.8f, DBROWN}, {0, 1.05f, -0.1f, 0.6f, 0.45f, 0.1f, VBLACK}, {0, 1.05f, -0.04f, 0.5f, 0.35f, 0.02f, TEAL}}; }

struct ModelDef { const char* name; std::vector<Part> (*fn)(); };
std::vector<Part> zombi() { return humano(ZOMB, SLATE, ZOMB, false, true); }
std::vector<Part> aldeano() { return humano(BLUE, DBROWN, SKIN, false, false); }
std::vector<Part> oso() { return animatronico(BROWN, TAN); }
std::vector<Part> conejo() { return animatronico(PURPLE, PINK); }
std::vector<Part> jugador() { return humano(TEAL, SLATE, SKIN, false, false); }
// ---- v10.4: modelos con más detalle
std::vector<Part> carro2() {   // coche deportivo: carrocería, cabina de vidrio, ruedas con rin, faros, alerón, espejos
    std::vector<Part> v = {
        {0, 0.42f, 0, 1.9f, 0.4f, 4.3f, RED}, {0, 0.30f, 0, 1.96f, 0.14f, 4.36f, DRED},            // chasis y faldones
        {0, 0.66f, 1.35f, 1.7f, 0.16f, 1.5f, RED}, {0, 0.66f, -1.5f, 1.8f, 0.2f, 1.3f, RED},        // cofre y cajuela
        {0, 0.92f, -0.15f, 1.5f, 0.42f, 1.9f, RED}, {0, 0.96f, -0.15f, 1.54f, 0.3f, 1.7f, SLATE},  // cabina y vidrios
        {0, 1.16f, -0.2f, 1.4f, 0.06f, 1.2f, DRED},                                                 // techo
        {-0.8f, 0.5f, 2.16f, 0.45f, 0.16f, 0.08f, LYELLOW}, {0.8f, 0.5f, 2.16f, 0.45f, 0.16f, 0.08f, LYELLOW},
        {-0.8f, 0.5f, -2.16f, 0.45f, 0.14f, 0.08f, BRIGHT}, {0.8f, 0.5f, -2.16f, 0.45f, 0.14f, 0.08f, BRIGHT},
        {0, 0.3f, 2.2f, 1.7f, 0.14f, 0.12f, VBLACK}, {0, 0.27f, -2.2f, 1.7f, 0.14f, 0.12f, VBLACK},   // defensas
        {0, 0.42f, 2.18f, 0.7f, 0.18f, 0.06f, VBLACK},                                              // parrilla
        {-1.02f, 0.85f, 0.65f, 0.1f, 0.12f, 0.2f, DRED}, {1.02f, 0.85f, 0.65f, 0.1f, 0.12f, 0.2f, DRED},  // espejos
        {-0.8f, 1.02f, -2.0f, 0.1f, 0.4f, 0.1f, VBLACK}, {0.8f, 1.02f, -2.0f, 0.1f, 0.4f, 0.1f, VBLACK}, {0, 1.24f, -2.05f, 2.0f, 0.08f, 0.5f, VBLACK},  // alerón
        {0, 0.72f, 0.02f, 0.14f, 0.02f, 3.2f, WHITE}};                                               // franja
    for (float sx : {-1.f, 1.f})
        for (float z : {1.4f, -1.4f}) {
            v.push_back({sx * 1.0f, 0.36f, z, 0.32f, 0.72f, 0.72f, VBLACK});
            v.push_back({sx * 1.17f, 0.36f, z, 0.04f, 0.42f, 0.42f, STEEL});
            v.push_back({sx * 1.19f, 0.36f, z, 0.03f, 0.14f, 0.14f, GREY});
        }
    return v;
}
std::vector<Part> espada2() {   // espada larga con guarda, empuñadura y pomo
    return {{0, 0.95f, 0, 0.12f, 1.5f, 0.03f, STEEL}, {0, 0.95f, 0.02f, 0.03f, 1.45f, 0.03f, WHITE}, {0, 1.76f, 0, 0.08f, 0.14f, 0.03f, STEEL},
            {0, 0.15f, 0, 0.62f, 0.1f, 0.12f, YELLOW}, {-0.33f, 0.15f, 0, 0.1f, 0.18f, 0.12f, MUSTARD}, {0.33f, 0.15f, 0, 0.1f, 0.18f, 0.12f, MUSTARD},
            {0, -0.1f, 0, 0.09f, 0.42f, 0.09f, DBROWN}, {0, -0.1f, 0, 0.11f, 0.06f, 0.11f, VBLACK}, {0, -0.36f, 0, 0.16f, 0.14f, 0.16f, YELLOW}};
}
std::vector<Part> caballero() {   // armadura: yelmo con penacho, hombreras, escudo y espada
    std::vector<Part> p = {{0, 1.0f, 0, 0.62f, 0.75f, 0.36f, STEEL}, {0, 1.0f, 0.19f, 0.4f, 0.5f, 0.04f, GREY}, {0, 1.62f, 0, 0.4f, 0.4f, 0.4f, STEEL}, {0, 1.62f, 0.2f, 0.3f, 0.06f, 0.03f, VBLACK},
                           {0, 1.9f, 0, 0.08f, 0.2f, 0.34f, RED}, {-0.18f, 0.35f, 0, 0.24f, 0.72f, 0.26f, SLATE}, {0.18f, 0.35f, 0, 0.24f, 0.72f, 0.26f, SLATE},
                           {-0.18f, 0.06f, 0.05f, 0.26f, 0.12f, 0.36f, GREY}, {0.18f, 0.06f, 0.05f, 0.26f, 0.12f, 0.36f, GREY},
                           {-0.46f, 1.28f, 0, 0.3f, 0.2f, 0.34f, STEEL}, {0.46f, 1.28f, 0, 0.3f, 0.2f, 0.34f, STEEL},
                           {-0.46f, 0.95f, 0, 0.18f, 0.65f, 0.2f, GREY}, {0.46f, 0.95f, 0.1f, 0.18f, 0.6f, 0.2f, GREY},
                           {-0.62f, 1.0f, 0.12f, 0.08f, 0.7f, 0.5f, BLUE}, {-0.64f, 1.0f, 0.12f, 0.03f, 0.4f, 0.28f, YELLOW},
                           {0, 0.62f, 0, 0.66f, 0.12f, 0.38f, DBROWN}};
    p.push_back({0.5f, 1.05f, 0.5f, 0.07f, 0.07f, 0.26f, DBROWN});   // empuñadura
    p.push_back({0.5f, 1.4f, 0.6f, 0.04f, 0.8f, 0.1f, STEEL});       // hoja
    return p;
}
std::vector<Part> orco() {
    return {{0, 1.15f, 0, 1.0f, 1.2f, 0.7f, DOLIVE}, {0, 1.0f, 0.36f, 0.8f, 0.7f, 0.04f, DBROWN}, {0, 2.05f, 0.05f, 0.7f, 0.65f, 0.6f, OLIVE}, {-0.2f, 2.1f, 0.36f, 0.16f, 0.1f, 0.04f, BRIGHT}, {0.2f, 2.1f, 0.36f, 0.16f, 0.1f, 0.04f, BRIGHT},
            {-0.2f, 1.82f, 0.38f, 0.1f, 0.2f, 0.06f, WHITE}, {0.2f, 1.82f, 0.38f, 0.1f, 0.2f, 0.06f, WHITE}, {-0.45f, 0.4f, 0, 0.4f, 0.8f, 0.42f, DBROWN}, {0.45f, 0.4f, 0, 0.4f, 0.8f, 0.42f, DBROWN},
            {-0.8f, 1.25f, 0.1f, 0.38f, 1.0f, 0.38f, OLIVE}, {0.8f, 1.25f, 0.15f, 0.38f, 1.0f, 0.38f, OLIVE}, {0.85f, 1.8f, 0.4f, 0.14f, 0.14f, 1.1f, DBROWN}, {0.85f, 1.8f, 0.95f, 0.3f, 0.3f, 0.3f, GREY},
            {-0.7f, 1.78f, 0, 0.5f, 0.2f, 0.5f, GREY}, {0.7f, 1.78f, 0, 0.5f, 0.2f, 0.5f, GREY}};
}
std::vector<Part> esqueleto() {
    return {{0, 1.1f, 0, 0.5f, 0.7f, 0.22f, WHITE}, {0, 1.1f, 0.12f, 0.46f, 0.08f, 0.02f, GREY}, {0, 1.0f, 0.12f, 0.4f, 0.08f, 0.02f, GREY}, {0, 0.9f, 0.12f, 0.34f, 0.08f, 0.02f, GREY},
            {0, 1.65f, 0, 0.36f, 0.36f, 0.34f, WHITE}, {-0.08f, 1.68f, 0.18f, 0.1f, 0.1f, 0.03f, VBLACK}, {0.08f, 1.68f, 0.18f, 0.1f, 0.1f, 0.03f, VBLACK}, {0, 1.52f, 0.18f, 0.18f, 0.06f, 0.03f, VBLACK},
            {-0.14f, 0.38f, 0, 0.09f, 0.75f, 0.09f, WHITE}, {0.14f, 0.38f, 0, 0.09f, 0.75f, 0.09f, WHITE}, {0, 0.72f, 0, 0.4f, 0.1f, 0.18f, WHITE},
            {-0.36f, 1.1f, 0, 0.08f, 0.7f, 0.08f, WHITE}, {0.36f, 1.1f, 0, 0.08f, 0.7f, 0.08f, WHITE}, {0.36f, 0.9f, 0.4f, 0.04f, 0.9f, 0.06f, STEEL}};
}
std::vector<Part> luchador(int skin, int pants, int band) {   // peleador: torso ancho, guantes, cinta
    return {{0, 1.05f, 0, 0.7f, 0.75f, 0.34f, skin}, {0, 1.62f, 0, 0.36f, 0.38f, 0.36f, skin}, {0, 1.82f, 0, 0.4f, 0.1f, 0.4f, VBLACK}, {0, 1.74f, 0.19f, 0.4f, 0.07f, 0.02f, band},
            {-0.08f, 1.64f, 0.19f, 0.07f, 0.06f, 0.02f, VBLACK}, {0.08f, 1.64f, 0.19f, 0.07f, 0.06f, 0.02f, VBLACK},
            {-0.18f, 0.4f, 0, 0.26f, 0.8f, 0.28f, pants}, {0.18f, 0.4f, 0, 0.26f, 0.8f, 0.28f, pants}, {0, 0.76f, 0, 0.62f, 0.14f, 0.34f, band},
            {-0.5f, 1.12f, 0.12f, 0.22f, 0.7f, 0.24f, skin}, {0.5f, 1.12f, 0.12f, 0.22f, 0.7f, 0.24f, skin},
            {-0.5f, 0.7f, 0.3f, 0.3f, 0.3f, 0.3f, RED}, {0.5f, 0.7f, 0.3f, 0.3f, 0.3f, 0.3f, RED},
            {-0.18f, 0.06f, 0.05f, 0.28f, 0.12f, 0.38f, VBLACK}, {0.18f, 0.06f, 0.05f, 0.28f, 0.12f, 0.38f, VBLACK}};
}
std::vector<Part> luchadorA() { return luchador(SKIN, DBLUE, RED); }
std::vector<Part> luchadorB() { return luchador(TAN, VBLACK, YELLOW); }
std::vector<Part> puertaMetal() {   // puerta de seguridad: marco, hoja metálica con ventana y franjas de aviso
    return {{-1.1f, 1.3f, 0, 0.2f, 2.6f, 0.4f, GREY}, {1.1f, 1.3f, 0, 0.2f, 2.6f, 0.4f, GREY}, {0, 2.7f, 0, 2.4f, 0.2f, 0.4f, GREY},
            {0, 1.3f, 0, 2.0f, 2.6f, 0.14f, STEEL}, {0, 1.7f, 0.08f, 0.8f, 0.5f, 0.02f, SLATE}, {0, 0.25f, 0.08f, 2.0f, 0.16f, 0.02f, YELLOW}, {0, 0.25f, 0.085f, 0.3f, 0.16f, 0.02f, VBLACK},
            {0.7f, 1.2f, 0.1f, 0.12f, 0.4f, 0.06f, GREY}, {0.7f, 1.2f, 0.14f, 0.05f, 0.05f, 0.04f, RED}};
}
std::vector<Part> camaraSeg() {
    return {{0, 0, 0, 0.5f, 0.32f, 0.9f, GREY}, {0, 0, 0.47f, 0.34f, 0.24f, 0.1f, VBLACK}, {0, 0, 0.53f, 0.18f, 0.14f, 0.04f, TEAL}, {0, 0.1f, 0.25f, 0.5f, 0.06f, 0.5f, STEEL}, {0.16f, 0.12f, -0.2f, 0.06f, 0.06f, 0.04f, RED},
            {0, 0.28f, -0.4f, 0.14f, 0.5f, 0.14f, SLATE}, {0, 0.52f, -0.5f, 0.4f, 0.06f, 0.3f, SLATE}};
}
std::vector<Part> monitor() {
    return {{0, 0.5f, 0, 0.9f, 0.7f, 0.6f, DBROWN}, {0, 0.55f, 0.31f, 0.7f, 0.5f, 0.02f, TEAL}, {0, 0.55f, 0.33f, 0.72f, 0.02f, 0.01f, WHITE}, {0.3f, 0.2f, 0.31f, 0.08f, 0.08f, 0.02f, GLOW},
            {0, 0.1f, 0, 0.5f, 0.2f, 0.4f, SLATE}};
}
std::vector<Part> ninja() { return humano(VBLACK, VBLACK, SKIN, false, false); }
std::vector<Part> obstaculo() {   // cono / valla para carreras y runners
    return {{0, 0.1f, 0, 0.7f, 0.2f, 0.7f, VBLACK}, {0, 0.45f, 0, 0.5f, 0.5f, 0.5f, ORANGE}, {0, 0.8f, 0, 0.3f, 0.3f, 0.3f, ORANGE}, {0, 0.55f, 0, 0.52f, 0.1f, 0.52f, WHITE}, {0, 0.95f, 0, 0.2f, 0.1f, 0.2f, ORANGE}};
}
const ModelDef kModels[] = {
    {"lib_carro2.fmdl", carro2}, {"lib_espada2.fmdl", espada2}, {"lib_caballero.fmdl", caballero}, {"lib_orco.fmdl", orco}, {"lib_esqueleto.fmdl", esqueleto},
    {"lib_luchador1.fmdl", luchadorA}, {"lib_luchador2.fmdl", luchadorB}, {"lib_puerta_metal.fmdl", puertaMetal}, {"lib_camara_seg.fmdl", camaraSeg}, {"lib_monitor.fmdl", monitor},
    {"lib_ninja.fmdl", ninja}, {"lib_cono.fmdl", obstaculo},
    {"lib_carro.fmdl", carro}, {"lib_soldado.fmdl", soldado}, {"lib_zombi.fmdl", zombi}, {"lib_monstruo.fmdl", monstruo}, {"lib_aldeano.fmdl", aldeano},
    {"lib_jugador.fmdl", jugador}, {"lib_animatronico_oso.fmdl", oso}, {"lib_animatronico_conejo.fmdl", conejo}, {"lib_pistola.fmdl", pistola}, {"lib_rifle.fmdl", rifle},
    {"lib_espada.fmdl", espada}, {"lib_arbol.fmdl", arbol}, {"lib_caja.fmdl", caja}, {"lib_barril.fmdl", barril}, {"lib_casa.fmdl", casa}, {"lib_farola.fmdl", farola},
    {"lib_lapida.fmdl", lapida}, {"lib_moneda.fmdl", moneda}, {"lib_cofre.fmdl", cofre}, {"lib_puerta.fmdl", puerta}, {"lib_escritorio.fmdl", escritorio}};

// ------------------------------------------------------------ texturas
float hash2(int x, int y, int s) { unsigned h = (unsigned)(x * 374761393 + y * 668265263 + s * 1274126177); h = (h ^ (h >> 13)) * 1274126177u; return ((h ^ (h >> 16)) & 0xffff) / 65535.f; }
float vnoise(float x, float y, int s) {
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    float fx = x - xi, fy = y - yi, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    float a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
float fbm(float x, float y, int s) { return vnoise(x, y, s) * 0.5f + vnoise(x * 2, y * 2, s + 1) * 0.3f + vnoise(x * 4, y * 4, s + 2) * 0.2f; }

typedef void (*TexFn)(int x, int y, float* rgb);
const int T = 128;
void put(float* c, float r, float g, float b) { c[0] = r; c[1] = g; c[2] = b; }
void tConcreto(int x, int y, float* c) { float n = fbm(x / 12.f, y / 12.f, 1); put(c, 0.5f + n * .25f, 0.5f + n * .25f, 0.52f + n * .25f); }
void tLadrillo(int x, int y, float* c) {
    int row = y / 16, off = (row % 2) * 16, bx = (x + off) % 32, by = y % 16;
    bool mortar = bx < 2 || by < 2;
    float n = hash2((x + off) / 32, row, 3) * .2f;
    if (mortar) put(c, 0.62f, 0.6f, 0.56f); else put(c, 0.62f + n, 0.25f + n * .5f, 0.18f + n * .3f);
}
void tMadera(int x, int y, float* c) { float n = fbm(x / 40.f, y / 4.f, 5); put(c, 0.45f + n * .3f, 0.28f + n * .2f, 0.14f + n * .1f); }
void tPasto(int x, int y, float* c) { float n = fbm(x / 6.f, y / 6.f, 7); put(c, 0.2f + n * .15f, 0.5f + n * .3f, 0.18f + n * .1f); }
void tArena(int x, int y, float* c) { float n = fbm(x / 5.f, y / 5.f, 9); put(c, 0.8f + n * .15f, 0.7f + n * .15f, 0.45f + n * .1f); }
void tMetal(int x, int y, float* c) { float n = fbm(x / 30.f, y / 3.f, 11); bool rv = (x % 32 < 3 || y % 32 < 2); put(c, 0.42f + n * .2f - rv * .1f, 0.44f + n * .2f - rv * .1f, 0.48f + n * .2f - rv * .1f); }
void tOxido(int x, int y, float* c) { float n = fbm(x / 8.f, y / 8.f, 13); put(c, 0.45f + n * .4f, 0.2f + n * .2f, 0.1f + n * .05f); }
void tAzulejo(int x, int y, float* c) { bool g = x % 32 < 2 || y % 32 < 2; float n = fbm(x / 20.f, y / 20.f, 15) * .08f; if (g) put(c, 0.55f, 0.58f, 0.55f); else put(c, 0.82f + n, 0.9f + n, 0.88f + n); }
void tAlfombra(int x, int y, float* c) { float n = hash2(x, y, 17) * .08f; bool d = ((x / 16) + (y / 16)) % 2; put(c, (d ? 0.5f : 0.38f) + n, 0.1f + n, 0.12f + n); }
void tSangre(int x, int y, float* c) { float n = fbm(x / 10.f, y / 10.f, 19); if (n > 0.55f) put(c, 0.45f, 0.02f, 0.03f); else put(c, 0.32f + n * .2f, 0.3f + n * .2f, 0.3f + n * .2f); }
void tAsfalto(int x, int y, float* c) { float n = hash2(x, y, 21) * .1f; put(c, 0.2f + n, 0.2f + n, 0.22f + n); if (x > 60 && x < 68 && (y / 16) % 2 == 0) put(c, 0.9f, 0.85f, 0.2f); }
void tDamero(int x, int y, float* c) { bool d = ((x / 16) + (y / 16)) % 2; float n = hash2(x, y, 23) * .05f; put(c, (d ? 0.9f : 0.12f) + n, (d ? 0.9f : 0.12f) + n, (d ? 0.9f : 0.12f) + n); }
void tPapel(int x, int y, float* c) { bool s = (x / 8) % 2; float n = fbm(x / 20.f, y / 20.f, 25) * .1f; put(c, (s ? 0.55f : 0.5f) + n, (s ? 0.5f : 0.42f) + n, (s ? 0.35f : 0.3f) + n); }
void tNieve(int x, int y, float* c) { float n = fbm(x / 9.f, y / 9.f, 27) * .12f; put(c, 0.9f + n, 0.93f + n, 0.97f); }
void tRoca(int x, int y, float* c) { float n = fbm(x / 14.f, y / 14.f, 29); put(c, 0.35f + n * .3f, 0.33f + n * .28f, 0.3f + n * .25f); }
void tCesped2(int x, int y, float* c) { float n = fbm(x / 3.f, y / 10.f, 31); put(c, 0.12f + n * .2f, 0.35f + n * .35f, 0.1f); }
struct TexDef { const char* name; TexFn fn; };
const TexDef kTex[] = {{"lib_tex_concreto.png", tConcreto}, {"lib_tex_ladrillo.png", tLadrillo}, {"lib_tex_madera.png", tMadera}, {"lib_tex_pasto.png", tPasto},
                       {"lib_tex_arena.png", tArena}, {"lib_tex_metal.png", tMetal}, {"lib_tex_oxido.png", tOxido}, {"lib_tex_azulejo.png", tAzulejo},
                       {"lib_tex_alfombra.png", tAlfombra}, {"lib_tex_sangre.png", tSangre}, {"lib_tex_asfalto.png", tAsfalto}, {"lib_tex_damero.png", tDamero},
                       {"lib_tex_papel_pared.png", tPapel}, {"lib_tex_nieve.png", tNieve}, {"lib_tex_roca.png", tRoca}, {"lib_tex_cesped_oscuro.png", tCesped2}};


// sprites 2D (dibujos con formas) con fondo transparente
bool inC(float x, float y, float cx, float cy, float r) { return (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r; }
bool inE(float x, float y, float cx, float cy, float rx, float ry) { float a = (x - cx) / rx, b = (y - cy) / ry; return a * a + b * b <= 1.f; }
void sOso(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.25f, 0.17f, 0.11f) || inC(x, y, 0.75f, 0.17f, 0.11f)) set(100, 60, 30);
    if (inC(x, y, 0.25f, 0.17f, 0.06f) || inC(x, y, 0.75f, 0.17f, 0.06f)) set(60, 35, 20);
    if (inE(x, y, 0.5f, 0.45f, 0.38f, 0.33f)) set(120, 75, 40);
    if (inE(x, y, 0.5f, 0.58f, 0.2f, 0.15f)) set(205, 165, 115);
    if (inE(x, y, 0.5f, 0.5f, 0.07f, 0.04f)) set(15, 15, 15);
    if (inC(x, y, 0.33f, 0.37f, 0.08f) || inC(x, y, 0.67f, 0.37f, 0.08f)) set(240, 240, 240);
    if (inC(x, y, 0.33f, 0.38f, 0.035f) || inC(x, y, 0.67f, 0.38f, 0.035f)) set(10, 10, 10);
    if (y > 0.63f && y < 0.655f && x > 0.4f && x < 0.6f) set(20, 10, 10);
    if (y > 0.76f && y < 0.95f && x > 0.2f && x < 0.8f) set(120, 75, 40);
    if (y > 0.78f && y < 0.88f && x > 0.4f && x < 0.6f) set(40, 80, 200);
    memcpy(c, col, 4);
}
void sOjos(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t v = 0;
    if (inE(x, y, 0.25f, 0.5f, 0.2f, 0.12f) || inE(x, y, 0.75f, 0.5f, 0.2f, 0.12f)) v = 255;
    c[0] = 255; c[1] = 255; c[2] = 230; c[3] = v;
}
void sConejo(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inE(x, y, 0.34f, 0.13f, 0.07f, 0.17f) || inE(x, y, 0.66f, 0.13f, 0.07f, 0.17f)) set(130, 70, 170);
    if (inE(x, y, 0.34f, 0.14f, 0.035f, 0.12f) || inE(x, y, 0.66f, 0.14f, 0.035f, 0.12f)) set(240, 150, 200);
    if (inE(x, y, 0.5f, 0.5f, 0.36f, 0.3f)) set(130, 70, 170);
    if (inE(x, y, 0.5f, 0.62f, 0.2f, 0.13f)) set(220, 200, 235);
    if (inE(x, y, 0.5f, 0.54f, 0.06f, 0.035f)) set(15, 15, 15);
    if (inC(x, y, 0.34f, 0.42f, 0.08f) || inC(x, y, 0.66f, 0.42f, 0.08f)) set(245, 245, 245);
    if (inC(x, y, 0.34f, 0.43f, 0.035f) || inC(x, y, 0.66f, 0.43f, 0.035f)) set(200, 20, 20);
    if (y > 0.7f && y < 0.74f && x > 0.4f && x < 0.6f) set(20, 10, 10);
    if (y > 0.8f && y < 0.97f && x > 0.22f && x < 0.78f) set(130, 70, 170);
    if (y > 0.82f && y < 0.9f && x > 0.4f && x < 0.6f) set(240, 130, 190);
    memcpy(c, col, 4);
}
void sPajaro(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inE(x, y, 0.45f, 0.52f, 0.36f, 0.3f)) set(250, 210, 50);
    if (inE(x, y, 0.4f, 0.6f, 0.2f, 0.12f)) set(255, 240, 150);
    if (inE(x, y, 0.3f, 0.55f, 0.16f, 0.1f)) set(235, 150, 40);
    if (inE(x, y, 0.88f, 0.55f, 0.12f, 0.07f)) set(245, 110, 30);
    if (inC(x, y, 0.65f, 0.4f, 0.1f)) set(255, 255, 255);
    if (inC(x, y, 0.68f, 0.41f, 0.045f)) set(10, 10, 10);
    memcpy(c, col, 4);
}
void sFruta(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.35f, 0.58f, 0.27f) || inC(x, y, 0.65f, 0.58f, 0.27f)) set(210, 30, 40);
    if (inC(x, y, 0.3f, 0.5f, 0.07f)) set(255, 130, 130);
    if (x > 0.48f && x < 0.52f && y > 0.12f && y < 0.38f) set(100, 60, 30);
    if (inE(x, y, 0.62f, 0.2f, 0.14f, 0.06f)) set(60, 170, 60);
    memcpy(c, col, 4);
}
void sMoneda2(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.5f, 0.5f, 0.42f)) set(200, 150, 20);
    if (inC(x, y, 0.5f, 0.5f, 0.35f)) set(250, 210, 60);
    if (x > 0.46f && x < 0.54f && y > 0.28f && y < 0.72f) set(200, 150, 20);
    memcpy(c, col, 4);
}
void sTuberia(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    float sh = 0.75f + 0.25f * std::sin(x * 6.28f * 1.2f + 0.8f);
    bool lip = y < 0.1f;
    float k = lip ? 1.1f : 1.f;
    c[0] = (uint8_t)std::min(255.f, 70 * sh * k); c[1] = (uint8_t)std::min(255.f, 190 * sh * k); c[2] = (uint8_t)std::min(255.f, 60 * sh * k); c[3] = 255;
    if (y > 0.095f && y < 0.115f) { c[0] = c[1] = c[2] = 20; }
    if (x < 0.03f || x > 0.97f) { c[0] = c[1] = c[2] = 20; }
}
void sBoton(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.5f, 0.55f, 0.46f)) set(150, 30, 30);
    if (inC(x, y, 0.5f, 0.5f, 0.42f)) set(235, 60, 60);
    if (inC(x, y, 0.42f, 0.36f, 0.14f)) set(255, 150, 150);
    memcpy(c, col, 4);
}
struct SprDef { const char* name; void (*fn)(int, int, uint8_t*); };
const SprDef kSpr[] = {{"lib_spr_oso.png", sOso}, {"lib_spr_ojos.png", sOjos}, {"lib_spr_conejo.png", sConejo}, {"lib_spr_pajaro.png", sPajaro}, {"lib_spr_fruta.png", sFruta},
                       {"lib_spr_moneda.png", sMoneda2}, {"lib_spr_tuberia.png", sTuberia}, {"lib_spr_boton.png", sBoton}};

// ------------------------------------------------------------ musica (bucles cortos hechos por codigo)
const int kRate = 22050;
std::vector<uint8_t> wavOf(const std::vector<float>& s) {
    std::vector<uint8_t> o(44 + s.size() * 2);
    auto w32 = [&](size_t p, uint32_t v) { for (int i = 0; i < 4; i++) o[p + i] = (uint8_t)(v >> (8 * i)); };
    auto w16 = [&](size_t p, uint16_t v) { o[p] = (uint8_t)v; o[p + 1] = (uint8_t)(v >> 8); };
    memcpy(&o[0], "RIFF", 4); w32(4, (uint32_t)(36 + s.size() * 2)); memcpy(&o[8], "WAVEfmt ", 8);
    w32(16, 16); w16(20, 1); w16(22, 1); w32(24, kRate); w32(28, kRate * 2); w16(32, 2); w16(34, 16);
    memcpy(&o[36], "data", 4); w32(40, (uint32_t)(s.size() * 2));
    for (size_t i = 0; i < s.size(); i++) { float v = std::max(-1.f, std::min(1.f, s[i])); w16(44 + i * 2, (uint16_t)(int16_t)(v * 30000.f)); }
    return o;
}
float hz(int semis) { return 110.f * std::pow(2.f, semis / 12.f); }
// notas: arreglo de semitonos por paso (-99 = silencio); bpm; ondas: 0 seno, 1 cuadrada suave, 2 sierra
std::vector<float> secuencia(const int* notes, int n, float bpm, int wave, float vol, int octave, int repeat, float decay) {
    float step = 60.f / bpm / 2.f;
    size_t len = (size_t)(step * n * kRate);
    std::vector<float> o(len * repeat, 0.f);
    for (int r = 0; r < repeat; r++)
        for (int i = 0; i < n; i++) {
            if (notes[i] < -50) continue;
            float f = hz(notes[i] + 12 * octave);
            size_t st = r * len + (size_t)(i * step * kRate), nl = (size_t)(step * kRate * 1.2f);
            for (size_t k = 0; k < nl && st + k < o.size(); k++) {
                float t = (float)k / kRate, ph = 6.2831853f * f * t, s;
                if (wave == 0) s = std::sin(ph);
                else if (wave == 1) s = std::tanh(3.f * std::sin(ph)) * 0.8f;
                else s = 2.f * (f * t - std::floor(f * t + 0.5f));
                o[st + k] += s * vol * std::exp(-t * decay) * std::min(1.f, t * 200.f);
            }
        }
    return o;
}
void mix(std::vector<float>& a, const std::vector<float>& b) { if (b.size() > a.size()) a.resize(b.size(), 0.f); for (size_t i = 0; i < b.size(); i++) a[i] += b[i]; }
std::vector<uint8_t> musica(const std::string& n) {
    std::vector<float> o;
    if (n == "lib_musica_accion") {
        int bass[16] = {0, 0, 7, 0, 0, 0, 5, 3, 0, 0, 7, 0, 10, 8, 7, 5};
        int lead[16] = {12, -99, 15, -99, 19, -99, 15, 12, 12, -99, 15, 17, 19, -99, 17, 15};
        o = secuencia(bass, 16, 150, 2, 0.18f, -1, 2, 6.f);
        mix(o, secuencia(lead, 16, 150, 1, 0.12f, 0, 2, 5.f));
    } else if (n == "lib_musica_terror") {
        int pad[8] = {0, -99, -99, -99, 1, -99, -99, -99};
        int hi[16] = {-99, -99, -99, -99, -99, -99, 18, -99, -99, -99, -99, -99, -99, -99, -99, 19};
        o = secuencia(pad, 8, 50, 2, 0.22f, -1, 3, 0.6f);
        mix(o, secuencia(hi, 16, 50, 0, 0.1f, 1, 2, 2.f));
    } else if (n == "lib_musica_carrera") {
        int bass[16] = {0, 0, 12, 0, 0, 0, 12, 0, 5, 5, 17, 5, 7, 7, 19, 7};
        int lead[16] = {19, 22, 24, 22, 19, 22, 24, 26, 24, 22, 19, 17, 19, -99, 22, -99};
        o = secuencia(bass, 16, 170, 2, 0.16f, -1, 2, 7.f);
        mix(o, secuencia(lead, 16, 170, 1, 0.1f, 0, 2, 4.f));
    } else if (n == "lib_musica_pelea") {
        int bass[16] = {0, 0, -99, 0, 3, -99, 3, 0, 0, 0, -99, 0, 5, -99, 7, 3};
        int lead[16] = {12, -99, 12, 15, -99, 17, -99, 15, 12, -99, 10, 12, -99, 15, 19, -99};
        o = secuencia(bass, 16, 160, 2, 0.2f, -1, 2, 7.f);
        mix(o, secuencia(lead, 16, 160, 1, 0.12f, 0, 2, 6.f));
    } else if (n == "lib_musica_casual") {
        int a[16] = {0, 4, 7, 4, 2, 5, 9, 5, 4, 7, 12, 7, 5, 9, 12, 9};
        int b[8] = {0, -99, -99, -99, 5, -99, -99, -99};
        o = secuencia(a, 16, 125, 1, 0.16f, 1, 2, 4.f);
        mix(o, secuencia(b, 8, 125, 0, 0.14f, -1, 3, 1.5f));
    } else {  // aventura
        int a[16] = {0, 4, 7, 12, 7, 4, 0, 4, 5, 9, 12, 17, 12, 9, 5, 9};
        int b[8] = {0, -99, 5, -99, 7, -99, 5, -99};
        o = secuencia(a, 16, 110, 0, 0.2f, 1, 2, 3.f);
        mix(o, secuencia(b, 8, 110, 1, 0.12f, -1, 4, 1.5f));
    }
    for (auto& v : o) v *= 0.8f;
    return wavOf(o);
}
std::vector<uint8_t> efecto(const std::string& n) {
    std::vector<float> o;
    uint32_t s = 12345;
    auto rnd = [&]() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (float)(s & 0xffff) / 32768.f - 1.f; };
    if (n == "lib_motor") {
        o.assign(kRate * 2, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = 0.25f * (2.f * (std::fmod(55.f * t, 1.f)) - 1.f) + 0.1f * std::sin(6.28f * 110.f * t) + 0.04f * rnd(); }
    } else if (n == "lib_rugido") {
        o.assign(kRate, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, e = std::exp(-t * 2.5f) * std::min(1.f, t * 30.f); o[i] = e * (0.4f * (2.f * std::fmod((90.f - 40.f * t) * t, 1.f) - 1.f) + 0.25f * rnd()); }
    } else if (n == "lib_susto") {
        o.assign((size_t)(kRate * 1.2f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, e = std::exp(-t * 3.f); o[i] = e * (0.5f * rnd() + 0.3f * std::sin(6.28f * (800.f + 300.f * std::sin(t * 40.f)) * t)); }
    } else if (n == "lib_golpe") {
        o.assign((size_t)(kRate * 0.25f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 16.f) * (0.6f * rnd() + 0.7f * std::sin(6.28f * (150.f - 300.f * t) * t)); }
    } else if (n == "lib_puerta") {
        o.assign((size_t)(kRate * 0.6f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 7.f) * (0.35f * rnd() + 0.45f * std::sin(6.28f * 190.f * t) + 0.3f * std::sin(6.28f * 421.f * t)); }
    } else if (n == "lib_espadazo") {
        o.assign((size_t)(kRate * 0.3f), 0.f);
        float lp = 0.f;
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; lp += (rnd() - lp) * (0.1f + 1.2f * t); o[i] = lp * std::sin(3.14f * t / 0.3f) * 1.4f; }
    } else if (n == "lib_moneda") {
        o.assign((size_t)(kRate * 0.4f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, f = t < 0.08f ? 988.f : 1319.f; o[i] = std::exp(-t * 7.f) * 0.5f * (std::fmod(f * t, 1.f) < 0.5f ? 1.f : -1.f); }
    } else if (n == "lib_campana") {
        o.assign((size_t)(kRate * 2.5f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 1.6f) * (0.4f * std::sin(6.28f * 523.f * t) + 0.25f * std::sin(6.28f * 1318.f * t) + 0.15f * std::sin(6.28f * 1760.f * t)); }
    } else {  // ambiente de terror
        o.assign(kRate * 6, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = 0.12f * std::sin(6.28f * 55.f * t) * (0.6f + 0.4f * std::sin(t * 1.05f)) + 0.08f * std::sin(6.28f * 58.f * t) + 0.02f * rnd(); }
    }
    return wavOf(o);
}
const char* kSounds[] = {"lib_musica_accion", "lib_musica_terror", "lib_musica_carrera", "lib_musica_aventura", "lib_motor", "lib_rugido", "lib_susto", "lib_ambiente_terror", "lib_golpe", "lib_puerta", "lib_espadazo", "lib_moneda", "lib_campana", "lib_musica_pelea", "lib_musica_casual"};
}  // namespace

const std::vector<LibItem>& libraryItems() {
    static std::vector<LibItem> v = [] {
        std::vector<LibItem> r;
        for (auto& m : kModels) r.push_back({m.name, 2});
        for (auto& t : kTex) r.push_back({t.name, 0});
        for (auto& t : kSpr) r.push_back({t.name, 0});
        for (auto s : kSounds) r.push_back({std::string(s) + ".wav", 1});
        return r;
    }();
    return v;
}
bool libraryHas(const std::string& name) {
    for (auto& i : libraryItems()) if (i.name == name) return true;
    return false;
}
bool libraryAdd(const std::string& name, Files& assets) {
    if (assets.count(name)) return true;
    for (auto& m : kModels)
        if (name == m.name) {
            std::vector<uint8_t> b;
            if (!buildModel(m.fn(), b)) return false;
            assets[name] = b;
            if (!assets.count("lib_paleta.png")) assets["lib_paleta.png"] = paletteTex();
            return true;
        }
    for (auto& t : kTex)
        if (name == t.name) {
            std::vector<uint8_t> px(T * T * 4);
            for (int y = 0; y < T; y++)
                for (int x = 0; x < T; x++) {
                    float c[3];
                    t.fn(x, y, c);
                    for (int k = 0; k < 3; k++) px[(y * T + x) * 4 + k] = (uint8_t)std::max(0.f, std::min(255.f, c[k] * 255.f));
                    px[(y * T + x) * 4 + 3] = 255;
                }
            assets[name] = toPng(px, T, T);
            return true;
        }
    for (auto& t : kSpr)
        if (name == t.name) {
            std::vector<uint8_t> px(T * T * 4);
            for (int y = 0; y < T; y++)
                for (int x = 0; x < T; x++) t.fn(x, y, &px[(y * T + x) * 4]);
            assets[name] = toPng(px, T, T);
            return true;
        }
    for (auto s : kSounds)
        if (name == std::string(s) + ".wav") {
            std::string b = s;
            assets[name] = b.compare(0, 11, "lib_musica_") == 0 ? musica(b) : efecto(b);
            return true;
        }
    return false;
}
void libraryPrune(Files& assets, const std::string& text) {
    std::vector<std::string> used;
    for (auto& a : assets) if (a.first.compare(0, 4, "lib_") == 0 && text.find(a.first) != std::string::npos) used.push_back(a.first);
    // modelos que usan otras cosas (paleta)
    bool pal = false;
    for (auto& u : used) if (u.size() > 5 && u.substr(u.size() - 5) == ".fmdl") pal = true;
    for (auto it = assets.begin(); it != assets.end();) {
        bool lib = it->first.compare(0, 4, "lib_") == 0;
        bool keep = !lib || std::find(used.begin(), used.end(), it->first) != used.end() || (it->first == "lib_paleta.png" && pal);
        if (keep) ++it; else it = assets.erase(it);
    }
}

}  // namespace forge
