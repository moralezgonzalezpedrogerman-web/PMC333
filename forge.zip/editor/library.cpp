#include "library.h"

#include <algorithm>
#include <cmath>
#include <cstring>

#include "defsounds.h"
#include "model.h"
#include "packs_data.h"
#include "zip.h"
#include "stb_image_write.h"

namespace forge {
namespace {

// ------------------------------------------------------------ paleta (32 colores) para los modelos
const int kPal = 32;
const unsigned char kColors[kPal][3] = {
    {235, 235, 235}, {40, 40, 44},   {120, 120, 130}, {200, 40, 40},  {230, 120, 40}, {240, 210, 60}, {70, 170, 70},  {40, 110, 60},
    {60, 120, 220},  {30, 60, 140},  {150, 80, 190},  {240, 130, 190}, {130, 85, 50},  {90, 55, 30},   {200, 160, 110}, {235, 200, 170},
    {85, 100, 70},   {60, 70, 50},   {170, 175, 185}, {255, 255, 120}, {20, 20, 20},   {110, 20, 20},  {90, 140, 90},   {150, 60, 20},
    {70, 70, 90},    {255, 240, 200}, {40, 140, 160}, {190, 190, 60},  {120, 60, 60},  {245, 245, 120}, {10, 10, 10},   {255, 90, 90}};
enum C { WHITE, BLACK, GREY, RED, ORANGE, YELLOW, GREEN, DGREEN, BLUE, DBLUE, PURPLE, PINK, BROWN, DBROWN, TAN, SKIN, OLIVE, DOLIVE, STEEL, LYELLOW, VBLACK, BLOOD, ZOMB, RUST, SLATE, CREAM, TEAL, MUSTARD, DRED, GLOW, PITCH, BRIGHT };

struct Part { float x, y, z, w, h, d; int c; int k = 0; int ax = 0; float rx = 0.f, rz = 0.f; };

void pngSink(void* ctx, void* data, int size) {
    auto* v = (std::vector<uint8_t>*)ctx;
    v->insert(v->end(), (uint8_t*)data, (uint8_t*)data + size);
}
std::vector<uint8_t> toPng(const std::vector<uint8_t>& rgba, int w, int h) {
    std::vector<uint8_t> o;
    stbi_write_png_to_func(pngSink, &o, w, h, 4, rgba.data(), w * 4);
    return o;
}
std::vector<uint8_t> paletteTex() {
    const int W = 256, H = 8;
    std::vector<uint8_t> px(W * H * 4);
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            int c = x / 8;
            for (int k = 0; k < 3; k++) px[(y * W + x) * 4 + k] = kColors[c][k];
            px[(y * W + x) * 4 + 3] = 255;
        }
    return toPng(px, W, H);
}

// v10.7: piezas redondeadas. k: 0 caja, 1 elipsoide, 2 cilindro, 3 cono, 4 capsula. ax: eje largo (0 Y, 1 Z, 2 X). rx/rz: giro en grados.
void emitSmooth(ModelData& m, const Part& p, float u) {
    struct PV { float r, y, nr, ny; };
    std::vector<PV> prof;
    const int R = 8;
    if (p.k == 1) { for (int i = 0; i <= R; i++) { float ph = 3.14159265f * i / R; prof.push_back({std::sin(ph), -std::cos(ph), std::sin(ph), -std::cos(ph)}); } }
    else if (p.k == 2) { prof = {{0, -1, 0, -1}, {1, -1, 0, -1}, {1, -1, 1, 0}, {1, 1, 1, 0}, {1, 1, 0, 1}, {0, 1, 0, 1}}; }
    else if (p.k == 3) { prof = {{0, -1, 0, -1}, {1, -1, 0, -1}, {1, -1, 0.9f, 0.45f}, {0, 1, 0.9f, 0.45f}}; }
    else {   // capsula: tapas redondas (cap = alto de la tapa dentro de [-1,1])
        float L = (p.ax == 0 ? p.h : p.ax == 1 ? p.d : p.w), D = (p.ax == 0 ? std::min(p.w, p.d) : p.ax == 1 ? std::min(p.w, p.h) : std::min(p.h, p.d));
        float cap = std::min(1.f, D / std::max(L, 1e-3f));
        for (int i = 0; i <= 4; i++) { float ph = 1.5707963f * i / 4; prof.push_back({std::sin(ph), -1 + cap * (1 - std::cos(ph)), std::sin(ph), -std::cos(ph)}); }
        for (int i = 0; i <= 4; i++) { float ph = 1.5707963f * i / 4; prof.push_back({std::cos(ph), 1 - cap + cap * std::sin(ph), std::cos(ph), std::sin(ph)}); }
    }
    const int S = 14;
    float sx = (p.ax == 0 ? p.w : p.ax == 1 ? p.w : p.h) / 2, sz = (p.ax == 0 ? p.d : p.ax == 1 ? p.h : p.d) / 2, sy = (p.ax == 0 ? p.h : p.ax == 1 ? p.d : p.w) / 2;
    uint32_t base = (uint32_t)(m.v.size() / 8);
    for (auto& q : prof)
        for (int j = 0; j <= S; j++) {
            float a = 6.2831853f * j / S, ca = std::cos(a), sa = std::sin(a);
            float lx = q.r * ca * sx, ly = q.y * sy, lz = q.r * sa * sz;
            float nx = q.nr * ca / std::max(sx, 1e-4f), ny = q.ny / std::max(sy, 1e-4f), nz = q.nr * sa / std::max(sz, 1e-4f);
            float nl = std::sqrt(nx * nx + ny * ny + nz * nz); if (nl < 1e-6f) nl = 1.f; nx /= nl; ny /= nl; nz /= nl;
            float pp[3] = {lx, ly, lz}, nn[3] = {nx, ny, nz};
            if (p.ax == 1) { pp[0] = lx; pp[1] = lz; pp[2] = ly; nn[0] = nx; nn[1] = nz; nn[2] = ny; }          // eje Z
            else if (p.ax == 2) { pp[0] = ly; pp[1] = lx; pp[2] = lz; nn[0] = ny; nn[1] = nx; nn[2] = nz; }     // eje X
            float v8[8] = {p.x + pp[0], p.y + pp[1], p.z + pp[2], nn[0], nn[1], nn[2], u, 0.5f};
            m.v.insert(m.v.end(), v8, v8 + 8);
        }
    for (size_t i = 0; i + 1 < prof.size(); i++)
        for (int j = 0; j < S; j++) {
            uint32_t a0 = base + (uint32_t)(i * (S + 1) + j), a1 = a0 + 1, b0 = a0 + (S + 1), b1 = b0 + 1;
            uint32_t tri[2][3] = {{a0, b0, a1}, {a1, b0, b1}};
            for (auto& t : tri) {
                const float *p0 = &m.v[t[0] * 8], *p1 = &m.v[t[1] * 8], *p2 = &m.v[t[2] * 8];
                float ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
                float cx = uy * vz - uz * vy, cy = uz * vx - ux * vz, cz = ux * vy - uy * vx;
                if (cx * cx + cy * cy + cz * cz < 1e-14f) continue;
                float d = cx * (p0[3] + p1[3] + p2[3]) + cy * (p0[4] + p1[4] + p2[4]) + cz * (p0[5] + p1[5] + p2[5]);
                if (d >= 0) { m.idx.push_back(t[0]); m.idx.push_back(t[1]); m.idx.push_back(t[2]); }
                else { m.idx.push_back(t[0]); m.idx.push_back(t[2]); m.idx.push_back(t[1]); }
            }
        }
}

bool buildModel(const std::vector<Part>& parts, std::vector<uint8_t>& out) {
    ModelData m;
    m.tex = "lib_paleta.png";
    static const float nrm[6][3] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    for (auto& p : parts) {
        float u = (p.c * 8 + 4) / 256.f;
        size_t v0 = m.v.size() / 8;
        if (p.k > 0) emitSmooth(m, p, u);
        else
        for (int f = 0; f < 6; f++) {
            const float* n = nrm[f];
            int a = f / 2;                  // eje de la cara
            int b = (a + 1) % 3, c2 = (a + 2) % 3;
            float cen[3] = {p.x, p.y, p.z}, half[3] = {p.w / 2, p.h / 2, p.d / 2};
            uint32_t base = (uint32_t)(m.v.size() / 8);
            for (int q = 0; q < 4; q++) {
                float sb = (q == 0 || q == 3) ? -1.f : 1.f, sc2 = (q < 2) ? -1.f : 1.f;
                float pos[3];
                pos[a] = cen[a] + n[a] * half[a];
                pos[b] = cen[b] + sb * half[b];
                pos[c2] = cen[c2] + sc2 * half[c2];
                float v8[8] = {pos[0], pos[1], pos[2], n[0], n[1], n[2], u, 0.5f};
                m.v.insert(m.v.end(), v8, v8 + 8);
            }
            const float *p0 = &m.v[(base + 0) * 8], *p1 = &m.v[(base + 1) * 8], *p2 = &m.v[(base + 2) * 8];
            float ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2], vx = p2[0] - p0[0], vy = p2[1] - p0[1], vz = p2[2] - p0[2];
            float dot = (uy * vz - uz * vy) * n[0] + (uz * vx - ux * vz) * n[1] + (ux * vy - uy * vx) * n[2];
            if (dot > 0) { uint32_t t[6] = {0, 1, 2, 0, 2, 3}; for (auto i : t) m.idx.push_back(base + i); }
            else { uint32_t t[6] = {0, 2, 1, 0, 3, 2}; for (auto i : t) m.idx.push_back(base + i); }
        }
        if (p.rx != 0.f || p.rz != 0.f) {   // girar la pieza alrededor de su centro
            float cx = std::cos(p.rx * 0.0174533f), sx = std::sin(p.rx * 0.0174533f), cz = std::cos(p.rz * 0.0174533f), sz = std::sin(p.rz * 0.0174533f);
            auto rot = [&](float& x, float& y, float& z) {
                float y1 = y * cx - z * sx, z1 = y * sx + z * cx; y = y1; z = z1;
                float x2 = x * cz - y * sz, y2 = x * sz + y * cz; x = x2; y = y2;
            };
            for (size_t i = v0; i < m.v.size() / 8; i++) {
                float* v = &m.v[i * 8];
                float px = v[0] - p.x, py = v[1] - p.y, pz = v[2] - p.z;
                rot(px, py, pz); v[0] = p.x + px; v[1] = p.y + py; v[2] = p.z + pz;
                rot(v[3], v[4], v[5]);
            }
        }
    }
    if (m.v.empty()) return false;
    float mn[3] = {1e9f, 1e9f, 1e9f}, mx[3] = {-1e9f, -1e9f, -1e9f};
    for (size_t i = 0; i < m.v.size() / 8; i++)
        for (int k = 0; k < 3; k++) { mn[k] = std::min(mn[k], m.v[i * 8 + k]); mx[k] = std::max(mx[k], m.v[i * 8 + k]); }
    float ext = std::max(mx[0] - mn[0], std::max(mx[1] - mn[1], mx[2] - mn[2]));
    if (ext < 1e-6f) return false;
    float ce[3] = {(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2}, sc = 1.f / ext;
    for (size_t i = 0; i < m.v.size() / 8; i++)
        for (int k = 0; k < 3; k++) m.v[i * 8 + k] = (m.v[i * 8 + k] - ce[k]) * sc;
    return modelWrite(m, out);
}

// ------------------------------------------------------------ modelos
std::vector<Part> carro() {
    return {{0, 0.35f, 0, 1.8f, 0.5f, 4.0f, RED}, {0, 0.8f, -0.2f, 1.5f, 0.45f, 2.0f, DRED}, {0, 0.82f, -0.2f, 1.52f, 0.3f, 1.8f, TEAL},
            {-0.95f, 0.22f, 1.3f, 0.3f, 0.5f, 0.6f, VBLACK}, {0.95f, 0.22f, 1.3f, 0.3f, 0.5f, 0.6f, VBLACK},
            {-0.95f, 0.22f, -1.3f, 0.3f, 0.5f, 0.6f, VBLACK}, {0.95f, 0.22f, -1.3f, 0.3f, 0.5f, 0.6f, VBLACK},
            {-0.6f, 0.4f, 2.02f, 0.4f, 0.2f, 0.05f, LYELLOW}, {0.6f, 0.4f, 2.02f, 0.4f, 0.2f, 0.05f, LYELLOW},
            {-0.6f, 0.4f, -2.02f, 0.4f, 0.2f, 0.05f, BRIGHT}, {0.6f, 0.4f, -2.02f, 0.4f, 0.2f, 0.05f, BRIGHT}, {0, 0.62f, -2.0f, 1.9f, 0.1f, 0.3f, BLACK}};
}
std::vector<Part> humano(int shirt, int pants, int skin, bool armed, bool torn) {
    std::vector<Part> p = {{0, 1.0f, 0, 0.55f, 0.7f, 0.3f, shirt}, {0, 1.55f, 0, 0.35f, 0.35f, 0.35f, skin}, {-0.15f, 0.35f, 0, 0.2f, 0.7f, 0.22f, pants}, {0.15f, 0.35f, 0, 0.2f, 0.7f, 0.22f, pants},
                           {-0.4f, 1.0f, 0, 0.18f, 0.65f, 0.2f, shirt}, {0.4f, 1.0f, 0, 0.18f, 0.65f, 0.2f, shirt}, {-0.4f, 0.62f, 0, 0.16f, 0.14f, 0.18f, skin}, {0.4f, 0.62f, 0, 0.16f, 0.14f, 0.18f, skin},
                           {-0.08f, 1.58f, 0.18f, 0.07f, 0.07f, 0.02f, VBLACK}, {0.08f, 1.58f, 0.18f, 0.07f, 0.07f, 0.02f, VBLACK}};
    if (armed) { p.push_back({0.4f, 0.75f, 0.35f, 0.1f, 0.12f, 0.6f, VBLACK}); p[5].z = 0.2f; }
    if (torn) { p.push_back({0, 1.0f, 0.16f, 0.3f, 0.3f, 0.02f, BLOOD}); p[4].y = 1.15f; p[4].h = 0.5f; p[4].z = 0.25f; p[5].y = 1.15f; p[5].h = 0.5f; p[5].z = 0.25f; }
    return p;
}
std::vector<Part> soldado() {
    auto p = humano(OLIVE, DOLIVE, SKIN, true, false);
    p.push_back({0, 1.78f, 0, 0.42f, 0.18f, 0.42f, DOLIVE});  // casco
    return p;
}
std::vector<Part> monstruo() {
    return {{0, 1.1f, 0, 1.1f, 1.3f, 0.8f, DGREEN}, {0, 2.0f, 0.1f, 0.8f, 0.7f, 0.7f, GREEN}, {-0.3f, 2.5f, 0.1f, 0.12f, 0.4f, 0.12f, TAN}, {0.3f, 2.5f, 0.1f, 0.12f, 0.4f, 0.12f, TAN},
            {-0.2f, 2.05f, 0.47f, 0.15f, 0.15f, 0.05f, BRIGHT}, {0.2f, 2.05f, 0.47f, 0.15f, 0.15f, 0.05f, BRIGHT}, {0, 1.8f, 0.45f, 0.5f, 0.12f, 0.1f, WHITE},
            {-0.45f, 0.4f, 0, 0.4f, 0.8f, 0.4f, DGREEN}, {0.45f, 0.4f, 0, 0.4f, 0.8f, 0.4f, DGREEN},
            {-0.85f, 1.2f, 0.2f, 0.35f, 1.1f, 0.35f, GREEN}, {0.85f, 1.2f, 0.2f, 0.35f, 1.1f, 0.35f, GREEN}, {-0.85f, 0.55f, 0.3f, 0.45f, 0.3f, 0.45f, TAN}, {0.85f, 0.55f, 0.3f, 0.45f, 0.3f, 0.45f, TAN}};
}
std::vector<Part> animatronico(int body, int belly) {  // oso / conejo de pizzeria (terror)
    return {{0, 1.0f, 0, 0.9f, 1.2f, 0.55f, body}, {0, 0.95f, 0.28f, 0.6f, 0.7f, 0.05f, belly}, {0, 1.95f, 0, 0.8f, 0.7f, 0.65f, body},
            {-0.28f, 2.42f, 0, 0.25f, 0.25f, 0.15f, body}, {0.28f, 2.42f, 0, 0.25f, 0.25f, 0.15f, body}, {0, 1.8f, 0.4f, 0.4f, 0.28f, 0.2f, belly},
            {-0.2f, 2.05f, 0.34f, 0.16f, 0.16f, 0.04f, WHITE}, {0.2f, 2.05f, 0.34f, 0.16f, 0.16f, 0.04f, WHITE},
            {-0.2f, 2.05f, 0.37f, 0.06f, 0.06f, 0.03f, VBLACK}, {0.2f, 2.05f, 0.37f, 0.06f, 0.06f, 0.03f, VBLACK}, {0, 1.5f, 0.3f, 0.5f, 0.14f, 0.1f, BLUE},
            {-0.65f, 1.0f, 0, 0.28f, 0.95f, 0.3f, body}, {0.65f, 1.0f, 0, 0.28f, 0.95f, 0.3f, body}, {-0.25f, 0.2f, 0, 0.3f, 0.5f, 0.35f, body}, {0.25f, 0.2f, 0, 0.3f, 0.5f, 0.35f, body},
            {0, 2.85f, 0, 0.35f, 0.15f, 0.35f, VBLACK}};
}
std::vector<Part> pistola() { return {{0, 0, 0.1f, 0.12f, 0.2f, 0.5f, STEEL}, {0, -0.2f, -0.12f, 0.12f, 0.35f, 0.14f, VBLACK}, {0, 0.14f, 0.1f, 0.08f, 0.05f, 0.45f, GREY}}; }
std::vector<Part> rifle() { return {{0, 0, 0, 0.14f, 0.2f, 1.1f, VBLACK}, {0, -0.2f, 0.1f, 0.1f, 0.3f, 0.18f, VBLACK}, {0, 0, 0.8f, 0.07f, 0.07f, 0.5f, GREY}, {0, 0.05f, -0.7f, 0.14f, 0.28f, 0.35f, DBROWN}, {0, 0.15f, 0.1f, 0.08f, 0.08f, 0.3f, GREY}}; }
std::vector<Part> espada() { return {{0, 0.7f, 0, 0.1f, 1.3f, 0.03f, STEEL}, {0, 0, 0, 0.5f, 0.1f, 0.1f, BROWN}, {0, -0.25f, 0, 0.08f, 0.4f, 0.08f, DBROWN}, {0, -0.5f, 0, 0.15f, 0.12f, 0.15f, YELLOW}}; }
std::vector<Part> arbol() { return {{0, 1.0f, 0, 0.4f, 2.0f, 0.4f, DBROWN}, {0, 2.6f, 0, 2.0f, 1.6f, 2.0f, DGREEN}, {0, 3.6f, 0, 1.3f, 1.2f, 1.3f, GREEN}}; }
std::vector<Part> caja() { return {{0, 0.5f, 0, 1.f, 1.f, 1.f, BROWN}, {0, 0.5f, 0.51f, 1.02f, 0.12f, 0.02f, DBROWN}, {0, 0.5f, -0.51f, 1.02f, 0.12f, 0.02f, DBROWN}, {0.51f, 0.5f, 0, 0.02f, 0.12f, 1.02f, DBROWN}, {-0.51f, 0.5f, 0, 0.02f, 0.12f, 1.02f, DBROWN}}; }
std::vector<Part> barril() { return {{0, 0.5f, 0, 0.7f, 1.0f, 0.7f, RUST}, {0, 0.25f, 0, 0.74f, 0.08f, 0.74f, DBROWN}, {0, 0.75f, 0, 0.74f, 0.08f, 0.74f, DBROWN}}; }
std::vector<Part> casa() { return {{0, 1.5f, 0, 6.f, 3.f, 5.f, CREAM}, {0, 3.4f, 0, 6.6f, 0.8f, 5.6f, DRED}, {0, 4.0f, 0, 4.4f, 0.6f, 4.0f, DRED}, {0, 1.0f, 2.52f, 1.0f, 2.0f, 0.06f, DBROWN}, {-1.8f, 1.8f, 2.52f, 1.0f, 1.0f, 0.06f, TEAL}, {1.8f, 1.8f, 2.52f, 1.0f, 1.0f, 0.06f, TEAL}}; }
std::vector<Part> farola() { return {{0, 2.0f, 0, 0.15f, 4.f, 0.15f, SLATE}, {0, 4.1f, 0, 0.5f, 0.3f, 0.5f, GLOW}}; }
std::vector<Part> lapida() { return {{0, 0.5f, 0, 0.8f, 1.0f, 0.2f, GREY}, {0, 1.05f, 0, 0.6f, 0.2f, 0.2f, GREY}}; }
std::vector<Part> moneda() { return {{0, 0, 0, 0.8f, 0.8f, 0.12f, YELLOW}, {0, 0, 0, 0.5f, 0.5f, 0.14f, MUSTARD}}; }
std::vector<Part> cofre() { return {{0, 0.3f, 0, 1.0f, 0.6f, 0.6f, BROWN}, {0, 0.7f, 0, 1.0f, 0.2f, 0.6f, DBROWN}, {0, 0.55f, 0.31f, 0.15f, 0.2f, 0.04f, YELLOW}}; }
std::vector<Part> puerta() { return {{0, 1.0f, 0, 1.0f, 2.0f, 0.12f, BROWN}, {0.35f, 1.0f, 0.08f, 0.1f, 0.1f, 0.06f, YELLOW}}; }
std::vector<Part> escritorio() { return {{0, 0.75f, 0, 1.8f, 0.1f, 0.9f, BROWN}, {-0.8f, 0.37f, 0, 0.1f, 0.75f, 0.8f, DBROWN}, {0.8f, 0.37f, 0, 0.1f, 0.75f, 0.8f, DBROWN}, {0, 1.05f, -0.1f, 0.6f, 0.45f, 0.1f, VBLACK}, {0, 1.05f, -0.04f, 0.5f, 0.35f, 0.02f, TEAL}}; }


// ------------------------------------------------------------ v10.7: modelos redondeados y más reales
Part mk(int k, int ax, float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) {
    Part p{x, y, z, w, h, d, c}; p.k = k; p.ax = ax; p.rz = rz; p.rx = rx; return p;
}
Part El(float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) { return mk(1, 0, x, y, z, w, h, d, c, rz, rx); }
Part Cy(float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) { return mk(2, 0, x, y, z, w, h, d, c, rz, rx); }
Part CyZ(float x, float y, float z, float w, float h, float d, int c) { return mk(2, 1, x, y, z, w, h, d, c); }
Part CyX(float x, float y, float z, float w, float h, float d, int c) { return mk(2, 2, x, y, z, w, h, d, c); }
Part Cp(float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) { return mk(4, 0, x, y, z, w, h, d, c, rz, rx); }
Part CpZ(float x, float y, float z, float w, float h, float d, int c) { return mk(4, 1, x, y, z, w, h, d, c); }
Part Co(float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) { return mk(3, 0, x, y, z, w, h, d, c, rz, rx); }
Part Bx(float x, float y, float z, float w, float h, float d, int c, float rz = 0.f, float rx = 0.f) { Part p{x, y, z, w, h, d, c}; p.rz = rz; p.rx = rx; return p; }

// persona base (1.8 de alto): piel, camisa, pantalón, zapatos, pelo
std::vector<Part> persona(int skin, int shirt, int pants, int shoes, int hair, bool woman = false, bool zombie = false) {
    float arm = zombie ? 1.f : 0.f;
    std::vector<Part> p = {
        El(0, 1.36f, 0, woman ? 0.42f : 0.5f, 0.62f, 0.27f, shirt),                 // pecho
        El(0, 1.0f, 0, woman ? 0.46f : 0.44f, 0.34f, 0.26f, pants),                  // cadera
        Cp(-0.12f, 0.5f, 0, 0.2f, 0.95f, 0.21f, pants), Cp(0.12f, 0.5f, 0, 0.2f, 0.95f, 0.21f, pants),   // piernas
        El(-0.12f, 0.06f, 0.05f, 0.2f, 0.12f, 0.34f, shoes), El(0.12f, 0.06f, 0.05f, 0.2f, 0.12f, 0.34f, shoes),
        Cy(0, 1.7f, 0, 0.12f, 0.12f, 0.12f, skin),                                  // cuello
        El(0, 1.82f, 0, 0.23f, 0.27f, 0.25f, skin),                                  // cabeza
        El(0, 1.9f, -0.02f, 0.25f, 0.2f, 0.27f, hair),                               // pelo
        El(-0.05f, 1.83f, 0.115f, 0.035f, 0.02f, 0.02f, VBLACK), El(0.05f, 1.83f, 0.115f, 0.035f, 0.02f, 0.02f, VBLACK),
    };
    if (zombie) {   // brazos estirados al frente
        p.push_back(Cp(-0.32f, 1.38f, 0.3f, 0.13f, 0.12f, 0.6f, shirt)); p.back().ax = 1; p.back().rx = 0;
        p.push_back(Cp(0.32f, 1.38f, 0.3f, 0.13f, 0.12f, 0.6f, shirt)); p.back().ax = 1;
        p.push_back(El(-0.32f, 1.38f, 0.62f, 0.13f, 0.13f, 0.13f, skin)); p.push_back(El(0.32f, 1.38f, 0.62f, 0.13f, 0.13f, 0.13f, skin));
    } else {
        p.push_back(Cp(-0.33f, 1.28f, 0, 0.14f, 0.66f, 0.14f, shirt, 5.f)); p.push_back(Cp(0.33f, 1.28f, 0, 0.14f, 0.66f, 0.14f, shirt, -5.f));
        p.push_back(El(-0.38f, 0.92f, 0, 0.13f, 0.14f, 0.13f, skin)); p.push_back(El(0.38f, 0.92f, 0, 0.13f, 0.14f, 0.13f, skin));
    }
    (void)arm;
    if (woman) {
        p.push_back(Co(0, 0.78f, 0, 0.58f, 0.6f, 0.4f, pants));   // falda
        p[0].w = 0.42f;
        p.push_back(El(0, 1.62f, -0.12f, 0.3f, 0.6f, 0.16f, hair));   // pelo largo
    }
    return p;
}
void add(std::vector<Part>& a, const std::vector<Part>& b, float dx, float dy, float dz) { for (auto q : b) { q.x += dx; q.y += dy; q.z += dz; a.push_back(q); } }

std::vector<Part> civilHombre() { auto p = persona(SKIN, BLUE, DBLUE, DBROWN, DBROWN); return p; }
std::vector<Part> civilMujer() { return persona(SKIN, PINK, PURPLE, VBLACK, DBROWN, true); }
std::vector<Part> zombi2() { auto p = persona(ZOMB, RUST, DBROWN, VBLACK, VBLACK, false, true); p.push_back(El(0, 1.36f, 0.14f, 0.2f, 0.24f, 0.02f, BLOOD)); return p; }

// armas en mano: eje largo en z, boca hacia +z
std::vector<Part> fusilAsalto() {
    return {Bx(0, 0, -0.1f, 0.09f, 0.16f, 0.8f, VBLACK), CyZ(0, 0.02f, 0.62f, 0.035f, 0.035f, 0.5f, STEEL), CyZ(0, 0.02f, 0.9f, 0.05f, 0.05f, 0.1f, VBLACK),
            Bx(0, -0.02f, -0.62f, 0.09f, 0.2f, 0.36f, DBROWN), Bx(0, -0.18f, -0.02f, 0.07f, 0.26f, 0.1f, VBLACK, 0, -12), Bx(0, -0.14f, 0.2f, 0.07f, 0.1f, 0.3f, DBROWN),
            Bx(0, 0.11f, -0.05f, 0.04f, 0.05f, 0.4f, GREY), Bx(0, -0.15f, -0.28f, 0.06f, 0.24f, 0.07f, VBLACK, 0, 15)};
}
std::vector<Part> escopeta() {
    return {CyZ(0, 0.03f, 0.45f, 0.06f, 0.06f, 1.0f, STEEL), CyZ(0, -0.04f, 0.4f, 0.05f, 0.05f, 0.7f, VBLACK), Bx(0, 0, -0.2f, 0.09f, 0.14f, 0.5f, BROWN),
            Bx(0, -0.04f, -0.7f, 0.08f, 0.2f, 0.45f, DBROWN), Bx(0, -0.1f, 0.35f, 0.09f, 0.1f, 0.3f, DBROWN)};
}
std::vector<Part> francotirador() {
    return {Bx(0, 0, -0.2f, 0.08f, 0.14f, 0.9f, DOLIVE), CyZ(0, 0.02f, 0.85f, 0.035f, 0.035f, 0.9f, STEEL), CyZ(0, 0.14f, 0.05f, 0.07f, 0.07f, 0.45f, VBLACK),
            Bx(0, -0.03f, -0.85f, 0.08f, 0.22f, 0.4f, DBROWN), Bx(0, -0.16f, -0.05f, 0.06f, 0.22f, 0.09f, VBLACK), Bx(-0.05f, -0.12f, 0.8f, 0.02f, 0.2f, 0.02f, GREY, 0, 0), Bx(0.05f, -0.12f, 0.8f, 0.02f, 0.2f, 0.02f, GREY)};
}
std::vector<Part> pistola2() {
    return {Bx(0, 0.04f, 0.05f, 0.07f, 0.1f, 0.5f, STEEL), Bx(0, -0.08f, -0.12f, 0.07f, 0.26f, 0.12f, VBLACK, 0, -12), CyZ(0, 0.05f, 0.36f, 0.03f, 0.03f, 0.12f, VBLACK), Bx(0, 0.0f, 0.02f, 0.05f, 0.02f, 0.18f, GREY)};
}
std::vector<Part> subfusil() {
    return {Bx(0, 0, 0, 0.09f, 0.15f, 0.6f, VBLACK), CyZ(0, 0.02f, 0.4f, 0.035f, 0.035f, 0.26f, STEEL), Bx(0, -0.2f, 0.0f, 0.06f, 0.3f, 0.1f, VBLACK), Bx(0, -0.1f, -0.22f, 0.06f, 0.2f, 0.08f, VBLACK, 0, 15), Bx(0, 0.0f, -0.42f, 0.04f, 0.04f, 0.3f, GREY)};
}
std::vector<Part> cuchillo() { return {Bx(0, 0.35f, 0, 0.05f, 0.5f, 0.012f, STEEL), Co(0, 0.64f, 0, 0.05f, 0.1f, 0.012f, STEEL), Cy(0, 0, 0, 0.07f, 0.28f, 0.07f, VBLACK), Bx(0, 0.1f, 0, 0.14f, 0.04f, 0.05f, VBLACK)}; }
std::vector<Part> machete() { return {Bx(0, 0.6f, 0, 0.11f, 0.9f, 0.015f, STEEL), Co(0, 1.1f, 0, 0.11f, 0.16f, 0.015f, STEEL), Cy(0, 0, 0, 0.07f, 0.3f, 0.07f, DBROWN), Bx(0, 0.16f, 0, 0.13f, 0.04f, 0.06f, VBLACK)}; }
std::vector<Part> hacha() { return {Cy(0, 0.5f, 0, 0.06f, 1.2f, 0.06f, BROWN), Bx(0.14f, 1.0f, 0, 0.3f, 0.36f, 0.04f, STEEL), Bx(-0.04f, 1.0f, 0, 0.1f, 0.2f, 0.08f, GREY)}; }
std::vector<Part> bate() { return {Cy(0, 0.55f, 0, 0.1f, 1.1f, 0.1f, TAN), Cy(0, 0.95f, 0, 0.14f, 0.5f, 0.14f, TAN), Cy(0, 0.0f, 0, 0.08f, 0.2f, 0.08f, VBLACK), El(0, -0.1f, 0, 0.1f, 0.06f, 0.1f, VBLACK)}; }
std::vector<Part> katana() { return {Bx(0, 0.7f, 0, 0.05f, 1.2f, 0.012f, STEEL, 0, 0), Co(0, 1.32f, 0, 0.05f, 0.12f, 0.012f, STEEL), Cy(0, 0.0f, 0, 0.06f, 0.36f, 0.06f, DRED), Cy(0, 0.2f, 0, 0.16f, 0.03f, 0.16f, YELLOW)}; }
std::vector<Part> martillo() { return {Cy(0, 0.5f, 0, 0.07f, 1.1f, 0.07f, BROWN), Bx(0, 1.1f, 0, 0.5f, 0.24f, 0.24f, STEEL)}; }
std::vector<Part> granada() { return {El(0, 0, 0, 0.16f, 0.2f, 0.16f, DOLIVE), Cy(0, 0.13f, 0, 0.07f, 0.06f, 0.07f, STEEL), Bx(0.06f, 0.16f, 0, 0.1f, 0.02f, 0.02f, STEEL)}; }

// soldados: persona + casco + chaleco + arma
std::vector<Part> soldadoBase(int skin, int uni, int pants, int helmet, int vest, int boots) {
    auto p = persona(skin, uni, pants, boots, VBLACK);
    p.erase(p.begin() + 8);   // sin pelo debajo del casco
    p.push_back(El(0, 1.9f, 0, 0.27f, 0.22f, 0.29f, helmet));
    p.push_back(Bx(0, 1.8f, 0.0f, 0.001f, 0.001f, 0.001f, helmet));
    p.push_back(El(0, 1.4f, 0.01f, 0.54f, 0.5f, 0.32f, vest));        // chaleco
    p.push_back(Bx(0, 1.24f, 0.17f, 0.4f, 0.12f, 0.08f, DOLIVE));     // bolsas
    p.push_back(El(0, 1.35f, -0.22f, 0.36f, 0.5f, 0.16f, DOLIVE));    // mochila
    p.push_back(Bx(0, 1.0f, 0, 0.5f, 0.06f, 0.3f, VBLACK));           // cinturón
    return p;
}
std::vector<Part> soldadoReal() { auto p = soldadoBase(SKIN, OLIVE, DOLIVE, DOLIVE, DGREEN, VBLACK); add(p, fusilAsalto(), 0.2f, 1.2f, 0.28f); return p; }
std::vector<Part> soldadoEnemigo() { auto p = soldadoBase(TAN, RUST, DBROWN, DRED, DBROWN, VBLACK); add(p, subfusil(), 0.2f, 1.2f, 0.28f); p.push_back(Bx(0, 1.74f, 0.1f, 0.24f, 0.08f, 0.06f, DRED)); return p; }
std::vector<Part> comando() { auto p = soldadoBase(SKIN, BLACK, VBLACK, VBLACK, VBLACK, VBLACK); add(p, fusilAsalto(), 0.2f, 1.2f, 0.28f); p.push_back(El(0, 1.78f, 0.12f, 0.2f, 0.12f, 0.05f, VBLACK)); return p; }
std::vector<Part> francotiradorSol() { auto p = soldadoBase(SKIN, DGREEN, DOLIVE, DGREEN, DOLIVE, DBROWN); add(p, francotirador(), 0.2f, 1.2f, 0.3f); return p; }
std::vector<Part> policia() { auto p = persona(SKIN, DBLUE, BLACK, VBLACK, VBLACK); p.push_back(Cy(0, 1.99f, 0, 0.27f, 0.08f, 0.27f, DBLUE)); p.push_back(Bx(0, 1.95f, 0.15f, 0.27f, 0.02f, 0.14f, VBLACK)); p.push_back(El(0.12f, 1.42f, 0.14f, 0.08f, 0.08f, 0.02f, YELLOW)); add(p, pistola2(), 0.25f, 1.15f, 0.25f); return p; }
std::vector<Part> luchadorReal() { auto p = persona(SKIN, RED, DBLUE, VBLACK, VBLACK); p[2].c = BLACK; p.push_back(El(-0.4f, 0.96f, 0.06f, 0.2f, 0.2f, 0.2f, RED)); p.push_back(El(0.4f, 0.96f, 0.06f, 0.2f, 0.2f, 0.2f, RED)); return p; }
std::vector<Part> luchadorReal2() { auto p = persona(TAN, BLUE, BLACK, VBLACK, DBROWN); p.push_back(El(-0.4f, 0.96f, 0.06f, 0.2f, 0.2f, 0.2f, BLUE)); p.push_back(El(0.4f, 0.96f, 0.06f, 0.2f, 0.2f, 0.2f, BLUE)); p.push_back(Bx(0, 1.93f, 0.0f, 0.3f, 0.05f, 0.3f, BLUE)); return p; }
std::vector<Part> guerrero() { auto p = persona(SKIN, DBROWN, DBROWN, DBROWN, VBLACK); p.push_back(El(0, 1.4f, 0.0f, 0.54f, 0.5f, 0.31f, STEEL)); p.push_back(El(0, 1.94f, 0, 0.27f, 0.2f, 0.29f, STEEL)); p.push_back(El(-0.34f, 1.62f, 0, 0.2f, 0.12f, 0.24f, STEEL)); p.push_back(El(0.34f, 1.62f, 0, 0.2f, 0.12f, 0.24f, STEEL)); return p; }
std::vector<Part> tanque() {
    std::vector<Part> p = {Bx(0, 0.5f, 0, 2.0f, 0.5f, 3.2f, OLIVE), CyX(-1.15f, 0.4f, 0, 0.6f, 0.6f, 3.4f, VBLACK), CyX(1.15f, 0.4f, 0, 0.6f, 0.6f, 3.4f, VBLACK),
                           El(0, 1.0f, -0.1f, 1.5f, 0.55f, 1.6f, DOLIVE), CyZ(0, 1.05f, 1.6f, 0.18f, 0.18f, 1.8f, VBLACK), Cy(0, 1.4f, -0.2f, 0.5f, 0.2f, 0.5f, OLIVE),
                           Bx(0, 0.62f, 1.6f, 1.9f, 0.3f, 0.2f, DOLIVE)};
    for (int i = 0; i < 5; i++) { p.push_back(CyX(-1.15f, 0.3f, -1.2f + i * 0.6f, 0.4f, 0.4f, 0.5f, GREY)); p.push_back(CyX(1.15f, 0.3f, -1.2f + i * 0.6f, 0.4f, 0.4f, 0.5f, GREY)); }
    return p;
}

std::vector<Part> tren() {
    std::vector<Part> p = {Bx(0, 1.3f, 0, 2.0f, 2.2f, 6.0f, BLUE), Bx(0, 0.15f, 0, 1.9f, 0.3f, 5.8f, VBLACK), Bx(0, 2.45f, 0, 2.0f, 0.12f, 6.0f, GREY), Bx(0, 1.6f, 3.01f, 1.4f, 0.9f, 0.04f, TEAL), Bx(-0.55f, 0.7f, 3.02f, 0.28f, 0.2f, 0.04f, LYELLOW), Bx(0.55f, 0.7f, 3.02f, 0.28f, 0.2f, 0.04f, LYELLOW), Bx(0, 1.0f, 3.0f, 2.0f, 0.12f, 0.05f, YELLOW)};
    for (int i = 0; i < 3; i++) { p.push_back(Bx(1.01f, 1.6f, -1.8f + i * 1.8f, 0.04f, 0.7f, 1.0f, TEAL)); p.push_back(Bx(-1.01f, 1.6f, -1.8f + i * 1.8f, 0.04f, 0.7f, 1.0f, TEAL)); }
    return p;
}
std::vector<Part> barrera() { return {Bx(-0.8f, 0.5f, 0, 0.1f, 1.0f, 0.1f, GREY), Bx(0.8f, 0.5f, 0, 0.1f, 1.0f, 0.1f, GREY), Bx(0, 0.85f, 0, 1.8f, 0.25f, 0.08f, RED), Bx(0, 0.85f, 0.01f, 0.5f, 0.25f, 0.09f, WHITE), Bx(0.6f, 0.85f, 0.01f, 0.4f, 0.25f, 0.09f, WHITE), Bx(-0.6f, 0.85f, 0.01f, 0.4f, 0.25f, 0.09f, WHITE)}; }
std::vector<Part> edificio() { std::vector<Part> p = {Bx(0, 2.5f, 0, 3.0f, 5.0f, 3.0f, SLATE)}; for (int y = 0; y < 4; y++) for (int x = 0; x < 3; x++) p.push_back(Bx(-1.0f + x * 1.0f, 0.9f + y * 1.1f, 1.51f, 0.5f, 0.6f, 0.03f, (x + y) % 2 ? LYELLOW : TEAL)); return p; }
std::vector<Part> cono2() { return {Co(0, 0.5f, 0, 0.7f, 1.0f, 0.7f, ORANGE), Bx(0, 0.05f, 0, 0.9f, 0.1f, 0.9f, ORANGE), Cy(0, 0.45f, 0, 0.45f, 0.14f, 0.45f, WHITE)}; }
std::vector<Part> carroDep(int body) {   // frente hacia +z
    return {El(0, 0.45f, 0, 1.9f, 0.55f, 4.2f, body), El(0, 0.82f, -0.2f, 1.45f, 0.5f, 2.1f, TEAL), Bx(0, 0.25f, 0, 1.95f, 0.18f, 4.3f, VBLACK),
            Cy(-0.95f, 0.38f, 1.3f, 0.7f, 0.3f, 0.7f, VBLACK), Cy(0.95f, 0.38f, 1.3f, 0.7f, 0.3f, 0.7f, VBLACK), Cy(-0.95f, 0.38f, -1.3f, 0.7f, 0.3f, 0.7f, VBLACK), Cy(0.95f, 0.38f, -1.3f, 0.7f, 0.3f, 0.7f, VBLACK),
            El(-0.6f, 0.5f, 2.0f, 0.4f, 0.16f, 0.12f, LYELLOW), El(0.6f, 0.5f, 2.0f, 0.4f, 0.16f, 0.12f, LYELLOW), El(-0.6f, 0.55f, -2.05f, 0.4f, 0.14f, 0.1f, BRIGHT), El(0.6f, 0.55f, -2.05f, 0.4f, 0.14f, 0.1f, BRIGHT),
            Bx(0, 0.95f, -1.9f, 1.8f, 0.07f, 0.35f, VBLACK)};
}
std::vector<Part> carroDeportivo() { return carroDep(RED); }
std::vector<Part> carroAzul() { return carroDep(BLUE); }
std::vector<Part> carroAmarillo() { return carroDep(YELLOW); }
std::vector<Part> carroVerde() { return carroDep(GREEN); }
std::vector<Part> helicoptero() { return {El(0, 1.0f, 0, 1.2f, 1.1f, 2.6f, DOLIVE), Cp(0, 1.1f, -2.2f, 0.25f, 0.3f, 2.0f, DOLIVE), Bx(0, 1.8f, 0, 4.2f, 0.06f, 0.2f, VBLACK), Bx(0, 1.8f, 0, 0.2f, 0.06f, 4.2f, VBLACK), CyX(0, 0.1f, 0, 0.1f, 0.1f, 1.4f, VBLACK), El(0, 1.2f, 0.9f, 0.9f, 0.6f, 0.8f, TEAL)}; }

struct ModelDef { const char* name; std::vector<Part> (*fn)(); };
std::vector<Part> zombi() { return humano(ZOMB, SLATE, ZOMB, false, true); }
std::vector<Part> aldeano() { return humano(BLUE, DBROWN, SKIN, false, false); }
std::vector<Part> oso() { return animatronico(BROWN, TAN); }
std::vector<Part> conejo() { return animatronico(PURPLE, PINK); }
std::vector<Part> jugador() { return humano(TEAL, SLATE, SKIN, false, false); }
// ---- v10.4: modelos con más detalle
std::vector<Part> carro2() {   // coche deportivo: carrocería, cabina de vidrio, ruedas con rin, faros, alerón, espejos
    std::vector<Part> v = {
        {0, 0.42f, 0, 1.9f, 0.4f, 4.3f, RED}, {0, 0.30f, 0, 1.96f, 0.14f, 4.36f, DRED},            // chasis y faldones
        {0, 0.66f, 1.35f, 1.7f, 0.16f, 1.5f, RED}, {0, 0.66f, -1.5f, 1.8f, 0.2f, 1.3f, RED},        // cofre y cajuela
        {0, 0.92f, -0.15f, 1.5f, 0.42f, 1.9f, RED}, {0, 0.96f, -0.15f, 1.54f, 0.3f, 1.7f, SLATE},  // cabina y vidrios
        {0, 1.16f, -0.2f, 1.4f, 0.06f, 1.2f, DRED},                                                 // techo
        {-0.8f, 0.5f, 2.16f, 0.45f, 0.16f, 0.08f, LYELLOW}, {0.8f, 0.5f, 2.16f, 0.45f, 0.16f, 0.08f, LYELLOW},
        {-0.8f, 0.5f, -2.16f, 0.45f, 0.14f, 0.08f, BRIGHT}, {0.8f, 0.5f, -2.16f, 0.45f, 0.14f, 0.08f, BRIGHT},
        {0, 0.3f, 2.2f, 1.7f, 0.14f, 0.12f, VBLACK}, {0, 0.27f, -2.2f, 1.7f, 0.14f, 0.12f, VBLACK},   // defensas
        {0, 0.42f, 2.18f, 0.7f, 0.18f, 0.06f, VBLACK},                                              // parrilla
        {-1.02f, 0.85f, 0.65f, 0.1f, 0.12f, 0.2f, DRED}, {1.02f, 0.85f, 0.65f, 0.1f, 0.12f, 0.2f, DRED},  // espejos
        {-0.8f, 1.02f, -2.0f, 0.1f, 0.4f, 0.1f, VBLACK}, {0.8f, 1.02f, -2.0f, 0.1f, 0.4f, 0.1f, VBLACK}, {0, 1.24f, -2.05f, 2.0f, 0.08f, 0.5f, VBLACK},  // alerón
        {0, 0.72f, 0.02f, 0.14f, 0.02f, 3.2f, WHITE}};                                               // franja
    for (float sx : {-1.f, 1.f})
        for (float z : {1.4f, -1.4f}) {
            v.push_back({sx * 1.0f, 0.36f, z, 0.32f, 0.72f, 0.72f, VBLACK});
            v.push_back({sx * 1.17f, 0.36f, z, 0.04f, 0.42f, 0.42f, STEEL});
            v.push_back({sx * 1.19f, 0.36f, z, 0.03f, 0.14f, 0.14f, GREY});
        }
    return v;
}
std::vector<Part> espada2() {   // espada larga con guarda, empuñadura y pomo
    return {{0, 0.95f, 0, 0.12f, 1.5f, 0.03f, STEEL}, {0, 0.95f, 0.02f, 0.03f, 1.45f, 0.03f, WHITE}, {0, 1.76f, 0, 0.08f, 0.14f, 0.03f, STEEL},
            {0, 0.15f, 0, 0.62f, 0.1f, 0.12f, YELLOW}, {-0.33f, 0.15f, 0, 0.1f, 0.18f, 0.12f, MUSTARD}, {0.33f, 0.15f, 0, 0.1f, 0.18f, 0.12f, MUSTARD},
            {0, -0.1f, 0, 0.09f, 0.42f, 0.09f, DBROWN}, {0, -0.1f, 0, 0.11f, 0.06f, 0.11f, VBLACK}, {0, -0.36f, 0, 0.16f, 0.14f, 0.16f, YELLOW}};
}
std::vector<Part> caballero() {   // armadura: yelmo con penacho, hombreras, escudo y espada
    std::vector<Part> p = {{0, 1.0f, 0, 0.62f, 0.75f, 0.36f, STEEL}, {0, 1.0f, 0.19f, 0.4f, 0.5f, 0.04f, GREY}, {0, 1.62f, 0, 0.4f, 0.4f, 0.4f, STEEL}, {0, 1.62f, 0.2f, 0.3f, 0.06f, 0.03f, VBLACK},
                           {0, 1.9f, 0, 0.08f, 0.2f, 0.34f, RED}, {-0.18f, 0.35f, 0, 0.24f, 0.72f, 0.26f, SLATE}, {0.18f, 0.35f, 0, 0.24f, 0.72f, 0.26f, SLATE},
                           {-0.18f, 0.06f, 0.05f, 0.26f, 0.12f, 0.36f, GREY}, {0.18f, 0.06f, 0.05f, 0.26f, 0.12f, 0.36f, GREY},
                           {-0.46f, 1.28f, 0, 0.3f, 0.2f, 0.34f, STEEL}, {0.46f, 1.28f, 0, 0.3f, 0.2f, 0.34f, STEEL},
                           {-0.46f, 0.95f, 0, 0.18f, 0.65f, 0.2f, GREY}, {0.46f, 0.95f, 0.1f, 0.18f, 0.6f, 0.2f, GREY},
                           {-0.62f, 1.0f, 0.12f, 0.08f, 0.7f, 0.5f, BLUE}, {-0.64f, 1.0f, 0.12f, 0.03f, 0.4f, 0.28f, YELLOW},
                           {0, 0.62f, 0, 0.66f, 0.12f, 0.38f, DBROWN}};
    p.push_back({0.5f, 1.05f, 0.5f, 0.07f, 0.07f, 0.26f, DBROWN});   // empuñadura
    p.push_back({0.5f, 1.4f, 0.6f, 0.04f, 0.8f, 0.1f, STEEL});       // hoja
    return p;
}
std::vector<Part> orco() {
    return {{0, 1.15f, 0, 1.0f, 1.2f, 0.7f, DOLIVE}, {0, 1.0f, 0.36f, 0.8f, 0.7f, 0.04f, DBROWN}, {0, 2.05f, 0.05f, 0.7f, 0.65f, 0.6f, OLIVE}, {-0.2f, 2.1f, 0.36f, 0.16f, 0.1f, 0.04f, BRIGHT}, {0.2f, 2.1f, 0.36f, 0.16f, 0.1f, 0.04f, BRIGHT},
            {-0.2f, 1.82f, 0.38f, 0.1f, 0.2f, 0.06f, WHITE}, {0.2f, 1.82f, 0.38f, 0.1f, 0.2f, 0.06f, WHITE}, {-0.45f, 0.4f, 0, 0.4f, 0.8f, 0.42f, DBROWN}, {0.45f, 0.4f, 0, 0.4f, 0.8f, 0.42f, DBROWN},
            {-0.8f, 1.25f, 0.1f, 0.38f, 1.0f, 0.38f, OLIVE}, {0.8f, 1.25f, 0.15f, 0.38f, 1.0f, 0.38f, OLIVE}, {0.85f, 1.8f, 0.4f, 0.14f, 0.14f, 1.1f, DBROWN}, {0.85f, 1.8f, 0.95f, 0.3f, 0.3f, 0.3f, GREY},
            {-0.7f, 1.78f, 0, 0.5f, 0.2f, 0.5f, GREY}, {0.7f, 1.78f, 0, 0.5f, 0.2f, 0.5f, GREY}};
}
std::vector<Part> esqueleto() {
    return {{0, 1.1f, 0, 0.5f, 0.7f, 0.22f, WHITE}, {0, 1.1f, 0.12f, 0.46f, 0.08f, 0.02f, GREY}, {0, 1.0f, 0.12f, 0.4f, 0.08f, 0.02f, GREY}, {0, 0.9f, 0.12f, 0.34f, 0.08f, 0.02f, GREY},
            {0, 1.65f, 0, 0.36f, 0.36f, 0.34f, WHITE}, {-0.08f, 1.68f, 0.18f, 0.1f, 0.1f, 0.03f, VBLACK}, {0.08f, 1.68f, 0.18f, 0.1f, 0.1f, 0.03f, VBLACK}, {0, 1.52f, 0.18f, 0.18f, 0.06f, 0.03f, VBLACK},
            {-0.14f, 0.38f, 0, 0.09f, 0.75f, 0.09f, WHITE}, {0.14f, 0.38f, 0, 0.09f, 0.75f, 0.09f, WHITE}, {0, 0.72f, 0, 0.4f, 0.1f, 0.18f, WHITE},
            {-0.36f, 1.1f, 0, 0.08f, 0.7f, 0.08f, WHITE}, {0.36f, 1.1f, 0, 0.08f, 0.7f, 0.08f, WHITE}, {0.36f, 0.9f, 0.4f, 0.04f, 0.9f, 0.06f, STEEL}};
}
std::vector<Part> luchador(int skin, int pants, int band) {   // peleador: torso ancho, guantes, cinta
    return {{0, 1.05f, 0, 0.7f, 0.75f, 0.34f, skin}, {0, 1.62f, 0, 0.36f, 0.38f, 0.36f, skin}, {0, 1.82f, 0, 0.4f, 0.1f, 0.4f, VBLACK}, {0, 1.74f, 0.19f, 0.4f, 0.07f, 0.02f, band},
            {-0.08f, 1.64f, 0.19f, 0.07f, 0.06f, 0.02f, VBLACK}, {0.08f, 1.64f, 0.19f, 0.07f, 0.06f, 0.02f, VBLACK},
            {-0.18f, 0.4f, 0, 0.26f, 0.8f, 0.28f, pants}, {0.18f, 0.4f, 0, 0.26f, 0.8f, 0.28f, pants}, {0, 0.76f, 0, 0.62f, 0.14f, 0.34f, band},
            {-0.5f, 1.12f, 0.12f, 0.22f, 0.7f, 0.24f, skin}, {0.5f, 1.12f, 0.12f, 0.22f, 0.7f, 0.24f, skin},
            {-0.5f, 0.7f, 0.3f, 0.3f, 0.3f, 0.3f, RED}, {0.5f, 0.7f, 0.3f, 0.3f, 0.3f, 0.3f, RED},
            {-0.18f, 0.06f, 0.05f, 0.28f, 0.12f, 0.38f, VBLACK}, {0.18f, 0.06f, 0.05f, 0.28f, 0.12f, 0.38f, VBLACK}};
}
std::vector<Part> luchadorA() { return luchador(SKIN, DBLUE, RED); }
std::vector<Part> luchadorB() { return luchador(TAN, VBLACK, YELLOW); }
std::vector<Part> puertaMetal() {   // puerta de seguridad: marco, hoja metálica con ventana y franjas de aviso
    return {{-1.1f, 1.3f, 0, 0.2f, 2.6f, 0.4f, GREY}, {1.1f, 1.3f, 0, 0.2f, 2.6f, 0.4f, GREY}, {0, 2.7f, 0, 2.4f, 0.2f, 0.4f, GREY},
            {0, 1.3f, 0, 2.0f, 2.6f, 0.14f, STEEL}, {0, 1.7f, 0.08f, 0.8f, 0.5f, 0.02f, SLATE}, {0, 0.25f, 0.08f, 2.0f, 0.16f, 0.02f, YELLOW}, {0, 0.25f, 0.085f, 0.3f, 0.16f, 0.02f, VBLACK},
            {0.7f, 1.2f, 0.1f, 0.12f, 0.4f, 0.06f, GREY}, {0.7f, 1.2f, 0.14f, 0.05f, 0.05f, 0.04f, RED}};
}
std::vector<Part> camaraSeg() {
    return {{0, 0, 0, 0.5f, 0.32f, 0.9f, GREY}, {0, 0, 0.47f, 0.34f, 0.24f, 0.1f, VBLACK}, {0, 0, 0.53f, 0.18f, 0.14f, 0.04f, TEAL}, {0, 0.1f, 0.25f, 0.5f, 0.06f, 0.5f, STEEL}, {0.16f, 0.12f, -0.2f, 0.06f, 0.06f, 0.04f, RED},
            {0, 0.28f, -0.4f, 0.14f, 0.5f, 0.14f, SLATE}, {0, 0.52f, -0.5f, 0.4f, 0.06f, 0.3f, SLATE}};
}
std::vector<Part> monitor() {
    return {{0, 0.5f, 0, 0.9f, 0.7f, 0.6f, DBROWN}, {0, 0.55f, 0.31f, 0.7f, 0.5f, 0.02f, TEAL}, {0, 0.55f, 0.33f, 0.72f, 0.02f, 0.01f, WHITE}, {0.3f, 0.2f, 0.31f, 0.08f, 0.08f, 0.02f, GLOW},
            {0, 0.1f, 0, 0.5f, 0.2f, 0.4f, SLATE}};
}
std::vector<Part> ninja() { return humano(VBLACK, VBLACK, SKIN, false, false); }
std::vector<Part> obstaculo() {   // cono / valla para carreras y runners
    return {{0, 0.1f, 0, 0.7f, 0.2f, 0.7f, VBLACK}, {0, 0.45f, 0, 0.5f, 0.5f, 0.5f, ORANGE}, {0, 0.8f, 0, 0.3f, 0.3f, 0.3f, ORANGE}, {0, 0.55f, 0, 0.52f, 0.1f, 0.52f, WHITE}, {0, 0.95f, 0, 0.2f, 0.1f, 0.2f, ORANGE}};
}
// ------------------------------------------------------------ v10.9: modelos de las fotos de referencia (estructuras, vehículos, armas, soldados, vegetación)
std::vector<Part> ventanasFila(float x0, float dx, int n, float y, float z, float w, float h, int c, bool back = false) {
    std::vector<Part> p;
    for (int i = 0; i < n; i++) { p.push_back(Bx(x0 + i * dx, y, z, w, h, 0.05f, c)); if (back) p.push_back(Bx(x0 + i * dx, y, -z, w, h, 0.05f, c)); }
    return p;
}
std::vector<Part> bodega() {   // nave industrial con techo a dos aguas azul, portones y ventanas altas
    std::vector<Part> p = {Bx(0, 1.6f, 0, 8.f, 3.2f, 5.f, CREAM), Bx(0, 0.1f, 0, 8.2f, 0.2f, 5.2f, GREY),
        Bx(-2.0f, 3.5f, 0, 4.4f, 0.14f, 5.6f, BLUE, 0, 0), Bx(2.0f, 3.5f, 0, 4.4f, 0.14f, 5.6f, BLUE, 0, 0),
        Bx(0, 3.75f, 0, 0.3f, 0.35f, 5.6f, DBLUE), Bx(0, 1.1f, 2.52f, 2.6f, 2.2f, 0.08f, GREY), Bx(-3.0f, 0.9f, 2.52f, 1.0f, 1.8f, 0.08f, DBROWN),
        Cy(3.4f, 3.7f, -1.5f, 0.4f, 0.5f, 0.4f, STEEL)};
    p[2].rz = 14.f; p[3].rz = -14.f;
    for (int i = 0; i < 5; i++) p.push_back(Bx(-3.2f + i * 1.6f, 2.55f, 2.52f, 0.9f, 0.5f, 0.06f, TEAL));
    return p;
}
std::vector<Part> casaPalafito() {   // casa de madera elevada sobre pilotes (estilo de las fotos)
    std::vector<Part> p;
    for (float x : {-2.6f, 0.f, 2.6f}) for (float z : {-1.8f, 1.8f}) p.push_back(Bx(x, 1.0f, z, 0.35f, 2.0f, 0.35f, DBROWN));
    p.push_back(Bx(0, 2.1f, 0, 6.6f, 0.2f, 4.6f, BROWN));
    p.push_back(Bx(0, 3.4f, 0, 5.6f, 2.4f, 3.8f, TAN)); p.push_back(Bx(0, 3.4f, 1.91f, 5.7f, 2.5f, 0.06f, DBROWN));
    p.push_back(Bx(-1.7f, 5.0f, 0, 3.4f, 0.16f, 4.4f, RUST, 0, 0)); p.push_back(Bx(1.7f, 5.0f, 0, 3.4f, 0.16f, 4.4f, RUST, 0, 0));
    p[p.size() - 2].rz = 22.f; p[p.size() - 1].rz = -22.f;
    p.push_back(Bx(0, 3.0f, 1.96f, 0.9f, 1.6f, 0.06f, VBLACK)); p.push_back(Bx(-1.8f, 3.5f, 1.96f, 0.9f, 0.8f, 0.06f, LYELLOW)); p.push_back(Bx(1.8f, 3.5f, 1.96f, 0.9f, 0.8f, 0.06f, LYELLOW));
    p.push_back(Bx(0, 1.0f, 2.9f, 1.0f, 0.12f, 2.2f, BROWN, 0, 0)); p.back().rx = 28.f;   // escalera
    p.push_back(CyX(2.9f, 5.4f, -1.2f, 0.12f, 1.2f, 0.12f, STEEL));
    return p;
}
std::vector<Part> rascacielos() {
    std::vector<Part> p = {Bx(0, 4.0f, 0, 3.0f, 8.0f, 3.0f, SLATE), Bx(0, 8.2f, 0, 2.4f, 0.5f, 2.4f, SLATE), Bx(0, 8.9f, 0, 0.1f, 1.0f, 0.1f, STEEL), Bx(0, 0.2f, 0, 3.4f, 0.4f, 3.4f, GREY)};
    for (int y = 0; y < 14; y++) for (int s = 0; s < 4; s++) {
        float yy = 0.9f + y * 0.52f;
        p.push_back(Bx(0, yy, 1.51f, 2.7f, 0.34f, 0.03f, TEAL)); p.push_back(Bx(0, yy, -1.51f, 2.7f, 0.34f, 0.03f, TEAL));
        p.push_back(Bx(1.51f, yy, 0, 0.03f, 0.34f, 2.7f, TEAL)); p.push_back(Bx(-1.51f, yy, 0, 0.03f, 0.34f, 2.7f, TEAL));
        break;
    }
    return p;
}
std::vector<Part> torreReloj() {   // campanario / torre de reloj de plaza
    return {Bx(0, 0.4f, 0, 2.2f, 0.8f, 2.2f, TAN), Bx(0, 3.0f, 0, 1.4f, 5.0f, 1.4f, CREAM), Bx(0, 5.7f, 0, 1.7f, 0.4f, 1.7f, TAN),
            Bx(0, 6.4f, 0, 1.3f, 1.2f, 1.3f, CREAM), Co(0, 7.6f, 0, 1.6f, 1.5f, 1.6f, DRED), El(0, 6.4f, 0.67f, 0.8f, 0.8f, 0.06f, WHITE), El(0, 6.4f, -0.67f, 0.8f, 0.8f, 0.06f, WHITE),
            Bx(0, 6.4f, 0.71f, 0.05f, 0.35f, 0.02f, VBLACK), Bx(0, 3.0f, 0.72f, 0.5f, 1.2f, 0.04f, DBROWN), Bx(0, 4.4f, 0.72f, 0.4f, 0.8f, 0.04f, VBLACK)};
}
std::vector<Part> contenedor() {   // contenedor de carga corrugado
    std::vector<Part> p = {Bx(0, 1.3f, 0, 2.4f, 2.6f, 6.0f, RED)};
    for (int i = 0; i < 12; i++) { p.push_back(Bx(1.21f, 1.3f, -2.75f + i * 0.5f, 0.04f, 2.4f, 0.12f, DRED)); p.push_back(Bx(-1.21f, 1.3f, -2.75f + i * 0.5f, 0.04f, 2.4f, 0.12f, DRED)); }
    p.push_back(Bx(0, 1.3f, 3.02f, 2.3f, 2.5f, 0.05f, DRED)); p.push_back(Bx(-0.5f, 1.3f, 3.06f, 0.06f, 2.4f, 0.06f, STEEL)); p.push_back(Bx(0.5f, 1.3f, 3.06f, 0.06f, 2.4f, 0.06f, STEEL));
    return p;
}
std::vector<Part> tuberias() {
    std::vector<Part> p;
    for (int i = 0; i < 3; i++) p.push_back(CyX(0, 0.4f + (i == 2 ? 0.7f : 0.f), (i == 2 ? 0.f : (i ? 0.4f : -0.4f)), 0.8f, 3.0f, 0.8f, i % 2 ? STEEL : GREY));
    p.push_back(CyX(0, 0.4f, 1.2f, 0.7f, 3.0f, 0.7f, RUST));
    return p;
}
std::vector<Part> tanqueGas() {
    return {CyX(0, 1.1f, 0, 2.0f, 4.0f, 2.0f, GREY), El(-2.0f, 1.1f, 0, 0.9f, 2.0f, 2.0f, GREY), El(2.0f, 1.1f, 0, 0.9f, 2.0f, 2.0f, GREY),
            Bx(-1.2f, 0.15f, 0, 0.3f, 0.3f, 1.8f, DBROWN), Bx(1.2f, 0.15f, 0, 0.3f, 0.3f, 1.8f, DBROWN), Cy(0, 2.3f, 0, 0.4f, 0.3f, 0.4f, RUST), Bx(0, 1.8f, 0.4f, 3.8f, 0.1f, 0.05f, RUST)};
}
std::vector<Part> silo() {
    return {Cy(0, 2.5f, 0, 2.0f, 5.0f, 2.0f, STEEL), Co(0, 5.5f, 0, 2.0f, 1.0f, 2.0f, GREY), Bx(1.3f, 2.5f, 0, 0.1f, 5.0f, 0.4f, DBLUE), Cy(0, 0.2f, 0, 2.4f, 0.4f, 2.4f, GREY)};
}
std::vector<Part> casaRural() {   // casa de dos pisos con balcón y tejado
    std::vector<Part> p = {Bx(0, 1.4f, 0, 5.f, 2.8f, 4.f, TAN), Bx(0, 3.5f, 0, 4.4f, 1.4f, 3.4f, CREAM), Bx(-1.2f, 4.5f, 0, 2.6f, 0.14f, 4.f, DRED), Bx(1.2f, 4.5f, 0, 2.6f, 0.14f, 4.f, DRED),
        Bx(0, 1.0f, 2.02f, 0.9f, 2.0f, 0.06f, DBROWN), Bx(-1.5f, 1.6f, 2.02f, 0.9f, 0.9f, 0.06f, TEAL), Bx(1.5f, 1.6f, 2.02f, 0.9f, 0.9f, 0.06f, TEAL), Bx(0, 3.5f, 1.72f, 1.0f, 0.9f, 0.06f, TEAL),
        Bx(0, 2.9f, 2.4f, 3.0f, 0.1f, 0.8f, BROWN), Bx(1.8f, 4.9f, -0.8f, 0.5f, 1.2f, 0.5f, GREY)};
    p[2].rz = 20.f; p[3].rz = -20.f;
    return p;
}
// ---- vehículos (frente hacia +z)
std::vector<Part> ruedas4(float x, float z1, float z2, float r, float w, int rim = STEEL) {
    std::vector<Part> p;
    for (float sx : {-1.f, 1.f}) for (float z : {z1, z2}) { p.push_back(CyX(sx * x, r, z, r * 2.f, w, r * 2.f, VBLACK)); p.push_back(CyX(sx * (x + w * 0.45f), r, z, r * 1.1f, w * 0.2f, r * 1.1f, rim)); }
    return p;
}
std::vector<Part> sedan() {
    std::vector<Part> p = {El(0, 0.55f, 0, 1.8f, 0.6f, 4.4f, BLUE), Bx(0, 0.45f, 0, 1.85f, 0.4f, 4.3f, DBLUE), El(0, 0.98f, -0.1f, 1.5f, 0.55f, 2.4f, SLATE), Bx(0, 1.25f, -0.1f, 1.4f, 0.05f, 1.9f, DBLUE),
        El(-0.65f, 0.6f, 2.15f, 0.4f, 0.16f, 0.1f, LYELLOW), El(0.65f, 0.6f, 2.15f, 0.4f, 0.16f, 0.1f, LYELLOW), El(-0.65f, 0.65f, -2.15f, 0.4f, 0.14f, 0.1f, BRIGHT), El(0.65f, 0.65f, -2.15f, 0.4f, 0.14f, 0.1f, BRIGHT),
        Bx(0, 0.35f, 2.2f, 1.7f, 0.14f, 0.1f, VBLACK), Bx(0, 0.35f, -2.2f, 1.7f, 0.14f, 0.1f, VBLACK)};
    add(p, ruedas4(0.88f, 1.4f, -1.4f, 0.34f, 0.24f), 0, 0, 0);
    return p;
}
std::vector<Part> pickup() {
    std::vector<Part> p = {Bx(0, 0.75f, 1.0f, 2.0f, 0.9f, 2.4f, GREEN), El(0, 1.3f, 0.7f, 1.8f, 0.7f, 1.6f, DOLIVE), Bx(0, 1.32f, 0.7f, 1.84f, 0.45f, 1.45f, SLATE),
        Bx(0, 0.62f, -1.4f, 2.0f, 0.2f, 2.2f, DOLIVE), Bx(-0.98f, 0.95f, -1.4f, 0.08f, 0.5f, 2.2f, GREEN), Bx(0.98f, 0.95f, -1.4f, 0.08f, 0.5f, 2.2f, GREEN), Bx(0, 0.95f, -2.46f, 2.0f, 0.5f, 0.08f, GREEN),
        El(-0.7f, 0.85f, 2.25f, 0.4f, 0.2f, 0.1f, LYELLOW), El(0.7f, 0.85f, 2.25f, 0.4f, 0.2f, 0.1f, LYELLOW), Bx(0, 0.5f, 2.3f, 1.9f, 0.18f, 0.12f, VBLACK)};
    add(p, ruedas4(1.0f, 1.5f, -1.5f, 0.45f, 0.3f), 0, 0, 0);
    return p;
}
std::vector<Part> camion() {   // camión de carga con caja
    std::vector<Part> p = {Bx(0, 1.0f, 2.6f, 2.2f, 1.4f, 1.8f, WHITE), Bx(0, 1.55f, 3.2f, 2.0f, 0.7f, 0.1f, SLATE), Bx(0, 0.6f, 0.1f, 2.2f, 0.25f, 7.0f, VBLACK), Bx(0, 2.1f, -0.9f, 2.5f, 2.6f, 5.2f, BLUE), Bx(0, 0.6f, 3.6f, 2.2f, 0.4f, 0.2f, VBLACK),
        El(-0.8f, 0.8f, 3.55f, 0.4f, 0.2f, 0.1f, LYELLOW), El(0.8f, 0.8f, 3.55f, 0.4f, 0.2f, 0.1f, LYELLOW), Bx(0, 2.1f, -3.52f, 2.3f, 2.4f, 0.06f, DBLUE)};
    add(p, ruedas4(1.15f, 2.6f, -0.2f, 0.5f, 0.35f), 0, 0, 0);
    add(p, ruedas4(1.15f, -2.2f, -2.2f, 0.5f, 0.35f), 0, 0, 0);
    return p;
}
std::vector<Part> autobus() {
    std::vector<Part> p = {Bx(0, 1.7f, 0, 2.5f, 2.6f, 9.0f, YELLOW), Bx(0, 0.45f, 0, 2.55f, 0.3f, 9.05f, VBLACK), Bx(0, 1.9f, 4.52f, 2.3f, 1.2f, 0.06f, SLATE), Bx(0, 0.75f, 4.55f, 2.2f, 0.25f, 0.1f, VBLACK), Bx(0, 3.05f, 0, 2.3f, 0.1f, 8.8f, WHITE)};
    for (int i = 0; i < 7; i++) { p.push_back(Bx(1.27f, 2.0f, -3.6f + i * 1.2f, 0.04f, 0.9f, 0.9f, SLATE)); p.push_back(Bx(-1.27f, 2.0f, -3.6f + i * 1.2f, 0.04f, 0.9f, 0.9f, SLATE)); }
    p.push_back(Bx(1.27f, 1.7f, -4.0f, 0.04f, 0.04f, 0.04f, BLACK));
    add(p, ruedas4(1.2f, 3.0f, -3.0f, 0.5f, 0.35f), 0, 0, 0);
    p.push_back(El(-0.8f, 1.0f, 4.55f, 0.4f, 0.2f, 0.1f, LYELLOW)); p.push_back(El(0.8f, 1.0f, 4.55f, 0.4f, 0.2f, 0.1f, LYELLOW));
    return p;
}
std::vector<Part> bulldozer() {
    std::vector<Part> p = {Bx(0, 1.0f, -0.2f, 1.8f, 0.9f, 2.6f, ORANGE), Bx(0, 1.9f, -0.5f, 1.4f, 1.1f, 1.4f, ORANGE), Bx(0, 1.95f, -0.45f, 1.45f, 0.7f, 1.2f, SLATE), Bx(0, 2.55f, -0.5f, 1.6f, 0.1f, 1.6f, VBLACK),
        Bx(0, 0.9f, 2.3f, 3.2f, 1.2f, 0.25f, YELLOW), Bx(-1.2f, 0.9f, 1.4f, 0.2f, 0.2f, 1.8f, VBLACK), Bx(1.2f, 0.9f, 1.4f, 0.2f, 0.2f, 1.8f, VBLACK), Cy(0.5f, 2.6f, 0.4f, 0.12f, 0.8f, 0.12f, VBLACK)};
    for (float sx : {-1.f, 1.f}) { p.push_back(Bx(sx * 1.05f, 0.45f, -0.1f, 0.6f, 0.9f, 3.4f, VBLACK)); p.push_back(CyX(sx * 1.05f, 0.5f, 1.55f, 0.8f, 0.6f, 0.8f, BLACK)); p.push_back(CyX(sx * 1.05f, 0.5f, -1.7f, 0.8f, 0.6f, 0.8f, BLACK)); }
    return p;
}
std::vector<Part> excavadora() {
    std::vector<Part> p = {Bx(0, 0.9f, 0, 2.2f, 0.5f, 3.2f, DOLIVE), Bx(0, 1.5f, -0.5f, 2.0f, 0.9f, 2.2f, YELLOW), Bx(0.55f, 2.2f, 0.4f, 1.0f, 1.0f, 1.2f, YELLOW), Bx(0.55f, 2.25f, 0.45f, 1.05f, 0.7f, 1.1f, SLATE),
        Bx(0, 2.0f, 1.6f, 0.5f, 0.5f, 2.6f, YELLOW, 0, 0), Bx(0, 2.9f, 3.2f, 0.4f, 0.4f, 2.4f, YELLOW), Bx(0, 1.7f, 4.4f, 0.8f, 0.9f, 0.9f, DOLIVE)};
    p[4].rx = -25.f; p[5].rx = 35.f;
    for (float sx : {-1.f, 1.f}) { p.push_back(Bx(sx * 1.2f, 0.4f, 0, 0.6f, 0.8f, 3.8f, VBLACK)); p.push_back(CyX(sx * 1.2f, 0.4f, 1.8f, 0.8f, 0.6f, 0.8f, BLACK)); p.push_back(CyX(sx * 1.2f, 0.4f, -1.8f, 0.8f, 0.6f, 0.8f, BLACK)); }
    return p;
}
std::vector<Part> avion() {   // avión comercial: fuselaje, alas, motores, cola
    return {CpZ(0, 0, 0, 1.2f, 1.2f, 8.0f, WHITE), Bx(0, 0.1f, 0.5f, 9.0f, 0.1f, 1.6f, GREY, 0, 0), CyX(-1.9f, -0.35f, 0.9f, 0.5f, 0.9f, 0.5f, STEEL), CyX(1.9f, -0.35f, 0.9f, 0.5f, 0.9f, 0.5f, STEEL),
            Bx(0, 1.0f, -3.4f, 0.12f, 1.8f, 1.2f, BLUE), Bx(0, 0.25f, -3.5f, 3.2f, 0.08f, 0.9f, GREY), El(0, 0.25f, 3.5f, 0.9f, 0.5f, 1.0f, SLATE),
            Bx(0, 0.0f, 0, 1.22f, 0.12f, 6.0f, BLUE)};
}
std::vector<Part> caza() {   // caza a reacción
    return {CpZ(0, 0, 0, 0.9f, 0.8f, 7.0f, STEEL), Co(0, 0, 4.0f, 0.5f, 1.0f, 0.5f, DOLIVE, 0, 90.f), Bx(0, -0.05f, -0.6f, 5.0f, 0.06f, 2.4f, GREY), Bx(0, 0.0f, -2.8f, 2.4f, 0.05f, 1.0f, GREY),
            Bx(0, 0.7f, -2.8f, 0.08f, 1.1f, 1.0f, DOLIVE), El(0, 0.4f, 1.2f, 0.5f, 0.35f, 1.4f, TEAL), CyX(-0.3f, -0.1f, -3.4f, 0.4f, 0.5f, 0.4f, VBLACK)};
}
std::vector<Part> dron() {
    return {El(0, 0, 0, 0.9f, 0.4f, 0.9f, VBLACK), Bx(0, 0, 0, 2.8f, 0.07f, 0.12f, GREY, 0, 0), Bx(0, 0, 0, 0.12f, 0.07f, 2.8f, GREY), Cy(1.4f, 0.1f, 0, 0.8f, 0.05f, 0.8f, STEEL), Cy(-1.4f, 0.1f, 0, 0.8f, 0.05f, 0.8f, STEEL),
            Cy(0, 0.1f, 1.4f, 0.8f, 0.05f, 0.8f, STEEL), Cy(0, 0.1f, -1.4f, 0.8f, 0.05f, 0.8f, STEEL), El(0, -0.2f, 0.3f, 0.25f, 0.25f, 0.25f, BLUE)};
}
// ---- armas de ciencia ficción y pesadas (apuntan hacia +z)
std::vector<Part> lanzacohetes() {
    return {CyZ(0, 0, 0, 0.3f, 2.4f, 0.3f, DOLIVE), CyZ(0, 0, 1.3f, 0.4f, 0.4f, 0.4f, GREY), Bx(0, -0.35f, -0.3f, 0.12f, 0.5f, 0.15f, VBLACK), Bx(0, 0.25f, 0.3f, 0.1f, 0.15f, 0.5f, VBLACK), CyZ(0, 0, -1.3f, 0.34f, 0.2f, 0.34f, VBLACK), Bx(0, -0.15f, 0.5f, 0.1f, 0.25f, 0.12f, VBLACK)};
}
std::vector<Part> ametralladora() {
    return {Bx(0, 0, 0, 0.2f, 0.28f, 1.6f, VBLACK), CyZ(0, 0.03f, 1.3f, 0.07f, 1.1f, 0.07f, STEEL), Bx(0, -0.3f, -0.2f, 0.14f, 0.4f, 0.16f, VBLACK), Bx(0, -0.45f, 0.4f, 0.18f, 0.6f, 0.3f, OLIVE), Bx(0, 0.2f, 0.1f, 0.08f, 0.1f, 0.9f, STEEL),
            Bx(0, -0.1f, -0.9f, 0.14f, 0.3f, 0.5f, VBLACK), Bx(0, -0.55f, 1.0f, 0.04f, 0.5f, 0.04f, STEEL, 0, 0), Bx(-0.1f, -0.55f, 1.0f, 0.04f, 0.5f, 0.04f, STEEL)};
}
std::vector<Part> pistolaEnergia() {
    return {Bx(0, 0.05f, 0.2f, 0.12f, 0.2f, 0.7f, STEEL), Bx(0, -0.25f, -0.1f, 0.1f, 0.4f, 0.14f, SLATE, 0, 0), El(0, 0.05f, 0.62f, 0.14f, 0.14f, 0.16f, TEAL), Bx(0, 0.18f, 0.2f, 0.05f, 0.05f, 0.5f, GLOW), CyZ(0, 0.05f, 0.7f, 0.07f, 0.3f, 0.07f, BLACK)};
}
std::vector<Part> rifleEnergia() {
    return {Bx(0, 0, 0, 0.18f, 0.3f, 1.8f, SLATE), Bx(0, 0.0f, 0.1f, 0.2f, 0.12f, 1.0f, TEAL), CyZ(0, 0.02f, 1.5f, 0.08f, 1.0f, 0.08f, STEEL), El(0, 0.0f, 2.0f, 0.16f, 0.16f, 0.2f, GLOW), Bx(0, -0.3f, -0.2f, 0.13f, 0.4f, 0.16f, VBLACK),
            Bx(0, 0.0f, -1.1f, 0.14f, 0.34f, 0.5f, SLATE), Bx(0, 0.22f, 0.4f, 0.1f, 0.14f, 0.5f, BLACK), Bx(0, -0.25f, 0.6f, 0.14f, 0.35f, 0.3f, ORANGE)};
}
// ---- personas
std::vector<Part> soldadoTactico(bool swat) {
    std::vector<Part> p = persona(SKIN, swat ? DBLUE : DOLIVE, swat ? DBLUE : DOLIVE, VBLACK, BLACK);
    p.push_back(El(0, 1.9f, 0, 0.3f, 0.26f, 0.32f, swat ? VBLACK : OLIVE));                    // casco
    p.push_back(Bx(0, 1.86f, 0.17f, 0.24f, 0.1f, 0.04f, VBLACK));                             // gafas
    p.push_back(El(0, 1.9f, 0.18f, 0.1f, 0.1f, 0.12f, TEAL));                                  // visor de visión nocturna
    p.push_back(Bx(0, 1.38f, 0.13f, 0.5f, 0.55f, 0.12f, swat ? VBLACK : DOLIVE));              // chaleco
    p.push_back(Bx(-0.15f, 1.22f, 0.2f, 0.14f, 0.18f, 0.08f, OLIVE)); p.push_back(Bx(0.15f, 1.22f, 0.2f, 0.14f, 0.18f, 0.08f, OLIVE));   // cargadores
    p.push_back(Bx(0, 1.38f, -0.15f, 0.42f, 0.5f, 0.14f, VBLACK));                              // mochila
    p.push_back(Bx(-0.12f, 0.65f, 0.12f, 0.12f, 0.2f, 0.06f, OLIVE));                           // rodilleras
    p.push_back(Bx(0.1f, 1.15f, 0.5f, 0.1f, 0.14f, 0.9f, VBLACK));                              // arma
    return p;
}
std::vector<Part> comandoTactico() { return soldadoTactico(false); }
std::vector<Part> policiaSwat() { return soldadoTactico(true); }
std::vector<Part> zombiGordo() {   // bruto enorme
    std::vector<Part> p = {El(0, 1.35f, 0, 1.1f, 1.1f, 0.8f, ZOMB), El(0, 0.9f, 0.05f, 1.2f, 0.9f, 0.9f, BLOOD), Cp(-0.3f, 0.45f, 0, 0.38f, 0.9f, 0.38f, DBROWN), Cp(0.3f, 0.45f, 0, 0.38f, 0.9f, 0.38f, DBROWN),
        El(0, 1.95f, 0.1f, 0.4f, 0.4f, 0.4f, ZOMB), Cp(-0.8f, 1.2f, 0.1f, 0.3f, 1.1f, 0.3f, ZOMB, 10.f), Cp(0.8f, 1.2f, 0.1f, 0.3f, 1.1f, 0.3f, ZOMB, -10.f), El(-0.8f, 0.55f, 0.15f, 0.34f, 0.34f, 0.34f, ZOMB), El(0.8f, 0.55f, 0.15f, 0.34f, 0.34f, 0.34f, ZOMB),
        El(-0.08f, 2.0f, 0.3f, 0.07f, 0.05f, 0.04f, GLOW), El(0.08f, 2.0f, 0.3f, 0.07f, 0.05f, 0.04f, GLOW), Bx(0, 1.0f, 0.46f, 0.7f, 0.5f, 0.04f, BLOOD)};
    return p;
}
std::vector<Part> zombiObrero() { std::vector<Part> p = persona(ZOMB, MUSTARD, DBROWN, VBLACK, DBROWN, false, true); p.push_back(Bx(0, 1.38f, 0.14f, 0.5f, 0.5f, 0.05f, ORANGE)); p.push_back(El(0, 1.97f, 0, 0.27f, 0.12f, 0.28f, MUSTARD)); return p; }
// ---- vegetación
std::vector<Part> pino() {
    return {Cy(0, 0.8f, 0, 0.3f, 1.6f, 0.3f, DBROWN), Co(0, 2.0f, 0, 2.2f, 1.6f, 2.2f, DGREEN), Co(0, 3.0f, 0, 1.8f, 1.5f, 1.8f, DGREEN), Co(0, 3.9f, 0, 1.3f, 1.4f, 1.3f, GREEN), Co(0, 4.7f, 0, 0.7f, 1.0f, 0.7f, GREEN)};
}
std::vector<Part> palmera() {
    std::vector<Part> p = {Cp(0, 2.0f, 0, 0.3f, 4.0f, 0.3f, TAN, 4.f)};
    for (int i = 0; i < 7; i++) { float a = i * 0.8976f; p.push_back(El(std::cos(a) * 0.8f, 4.1f, std::sin(a) * 0.8f, 1.6f, 0.08f, 0.5f, GREEN, 0, 0)); p.back().rx = 0; p.back().rz = (std::cos(a) > 0 ? -18.f : 18.f); }
    p.push_back(El(0.1f, 3.9f, 0, 0.3f, 0.3f, 0.3f, DBROWN)); p.push_back(El(-0.1f, 3.9f, 0.1f, 0.3f, 0.3f, 0.3f, DBROWN));
    return p;
}
std::vector<Part> arbusto() { return {El(0, 0.4f, 0, 1.2f, 0.8f, 1.2f, DGREEN), El(0.5f, 0.35f, 0.2f, 0.9f, 0.7f, 0.9f, GREEN), El(-0.45f, 0.3f, -0.2f, 0.8f, 0.6f, 0.8f, GREEN), El(0.1f, 0.7f, -0.1f, 0.7f, 0.5f, 0.7f, ZOMB)}; }
std::vector<Part> roca() { return {El(0, 0.5f, 0, 1.6f, 1.0f, 1.3f, GREY), El(0.6f, 0.3f, 0.3f, 0.9f, 0.6f, 0.8f, STEEL), El(-0.5f, 0.25f, -0.4f, 0.8f, 0.5f, 0.7f, SLATE)}; }
std::vector<Part> roble() { return {Cp(0, 1.2f, 0, 0.5f, 2.4f, 0.5f, DBROWN), El(0, 3.4f, 0, 3.2f, 2.2f, 3.2f, DGREEN), El(1.0f, 3.1f, 0.5f, 2.0f, 1.6f, 2.0f, GREEN), El(-1.0f, 3.2f, -0.4f, 2.0f, 1.6f, 2.0f, GREEN), El(0, 4.1f, 0, 1.8f, 1.2f, 1.8f, ZOMB)}; }

const ModelDef kModels[] = {
    {"lib_carro2.fmdl", carro2}, {"lib_espada2.fmdl", espada2}, {"lib_caballero.fmdl", caballero}, {"lib_orco.fmdl", orco}, {"lib_esqueleto.fmdl", esqueleto},
    {"lib_luchador1.fmdl", luchadorA}, {"lib_luchador2.fmdl", luchadorB}, {"lib_puerta_metal.fmdl", puertaMetal}, {"lib_camara_seg.fmdl", camaraSeg}, {"lib_monitor.fmdl", monitor},
    {"lib_ninja.fmdl", ninja}, {"lib_cono.fmdl", obstaculo},
    {"lib_carro.fmdl", carro}, {"lib_soldado.fmdl", soldado}, {"lib_zombi.fmdl", zombi}, {"lib_monstruo.fmdl", monstruo}, {"lib_aldeano.fmdl", aldeano},
    {"lib_jugador.fmdl", jugador}, {"lib_animatronico_oso.fmdl", oso}, {"lib_animatronico_conejo.fmdl", conejo}, {"lib_pistola.fmdl", pistola}, {"lib_rifle.fmdl", rifle},
    {"lib_espada.fmdl", espada}, {"lib_civil_hombre.fmdl", civilHombre}, {"lib_civil_mujer.fmdl", civilMujer}, {"lib_zombi_real.fmdl", zombi2}, {"lib_soldado_real.fmdl", soldadoReal}, {"lib_soldado_enemigo.fmdl", soldadoEnemigo}, {"lib_comando.fmdl", comando}, {"lib_francotirador.fmdl", francotiradorSol}, {"lib_policia.fmdl", policia}, {"lib_peleador_rojo.fmdl", luchadorReal}, {"lib_peleador_azul.fmdl", luchadorReal2}, {"lib_guerrero.fmdl", guerrero}, {"lib_tanque.fmdl", tanque}, {"lib_tren.fmdl", tren}, {"lib_barrera.fmdl", barrera}, {"lib_edificio.fmdl", edificio}, {"lib_cono2.fmdl", cono2}, {"lib_carro_deportivo.fmdl", carroDeportivo}, {"lib_carro_azul.fmdl", carroAzul}, {"lib_carro_amarillo.fmdl", carroAmarillo}, {"lib_carro_verde.fmdl", carroVerde}, {"lib_helicoptero.fmdl", helicoptero}, {"lib_fusil.fmdl", fusilAsalto}, {"lib_escopeta.fmdl", escopeta}, {"lib_sniper.fmdl", francotirador}, {"lib_pistola_real.fmdl", pistola2}, {"lib_subfusil.fmdl", subfusil}, {"lib_cuchillo.fmdl", cuchillo}, {"lib_machete.fmdl", machete}, {"lib_hacha.fmdl", hacha}, {"lib_bate.fmdl", bate}, {"lib_katana.fmdl", katana}, {"lib_martillo.fmdl", martillo}, {"lib_granada.fmdl", granada}, {"lib_arbol.fmdl", arbol}, {"lib_caja.fmdl", caja}, {"lib_barril.fmdl", barril}, {"lib_casa.fmdl", casa}, {"lib_farola.fmdl", farola}, {"lib_bodega.fmdl", bodega}, {"lib_casa_palafito.fmdl", casaPalafito}, {"lib_rascacielos.fmdl", rascacielos}, {"lib_torre_reloj.fmdl", torreReloj}, {"lib_contenedor.fmdl", contenedor}, {"lib_tuberias.fmdl", tuberias}, {"lib_tanque_gas.fmdl", tanqueGas}, {"lib_silo.fmdl", silo}, {"lib_casa_rural.fmdl", casaRural}, {"lib_sedan.fmdl", sedan}, {"lib_pickup.fmdl", pickup}, {"lib_camion.fmdl", camion}, {"lib_autobus.fmdl", autobus}, {"lib_bulldozer.fmdl", bulldozer}, {"lib_excavadora.fmdl", excavadora}, {"lib_avion.fmdl", avion}, {"lib_caza.fmdl", caza}, {"lib_dron.fmdl", dron}, {"lib_lanzacohetes.fmdl", lanzacohetes}, {"lib_ametralladora.fmdl", ametralladora}, {"lib_pistola_energia.fmdl", pistolaEnergia}, {"lib_rifle_energia.fmdl", rifleEnergia}, {"lib_soldado_tactico.fmdl", comandoTactico}, {"lib_swat.fmdl", policiaSwat}, {"lib_zombi_gordo.fmdl", zombiGordo}, {"lib_zombi_obrero.fmdl", zombiObrero}, {"lib_pino.fmdl", pino}, {"lib_palmera.fmdl", palmera}, {"lib_arbusto.fmdl", arbusto}, {"lib_roca.fmdl", roca}, {"lib_roble.fmdl", roble},
    {"lib_lapida.fmdl", lapida}, {"lib_moneda.fmdl", moneda}, {"lib_cofre.fmdl", cofre}, {"lib_puerta.fmdl", puerta}, {"lib_escritorio.fmdl", escritorio}};

// ------------------------------------------------------------ texturas
float hash2(int x, int y, int s) { unsigned h = (unsigned)(x * 374761393 + y * 668265263 + s * 1274126177); h = (h ^ (h >> 13)) * 1274126177u; return ((h ^ (h >> 16)) & 0xffff) / 65535.f; }
float vnoise(float x, float y, int s) {
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    float fx = x - xi, fy = y - yi, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    float a = hash2(xi, yi, s), b = hash2(xi + 1, yi, s), c = hash2(xi, yi + 1, s), d = hash2(xi + 1, yi + 1, s);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
float fbm(float x, float y, int s) { return vnoise(x, y, s) * 0.5f + vnoise(x * 2, y * 2, s + 1) * 0.3f + vnoise(x * 4, y * 4, s + 2) * 0.2f; }

typedef void (*TexFn)(int x, int y, float* rgb);
const int T = 128;
void put(float* c, float r, float g, float b) { c[0] = r; c[1] = g; c[2] = b; }
void tConcreto(int x, int y, float* c) { float n = fbm(x / 12.f, y / 12.f, 1); put(c, 0.5f + n * .25f, 0.5f + n * .25f, 0.52f + n * .25f); }
void tLadrillo(int x, int y, float* c) {
    int row = y / 16, off = (row % 2) * 16, bx = (x + off) % 32, by = y % 16;
    bool mortar = bx < 2 || by < 2;
    float n = hash2((x + off) / 32, row, 3) * .2f;
    if (mortar) put(c, 0.62f, 0.6f, 0.56f); else put(c, 0.62f + n, 0.25f + n * .5f, 0.18f + n * .3f);
}
void tMadera(int x, int y, float* c) { float n = fbm(x / 40.f, y / 4.f, 5); put(c, 0.45f + n * .3f, 0.28f + n * .2f, 0.14f + n * .1f); }
void tPasto(int x, int y, float* c) { float n = fbm(x / 6.f, y / 6.f, 7); put(c, 0.2f + n * .15f, 0.5f + n * .3f, 0.18f + n * .1f); }
void tArena(int x, int y, float* c) { float n = fbm(x / 5.f, y / 5.f, 9); put(c, 0.8f + n * .15f, 0.7f + n * .15f, 0.45f + n * .1f); }
void tMetal(int x, int y, float* c) { float n = fbm(x / 30.f, y / 3.f, 11); bool rv = (x % 32 < 3 || y % 32 < 2); put(c, 0.42f + n * .2f - rv * .1f, 0.44f + n * .2f - rv * .1f, 0.48f + n * .2f - rv * .1f); }
void tOxido(int x, int y, float* c) { float n = fbm(x / 8.f, y / 8.f, 13); put(c, 0.45f + n * .4f, 0.2f + n * .2f, 0.1f + n * .05f); }
void tAzulejo(int x, int y, float* c) { bool g = x % 32 < 2 || y % 32 < 2; float n = fbm(x / 20.f, y / 20.f, 15) * .08f; if (g) put(c, 0.55f, 0.58f, 0.55f); else put(c, 0.82f + n, 0.9f + n, 0.88f + n); }
void tAlfombra(int x, int y, float* c) { float n = hash2(x, y, 17) * .08f; bool d = ((x / 16) + (y / 16)) % 2; put(c, (d ? 0.5f : 0.38f) + n, 0.1f + n, 0.12f + n); }
void tSangre(int x, int y, float* c) { float n = fbm(x / 10.f, y / 10.f, 19); if (n > 0.55f) put(c, 0.45f, 0.02f, 0.03f); else put(c, 0.32f + n * .2f, 0.3f + n * .2f, 0.3f + n * .2f); }
void tAsfalto(int x, int y, float* c) { float n = hash2(x, y, 21) * .1f; put(c, 0.2f + n, 0.2f + n, 0.22f + n); if (x > 60 && x < 68 && (y / 16) % 2 == 0) put(c, 0.9f, 0.85f, 0.2f); }
void tDamero(int x, int y, float* c) { bool d = ((x / 16) + (y / 16)) % 2; float n = hash2(x, y, 23) * .05f; put(c, (d ? 0.9f : 0.12f) + n, (d ? 0.9f : 0.12f) + n, (d ? 0.9f : 0.12f) + n); }
void tPapel(int x, int y, float* c) { bool s = (x / 8) % 2; float n = fbm(x / 20.f, y / 20.f, 25) * .1f; put(c, (s ? 0.55f : 0.5f) + n, (s ? 0.5f : 0.42f) + n, (s ? 0.35f : 0.3f) + n); }
void tNieve(int x, int y, float* c) { float n = fbm(x / 9.f, y / 9.f, 27) * .12f; put(c, 0.9f + n, 0.93f + n, 0.97f); }
void tRoca(int x, int y, float* c) { float n = fbm(x / 14.f, y / 14.f, 29); put(c, 0.35f + n * .3f, 0.33f + n * .28f, 0.3f + n * .25f); }
void tCesped2(int x, int y, float* c) { float n = fbm(x / 3.f, y / 10.f, 31); put(c, 0.12f + n * .2f, 0.35f + n * .35f, 0.1f); }
void tEstrellas(int x, int y, float* c) {   // pared morada con estrellas (camaras del escenario)
    float n = fbm(x / 20.f, y / 20.f, 41);
    put(c, 0.28f + n * .15f, 0.1f + n * .08f, 0.42f + n * .2f);
    int gx = x / 16, gy = y / 16;
    float hsh = hash2(gx, gy, 77);
    if (hsh > 0.78f) {
        float cx = gx * 16 + 4 + hash2(gx, gy, 5) * 8, cy = gy * 16 + 4 + hash2(gx, gy, 9) * 8;
        float d = std::fabs(x - cx) + std::fabs(y - cy);
        if (d < 4.5f) put(c, 0.95f, 0.85f, 0.4f);
    }
    if ((x / 32) % 2 == 0 && (y % 64) < 2) put(c, 0.2f, 0.07f, 0.3f);
}
void tOficina(int x, int y, float* c) {   // pared gris de oficina oscura con zocalo
    float n = fbm(x / 18.f, y / 18.f, 51);
    float g = 0.34f + n * .16f;
    if (y > 200) g *= 0.65f;
    if (y > 196 && y < 202) g = 0.12f;
    put(c, g, g * 1.02f, g * 1.06f);
}
struct TexDef { const char* name; TexFn fn; };
const TexDef kTex[] = {{"lib_tex_concreto.png", tConcreto}, {"lib_tex_ladrillo.png", tLadrillo}, {"lib_tex_madera.png", tMadera}, {"lib_tex_pasto.png", tPasto},
                       {"lib_tex_arena.png", tArena}, {"lib_tex_metal.png", tMetal}, {"lib_tex_oxido.png", tOxido}, {"lib_tex_azulejo.png", tAzulejo},
                       {"lib_tex_alfombra.png", tAlfombra}, {"lib_tex_sangre.png", tSangre}, {"lib_tex_asfalto.png", tAsfalto}, {"lib_tex_damero.png", tDamero},
                       {"lib_tex_papel_pared.png", tPapel}, {"lib_tex_nieve.png", tNieve}, {"lib_tex_roca.png", tRoca}, {"lib_tex_cesped_oscuro.png", tCesped2}, {"lib_tex_estrellas.png", tEstrellas}, {"lib_tex_oficina.png", tOficina}};


// sprites 2D (dibujos con formas) con fondo transparente
bool inC(float x, float y, float cx, float cy, float r) { return (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r; }
bool inE(float x, float y, float cx, float cy, float rx, float ry) { float a = (x - cx) / rx, b = (y - cy) / ry; return a * a + b * b <= 1.f; }
void sOso(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.25f, 0.17f, 0.11f) || inC(x, y, 0.75f, 0.17f, 0.11f)) set(100, 60, 30);
    if (inC(x, y, 0.25f, 0.17f, 0.06f) || inC(x, y, 0.75f, 0.17f, 0.06f)) set(60, 35, 20);
    if (inE(x, y, 0.5f, 0.45f, 0.38f, 0.33f)) set(120, 75, 40);
    if (inE(x, y, 0.5f, 0.58f, 0.2f, 0.15f)) set(205, 165, 115);
    if (inE(x, y, 0.5f, 0.5f, 0.07f, 0.04f)) set(15, 15, 15);
    if (inC(x, y, 0.33f, 0.37f, 0.08f) || inC(x, y, 0.67f, 0.37f, 0.08f)) set(240, 240, 240);
    if (inC(x, y, 0.33f, 0.38f, 0.035f) || inC(x, y, 0.67f, 0.38f, 0.035f)) set(10, 10, 10);
    if (y > 0.63f && y < 0.655f && x > 0.4f && x < 0.6f) set(20, 10, 10);
    if (y > 0.76f && y < 0.95f && x > 0.2f && x < 0.8f) set(120, 75, 40);
    if (y > 0.78f && y < 0.88f && x > 0.4f && x < 0.6f) set(40, 80, 200);
    memcpy(c, col, 4);
}
void sOjos(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t v = 0;
    if (inE(x, y, 0.25f, 0.5f, 0.2f, 0.12f) || inE(x, y, 0.75f, 0.5f, 0.2f, 0.12f)) v = 255;
    c[0] = 255; c[1] = 255; c[2] = 230; c[3] = v;
}
void sConejo(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inE(x, y, 0.34f, 0.13f, 0.07f, 0.17f) || inE(x, y, 0.66f, 0.13f, 0.07f, 0.17f)) set(130, 70, 170);
    if (inE(x, y, 0.34f, 0.14f, 0.035f, 0.12f) || inE(x, y, 0.66f, 0.14f, 0.035f, 0.12f)) set(240, 150, 200);
    if (inE(x, y, 0.5f, 0.5f, 0.36f, 0.3f)) set(130, 70, 170);
    if (inE(x, y, 0.5f, 0.62f, 0.2f, 0.13f)) set(220, 200, 235);
    if (inE(x, y, 0.5f, 0.54f, 0.06f, 0.035f)) set(15, 15, 15);
    if (inC(x, y, 0.34f, 0.42f, 0.08f) || inC(x, y, 0.66f, 0.42f, 0.08f)) set(245, 245, 245);
    if (inC(x, y, 0.34f, 0.43f, 0.035f) || inC(x, y, 0.66f, 0.43f, 0.035f)) set(200, 20, 20);
    if (y > 0.7f && y < 0.74f && x > 0.4f && x < 0.6f) set(20, 10, 10);
    if (y > 0.8f && y < 0.97f && x > 0.22f && x < 0.78f) set(130, 70, 170);
    if (y > 0.82f && y < 0.9f && x > 0.4f && x < 0.6f) set(240, 130, 190);
    memcpy(c, col, 4);
}
void sPajaro(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inE(x, y, 0.45f, 0.52f, 0.36f, 0.3f)) set(250, 210, 50);
    if (inE(x, y, 0.4f, 0.6f, 0.2f, 0.12f)) set(255, 240, 150);
    if (inE(x, y, 0.3f, 0.55f, 0.16f, 0.1f)) set(235, 150, 40);
    if (inE(x, y, 0.88f, 0.55f, 0.12f, 0.07f)) set(245, 110, 30);
    if (inC(x, y, 0.65f, 0.4f, 0.1f)) set(255, 255, 255);
    if (inC(x, y, 0.68f, 0.41f, 0.045f)) set(10, 10, 10);
    memcpy(c, col, 4);
}
void sFruta(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.35f, 0.58f, 0.27f) || inC(x, y, 0.65f, 0.58f, 0.27f)) set(210, 30, 40);
    if (inC(x, y, 0.3f, 0.5f, 0.07f)) set(255, 130, 130);
    if (x > 0.48f && x < 0.52f && y > 0.12f && y < 0.38f) set(100, 60, 30);
    if (inE(x, y, 0.62f, 0.2f, 0.14f, 0.06f)) set(60, 170, 60);
    memcpy(c, col, 4);
}
void sMoneda2(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.5f, 0.5f, 0.42f)) set(200, 150, 20);
    if (inC(x, y, 0.5f, 0.5f, 0.35f)) set(250, 210, 60);
    if (x > 0.46f && x < 0.54f && y > 0.28f && y < 0.72f) set(200, 150, 20);
    memcpy(c, col, 4);
}
void sTuberia(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    float sh = 0.75f + 0.25f * std::sin(x * 6.28f * 1.2f + 0.8f);
    bool lip = y < 0.1f;
    float k = lip ? 1.1f : 1.f;
    c[0] = (uint8_t)std::min(255.f, 70 * sh * k); c[1] = (uint8_t)std::min(255.f, 190 * sh * k); c[2] = (uint8_t)std::min(255.f, 60 * sh * k); c[3] = 255;
    if (y > 0.095f && y < 0.115f) { c[0] = c[1] = c[2] = 20; }
    if (x < 0.03f || x > 0.97f) { c[0] = c[1] = c[2] = 20; }
}
void sBoton(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    uint8_t col[4] = {0, 0, 0, 0};
    auto set = [&](int r, int g, int b) { col[0] = (uint8_t)r; col[1] = (uint8_t)g; col[2] = (uint8_t)b; col[3] = 255; };
    if (inC(x, y, 0.5f, 0.55f, 0.46f)) set(150, 30, 30);
    if (inC(x, y, 0.5f, 0.5f, 0.42f)) set(235, 60, 60);
    if (inC(x, y, 0.42f, 0.36f, 0.14f)) set(255, 150, 150);
    memcpy(c, col, 4);
}

// ------------------------------------------------------------ v10.7: sprites pixel-art (16x16 ampliados a 128)
void pixPut(const char* const* R, int xi, int yi, uint8_t* c, char from = 0, char to = 0, char from2 = 0, char to2 = 0) {
    int gx = xi * 16 / 128, gy = yi * 16 / 128;
    const char* row = R[gy];
    char ch = gx < (int)strlen(row) ? row[gx] : '.';
    if (ch == from) ch = to; else if (ch == from2) ch = to2;
    static const struct { char k; uint8_t r, g, b; } pal[] = {
        {'k', 20, 20, 28}, {'w', 250, 250, 250}, {'r', 220, 50, 40}, {'R', 140, 30, 30}, {'o', 245, 140, 40}, {'y', 252, 218, 70}, {'Y', 205, 150, 30},
        {'g', 90, 200, 80}, {'G', 30, 120, 50}, {'b', 70, 125, 235}, {'B', 30, 60, 140}, {'n', 150, 90, 45}, {'N', 95, 55, 28}, {'t', 225, 185, 135},
        {'s', 242, 200, 168}, {'a', 160, 165, 175}, {'A', 85, 90, 102}, {'c', 110, 215, 235}, {'p', 240, 130, 190}, {'l', 100, 120, 60}, {'L', 60, 78, 40}};
    c[0] = c[1] = c[2] = c[3] = 0;
    if (ch == '.' || ch == ' ') return;
    for (auto& e : pal) if (e.k == ch) { c[0] = e.r; c[1] = e.g; c[2] = e.b; c[3] = 255; return; }
}
#define PIXSPR(NAME, ...) void NAME(int x, int y, uint8_t* c) { static const char* const R[16] = {__VA_ARGS__}; pixPut(R, x, y, c); }
PIXSPR(sHeroePix, ".....oooo.......", "....oooooooo....", "....nnnssnns....", "...nsnsssnsss...", "...nsnnsssnsss..", "....nsssssnnn...", ".....ssssss.....", "...bbbobbbb.....",
       "..bbbbobbobbb...", ".bbbbbooooobbb..", ".ssbboyoyobbss..", ".sssooooooosss..", "..sooooooooos...", "...ooo...ooo....", "..nnnn...nnnn...", ".nnnnn...nnnnn..")
PIXSPR(sBichoPix, "................", "................", ".....nnnnnn.....", "...nnnnnnnnnn...", "..nnnnnnnnnnnn..", ".nnnwwwnnnnwwwn.", ".nnnwkwNNNNwkwn.", "nnnnnnnNNNNnnnnn",
       "nnnnnnnnnnnnnnnn", ".nnnnttttttnnnn.", "..nnttttttttnn..", "...tttttttttt...", "....tttttttt....", "..kkkk....kkkk..", ".kkkkkk..kkkkkk.", "................")
PIXSPR(sLadrilloPix, "NNNNNNNNNNNNNNNN", "nnnnnnnNnnnnnnnN", "nnnnnnnNnnnnnnnN", "nnnnnnnNnnnnnnnN", "NNNNNNNNNNNNNNNN", "nnnNnnnnnnnNnnnn", "nnnNnnnnnnnNnnnn", "nnnNnnnnnnnNnnnn",
       "NNNNNNNNNNNNNNNN", "nnnnnnnNnnnnnnnN", "nnnnnnnNnnnnnnnN", "nnnnnnnNnnnnnnnN", "NNNNNNNNNNNNNNNN", "nnnNnnnnnnnNnnnn", "nnnNnnnnnnnNnnnn", "nnnNnnnnnnnNnnnn")
PIXSPR(sBloqueQ, "kkkkkkkkkkkkkkkk", "kyyyyyyyyyyyyyYk", "kyyyyykkkkyyyyYk", "kyyyykkyykkyyyYk", "kyyyykkyykkyyyYk", "kyyyyyyyykkyyyYk", "kyyyyyyykkyyyyYk", "kyyyyyykkyyyyyYk",
       "kyyyyyykkyyyyyYk", "kyyyyyyyyyyyyyYk", "kyyyyyykkyyyyyYk", "kyyyyyykkyyyyyYk", "kyyyyyyyyyyyyyYk", "kyyyyyyyyyyyyyYk", "kYYYYYYYYYYYYYYk", "kkkkkkkkkkkkkkkk")
PIXSPR(sTuboTapa, "kkkkkkkkkkkkkkkk", "kgggwwgggggGGGGk", "kgggwwgggggGGGGk", "kgggwwgggggGGGGk", "kgggwwgggggGGGGk", "kkkkkkkkkkkkkkkk", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.",
       ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.")
PIXSPR(sTuboCuerpo, ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.",
       ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.", ".kgggwwggggGGGk.")
PIXSPR(sNubePix, "................", "................", "................", "................", "......wwww......", "....wwwwwwww....", "..wwwwwwwwwwww..", ".wwwwwwwwwwwwwa.",
       "wwwwwwwwwwwwwwaa", ".aaaaaaaaaaaaaa.", "................", "................", "................", "................", "................", "................")
PIXSPR(sArbustoPix, "................", "................", "................", "................", "................", "................", "................", "......gggg......",
       "....gggggggg....", "..GggggggggggG..", ".GgggggGggggggG.", "GgggGgggggGggggG", "GggggggggggggggG", "GGGGGGGGGGGGGGGG", "................", "................")
PIXSPR(sMonedaPix, "................", ".....kkkkkk.....", "....kyyyyyyk....", "...kyywyyyyYk...", "..kyywyyoyyyYk..", "..kyywyyoyyyYk..", "..kyywyyoyyyYk..", "..kyywyyoyyyYk..",
       "..kyywyyoyyyYk..", "..kyywyyoyyyYk..", "..kyyyyyoyyyYk..", "...kyyyyyyyYk...", "....kYYYYYYk....", ".....kkkkkk.....", "................", "................")
PIXSPR(sPajaroPix, "................", "................", "......kkkkkk....", "....kkyyyyykk...", "...kyyyyyykwwk..", "..kyyyyyyykwkwk.", "..kyyyyyyykwwwk.", ".kkyyyyyyyykkkkk",
       ".kwwwyyyyykrrrrk", ".kwwwwyyyyykrrrk", "..kwwwyyyyykkkk.", "...kkyyyyyyyk...", "....kkyyyyykk...", "......kkkkkk....", "................", "................")
PIXSPR(sCiudadPix, "................", "................", "..........aa....", "....aa....aa..aa", "....aa..aaaa..aa", "aa..aaaaaaaa.aaa", "aa..aaacaaaaaaaa", "aaaaaaaaaaacaaaa",
       "aacaaaaaacaaaaca", "aaaaacaaaaaaaaaa", "acaaaaaaacaaaaaa", "aaaaaaacaaaacaaa", "aaacaaaaaaaaaaaa", "aaaaaaaaaacaaaca", "aaaaaaaaaaaaaaaa", "aaaaaaaaaaaaaaaa")
PIXSPR(sSoldadoPix, "......LLLL......", ".....LlllLL.....", ".....LllllLL....", ".....ssssss.....", ".....sksssss....", ".....sssssss....", "....lllllllllaaa", "...lllllllsaaaAA",
       "...lllllllaaAAAA", "...lllllll.aA...", "...lnnnnnl......", "....lll.lll.....", "....lll.lll.....", "....lll..ll.....", "...kkkk..kkk....", "...kkkk..kkkk...")
void sSoldadoEnPix(int x, int y, uint8_t* c) { static const char* const R[16] = {"......RRRR......", ".....RrrrRR.....", ".....RrrrrRR....", ".....ssssss.....", ".....sksssss....", ".....sssssss....", "....rrrrrrrrraaa", "...rrrrrrrsaaaAA",
       "...rrrrrrraaAAAA", "...rrrrrrr.aA...", "...rNNNNNr......", "....rrr.rrr.....", "....rrr.rrr.....", "....rrr..rr.....", "...kkkk..kkk....", "...kkkk..kkkk..."}; pixPut(R, x, y, c); }
PIXSPR(sTanquePix, "................", "................", "................", "........LLLL....", ".......LllllL...", "......LlllllLaaa", ".....LlllllllLaA", "...LLLLLLLLLLLaA",
       "..LllllllllllLL.", "..LllllllllllllL", ".AAAAAAAAAAAAAA.", "AakkakkakkakkakA", "AkaakaakaakaakaA", ".AkkAkkAkkAkkAA.", "..AAAAAAAAAAAA..", "................")
PIXSPR(sPuentePix, "nnnnnnnnnnnnnnnn", "NNNNNNNNNNNNNNNN", "AaaAaaAaaAaaAaaA", "aAaaaAaaaAaaaAaa", "aaAaaaAaaaAaaaAa", "AaaAaaAaaAaaAaaA", "................", "................", "................", "................", "................", "................", "................", "................", "................", "................")
PIXSPR(sLuchadorPixA, "......kkkk......", ".....kkkkkk.....", ".....ssssss.....", ".....sksssss....", "......ssss......", "....rrrrrrrr....", "...rrrrrrrrrs...", "..ssrrrrrrr.ss..",
       "..ss.rrrrr..ss..", "......kkkk......", "....bbbbbbbb....", "....bbb..bbb....", "....bbb..bbb....", "....bbb..bbb....", "...kkkk..kkkk...", "...kkkk..kkkk...")
void sLuchadorPixB(int x, int y, uint8_t* c) { static const char* const R[16] = {"......nnnn......", ".....nnnnnn.....", ".....tttttt.....", ".....tkttttt....", "......tttt......", "....bbbbbbbb....", "...bbbbbbbbbt...", "..ttbbbbbbb.tt..",
       "..tt.bbbbb..tt..", "......kkkk......", "....AAAAAAAA....", "....AAA..AAA....", "....AAA..AAA....", "....AAA..AAA....", "...kkkk..kkkk...", "...kkkk..kkkk..."}; pixPut(R, x, y, c); }
void sExplosion(int xi, int yi, uint8_t* c) {
    float x = xi / 128.f, y = yi / 128.f;
    c[0] = c[1] = c[2] = c[3] = 0;
    auto set = [&](int r, int g, int b) { c[0] = (uint8_t)r; c[1] = (uint8_t)g; c[2] = (uint8_t)b; c[3] = 255; };
    float dx = x - 0.5f, dy = y - 0.5f, d = std::sqrt(dx * dx + dy * dy), a = std::atan2(dy, dx);
    float spike = 0.34f + 0.12f * std::sin(a * 7.f) + 0.05f * std::sin(a * 13.f);
    if (d < spike) set(230, 70, 30);
    if (d < spike * 0.72f) set(250, 150, 40);
    if (d < spike * 0.45f) set(255, 225, 90);
    if (d < spike * 0.2f) set(255, 255, 230);
}
struct SprDef { const char* name; void (*fn)(int, int, uint8_t*); };
const SprDef kSpr[] = {{"lib_spr_oso.png", sOso}, {"lib_spr_ojos.png", sOjos}, {"lib_spr_conejo.png", sConejo}, {"lib_spr_pajaro.png", sPajaro}, {"lib_spr_fruta.png", sFruta},
                       {"lib_spr_moneda.png", sMoneda2}, {"lib_spr_tuberia.png", sTuberia}, {"lib_spr_boton.png", sBoton},
                       {"lib_spr_pix_heroe.png", sHeroePix}, {"lib_spr_pix_bicho.png", sBichoPix}, {"lib_spr_pix_ladrillo.png", sLadrilloPix}, {"lib_spr_pix_bloque.png", sBloqueQ}, {"lib_spr_pix_tubo_tapa.png", sTuboTapa},
                       {"lib_spr_pix_tubo.png", sTuboCuerpo}, {"lib_spr_pix_nube.png", sNubePix}, {"lib_spr_pix_arbusto.png", sArbustoPix}, {"lib_spr_pix_moneda.png", sMonedaPix}, {"lib_spr_pix_pajaro.png", sPajaroPix},
                       {"lib_spr_pix_ciudad.png", sCiudadPix}, {"lib_spr_pix_soldado.png", sSoldadoPix}, {"lib_spr_pix_soldado_enemigo.png", sSoldadoEnPix}, {"lib_spr_pix_tanque.png", sTanquePix},
                       {"lib_spr_pix_puente.png", sPuentePix}, {"lib_spr_pix_luchador_rojo.png", sLuchadorPixA}, {"lib_spr_pix_luchador_azul.png", sLuchadorPixB}, {"lib_spr_explosion.png", sExplosion}};

// ------------------------------------------------------------ musica (bucles cortos hechos por codigo)
const int kRate = 22050;
std::vector<uint8_t> wavOf(const std::vector<float>& s) {
    std::vector<uint8_t> o(44 + s.size() * 2);
    auto w32 = [&](size_t p, uint32_t v) { for (int i = 0; i < 4; i++) o[p + i] = (uint8_t)(v >> (8 * i)); };
    auto w16 = [&](size_t p, uint16_t v) { o[p] = (uint8_t)v; o[p + 1] = (uint8_t)(v >> 8); };
    memcpy(&o[0], "RIFF", 4); w32(4, (uint32_t)(36 + s.size() * 2)); memcpy(&o[8], "WAVEfmt ", 8);
    w32(16, 16); w16(20, 1); w16(22, 1); w32(24, kRate); w32(28, kRate * 2); w16(32, 2); w16(34, 16);
    memcpy(&o[36], "data", 4); w32(40, (uint32_t)(s.size() * 2));
    for (size_t i = 0; i < s.size(); i++) { float v = std::max(-1.f, std::min(1.f, s[i])); w16(44 + i * 2, (uint16_t)(int16_t)(v * 30000.f)); }
    return o;
}
float hz(int semis) { return 110.f * std::pow(2.f, semis / 12.f); }
// notas: arreglo de semitonos por paso (-99 = silencio); bpm; ondas: 0 seno, 1 cuadrada suave, 2 sierra
std::vector<float> secuencia(const int* notes, int n, float bpm, int wave, float vol, int octave, int repeat, float decay) {
    float step = 60.f / bpm / 2.f;
    size_t len = (size_t)(step * n * kRate);
    std::vector<float> o(len * repeat, 0.f);
    for (int r = 0; r < repeat; r++)
        for (int i = 0; i < n; i++) {
            if (notes[i] < -50) continue;
            float f = hz(notes[i] + 12 * octave);
            size_t st = r * len + (size_t)(i * step * kRate), nl = (size_t)(step * kRate * 1.2f);
            for (size_t k = 0; k < nl && st + k < o.size(); k++) {
                float t = (float)k / kRate, ph = 6.2831853f * f * t, s;
                if (wave == 0) s = std::sin(ph);
                else if (wave == 1) s = std::tanh(3.f * std::sin(ph)) * 0.8f;
                else s = 2.f * (f * t - std::floor(f * t + 0.5f));
                o[st + k] += s * vol * std::exp(-t * decay) * std::min(1.f, t * 200.f);
            }
        }
    return o;
}
void mix(std::vector<float>& a, const std::vector<float>& b) { if (b.size() > a.size()) a.resize(b.size(), 0.f); for (size_t i = 0; i < b.size(); i++) a[i] += b[i]; }
std::vector<uint8_t> musica(const std::string& n) {
    std::vector<float> o;
    if (n == "lib_musica_accion") {
        int bass[16] = {0, 0, 7, 0, 0, 0, 5, 3, 0, 0, 7, 0, 10, 8, 7, 5};
        int lead[16] = {12, -99, 15, -99, 19, -99, 15, 12, 12, -99, 15, 17, 19, -99, 17, 15};
        o = secuencia(bass, 16, 150, 2, 0.18f, -1, 2, 6.f);
        mix(o, secuencia(lead, 16, 150, 1, 0.12f, 0, 2, 5.f));
    } else if (n == "lib_musica_terror") {
        int pad[8] = {0, -99, -99, -99, 1, -99, -99, -99};
        int hi[16] = {-99, -99, -99, -99, -99, -99, 18, -99, -99, -99, -99, -99, -99, -99, -99, 19};
        o = secuencia(pad, 8, 50, 2, 0.22f, -1, 3, 0.6f);
        mix(o, secuencia(hi, 16, 50, 0, 0.1f, 1, 2, 2.f));
    } else if (n == "lib_musica_carrera") {
        int bass[16] = {0, 0, 12, 0, 0, 0, 12, 0, 5, 5, 17, 5, 7, 7, 19, 7};
        int lead[16] = {19, 22, 24, 22, 19, 22, 24, 26, 24, 22, 19, 17, 19, -99, 22, -99};
        o = secuencia(bass, 16, 170, 2, 0.16f, -1, 2, 7.f);
        mix(o, secuencia(lead, 16, 170, 1, 0.1f, 0, 2, 4.f));
    } else if (n == "lib_musica_pelea") {
        int bass[16] = {0, 0, -99, 0, 3, -99, 3, 0, 0, 0, -99, 0, 5, -99, 7, 3};
        int lead[16] = {12, -99, 12, 15, -99, 17, -99, 15, 12, -99, 10, 12, -99, 15, 19, -99};
        o = secuencia(bass, 16, 160, 2, 0.2f, -1, 2, 7.f);
        mix(o, secuencia(lead, 16, 160, 1, 0.12f, 0, 2, 6.f));
    } else if (n == "lib_musica_casual") {
        int a[16] = {0, 4, 7, 4, 2, 5, 9, 5, 4, 7, 12, 7, 5, 9, 12, 9};
        int b[8] = {0, -99, -99, -99, 5, -99, -99, -99};
        o = secuencia(a, 16, 125, 1, 0.16f, 1, 2, 4.f);
        mix(o, secuencia(b, 8, 125, 0, 0.14f, -1, 3, 1.5f));
    } else {  // aventura
        int a[16] = {0, 4, 7, 12, 7, 4, 0, 4, 5, 9, 12, 17, 12, 9, 5, 9};
        int b[8] = {0, -99, 5, -99, 7, -99, 5, -99};
        o = secuencia(a, 16, 110, 0, 0.2f, 1, 2, 3.f);
        mix(o, secuencia(b, 8, 110, 1, 0.12f, -1, 4, 1.5f));
    }
    for (auto& v : o) v *= 0.8f;
    return wavOf(o);
}
std::vector<uint8_t> efecto(const std::string& n) {
    std::vector<float> o;
    uint32_t s = 12345;
    auto rnd = [&]() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return (float)(s & 0xffff) / 32768.f - 1.f; };
    if (n == "lib_motor") {
        o.assign(kRate * 2, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = 0.25f * (2.f * (std::fmod(55.f * t, 1.f)) - 1.f) + 0.1f * std::sin(6.28f * 110.f * t) + 0.04f * rnd(); }
    } else if (n == "lib_rugido") {
        o.assign(kRate, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, e = std::exp(-t * 2.5f) * std::min(1.f, t * 30.f); o[i] = e * (0.4f * (2.f * std::fmod((90.f - 40.f * t) * t, 1.f) - 1.f) + 0.25f * rnd()); }
    } else if (n == "lib_susto") {
        o.assign((size_t)(kRate * 1.2f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, e = std::exp(-t * 3.f); o[i] = e * (0.5f * rnd() + 0.3f * std::sin(6.28f * (800.f + 300.f * std::sin(t * 40.f)) * t)); }
    } else if (n == "lib_golpe") {
        o.assign((size_t)(kRate * 0.25f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 16.f) * (0.6f * rnd() + 0.7f * std::sin(6.28f * (150.f - 300.f * t) * t)); }
    } else if (n == "lib_puerta") {
        o.assign((size_t)(kRate * 0.6f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 7.f) * (0.35f * rnd() + 0.45f * std::sin(6.28f * 190.f * t) + 0.3f * std::sin(6.28f * 421.f * t)); }
    } else if (n == "lib_espadazo") {
        o.assign((size_t)(kRate * 0.3f), 0.f);
        float lp = 0.f;
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; lp += (rnd() - lp) * (0.1f + 1.2f * t); o[i] = lp * std::sin(3.14f * t / 0.3f) * 1.4f; }
    } else if (n == "lib_moneda") {
        o.assign((size_t)(kRate * 0.4f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate, f = t < 0.08f ? 988.f : 1319.f; o[i] = std::exp(-t * 7.f) * 0.5f * (std::fmod(f * t, 1.f) < 0.5f ? 1.f : -1.f); }
    } else if (n == "lib_campana") {
        o.assign((size_t)(kRate * 2.5f), 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = std::exp(-t * 1.6f) * (0.4f * std::sin(6.28f * 523.f * t) + 0.25f * std::sin(6.28f * 1318.f * t) + 0.15f * std::sin(6.28f * 1760.f * t)); }
    } else {  // ambiente de terror
        o.assign(kRate * 6, 0.f);
        for (size_t i = 0; i < o.size(); i++) { float t = (float)i / kRate; o[i] = 0.12f * std::sin(6.28f * 55.f * t) * (0.6f + 0.4f * std::sin(t * 1.05f)) + 0.08f * std::sin(6.28f * 58.f * t) + 0.02f * rnd(); }
    }
    return wavOf(o);
}
const char* kSounds[] = {"lib_musica_accion", "lib_musica_terror", "lib_musica_carrera", "lib_musica_aventura", "lib_motor", "lib_rugido", "lib_susto", "lib_ambiente_terror", "lib_golpe", "lib_puerta", "lib_espadazo", "lib_moneda", "lib_campana", "lib_musica_pelea", "lib_musica_casual"};
}  // namespace

const std::vector<LibItem>& libraryItems() {
    static std::vector<LibItem> v = [] {
        std::vector<LibItem> r;
        for (auto& m : kModels) r.push_back({m.name, 2});
        for (int i = 0; i < kPackModelCount; i++) r.push_back({kPackModels[i], 2});   // armas, piezas y maniquí animado
        for (auto& t : kTex) r.push_back({t.name, 0});
        for (auto& t : kSpr) r.push_back({t.name, 0});
        for (auto s : kSounds) r.push_back({std::string(s) + ".wav", 1});
        return r;
    }();
    return v;
}
bool libraryHas(const std::string& name) {
    for (auto& i : libraryItems()) if (i.name == name) return true;
    return false;
}
static std::string lowerStr(std::string s) { for (auto& c : s) c = (char)tolower((unsigned char)c); return s; }
static const ResMap& packFiles() {
    static ResMap r = [] { ResMap m; std::string e; unzipAll(std::vector<uint8_t>(kPackZip, kPackZip + kPackZipLen), m, e); return m; }();
    return r;
}
static bool isPackModel(const std::string& name) {
    for (int i = 0; i < kPackModelCount; i++) if (name == kPackModels[i]) return true;
    return false;
}
static std::vector<uint8_t> fixWinding(const std::vector<uint8_t>& src) {
    ModelData md;
    if (!modelRead(src.data(), src.size(), md) || md.v.empty() || md.idx.size() < 3) return src;
    std::vector<uint32_t> out;
    out.reserve(md.idx.size());
    bool changed = false;
    for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
        uint32_t i0 = md.idx[t], i1 = md.idx[t + 1], i2 = md.idx[t + 2];
        if (i0 * 8 + 7 >= md.v.size() || i1 * 8 + 7 >= md.v.size() || i2 * 8 + 7 >= md.v.size()) return src;
        const float *a = &md.v[i0 * 8], *b = &md.v[i1 * 8], *c = &md.v[i2 * 8];
        float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float d = nx * a[3] + ny * a[4] + nz * a[5];
        if (d > 0) { out.insert(out.end(), {i0, i1, i2}); continue; }
        changed = true;
        if (d < 0) out.insert(out.end(), {i0, i2, i1});   // al reves: se voltea
        // d == 0: degenerado, se descarta
    }
    if (!changed || out.empty()) return src;
    md.idx = out;
    std::vector<uint8_t> dst;
    return modelWrite(md, dst) ? dst : src;
}
bool libraryAdd(const std::string& name, Files& assets) {
    if (assets.count(name)) return true;
    if (isPackModel(name)) {   // modelo del paquete + su textura (+ esqueleto y animaciones si trae)
        const ResMap& pk = packFiles();
        auto it = pk.find(lowerStr(name));
        if (it == pk.end()) return false;
        assets[name] = fixWinding(it->second);
        ModelData md;
        if (modelRead(it->second.data(), it->second.size(), md) && !md.tex.empty() && !assets.count(md.tex)) {
            auto t = pk.find(lowerStr(md.tex));
            if (t != pk.end()) assets[md.tex] = t->second;
        }
        std::string rig = name.substr(0, name.size() - 5) + ".fanim";
        auto r = pk.find(lowerStr(rig));
        if (r != pk.end()) assets[rig] = r->second;
        return true;
    }
    for (auto& m : kModels)
        if (name == m.name) {
            std::vector<uint8_t> b;
            if (!buildModel(m.fn(), b)) return false;
            assets[name] = b;
            if (!assets.count("lib_paleta.png")) assets["lib_paleta.png"] = paletteTex();
            return true;
        }
    for (auto& t : kTex)
        if (name == t.name) {
            std::vector<uint8_t> px(T * T * 4);
            for (int y = 0; y < T; y++)
                for (int x = 0; x < T; x++) {
                    float c[3];
                    t.fn(x, y, c);
                    for (int k = 0; k < 3; k++) px[(y * T + x) * 4 + k] = (uint8_t)std::max(0.f, std::min(255.f, c[k] * 255.f));
                    px[(y * T + x) * 4 + 3] = 255;
                }
            assets[name] = toPng(px, T, T);
            return true;
        }
    for (auto& t : kSpr)
        if (name == t.name) {
            std::vector<uint8_t> px(T * T * 4);
            for (int y = 0; y < T; y++)
                for (int x = 0; x < T; x++) t.fn(x, y, &px[(y * T + x) * 4]);
            assets[name] = toPng(px, T, T);
            return true;
        }
    for (auto s : kSounds)
        if (name == std::string(s) + ".wav") {
            std::string b = s;
            assets[name] = b.compare(0, 11, "lib_musica_") == 0 ? musica(b) : efecto(b);
            return true;
        }
    return false;
}
void libraryPrune(Files& assets, const std::string& text) {
    std::vector<std::string> used;
    for (auto& a : assets) if (a.first.compare(0, 4, "lib_") == 0 && text.find(a.first) != std::string::npos) used.push_back(a.first);
    // modelos que usan otras cosas (paleta)
    bool pal = false;
    for (auto& u : used) if (u.size() > 5 && u.substr(u.size() - 5) == ".fmdl") pal = true;
    // lo que arrastran los modelos usados: su textura y su esqueleto (.fanim con el mismo nombre)
    std::vector<std::string> extra;
    for (auto& u : used)
        if (u.size() > 5 && u.substr(u.size() - 5) == ".fmdl") {
            auto a = assets.find(u);
            ModelData md;
            if (a != assets.end() && modelRead(a->second.data(), a->second.size(), md) && !md.tex.empty()) extra.push_back(md.tex);
            extra.push_back(u.substr(0, u.size() - 5) + ".fanim");
        }
    for (auto& e : extra) used.push_back(e);
    for (auto it = assets.begin(); it != assets.end();) {
        bool lib = it->first.compare(0, 4, "lib_") == 0;
        bool keep = !lib || std::find(used.begin(), used.end(), it->first) != used.end() || (it->first == "lib_paleta.png" && pal);
        if (keep) ++it; else it = assets.erase(it);
    }
}

}  // namespace forge
