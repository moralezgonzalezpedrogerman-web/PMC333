#pragma once
// Paquetes por defecto (CC0): armas Kenney, piezas KayKit y maniqui Quaternius con animaciones. Generado.
namespace forge {
extern const unsigned char kPackZip[];
extern const unsigned kPackZipLen;
extern const char* const kPackModels[];
extern const int kPackModelCount;
}
