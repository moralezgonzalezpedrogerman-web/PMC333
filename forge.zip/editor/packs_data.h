#pragma once
// Paquetes por defecto (CC0): armas Kenney, piezas KayKit y maniqui Quaternius con animaciones. Generado.
namespace forge {
extern const unsigned long long kPackZip64[];   // el zip en bloques de 8 bytes (little-endian)
extern const unsigned kPackZipLen;
extern const char* const kPackModels[];
extern const int kPackModelCount;
extern const char* const kPackImages[];   // texturas y fondos del paquete
extern const int kPackImageCount;
}
