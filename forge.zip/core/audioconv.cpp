#include "audioconv.h"
#include <cstring>

#ifdef _WIN32
#include <windows.h>
#include <mfapi.h>
#include <mfidl.h>
#include <mfreadwrite.h>
#include <shlwapi.h>
#include <propvarutil.h>
#endif

namespace forge {

std::function<bool(const std::string&, const std::vector<uint8_t>&, std::vector<uint8_t>&)>& audioConvHook() {
    static std::function<bool(const std::string&, const std::vector<uint8_t>&, std::vector<uint8_t>&)> h;
    return h;
}

static bool endsLow(const std::string& name, const char* e) {
    size_t l = strlen(e);
    if (name.size() <= l) return false;
    for (size_t i = 0; i < l; i++)
        if (tolower((unsigned char)name[name.size() - l + i]) != e[i]) return false;
    return true;
}

bool audioNeedsConversion(const std::string& name) {
    static const char* ex[] = {".m4a", ".aac", ".ogg", ".oga", ".opus", ".amr", ".3gp"};
    for (auto e : ex) if (endsLow(name, e)) return true;
    return false;
}

std::vector<uint8_t> makeWav16(const int16_t* s, size_t count, int channels, int rate) {
    std::vector<uint8_t> w(44 + count * 2);
    auto u32 = [&](size_t o, uint32_t v) { for (int i = 0; i < 4; i++) w[o + i] = (uint8_t)(v >> (8 * i)); };
    auto u16 = [&](size_t o, uint16_t v) { w[o] = (uint8_t)v; w[o + 1] = (uint8_t)(v >> 8); };
    memcpy(&w[0], "RIFF", 4); u32(4, (uint32_t)(36 + count * 2)); memcpy(&w[8], "WAVEfmt ", 8);
    u32(16, 16); u16(20, 1); u16(22, (uint16_t)channels); u32(24, (uint32_t)rate);
    u32(28, (uint32_t)(rate * channels * 2)); u16(32, (uint16_t)(channels * 2)); u16(34, 16);
    memcpy(&w[36], "data", 4); u32(40, (uint32_t)(count * 2));
    for (size_t i = 0; i < count; i++) u16(44 + i * 2, (uint16_t)s[i]);
    return w;
}

#ifdef _WIN32
// Media Foundation: se escribe el archivo en una carpeta temporal y se decodifica a PCM16.
static bool winConvert(const std::string& name, const std::vector<uint8_t>& in, std::vector<uint8_t>& out) {
    wchar_t tmpDir[MAX_PATH]; if (!GetTempPathW(MAX_PATH, tmpDir)) return false;
    size_t dot = name.find_last_of('.');
    std::wstring ext = L".m4a";
    if (dot != std::string::npos) { ext.clear(); for (size_t i = dot; i < name.size(); i++) ext.push_back((wchar_t)(unsigned char)name[i]); }
    std::wstring path = std::wstring(tmpDir) + L"forge_import_tmp" + ext;
    HANDLE f = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_TEMPORARY, nullptr);
    if (f == INVALID_HANDLE_VALUE) return false;
    DWORD wr = 0; BOOL okw = WriteFile(f, in.data(), (DWORD)in.size(), &wr, nullptr); CloseHandle(f);
    if (!okw || wr != in.size()) { DeleteFileW(path.c_str()); return false; }

    bool ok = false;
    bool comInit = SUCCEEDED(CoInitializeEx(nullptr, COINIT_MULTITHREADED));
    if (SUCCEEDED(MFStartup(MF_VERSION))) {
        IMFSourceReader* rd = nullptr;
        if (SUCCEEDED(MFCreateSourceReaderFromURL(path.c_str(), nullptr, &rd)) && rd) {
            IMFMediaType* want = nullptr;
            if (SUCCEEDED(MFCreateMediaType(&want))) {
                want->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Audio);
                want->SetGUID(MF_MT_SUBTYPE, MFAudioFormat_PCM);
                want->SetUINT32(MF_MT_AUDIO_BITS_PER_SAMPLE, 16);
                if (SUCCEEDED(rd->SetStreamSelection((DWORD)MF_SOURCE_READER_ALL_STREAMS, FALSE)) &&
                    SUCCEEDED(rd->SetStreamSelection((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, TRUE)) &&
                    SUCCEEDED(rd->SetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, nullptr, want))) {
                    IMFMediaType* got = nullptr;
                    UINT32 ch = 2, rate = 44100;
                    if (SUCCEEDED(rd->GetCurrentMediaType((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, &got)) && got) {
                        got->GetUINT32(MF_MT_AUDIO_NUM_CHANNELS, &ch);
                        got->GetUINT32(MF_MT_AUDIO_SAMPLES_PER_SECOND, &rate);
                        got->Release();
                    }
                    std::vector<int16_t> pcm;
                    for (;;) {
                        DWORD flags = 0; IMFSample* smp = nullptr;
                        if (FAILED(rd->ReadSample((DWORD)MF_SOURCE_READER_FIRST_AUDIO_STREAM, 0, nullptr, &flags, nullptr, &smp))) break;
                        if (flags & MF_SOURCE_READERF_ENDOFSTREAM) { if (smp) smp->Release(); break; }
                        if (!smp) continue;
                        IMFMediaBuffer* buf = nullptr;
                        if (SUCCEEDED(smp->ConvertToContiguousBuffer(&buf)) && buf) {
                            BYTE* p = nullptr; DWORD len = 0;
                            if (SUCCEEDED(buf->Lock(&p, nullptr, &len))) {
                                size_t n = len / 2; size_t old = pcm.size(); pcm.resize(old + n);
                                memcpy(&pcm[old], p, n * 2);
                                buf->Unlock();
                            }
                            buf->Release();
                        }
                        smp->Release();
                        if (pcm.size() > 120u * 1000u * 1000u) break;   // tope de seguridad (~10 min estéreo)
                    }
                    if (!pcm.empty() && ch >= 1 && ch <= 8) { out = makeWav16(pcm.data(), pcm.size(), (int)ch, (int)rate); ok = true; }
                }
                want->Release();
            }
            rd->Release();
        }
        MFShutdown();
    }
    if (comInit) CoUninitialize();
    DeleteFileW(path.c_str());
    return ok;
}
#endif

bool audioConvertToWav(const std::string& name, const std::vector<uint8_t>& in, std::vector<uint8_t>& out) {
    out.clear();
    if (audioConvHook()) return audioConvHook()(name, in, out) && !out.empty();
#ifdef _WIN32
    return winConvert(name, in, out);
#else
    return false;
#endif
}

}  // namespace forge
