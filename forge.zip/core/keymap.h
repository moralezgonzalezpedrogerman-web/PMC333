#pragma once
// v10.8: mapeo de teclas / mouse / control. Se guarda en el proyecto (nombres de tecla), vale para el juego exportado
// y para el test en Windows. Si una accion queda vacia se usa la tecla por defecto.
#include <string>
#include "game.h"
#include "scene.h"

namespace forge {

enum KeyAct { KA_Fwd, KA_Back, KA_Left, KA_Right, KA_Jump, KA_Sprint, KA_Crouch, KA_Reload, KA_Weapon, KA_Interact, KA_Flash, KA_Shoot, KA_Count };

const char* keyActLabel(int act);
const char* keyActDefault(int act);
// nombre <-> ImGuiKey (int). false si el nombre no existe.
bool keyFromName(const std::string& name, int& key);
const char* keyToName(int imguiKey);                    // nullptr si no es una tecla que se pueda guardar
int keyCaptureNext();                                   // devuelve el ImGuiKey recien presionado, o 0
std::string keyEffective(const Project& p, int act);    // el nombre que vale ahora (propio o por defecto)

// Suma al Input lo que hay en teclado / mouse / control. Requiere un frame de ImGui activo.
//   mouseShoot: el clic izquierdo dispara (solo cuando no hay botones virtuales)
void pollKeys(const Project& p, Input& in, bool is3d, bool mouseShoot, bool gamepad);

}  // namespace forge
