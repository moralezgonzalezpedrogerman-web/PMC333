#include "hud.h"
#include "renderer.h"
#include "imgui.h"
#include <cmath>
#include <cstdio>

namespace forge {

void drawCameraLayer(ImDrawList* dl, const Game& g, Renderer* r, int w, int h) {
    if (!g.sc) return;
    const Scene& S = *g.sc;
    float fs = ImGui::GetFontSize();
    for (auto& ov : S.overlays) {  // imagenes fijas
        if (ov.tex.empty() || !r) continue;
        unsigned id = r->textureId(g, ov.tex);
        if (!id) continue;
        float cx = ov.x * w, cy = ov.y * h, hw = ov.w * w * 0.5f, hh = ov.h * h * 0.5f;
        dl->AddImage((ImTextureID)(intptr_t)id, ImVec2(cx - hw, cy - hh), ImVec2(cx + hw, cy + hh), ImVec2(0, 1), ImVec2(1, 0),
                     IM_COL32(255, 255, 255, (int)(std::max(0.f, std::min(1.f, ov.alpha)) * 255)));
    }
    const ScreenFx& f = S.sfx;
    if (!f.any()) return;
    float t = (float)ImGui::GetTime();
    if (f.tint > 0)
        dl->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h),
                          IM_COL32((int)(f.tintC[0] * 255), (int)(f.tintC[1] * 255), (int)(f.tintC[2] * 255), (int)(std::min(1.f, f.tint) * 90)));
    if (f.scan > 0) {  // lineas de barrido
        float step = std::max(3.f, h / 160.f);
        int a = (int)(std::min(1.f, f.scan) * 85);
        for (float y = std::fmod(t * 12.f, step); y < h; y += step) dl->AddRectFilled(ImVec2(0, y), ImVec2((float)w, y + step * 0.45f), IM_COL32(0, 0, 0, a));
    }
    if (f.track > 0) {  // banda de "tracking" que sube por la pantalla
        float y = h * (1.2f - std::fmod(t * 0.18f, 1.4f));
        float bh = h * 0.07f * f.track;
        dl->AddRectFilled(ImVec2(0, y), ImVec2((float)w, y + bh), IM_COL32(255, 255, 255, (int)(20 * std::min(1.f, f.track))));
        for (int i = 0; i < 3; i++) {
            float yy = y + bh * (0.2f + 0.3f * i), off = ((std::rand() % 100) / 100.f - 0.5f) * w * 0.05f * f.track;
            dl->AddRectFilled(ImVec2(off, yy), ImVec2(off + w * 0.6f, yy + 2.f), IM_COL32(255, 255, 255, 40));
        }
    }
    if (f.noise > 0) {  // grano
        int n = (int)(std::min(1.f, f.noise) * 260);
        for (int i = 0; i < n; i++) {
            float x = (float)(std::rand() % std::max(1, w)), y = (float)(std::rand() % std::max(1, h));
            int c = 120 + std::rand() % 135;
            dl->AddRectFilled(ImVec2(x, y), ImVec2(x + 2.f + std::rand() % 6, y + 1.5f), IM_COL32(c, c, c, 40));
        }
    }
    if (f.vignette > 0) {  // bordes oscuros
        float e = std::min(w, h) * 0.35f, a = std::min(1.f, f.vignette) * 200;
        ImU32 dark = IM_COL32(0, 0, 0, (int)a), clear = IM_COL32(0, 0, 0, 0);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2((float)w, e), dark, dark, clear, clear);
        dl->AddRectFilledMultiColor(ImVec2(0, h - e), ImVec2((float)w, (float)h), clear, clear, dark, dark);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(e, (float)h), dark, clear, clear, dark);
        dl->AddRectFilledMultiColor(ImVec2(w - e, 0), ImVec2((float)w, (float)h), clear, dark, dark, clear);
    }
    if (f.rec) {  // visor de camara de video
        float m = fs * 1.6f, l = fs * 2.2f;
        ImU32 wh = IM_COL32(255, 255, 255, 220);
        float xs[2] = {m, w - m}, ys[2] = {m, h - m};
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++) {
                float dx = i ? -l : l, dy = j ? -l : l;
                dl->AddLine(ImVec2(xs[i], ys[j]), ImVec2(xs[i] + dx, ys[j]), wh, 3.f);
                dl->AddLine(ImVec2(xs[i], ys[j]), ImVec2(xs[i], ys[j] + dy), wh, 3.f);
            }
        if (std::fmod(t, 1.2f) < 0.7f) dl->AddCircleFilled(ImVec2(m + fs * 0.9f, m + fs * 1.6f), fs * 0.45f, IM_COL32(235, 40, 40, 255));
        int sec = (int)g.time;
        char buf[48];
        snprintf(buf, sizeof buf, "REC  %02d:%02d:%02d", sec / 3600, (sec / 60) % 60, sec % 60);
        dl->AddText(ImVec2(m + fs * 1.8f, m + fs * 1.05f), wh, buf);
        dl->AddText(ImVec2(m + fs * 0.4f, h - m - fs * 2.2f), wh, "PLAY ▶");
    }
}

void Hud::setup(const Project& p, int mode_) {
    mode = mode_;
    btns = p.hudDefault ? defaultHud() : p.hud;
    if (mode == 2) {   // dentro de un auto: botones de carreras + Bajar
        btns.clear();
        auto add = [&](const char* l, float x, float y, float r, HudAct a, float cr, float cg, float cb) {
            HudBtn b; b.label = l; b.x = x; b.y = y; b.r = r; b.act = a; b.color[0] = cr; b.color[1] = cg; b.color[2] = cb; btns.push_back(b);
        };
        add("Izquierda", 0.10f, 0.78f, 0.10f, HudAct::Hold, 0.5f, 0.7f, 1.f);
        add("Derecha", 0.29f, 0.78f, 0.10f, HudAct::Hold, 0.5f, 0.7f, 1.f);
        add("Acelerar", 0.89f, 0.76f, 0.12f, HudAct::Hold, 0.3f, 1.f, 0.4f);
        add("Frenar", 0.72f, 0.86f, 0.08f, HudAct::Hold, 1.f, 0.4f, 0.35f);
        add("Bajar", 0.90f, 0.28f, 0.07f, HudAct::Script, 1.f, 0.8f, 0.3f);
        st_.assign(btns.size(), St());
        joy = Joy(); ctl2d_ = p.ctl2dEff(); b2_.clear(); stickPtr_ = -1; stickX_ = stickY_ = 0;
        return;
    }
    if (p.hudDefault) {  // v8: botones extra solo si el juego tiene varias armas o recarga
        if (!p.extraWeapons.empty()) {
            HudBtn n; n.label = "ARMA"; n.x = 0.88f; n.y = 0.38f; n.r = 0.07f; n.act = HudAct::NextWeapon;
            n.color[0] = 1.f; n.color[1] = 0.8f; n.color[2] = 0.2f;
            btns.push_back(n);
        }
        if (p.player.flashlight) {
            HudBtn n; n.label = "LUZ"; n.x = 0.88f; n.y = 0.18f; n.r = 0.06f; n.act = HudAct::Flashlight;
            n.color[0] = 1.f; n.color[1] = 0.95f; n.color[2] = 0.6f;
            btns.push_back(n);
        }
        bool mag = p.weapon.magSize > 0;
        for (auto& w : p.extraWeapons) mag = mag || w.magSize > 0;
        if (mag) {
            HudBtn n; n.label = "RECARGAR"; n.x = 0.72f; n.y = 0.64f; n.r = 0.07f; n.act = HudAct::Reload;
            n.color[0] = 0.4f; n.color[1] = 1.f; n.color[2] = 0.5f;
            btns.push_back(n);
        }
    }
    if (mode == 1) { HudBtn n; n.label = "Conducir"; n.x = 0.5f; n.y = 0.80f; n.r = 0.09f; n.act = HudAct::Script; n.color[0] = 1.f; n.color[1] = 0.8f; n.color[2] = 0.2f; btns.push_back(n); }
    st_.assign(btns.size(), St());
    joy = Joy();
    ctl2d_ = p.ctl2dEff();
    b2_.clear();
    stickPtr_ = -1; stickX_ = stickY_ = 0;
    auto add = [&](const char* l, float x, float y, float r, float cr, float cg, float cb) { B2 b; b.label = l; b.x = x; b.y = y; b.r = r; b.c[0] = cr; b.c[1] = cg; b.c[2] = cb; b2_.push_back(b); };
    if (ctl2d_ == 1) {
        add("Izquierda", 0.07f, 0.74f, 0.075f, 0.5f, 0.7f, 1.f); add("Derecha", 0.23f, 0.74f, 0.075f, 0.5f, 0.7f, 1.f);
        add("Arriba", 0.15f, 0.55f, 0.075f, 0.5f, 0.7f, 1.f); add("Abajo", 0.15f, 0.93f, 0.075f, 0.5f, 0.7f, 1.f);
    } else if (ctl2d_ == 3) {
        add("Izquierda", 0.08f, 0.8f, 0.095f, 0.5f, 0.7f, 1.f); add("Derecha", 0.26f, 0.8f, 0.095f, 0.5f, 0.7f, 1.f);
    }
    if (ctl2d_ == 1 || ctl2d_ == 2 || ctl2d_ == 5) { add("A", 0.9f, 0.76f, 0.08f, 0.4f, 1.f, 0.5f); add("B", 0.78f, 0.88f, 0.07f, 1.f, 0.5f, 0.4f); }
    if (ctl2d_ == 3) { add("A", 0.9f, 0.76f, 0.1f, 0.4f, 1.f, 0.5f); add("B", 0.76f, 0.9f, 0.07f, 1.f, 0.5f, 0.4f); }
}

void Hud::move(int id, float px, float py, int w, int h) {
    if (id != stickPtr_ || stickPtr_ < 0) return;
    float R = h * 0.16f, dx = (px - 0.17f * w) / R, dy = (py - 0.74f * h) / R;
    stickX_ = std::max(-1.f, std::min(1.f, dx));
    stickY_ = std::max(-1.f, std::min(1.f, dy));
}

bool Hud::down(int id, float px, float py, int w, int h, bool is3d) {
    if (!is3d) {
        if (ctl2d_ == 2 || ctl2d_ == 4) {  // palanca fija abajo a la izquierda
            float R = h * 0.16f, dx = px - 0.17f * w, dy = py - 0.74f * h;
            if (dx * dx + dy * dy <= R * R * 1.8f) { stickPtr_ = id; move(id, px, py, w, h); return true; }
        }
        for (auto& b : b2_) {
            float dx = px - b.x * w, dy = py - b.y * h, r = b.r * h;
            if (dx * dx + dy * dy <= r * r * 1.3f) { b.ptr = id; return true; }
        }
        return false;
    }
    for (size_t i = 0; i < btns.size(); i++) {
        const HudBtn& b = btns[i];
        if (b.act == HudAct::None) continue;
        float dx = px - b.x * w, dy = py - b.y * h, r = b.r * h;
        if (dx * dx + dy * dy <= r * r) {
            st_[i].ptr = id;
            st_[i].pressed = true;
            if (b.act == HudAct::Interact) st_[i].tapPending = true;
            return true;
        }
    }
    return false;
}

void Hud::up(int id) {
    for (auto& b : b2_) if (b.ptr == id) b.ptr = -1;
    if (stickPtr_ == id) { stickPtr_ = -1; stickX_ = stickY_ = 0; }
    for (auto& s : st_) if (s.ptr == id) s.ptr = -1;
}

void Hud::collect(Input& in) {
    for (auto& b : b2_) if (b.ptr >= 0) in.buttons.push_back(b.label);
    if (stickPtr_ >= 0) {
        if (stickX_ < -0.35f) in.buttons.push_back("Izquierda");
        if (stickX_ > 0.35f) in.buttons.push_back("Derecha");
        if (stickY_ < -0.35f) in.buttons.push_back("Arriba");
        if (stickY_ > 0.35f) in.buttons.push_back("Abajo");
    }
    for (size_t i = 0; i < btns.size() && i < st_.size(); i++) {
        if (st_[i].ptr >= 0) {
            if (btns[i].act == HudAct::Jump) in.jump = true;
            if (btns[i].act == HudAct::Shoot) in.shoot = true;
        }
        if (btns[i].act == HudAct::Sprint && st_[i].ptr >= 0) in.sprint = true;
        if (btns[i].act == HudAct::Crouch && st_[i].ptr >= 0) in.crouch = true;
        if (btns[i].act == HudAct::Hold && st_[i].ptr >= 0) in.buttons.push_back(btns[i].label);   // se repite mientras se mantiene
        if (st_[i].pressed && btns[i].act == HudAct::NextWeapon) in.nextWeapon = true;
        if (st_[i].pressed && btns[i].act == HudAct::Reload) in.reload = true;
        if (st_[i].pressed && btns[i].act == HudAct::Flashlight) in.flash = true;
        if (st_[i].tapPending) { in.tap = true; st_[i].tapPending = false; }
        if (st_[i].pressed) { if (btns[i].act != HudAct::Hold) in.buttons.push_back(btns[i].label); st_[i].pressed = false; }
    }
}

static ImU32 col(float r, float g, float b, float a) {
    return IM_COL32((int)(r * 255), (int)(g * 255), (int)(b * 255), (int)(a * 255));
}

// Cuerpo de un botón en pantalla, con varios diseños (como los de los juegos de celular actuales).
static void drawBtnBody(ImDrawList* dl, ImVec2 c, float r, const float* k, bool on, int style) {
    auto C = [&](float a) { return col(k[0], k[1], k[2], a); };
    switch (style) {
        case 1:   // anillo fino con relleno oscuro (estilo shooters)
            dl->AddCircleFilled(c, r, IM_COL32(10, 12, 18, on ? 170 : 110), 48);
            dl->AddCircle(c, r, C(on ? 1.f : 0.85f), 48, 2.f);
            dl->AddCircle(c, r * 0.82f, C(0.35f), 48, 1.5f);
            break;
        case 2: {   // cuadrado redondeado
            ImVec2 a(c.x - r, c.y - r), b(c.x + r, c.y + r);
            dl->AddRectFilled(a, b, C(on ? 0.7f : 0.3f), r * 0.35f);
            dl->AddRect(a, b, C(0.95f), r * 0.35f, 0, 3.f);
            break;
        }
        case 3:   // neón: borde brillante con halo
            dl->AddCircleFilled(c, r, IM_COL32(8, 8, 14, on ? 200 : 140), 48);
            for (int i = 3; i >= 1; i--) dl->AddCircle(c, r + i * 2.5f, C(0.10f * (4 - i) * (on ? 1.6f : 1.f)), 48, 2.f + i);
            dl->AddCircle(c, r, C(1.f), 48, 3.f);
            break;
        case 4:   // sólido plano
            dl->AddCircleFilled(c, r, C(on ? 1.f : 0.88f), 48);
            dl->AddCircle(c, r, IM_COL32(0, 0, 0, 90), 48, 3.f);
            dl->AddCircleFilled(ImVec2(c.x, c.y + r * 0.08f), r * 0.82f, IM_COL32(0, 0, 0, on ? 70 : 28), 48);
            break;
        case 5:   // cristal con brillo
            dl->AddCircleFilled(c, r, C(on ? 0.75f : 0.45f), 48);
            dl->AddCircle(c, r, C(0.95f), 48, 3.f);
            dl->AddCircleFilled(ImVec2(c.x, c.y - r * 0.38f), r * 0.55f, IM_COL32(255, 255, 255, on ? 30 : 60), 32);
            break;
        case 6: {   // hexágono
            ImVec2 pts[6];
            for (int i = 0; i < 6; i++) { float an = 0.5235988f + i * 1.0471976f; pts[i] = ImVec2(c.x + std::cos(an) * r * 1.08f, c.y + std::sin(an) * r * 1.08f); }
            dl->AddConvexPolyFilled(pts, 6, C(on ? 0.65f : 0.28f));
            dl->AddPolyline(pts, 6, C(0.95f), ImDrawFlags_Closed, 3.f);
            break;
        }
        default:   // clásico
            dl->AddCircleFilled(c, r, C(on ? 0.65f : 0.30f), 40);
            dl->AddCircle(c, r, C(0.9f), 40, 3.f);
    }
}


// ---------------------------------------------------------------- v10.5: pantalla del juego (HUD pro)
static void proBar(ImDrawList* dl, float x, float y, float w, float h, float f, ImU32 fill, bool segs) {
    f = std::max(0.f, std::min(1.f, f));
    dl->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), IM_COL32(0, 0, 0, 150), h * 0.25f);
    if (f > 0) dl->AddRectFilled(ImVec2(x + 2, y + 2), ImVec2(x + 2 + (w - 4) * f, y + h - 2), fill, h * 0.2f);
    if (segs) for (int k = 1; k < 5; k++) dl->AddLine(ImVec2(x + w * k / 5.f, y + 2), ImVec2(x + w * k / 5.f, y + h - 2), IM_COL32(0, 0, 0, 170), 2.f);
    dl->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), IM_COL32(255, 255, 255, 70), h * 0.25f);
}

static void drawProHud(ImDrawList* dl, const Game& g, int w, int h) {
    const GameUi& u = g.proj.ui;
    if (!u.on || !g.sc) return;
    bool is3d = g.sc->is3d;
    ImFont* font = ImGui::GetFont();
    float fs = ImGui::GetFontSize(), H = (float)h, W = (float)w;
    ImU32 acc = col(u.accent[0], u.accent[1], u.accent[2], 0.95f), white = IM_COL32(255, 255, 255, 235);
    auto num = [&](const char* k, double d) { auto it = g.vars.find(k); return it == g.vars.end() ? d : it->second.num(); };
    auto text = [&](float x, float y, const std::string& s, float sz, ImU32 c, bool centerX) {
        ImVec2 ts = font->CalcTextSizeA(sz, 1e9f, 0.f, s.c_str());
        if (centerX) x -= ts.x * 0.5f;
        dl->AddText(font, sz, ImVec2(x + 1.5f, y + 1.5f), IM_COL32(0, 0, 0, 180), s.c_str());
        dl->AddText(font, sz, ImVec2(x, y), c, s.c_str());
    };
    // estilo de color (tintes de pantalla) y viñeta
    static const float kGr[6][4] = {{0, 0, 0, 0}, {0.f, 0.12f, 0.18f, 0.10f}, {0.02f, 0.05f, 0.30f, 0.30f}, {0.1f, 0.3f, 0.6f, 0.14f}, {1.f, 0.55f, 0.2f, 0.16f}, {0.55f, 0.5f, 0.35f, 0.22f}};
    if (u.grade > 0 && u.grade < 6) dl->AddRectFilled(ImVec2(0, 0), ImVec2(W, H), col(kGr[u.grade][0], kGr[u.grade][1], kGr[u.grade][2], kGr[u.grade][3]));
    if (u.grade == 1) {   // cine: barras negras
        dl->AddRectFilled(ImVec2(0, 0), ImVec2(W, H * 0.06f), IM_COL32(0, 0, 0, 255));
        dl->AddRectFilled(ImVec2(0, H * 0.94f), ImVec2(W, H), IM_COL32(0, 0, 0, 255));
    }
    float vg = u.vignette;
    double life = num("vida", 100.0);
    float low = (u.lowHp && is3d && life < 30.0) ? (float)(0.35 + 0.25 * std::sin(g.time * 6.0)) * (float)(1.0 - life / 30.0) : 0.f;
    if (vg > 0 || low > 0) {
        float a = std::min(1.f, vg * 0.8f), t = std::max(W, H) * 0.30f;
        ImU32 e = col(low > 0 ? 0.6f : 0.f, 0.f, 0.f, std::min(1.f, a + low)), z = col(low > 0 ? 0.6f : 0.f, 0.f, 0.f, 0.f);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(t, H), e, z, z, e);
        dl->AddRectFilledMultiColor(ImVec2(W - t, 0), ImVec2(W, H), z, e, e, z);
        dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(W, t), e, e, z, z);
        dl->AddRectFilledMultiColor(ImVec2(0, H - t), ImVec2(W, H), z, z, e, e);
    }
    // puntos y tiempo (también en 2D)
    if (u.score) text(W - fs * 0.8f - font->CalcTextSizeA(fs * 1.6f, 1e9f, 0.f, ("PUNTOS " + std::to_string((long long)num("puntos", 0))).c_str()).x, H * 0.04f, "PUNTOS " + std::to_string((long long)num("puntos", 0)), fs * 1.6f, white, false);
    if (u.timer) { long long t = (long long)std::max(0.0, num("tiempo", 0)); char b[32]; snprintf(b, sizeof b, "%02lld:%02lld", t / 60, t % 60); text(W * 0.5f, H * (u.compass ? 0.11f : 0.04f), b, fs * 1.9f, white, true); }
    if (u.objective) { auto it = g.vars.find("objetivo"); if (it != g.vars.end() && !it->second.txt().empty()) text(W * 0.5f, H * 0.19f, "> " + it->second.txt(), fs * 1.15f, acc, true); }
    if (!is3d) return;

    // mira y marcador de impacto
    {
        float cx = W * 0.5f, cy = H * 0.5f, r = H * 0.012f;
        ImU32 c = IM_COL32(255, 255, 255, 220);
        if (u.crosshair == 1) dl->AddCircleFilled(ImVec2(cx, cy), r * 0.35f, c);
        else if (u.crosshair == 2) { dl->AddLine(ImVec2(cx - r * 1.6f, cy), ImVec2(cx + r * 1.6f, cy), c, 2.f); dl->AddLine(ImVec2(cx, cy - r * 1.6f), ImVec2(cx, cy + r * 1.6f), c, 2.f); }
        else if (u.crosshair == 3) { dl->AddCircle(ImVec2(cx, cy), r * 1.6f, c, 24, 2.f); dl->AddCircleFilled(ImVec2(cx, cy), r * 0.25f, c); }
        else if (u.crosshair == 4) {
            dl->AddLine(ImVec2(cx - r * 2.2f, cy), ImVec2(cx - r * 0.7f, cy), c, 2.f); dl->AddLine(ImVec2(cx + r * 0.7f, cy), ImVec2(cx + r * 2.2f, cy), c, 2.f);
            dl->AddLine(ImVec2(cx, cy - r * 2.2f), ImVec2(cx, cy - r * 0.7f), c, 2.f); dl->AddLine(ImVec2(cx, cy + r * 0.7f), ImVec2(cx, cy + r * 2.2f), c, 2.f);
        }
        if (u.hitmark && g.hitT > 0) {
            float k = g.hitT / 0.28f, a = r * (2.0f + (1.f - k) * 1.2f), b2 = r * 3.6f;
            ImU32 hc = col(1.f, 0.3f, 0.25f, std::min(1.f, k * 1.5f));
            for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2)
                dl->AddLine(ImVec2(cx + sx * a, cy + sy * a), ImVec2(cx + sx * b2, cy + sy * b2), hc, 3.f);
        }
    }
    if (u.fight) {   // barras de pelea: jugador a la izquierda, rival a la derecha, reloj en medio
        float bw2 = W * 0.36f, bh2 = H * 0.045f, y0 = H * 0.045f, mid = W * 0.5f;
        float fa = (float)(life / 100.0), fb = (float)(num("vidaRival", 100.0) / 100.0);
        proBar(dl, mid - W * 0.06f - bw2, y0, bw2, bh2, fa, col(0.95f, 0.8f, 0.2f, 1), false);
        proBar(dl, mid + W * 0.06f, y0, bw2, bh2, fb, col(0.95f, 0.3f, 0.25f, 1), false);
        text(mid - W * 0.06f - bw2, y0 + bh2 + 2, u.nameA, fs * 1.05f, white, false);
        ImVec2 tsb = font->CalcTextSizeA(fs * 1.05f, 1e9f, 0.f, u.nameB.c_str());
        text(mid + W * 0.06f + bw2 - tsb.x, y0 + bh2 + 2, u.nameB, fs * 1.05f, white, false);
        std::string tm = std::to_string((int)std::max(0.0, num("tiempo", 99.0)));
        text(mid, y0 - fs * 0.1f, tm, fs * 2.0f, white, true);
        double comb = num("combo", 0);
        if (comb >= 2) text(W * 0.06f, H * 0.2f, std::to_string((int)comb) + " HIT COMBO", fs * 1.6f, col(1.f, 0.85f, 0.2f, 1), false);
    }
    // vida y escudo (abajo a la izquierda)
    float bw = W * 0.26f, bh = H * 0.035f, bx = W * 0.03f, by = H * 0.93f;
    if (u.health && !u.fight) {
        float f = (float)(life / 100.0);
        ImU32 hc = f > 0.5f ? col(0.3f, 0.85f, 0.35f, 1) : f > 0.25f ? col(0.95f, 0.75f, 0.2f, 1) : col(0.95f, 0.25f, 0.2f, 1);
        proBar(dl, bx, by, bw, bh, f, hc, false);
        text(bx + 6, by - fs * 0.15f, "+ " + std::to_string((int)std::max(0.0, life)), fs * 1.1f, white, false);
    }
    if (u.shield) {
        double sh = num("escudo", 0);
        proBar(dl, bx, by - bh * 1.5f, bw, bh * 0.85f, (float)(sh / 100.0), acc, true);
        text(bx + 6, by - bh * 1.5f - fs * 0.1f, "# " + std::to_string((int)std::max(0.0, sh)), fs, white, false);
    }
    // armas y munición (abajo al centro)
    if (g.curWeapon() && (u.slots || u.ammo)) {
        int n = (int)g.proj.extraWeapons.size() + 1;
        float sz = H * 0.075f, gap = H * 0.012f, x0 = W * 0.5f - (n * sz + (n - 1) * gap) * 0.5f, y0 = H - sz - H * 0.025f;
        if (u.slots) {
            for (int i = 0; i < n; i++) {
                bool own = i < (int)g.owned_.size() && g.owned_[i], cur = i == g.curW_;
                float x = x0 + i * (sz + gap);
                dl->AddRectFilled(ImVec2(x, y0), ImVec2(x + sz, y0 + sz), cur ? col(u.accent[0], u.accent[1], u.accent[2], 0.45f) : IM_COL32(0, 0, 0, own ? 140 : 70), 6.f);
                dl->AddRect(ImVec2(x, y0), ImVec2(x + sz, y0 + sz), cur ? acc : IM_COL32(255, 255, 255, own ? 100 : 40), 6.f, 0, cur ? 3.f : 1.5f);
                std::string nm = g.weaponAt(i).name.substr(0, 6);
                text(x + sz * 0.5f, y0 + sz * 0.5f - fs * 0.45f, nm, fs * 0.8f, own ? white : IM_COL32(255, 255, 255, 90), true);
                text(x + 5, y0 + 2, std::to_string(i + 1), fs * 0.7f, IM_COL32(255, 255, 255, 160), false);
            }
        }
        if (u.ammo) {
            const Weapon& wp = *g.curWeapon();
            std::string a = wp.type == 1 ? "CUERPO A CUERPO" : (wp.infinite ? "INF" : std::to_string((int)num("municion", 0)) + " / " + std::to_string((int)num("reserva", 0)));
            if (g.reloadT_ > 0) a = "RECARGANDO...";
            text(W * 0.5f, y0 - fs * 1.7f, a, fs * 1.5f, white, true);
        }
    }
    // minimapa: varios estilos (círculo, óvalo, rectángulo, cuadrado, teléfono, anillo) que dibujan lo que hay en la escena
    if (u.minimap) {
        const int st = std::max(0, std::min(5, u.mapStyle));
        float R = H * 0.11f * (u.mapSize > 0.1f ? u.mapSize : 1.f);
        float hw = R, hh = R;
        if (st == 1) { hw = R * 1.45f; hh = R * 0.85f; }
        else if (st == 2) { hw = R * 1.5f; hh = R * 0.95f; }
        else if (st == 4) { hw = R * 0.8f; hh = R * 1.35f; }
        float cx = hw + W * 0.02f, cy = hh + H * 0.045f;
        const bool round = st == 0 || st == 1 || st == 5;
        const bool boxy = st == 2 || st == 3 || st == 4;
        float range = std::max(6.f, u.mapRange) * (is3d ? 1.f : 30.f);
        float sc = std::min(hw, hh) / range;
        // fondo y borde
        ImU32 bg = st == 5 ? IM_COL32(20, 22, 26, 110) : IM_COL32(14, 20, 28, 185);
        auto ell = [&](float sx, float sy, bool fill, ImU32 c, float th) {
            const int N = 56;
            ImVec2 pts[N];
            for (int i = 0; i < N; i++) { float a2 = 6.2831853f * i / N; pts[i] = ImVec2(cx + std::cos(a2) * sx, cy + std::sin(a2) * sy); }
            if (fill) dl->AddConvexPolyFilled(pts, N, c); else dl->AddPolyline(pts, N, c, ImDrawFlags_Closed, th);
        };
        if (round) ell(hw, hh, true, bg, 0); else dl->AddRectFilled(ImVec2(cx - hw, cy - hh), ImVec2(cx + hw, cy + hh), bg, st == 2 ? R * 0.12f : st == 4 ? R * 0.25f : 4.f);
        if (boxy) dl->PushClipRect(ImVec2(cx - hw, cy - hh), ImVec2(cx + hw, cy + hh), true);
        // posición y giro del jugador
        float pxw = 0, pzw = 0, rot = 0;
        if (is3d) { pxw = g.pos.x; pzw = g.pos.z; rot = g.yaw; }
        else for (const Obj& o : g.sc->objs) if (o.kind == Kind::Player) { pxw = o.pos.x; pzw = o.pos.y; break; }
        const bool spin = is3d && u.mapRotate;
        float sn = std::sin(rot), cs = std::cos(rot);
        auto toMap = [&](float wx, float wz, bool clampIt) {
            float dx = wx - pxw, dz = wz - pzw;
            float rx, ry;
            if (is3d) { if (spin) { rx = dx * cs + dz * sn; ry = dx * sn - dz * cs; } else { rx = dx; ry = -dz; } }
            else { rx = dx; ry = dz; }
            float px = rx * sc, py = -ry * sc;
            if (round && clampIt) { float l = std::sqrt((px / hw) * (px / hw) + (py / hh) * (py / hh)); if (l > 0.97f) { px *= 0.97f / l; py *= 0.97f / l; } }
            return ImVec2(cx + px, cy + py);
        };
        auto quad = [&](const Obj& o, ImU32 c) {
            float sx = o.scale.x * 0.5f, sz = (is3d ? o.scale.z : o.scale.y) * 0.5f;
            float wpx = o.pos.x, wpz = is3d ? o.pos.z : o.pos.y;
            ImVec2 q[4];
            static const float cr[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (int k = 0; k < 4; k++) {
                float lx = cr[k][0] * sx, lz = cr[k][1] * sz, ddx, ddz;
                if (is3d) { float ya = o.yaw * 0.0174532925f, c2 = std::cos(ya), s2 = std::sin(ya); ddx = lx * c2 + lz * s2; ddz = -lx * s2 + lz * c2; }
                else { float ra = -(o.yaw - 90.f) * 0.0174532925f, c2 = std::cos(ra), s2 = std::sin(ra); ddx = c2 * lx - s2 * lz; ddz = s2 * lx + c2 * lz; }
                q[k] = toMap(wpx + ddx, wpz + ddz, true);
            }
            dl->AddConvexPolyFilled(q, 4, c);
        };
        // 1) suelos y caminos, 2) paredes y objetos sólidos
        for (int pass = 0; pass < 2; pass++)
            for (const Obj& o : g.sc->objs) {
                if (!o.alive || !o.visible || o.kind == Kind::Light || o.kind == Kind::Player || o.bg) continue;
                bool foe = o.ai.type != AiType::None;
                if (foe || o.kind == Kind::Item) continue;
                bool ground = o.kind == Kind::Floor || (is3d ? o.scale.y < 0.5f : o.layer <= 1);
                if (pass == 0 && ground) quad(o, st == 5 ? IM_COL32(120, 125, 130, 150) : IM_COL32(150, 156, 168, 235));
                else if (pass == 1 && !ground && (o.solid || !is3d)) quad(o, st == 5 ? IM_COL32(60, 64, 70, 200) : IM_COL32(58, 72, 105, 255));
            }
        // enemigos y objetos
        for (const Obj& o : g.sc->objs) {
            if (!o.alive || !o.visible || o.kind == Kind::Player) continue;
            bool foe = o.ai.type != AiType::None, item = o.kind == Kind::Item;
            if (!foe && !item) continue;
            ImVec2 p = toMap(o.pos.x, is3d ? o.pos.z : o.pos.y, true);
            dl->AddCircleFilled(p, std::min(hw, hh) * 0.065f, foe ? IM_COL32(255, 70, 60, 255) : IM_COL32(255, 220, 60, 255), 10);
            dl->AddCircle(p, std::min(hw, hh) * 0.065f, IM_COL32(0, 0, 0, 160), 10, 1.5f);
        }
        if (boxy) dl->PopClipRect();
        // borde y marcas
        ImU32 rim = st == 1 ? IM_COL32(15, 15, 15, 255) : st == 0 ? IM_COL32(236, 160, 230, 255) : st == 3 ? IM_COL32(255, 255, 255, 230) : acc;
        if (round) ell(hw, hh, false, rim, st == 5 ? 2.f : 4.f); else dl->AddRect(ImVec2(cx - hw, cy - hh), ImVec2(cx + hw, cy + hh), rim, st == 2 ? R * 0.12f : st == 4 ? R * 0.25f : 4.f, 0, 3.f);
        if (st == 5 || st == 2) {   // anillo de vida (izquierda, verde) y escudo (derecha, azul), como los mapas de Rockstar
            float lf = (float)std::max(0.0, std::min(1.0, num("vida", 100.0) / 100.0)), sf = (float)std::max(0.0, std::min(1.0, num("escudo", 0.0) / 100.0));
            if (st == 5) {
                dl->PathArcTo(ImVec2(cx, cy), hw + 5.f, 3.14159f * 0.55f, 3.14159f * (0.55f + 0.9f * lf), 24); dl->PathStroke(IM_COL32(90, 200, 100, 230), 0, 4.f);
                dl->PathArcTo(ImVec2(cx, cy), hw + 5.f, -3.14159f * 0.55f, -3.14159f * (0.55f + 0.9f * sf), 24); dl->PathStroke(IM_COL32(70, 150, 235, 230), 0, 4.f);
            } else {
                float bw2 = hw * 2.f;
                dl->AddRectFilled(ImVec2(cx - hw, cy + hh + 4.f), ImVec2(cx - hw + bw2 * lf, cy + hh + 9.f), IM_COL32(90, 200, 100, 230));
                dl->AddRectFilled(ImVec2(cx - hw, cy + hh + 11.f), ImVec2(cx - hw + bw2 * sf, cy + hh + 16.f), IM_COL32(70, 150, 235, 230));
            }
        }
        // jugador (flecha) y norte
        float ang = (is3d && !spin) ? -rot : 0.f;
        float ca = std::cos(ang), sa = std::sin(ang);
        auto rp = [&](float x, float y) { return ImVec2(cx + x * ca - y * sa, cy + x * sa + y * ca); };
        float ar = std::min(hw, hh) * 0.12f;
        dl->AddTriangleFilled(rp(0, -ar), rp(-ar * 0.7f, ar * 0.8f), rp(ar * 0.7f, ar * 0.8f), st == 1 || st == 0 ? IM_COL32(255, 255, 255, 255) : acc);
        if (is3d && spin) {   // letra N donde está el norte
            float dirx = -sn, diry = -cs;   // hacia el norte (-Z) en pantalla
            float ex = dirx, ey = diry; float l2 = std::sqrt((ex / hw) * (ex / hw) + (ey / hh) * (ey / hh)); ex /= l2; ey /= l2;
            text(cx + ex * 0.92f - fs * 0.35f, cy + ey * 0.92f - fs * 0.55f, "N", fs * 0.85f, IM_COL32(255, 255, 255, 240), false);
        }
    }
    // brújula (arriba al centro)
    if (u.compass) {
        float cw = W * 0.34f, x0 = W * 0.5f - cw * 0.5f, y0 = H * 0.035f, deg = std::fmod(g.yaw * 57.29578f + 36000.f, 360.f);
        dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x0 + cw, y0 + H * 0.05f), IM_COL32(0, 0, 0, 110), 6.f);
        for (int d = -90; d <= 90; d += 5) {
            float ang = std::floor(deg / 5.f) * 5.f + d, x = W * 0.5f + (ang - deg) / 100.f * cw;
            int a2 = ((int)ang % 360 + 360) % 360;
            if (x < x0 + 4 || x > x0 + cw - 4) continue;
            bool major = a2 % 45 == 0;
            dl->AddLine(ImVec2(x, y0 + H * (major ? 0.01f : 0.025f)), ImVec2(x, y0 + H * 0.05f), IM_COL32(255, 255, 255, major ? 220 : 100), 1.5f);
            if (a2 % 90 == 0) { static const char* nm[4] = {"N", "E", "S", "O"}; text(x, y0 + H * 0.004f, nm[a2 / 90], fs * 0.95f, a2 == 0 ? col(1.f, 0.4f, 0.3f, 1.f) : white, true); }
        }
        dl->AddTriangleFilled(ImVec2(W * 0.5f, y0 + H * 0.052f), ImVec2(W * 0.5f - 5, y0 + H * 0.066f), ImVec2(W * 0.5f + 5, y0 + H * 0.066f), acc);
    }
    // velocímetro (modo vehículo)
    if (u.speedo) {
        float R = H * 0.12f, cx = W - R - W * 0.03f, cy = H * 0.34f;
        float kmh = std::fabs(g.carSpeed_) * 14.f, mx = std::max(60.f, g.walkSpeed * 14.f * 1.15f), f = std::min(1.f, kmh / mx);
        dl->AddCircleFilled(ImVec2(cx, cy), R, IM_COL32(8, 12, 18, 175), 48);
        const float a0 = 2.35f, a1 = a0 + 4.71f;   // arco de 270 grados
        dl->PathArcTo(ImVec2(cx, cy), R * 0.86f, a0, a1, 40); dl->PathStroke(IM_COL32(255, 255, 255, 60), 0, 5.f);
        dl->PathArcTo(ImVec2(cx, cy), R * 0.86f, a0, a0 + (a1 - a0) * f, 40); dl->PathStroke(f > 0.85f ? IM_COL32(255, 70, 60, 255) : acc, 0, 6.f);
        text(cx, cy - fs * 0.9f, std::to_string((int)kmh), fs * 2.2f, white, true);
        text(cx, cy + fs * 0.9f, "km/h", fs * 0.9f, IM_COL32(255, 255, 255, 170), true);
    }
}

void Hud::draw(ImDrawList* dl, const Game& g, Renderer* rend, int w, int h, bool showButtons) {
    drawCameraLayer(dl, g, rend, w, h);
    if (!g.sc || !dl) return;
    bool is3d = g.sc->is3d;
    ImFont* font = ImGui::GetFont();
    float fs = ImGui::GetFontSize();

    // Arma en primera persona.
    if (is3d && g.curWeapon() && g.curWeapon()->enabled && g.camMode == kFirstPerson && g.curWeapon()->model.empty()) {
        const Weapon& wp = *g.curWeapon();
        const float ak = g.aimK;   // al apuntar el arma de dibujo se centra, crece un poco y sube
        float sh = wp.scale * h * (1.f + 0.18f * ak), cx = (w * 0.62f + wp.ox * w) * (1.f - ak) + w * (0.5f + g.proj.player.aimWx) * ak;
        float bottom = h + wp.oy * h + g.recoil * 0.04f * h - ak * h * 0.04f;
        int tw = 1, th = 1;
        unsigned tid = rend ? rend->textureId(g, wp.tex, &tw, &th) : 0;
        float top;
        if (tid) {
            float sw = sh * (float)tw / (float)th;
            dl->AddImage((ImTextureID)(intptr_t)tid, ImVec2(cx - sw * 0.5f, bottom - sh), ImVec2(cx + sw * 0.5f, bottom),
                         ImVec2(0, 1), ImVec2(1, 0));
            top = bottom - sh;
        } else {  // arma basica dibujada
            float u = sh * 0.5f;
            dl->AddRectFilled(ImVec2(cx - 0.20f * u, bottom - 0.9f * u), ImVec2(cx + 0.20f * u, bottom), col(.18f, .18f, .2f, 1), 4.f);
            dl->AddRectFilled(ImVec2(cx - 0.34f * u, bottom - 1.35f * u), ImVec2(cx + 0.24f * u, bottom - 0.85f * u), col(.3f, .3f, .34f, 1), 4.f);
            dl->AddRectFilled(ImVec2(cx - 0.10f * u, bottom - 1.75f * u), ImVec2(cx + 0.04f * u, bottom - 1.30f * u), col(.22f, .22f, .26f, 1), 3.f);
            top = bottom - 1.75f * u;
        }
        if (g.flash > 0) dl->AddCircleFilled(ImVec2(cx, top), sh * 0.12f, col(1.f, .85f, .4f, .9f));
    }

    drawProHud(dl, g, w, h);

    // Destello rojo al recibir dano.
    if (is3d && g.hurtFlash > 0)
        dl->AddRectFilled(ImVec2(0, 0), ImVec2((float)w, (float)h), col(1.f, 0.f, 0.f, std::min(0.45f, g.hurtFlash)));

    // Botones y joystick.
    if (showButtons && is3d) {
        for (size_t i = 0; i < btns.size(); i++) {
            const HudBtn& b = btns[i];
            bool pressed = i < st_.size() && st_[i].ptr >= 0;
            ImVec2 c(b.x * w, b.y * h);
            float r = b.r * h;
            drawBtnBody(dl, c, r, b.color, pressed, g.proj.btnStyle);
            ImVec2 ts = font->CalcTextSizeA(fs, 1e9f, 0.f, b.label.c_str());
            dl->AddText(font, fs, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), IM_COL32(255, 255, 255, 230), b.label.c_str());
        }
        if (joy.active) {
            float R = w * 0.08f;
            dl->AddCircle(ImVec2(joy.ox, joy.oy), R, IM_COL32(255, 255, 255, 110), 40, 3.f);
            float dx = joy.x - joy.ox, dy = joy.y - joy.oy, l = std::sqrt(dx * dx + dy * dy);
            if (l > R) { dx *= R / l; dy *= R / l; }
            dl->AddCircleFilled(ImVec2(joy.ox + dx, joy.oy + dy), R * 0.4f, IM_COL32(255, 255, 255, 140), 24);
        }
    }

    // v10: controles 2D
    if (showButtons && !is3d && ctl2d_ > 0) {
        for (auto& b : b2_) {
            ImVec2 c(b.x * w, b.y * h);
            float r = b.r * h;
            bool on = b.ptr >= 0;
            drawBtnBody(dl, c, r, b.c, on, g.proj.btnStyle);
            float a = r * 0.45f;
            ImU32 wh = IM_COL32(255, 255, 255, 230);
            if (b.label == "Izquierda") dl->AddTriangleFilled(ImVec2(c.x - a, c.y), ImVec2(c.x + a * 0.6f, c.y - a), ImVec2(c.x + a * 0.6f, c.y + a), wh);
            else if (b.label == "Derecha") dl->AddTriangleFilled(ImVec2(c.x + a, c.y), ImVec2(c.x - a * 0.6f, c.y - a), ImVec2(c.x - a * 0.6f, c.y + a), wh);
            else if (b.label == "Arriba") dl->AddTriangleFilled(ImVec2(c.x, c.y - a), ImVec2(c.x - a, c.y + a * 0.6f), ImVec2(c.x + a, c.y + a * 0.6f), wh);
            else if (b.label == "Abajo") dl->AddTriangleFilled(ImVec2(c.x, c.y + a), ImVec2(c.x - a, c.y - a * 0.6f), ImVec2(c.x + a, c.y - a * 0.6f), wh);
            else {
                ImVec2 ts = font->CalcTextSizeA(fs * 1.3f, 1e9f, 0.f, b.label.c_str());
                dl->AddText(font, fs * 1.3f, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), wh, b.label.c_str());
            }
        }
        if (ctl2d_ == 2 || ctl2d_ == 4) {
            float R = h * 0.16f;
            ImVec2 c(0.17f * w, 0.74f * h);
            dl->AddCircleFilled(c, R, IM_COL32(120, 170, 255, 50), 40);
            dl->AddCircle(c, R, IM_COL32(150, 190, 255, 200), 40, 3.f);
            dl->AddCircleFilled(ImVec2(c.x + stickX_ * R * 0.6f, c.y + stickY_ * R * 0.6f), R * 0.38f, IM_COL32(255, 255, 255, stickPtr_ >= 0 ? 190 : 120), 28);
        }
    }

    // Marca de ruta fija (2D): solo el tramo que el objeto recorre ahora y los siguientes puntos, nunca la ruta completa.
    if (!is3d) {
        const float vw = g.view2W(), vh = g.view2H(), tm = (float)ImGui::GetTime();
        auto toS = [&](float x, float y) { return ImVec2(((x - g.cam2x) / vw + 0.5f) * w, (0.5f - (y - g.cam2y) / vh) * h); };
        const float px1 = h / std::max(1.f, vh);   // píxeles por unidad del mundo
        for (size_t oi = 0; oi < g.sc->objs.size(); oi++) {
            const Obj& o = g.sc->objs[oi];
            if (!o.routeMark || !o.alive || !o.routeOn || o.ghost || o.route.size() < 4) continue;
            int n = (int)o.route.size() / 2, wp = g.routeWp((int)oi);
            if (wp < 0 || wp >= n) continue;
            std::vector<ImVec2> path;
            path.push_back(toS(o.pos.x, o.pos.y));
            for (int k = 0; k < o.routeMarkAhead; k++) {
                int idx = wp + k;
                if (idx >= n) { if (!o.routeLoop) break; idx %= n; }
                path.push_back(toS(o.route[idx * 2], o.route[idx * 2 + 1]));
            }
            if (path.size() < 2) continue;
            float W = std::max(1.5f, o.routeMarkW * px1 * 0.5f + o.routeMarkW * 0.5f);
            float sp = W * 3.2f, total = 0.f;
            for (size_t k = 1; k < path.size(); k++) total += std::hypot(path[k].x - path[k - 1].x, path[k].y - path[k - 1].y);
            ImU32 base = IM_COL32((int)(o.routeMarkCol[0] * 255), (int)(o.routeMarkCol[1] * 255), (int)(o.routeMarkCol[2] * 255), 255);
            float flow = std::fmod(tm * W * 5.f, sp), run = -flow;   // las marcas avanzan en el sentido de la ruta
            for (size_t k = 1; k < path.size(); k++) {
                ImVec2 a = path[k - 1], b = path[k];
                float L = std::hypot(b.x - a.x, b.y - a.y);
                if (L < 1e-3f) continue;
                ImVec2 d((b.x - a.x) / L, (b.y - a.y) / L), nrm(-d.y, d.x);
                float t0 = std::fmod(run + sp * 1000.f, sp);
                for (float t = (t0 > 0.f ? sp - t0 : -t0); t < L; t += sp) {
                    float al = std::max(0.25f, 1.f - (run + t) / std::max(1.f, total) * 0.75f);
                    ImU32 col = (base & 0x00FFFFFF) | ((ImU32)(al * 255) << 24);
                    ImVec2 c(a.x + d.x * t, a.y + d.y * t);
                    switch (o.routeMarkStyle) {
                        case 0: dl->AddCircleFilled(c, W * 0.55f, col, 10); break;
                        case 1: dl->AddLine(ImVec2(c.x - d.x * W * 0.9f, c.y - d.y * W * 0.9f), ImVec2(c.x + d.x * W * 0.9f, c.y + d.y * W * 0.9f), col, std::max(1.5f, W * 0.55f)); break;
                        case 2: {
                            ImVec2 tip(c.x + d.x * W, c.y + d.y * W);
                            dl->AddLine(ImVec2(c.x - d.x * W * 0.2f + nrm.x * W, c.y - d.y * W * 0.2f + nrm.y * W), tip, col, std::max(1.5f, W * 0.4f));
                            dl->AddLine(ImVec2(c.x - d.x * W * 0.2f - nrm.x * W, c.y - d.y * W * 0.2f - nrm.y * W), tip, col, std::max(1.5f, W * 0.4f));
                            break;
                        }
                        default: dl->AddQuadFilled(ImVec2(c.x + d.x * W, c.y + d.y * W), ImVec2(c.x + nrm.x * W * 0.6f, c.y + nrm.y * W * 0.6f),
                                                   ImVec2(c.x - d.x * W, c.y - d.y * W), ImVec2(c.x - nrm.x * W * 0.6f, c.y - nrm.y * W * 0.6f), col);
                    }
                }
                run += L;
            }
            dl->AddCircle(path[1], W * 1.7f, base, 20, std::max(1.5f, W * 0.3f));   // el punto al que va ahora
        }
    }

    // Variables visibles ("Mostrar la variable ... en X, Y"): coordenadas del escenario (alto 1000, origen al centro).
    {
        float sw = g.stageW(), sh = kView2DHeight;
        for (auto& v : g.shown) {
            Val val = g.vars.count(Game::vkey(v.first)) ? g.vars.at(Game::vkey(v.first)) : Val(0.0);
            std::string txt = val.txt();
            ImVec2 ts = font->CalcTextSizeA(fs, 1e9f, 0.f, txt.c_str());
            float px = (v.second.first / sw + 0.5f) * w, py = (0.5f - v.second.second / sh) * h;
            dl->AddRectFilled(ImVec2(px - ts.x * .5f - 8, py - ts.y * .5f - 3), ImVec2(px + ts.x * .5f + 8, py + ts.y * .5f + 3),
                              IM_COL32(0, 0, 0, 110), 4.f);
            dl->AddText(font, fs, ImVec2(px - ts.x * .5f, py - ts.y * .5f), IM_COL32(255, 255, 255, 240), txt.c_str());
        }
    }

    for (auto& kv : g.texts) {   // textos puestos con «Mostrar texto»
        const auto& t = kv.second;
        float sz = fs * t.size / 30.f * 1.0f;
        ImVec2 ts = font->CalcTextSizeA(sz, 1e9f, 0.f, t.cur.c_str());
        float px = (t.x / g.stageW() + 0.5f) * w, py = (0.5f - t.y / kView2DHeight) * h;
        dl->AddText(font, sz, ImVec2(px - ts.x * .5f + 1.5f, py - ts.y * .5f + 1.5f), IM_COL32(0, 0, 0, 200), t.cur.c_str());
        dl->AddText(font, sz, ImVec2(px - ts.x * .5f, py - ts.y * .5f), IM_COL32(255, 255, 255, 255), t.cur.c_str());
    }

    if (g.proj.showFps) {   // contador de rendimiento
        float fr = ImGui::GetIO().Framerate;
        char fb[64]; std::snprintf(fb, sizeof fb, "%.0f FPS  %.1f ms", fr, fr > 0.f ? 1000.f / fr : 0.f);
        ImVec2 ts = font->CalcTextSizeA(fs * 0.9f, 1e9f, 0.f, fb);
        dl->AddRectFilled(ImVec2(w - ts.x - 22.f, 6.f), ImVec2(w - 6.f, ts.y + 14.f), IM_COL32(0, 0, 0, 140), 6.f);
        dl->AddText(font, fs * 0.9f, ImVec2(w - ts.x - 14.f, 10.f), IM_COL32(120, 255, 160, 255), fb);
    }

    // Texto del bloque "decir".
    if (g.sayT > 0 && !g.say.empty()) {
        ImVec2 ts = font->CalcTextSizeA(fs * 1.2f, 1e9f, 0.f, g.say.c_str());
        float x = (w - ts.x) * 0.5f, y = h * 0.14f;
        dl->AddRectFilled(ImVec2(x - 14, y - 8), ImVec2(x + ts.x + 14, y + ts.y + 8), IM_COL32(0, 0, 0, 150), 8.f);
        dl->AddText(font, fs * 1.2f, ImVec2(x, y), IM_COL32(255, 255, 255, 255), g.say.c_str());
    }
}

}  // namespace forge
