#include "net.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <random>
#include <sstream>
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
typedef int socklen_t_;
#else
#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace forge {

static std::vector<std::string> split(const std::string& s, char c) {
    std::vector<std::string> o; std::string cur;
    for (char ch : s) { if (ch == c) { o.push_back(cur); cur.clear(); } else cur += ch; }
    o.push_back(cur);
    return o;
}
static std::string clean(std::string s) { for (auto& c : s) if (c == '|' || c == '\n') c = ' '; return s; }

bool Net::start(const std::string& room, const std::string& myName) {
    if (sock_ >= 0 && room == room_) return true;
    stop();
    room_ = clean(room); name_ = clean(myName.empty() ? "Jugador" : myName);
#ifdef _WIN32
    WSADATA wd; if (WSAStartup(MAKEWORD(2, 2), &wd) != 0) return false;
#endif
    int s = (int)::socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (s < 0) return false;
    int yes = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, (const char*)&yes, sizeof(yes));
#ifdef SO_REUSEPORT
    setsockopt(s, SOL_SOCKET, SO_REUSEPORT, (const char*)&yes, sizeof(yes));
#endif
    setsockopt(s, SOL_SOCKET, SO_BROADCAST, (const char*)&yes, sizeof(yes));
    sockaddr_in a; std::memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET; a.sin_port = htons((unsigned short)port_); a.sin_addr.s_addr = htonl(INADDR_ANY);
    if (::bind(s, (sockaddr*)&a, sizeof(a)) < 0) {
#ifdef _WIN32
        closesocket(s);
#else
        close(s);
#endif
        return false;
    }
#ifdef _WIN32
    u_long nb = 1; ioctlsocket(s, FIONBIO, &nb);
#else
    fcntl(s, F_SETFL, fcntl(s, F_GETFL, 0) | O_NONBLOCK);
#endif
    sock_ = s;
    std::random_device rd; id_ = (rd() & 0x7fffffff) | 1u;
    peers_.clear(); lastSend_ = -1;
    return true;
}

void Net::stop() {
    if (sock_ < 0) return;
#ifdef _WIN32
    closesocket(sock_);
    WSACleanup();
#else
    close(sock_);
#endif
    sock_ = -1; peers_.clear();
}

void Net::sendRaw(const std::string& s) {
    if (sock_ < 0) return;
    sockaddr_in a; std::memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET; a.sin_port = htons((unsigned short)port_); a.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    ::sendto(sock_, s.data(), (int)s.size(), 0, (sockaddr*)&a, sizeof(a));
    // tambien por la propia maquina (pruebas con dos juegos en la misma PC)
    a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    ::sendto(sock_, s.data(), (int)s.size(), 0, (sockaddr*)&a, sizeof(a));
}

void Net::sendMsg(const std::string& msg) { sendRaw("FM|" + room_ + "|" + std::to_string(id_) + "|" + clean(msg)); }
void Net::sendVar(const std::string& n, const std::string& v) { sendRaw("FV|" + room_ + "|" + std::to_string(id_) + "|" + clean(n) + "|" + clean(v)); }

bool Net::isHost() const {
    for (auto& p : peers_) if (p.first < id_) return false;
    return true;
}

void Net::tick(double now, float x, float y, float z, float yaw, const std::string& scene) {
    if (sock_ < 0) return;
    if (now - lastSend_ >= 0.05) {
        lastSend_ = now;
        char buf[256];
        std::snprintf(buf, sizeof(buf), "FG|%s|%u|%s|%.3f|%.3f|%.3f|%.3f|%s", room_.c_str(), id_, name_.c_str(), x, y, z, yaw, clean(scene).c_str());
        sendRaw(buf);
    }
    char buf[1500];
    for (int n = 0; n < 200; n++) {
        int r = (int)::recv(sock_, buf, sizeof(buf) - 1, 0);
        if (r <= 0) break;
        buf[r] = 0;
        auto f = split(buf, '|');
        if (f.size() < 3 || f[1] != room_) continue;
        unsigned id = (unsigned)std::strtoul(f[2].c_str(), nullptr, 10);
        if (id == id_ || id == 0) continue;
        if (f[0] == "FG" && f.size() >= 9) {
            bool isNew = !peers_.count(id);
            NetPeer& p = peers_[id];
            p.id = id; p.name = f[3]; p.x = (float)std::atof(f[4].c_str()); p.y = (float)std::atof(f[5].c_str()); p.z = (float)std::atof(f[6].c_str());
            p.yaw = (float)std::atof(f[7].c_str()); p.scene = f[8]; p.seen = now;
            if (isNew) joined_++;
        } else if (f[0] == "FM" && f.size() >= 4) msgs_.push_back(f[3]);
        else if (f[0] == "FV" && f.size() >= 5) vars_.push_back({f[3], f[4]});
    }
    for (auto it = peers_.begin(); it != peers_.end();) {
        if (now - it->second.seen > 2.0) { it = peers_.erase(it); left_++; } else ++it;
    }
}

}  // namespace forge
