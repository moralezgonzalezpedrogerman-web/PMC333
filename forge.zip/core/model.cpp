#include <unordered_map>
#include <cmath>
#include <cstring>
#include "model.h"
#include <algorithm>
#include <cstring>


namespace forge {

static void w32(std::vector<uint8_t>& o, uint32_t v) {
    for (int i = 0; i < 4; i++) o.push_back((v >> (8 * i)) & 255);
}

bool modelWrite(const ModelData& m, std::vector<uint8_t>& out) {
    if (m.v.empty() || m.v.size() % 8 != 0 || m.idx.empty() || m.idx.size() % 3 != 0) return false;
    uint32_t nv = (uint32_t)(m.v.size() / 8), ni = (uint32_t)m.idx.size();
    bool wide = nv > 65535;
    out.clear();
    out.insert(out.end(), {'F', 'M', 'D', '1'});
    w32(out, nv);
    w32(out, ni);
    out.push_back(wide ? 1 : 0);
    out.push_back((uint8_t)std::min<size_t>(m.tex.size(), 255));
    out.insert(out.end(), m.tex.begin(), m.tex.begin() + std::min<size_t>(m.tex.size(), 255));
    for (int i = 0; i < 3; i++) {
        uint32_t u;
        memcpy(&u, &m.color[i], 4);
        w32(out, u);
    }
    size_t at = out.size();
    out.resize(at + m.v.size() * 4);
    memcpy(out.data() + at, m.v.data(), m.v.size() * 4);
    for (uint32_t i : m.idx) {
        out.push_back(i & 255);
        out.push_back((i >> 8) & 255);
        if (wide) { out.push_back((i >> 16) & 255); out.push_back((i >> 24) & 255); }
    }
    return true;
}

bool modelRead(const uint8_t* d, size_t n, ModelData& m) {
    if (n < 18 || memcmp(d, "FMD1", 4) != 0) return false;
    auto r32 = [&](size_t p) { return (uint32_t)d[p] | ((uint32_t)d[p + 1] << 8) | ((uint32_t)d[p + 2] << 16) | ((uint32_t)d[p + 3] << 24); };
    uint32_t nv = r32(4), ni = r32(8);
    bool wide = d[12] != 0;
    size_t tl = d[13], p = 14;
    if (p + tl + 12 > n || nv == 0 || ni == 0 || ni % 3 != 0) return false;
    m.tex.assign((const char*)d + p, tl);
    p += tl;
    for (int i = 0; i < 3; i++) {
        uint32_t u = r32(p);
        memcpy(&m.color[i], &u, 4);
        p += 4;
    }
    size_t vb = (size_t)nv * 32, ib = (size_t)ni * (wide ? 4 : 2);
    if (p + vb + ib > n) return false;
    m.v.resize((size_t)nv * 8);
    memcpy(m.v.data(), d + p, vb);
    p += vb;
    m.idx.resize(ni);
    for (uint32_t i = 0; i < ni; i++) {
        m.idx[i] = wide ? r32(p) : (uint32_t)(d[p] | (d[p + 1] << 8));
        p += wide ? 4 : 2;
        if (m.idx[i] >= nv) return false;
    }
    return true;
}

bool modelSmooth(ModelData& m, float angleDeg, bool onlyIfFlat) {
    size_t nt = m.idx.size() / 3;
    if (nt == 0 || m.v.size() < 24) return false;
    for (uint32_t i : m.idx) if ((size_t)i * 8 + 7 >= m.v.size()) return false;
    std::vector<float> fn(nt * 3);       // normal de cada cara, ponderada por el área (sin normalizar)
    std::vector<float> fu(nt * 3);       // y normalizada
    size_t flat = 0, corners = 0;
    for (size_t t = 0; t < nt; t++) {
        const float *a = &m.v[(size_t)m.idx[t * 3] * 8], *b = &m.v[(size_t)m.idx[t * 3 + 1] * 8], *c = &m.v[(size_t)m.idx[t * 3 + 2] * 8];
        float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
        float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
        float l = std::sqrt(nx * nx + ny * ny + nz * nz);
        fn[t * 3] = nx; fn[t * 3 + 1] = ny; fn[t * 3 + 2] = nz;
        if (l > 1e-20f) { nx /= l; ny /= l; nz /= l; } else { nx = ny = nz = 0.f; }
        fu[t * 3] = nx; fu[t * 3 + 1] = ny; fu[t * 3 + 2] = nz;
        for (int k = 0; k < 3; k++) {
            const float* p = &m.v[(size_t)m.idx[t * 3 + k] * 8];
            float pl = std::sqrt(p[3] * p[3] + p[4] * p[4] + p[5] * p[5]);
            corners++;
            if (pl < 1e-6f || std::fabs((p[3] * nx + p[4] * ny + p[5] * nz) / pl) > 0.995f) flat++;
        }
    }
    if (onlyIfFlat && flat < corners * 0.9) return false;
    // se agrupan las esquinas por posición (soldadura)
    struct Key { int64_t x, y, z; bool operator==(const Key& o) const { return x == o.x && y == o.y && z == o.z; } };
    struct KH { size_t operator()(const Key& k) const { return (size_t)(k.x * 73856093LL ^ k.y * 19349663LL ^ k.z * 83492791LL); } };
    std::unordered_map<Key, std::vector<uint32_t>, KH> grp;
    grp.reserve(nt * 2);
    auto keyOf = [&](const float* p) { return Key{(int64_t)std::llround(p[0] * 4000.0), (int64_t)std::llround(p[1] * 4000.0), (int64_t)std::llround(p[2] * 4000.0)}; };
    for (size_t t = 0; t < nt; t++)
        for (int k = 0; k < 3; k++) grp[keyOf(&m.v[(size_t)m.idx[t * 3 + k] * 8])].push_back((uint32_t)t);
    float cosT = std::cos(angleDeg * 3.14159265f / 180.f);
    std::vector<float> nv;
    nv.reserve(nt * 3 * 8);
    for (size_t t = 0; t < nt; t++)
        for (int k = 0; k < 3; k++) {
            const float* p = &m.v[(size_t)m.idx[t * 3 + k] * 8];
            float sx = 0, sy = 0, sz = 0;
            for (uint32_t o : grp[keyOf(p)]) {
                float d = fu[o * 3] * fu[t * 3] + fu[o * 3 + 1] * fu[t * 3 + 1] + fu[o * 3 + 2] * fu[t * 3 + 2];
                if (d >= cosT) { sx += fn[o * 3]; sy += fn[o * 3 + 1]; sz += fn[o * 3 + 2]; }
            }
            float l = std::sqrt(sx * sx + sy * sy + sz * sz);
            if (l > 1e-20f) { sx /= l; sy /= l; sz /= l; } else { sx = fu[t * 3]; sy = fu[t * 3 + 1]; sz = fu[t * 3 + 2]; }
            nv.insert(nv.end(), {p[0], p[1], p[2], sx, sy, sz, p[6], p[7]});
        }
    // se vuelven a indexar los vértices repetidos
    struct VK { uint32_t k[8]; bool operator==(const VK& o) const { return std::memcmp(k, o.k, sizeof k) == 0; } };
    struct VH { size_t operator()(const VK& a) const { size_t h = 1469598103934665603ull; for (uint32_t x : a.k) { h ^= x; h *= 1099511628211ull; } return h; } };
    std::unordered_map<VK, uint32_t, VH> seen;
    seen.reserve(nv.size() / 16);
    std::vector<float> ov;
    std::vector<uint32_t> oi;
    oi.reserve(nt * 3);
    for (size_t i = 0; i < nv.size() / 8; i++) {
        VK key;
        std::memcpy(key.k, &nv[i * 8], 32);
        auto it = seen.find(key);
        if (it == seen.end()) { it = seen.emplace(key, (uint32_t)(ov.size() / 8)).first; ov.insert(ov.end(), nv.begin() + i * 8, nv.begin() + i * 8 + 8); }
        oi.push_back(it->second);
    }
    m.v.swap(ov);
    m.idx.swap(oi);
    return true;
}

}  // namespace forge
