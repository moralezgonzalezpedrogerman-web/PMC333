#include "textscript.h"
#include "formula.h"
#include <sstream>

namespace forge {

namespace {

// huecos de un bloque en el orden en que aparecen en su título: 't' = texto, 0..2 = fórmulas
std::vector<int> slotsOf(const OpInfo& oi) {
    std::vector<int> r;
    std::string t = oi.title;
    for (size_t i = 0; i + 2 < t.size(); i++) {
        if (t[i] != '{') continue;
        if (t[i + 1] == 't' && t[i + 2] == '}') r.push_back(3);
        else if (t[i + 1] >= '0' && t[i + 1] <= '2' && t[i + 2] == '}') r.push_back(t[i + 1] - '0');
    }
    return r;
}

std::string quote(const std::string& s) {
    std::string r = "\"";
    for (char c : s) {
        if (c == '"') r += "\\\"";
        else if (c == '\\') r += "\\\\";
        else if (c == '\n') r += "\\n";
        else r += c;
    }
    return r + "\"";
}

}  // namespace

std::string blocksToText(const std::vector<Block>& blocks) {
    std::string out;
    int depth = 0;
    for (const Block& b : blocks) {
        const OpInfo& oi = opInfo(b.op);
        int k = oi.indent;
        int lvl = (k == 2) ? 0 : ((k == -1 || k == 3) ? depth - 1 : depth);
        if (lvl < 0) lvl = 0;
        if (k == 2) { depth = 0; if (!out.empty()) out += "\n"; }
        else if (k == -1) depth = std::max(0, depth - 1);
        else if (k == 1) depth++;
        out += std::string((size_t)lvl * 2, ' ') + oi.key + "(";
        auto sl = slotsOf(oi);
        for (size_t i = 0; i < sl.size(); i++) {
            if (i) out += ", ";
            out += quote(sl[i] == 3 ? b.t : b.f[sl[i]]);
        }
        out += ")\n";
    }
    return out;
}

bool textToBlocks(const std::string& text, std::vector<Block>& out, std::string& err) {
    out.clear();
    err.clear();
    // se parte en instrucciones: saltos de línea o ';' fuera de comillas
    struct Ln { std::string s; int no; };
    std::vector<Ln> lines;
    {
        std::string cur; bool q = false; int no = 1, start = 1;
        for (size_t i = 0; i < text.size(); i++) {
            char c = text[i];
            if (q) { cur += c; if (c == '\\' && i + 1 < text.size()) cur += text[++i]; else if (c == '"') q = false; if (c == '\n') no++; continue; }
            if (c == '"') { q = true; cur += c; continue; }
            if (c == '\n' || c == ';') { lines.push_back({cur, start}); cur.clear(); if (c == '\n') no++; start = no; continue; }
            cur += c;
        }
        lines.push_back({cur, start});
    }
    bool ok = true;
    for (auto& ln : lines) {
        std::string s = ln.s;
        size_t a = s.find_first_not_of(" \t\r");
        if (a == std::string::npos) continue;
        s = s.substr(a);
        if (s[0] == '#' || s.compare(0, 2, "//") == 0) continue;
        while (!s.empty() && (s.back() == ' ' || s.back() == '\t' || s.back() == '\r')) s.pop_back();
        size_t par = s.find('(');
        std::string key = s.substr(0, par);
        while (!key.empty() && key.back() == ' ') key.pop_back();
        for (auto& ch : key) ch = (char)std::tolower((unsigned char)ch);
        const OpInfo* oi = opInfoByKey(key);
        if (!oi) { err += "línea " + std::to_string(ln.no) + ": no conozco el bloque '" + key + "'\n"; ok = false; continue; }
        std::vector<std::string> args;
        if (par != std::string::npos) {
            size_t end = s.rfind(')');
            if (end == std::string::npos || end < par) { err += "línea " + std::to_string(ln.no) + ": falta cerrar el paréntesis\n"; ok = false; continue; }
            std::string in = s.substr(par + 1, end - par - 1);
            std::string cur; bool q = false, any = false;
            for (size_t i = 0; i < in.size(); i++) {
                char c = in[i];
                if (q) {
                    if (c == '\\' && i + 1 < in.size()) { char n = in[++i]; cur += n == 'n' ? '\n' : n; }
                    else if (c == '"') q = false;
                    else cur += c;
                    continue;
                }
                if (c == '"') { q = true; any = true; continue; }
                if (c == ',') { args.push_back(cur); cur.clear(); any = false; continue; }
                if (c == ' ' || c == '\t') { if (!cur.empty()) cur += c; continue; }
                cur += c; any = true;
            }
            if (any || !args.empty() || !cur.empty()) args.push_back(cur);
            for (auto& g : args) while (!g.empty() && g.back() == ' ') g.pop_back();
        }
        Block b;
        b.op = oi->op;
        // valores por defecto del bloque y luego los argumentos dados
        b.t = oi->t ? oi->t : "";
        b.f[0] = oi->f0 ? oi->f0 : ""; b.f[1] = oi->f1 ? oi->f1 : ""; b.f[2] = oi->f2 ? oi->f2 : "";
        auto sl = slotsOf(*oi);
        if (args.size() > sl.size()) { err += "línea " + std::to_string(ln.no) + ": '" + key + "' lleva " + std::to_string(sl.size()) + " dato(s) y pusiste " + std::to_string(args.size()) + "\n"; ok = false; continue; }
        for (size_t i = 0; i < args.size(); i++) { if (sl[i] == 3) b.t = args[i]; else b.f[sl[i]] = args[i]; }
        out.push_back(std::move(b));
    }
    return ok;
}

const char* scriptStyleName(int style) { return style == 1 ? "C#" : style == 2 ? "C++" : "GDScript"; }

std::string aiPromptText(int style) {
    std::ostringstream o;
    const char* ev = style == 1 ? "Start() / Update() / OnTriggerEnter()" : style == 2 ? "BeginPlay() / Tick() / OnOverlap()" : "_ready() / _process(delta) / body_entered";
    o << "Eres un asistente que programa para P-Maker, un creador de juegos con bloques. No uses ningún lenguaje de motor: escribe SOLO en el formato de texto de P-Maker que se describe abajo.\n"
         "Piensa la lógica como lo harías en " << scriptStyleName(style) << " (eventos como " << ev << "), pero tradúcela a los bloques de la lista.\n\n"
         "FORMATO\n"
         "- Una instrucción por línea: nombre(\"dato1\", \"dato2\", ...). Todos los datos van entre comillas dobles.\n"
         "- Los datos van en el mismo orden que aparecen los huecos en la descripción del bloque. {t} es un texto (nombre de variable, objeto, sonido, mensaje) y {0} {1} {2} son fórmulas.\n"
         "- Los eventos (cuando...) van al inicio de línea y todo lo que sigue hasta el siguiente evento es su programa. La sangría es opcional.\n"
         "- Los bloques de control se cierran con su bloque de cierre (fin...). Comentarios con # al inicio.\n"
         "- Las fórmulas aceptan números, variables por su nombre, + - * / y comparaciones (=, <, >, <=, >=) y funciones del editor de fórmulas.\n"
         "- Usa únicamente los bloques de la lista. Si algo no existe, dilo en un comentario y propón una alternativa con bloques.\n\n"
         "BLOQUES DISPONIBLES (nombre → descripción)\n";
    for (int i = 0; i < (int)Op::Count; i++) {
        const OpInfo& oi = opInfo((Op)i);
        if (!oi.key || !*oi.key) continue;
        o << "- " << oi.key << " → " << oi.title << "\n";
    }
    o << "\nEjemplo:\ncuandoempieza()\nsi(\"puntos > 10\")\n  decir(\"¡Ganaste!\")\nfinsi()\n\nAhora escribe el programa que te pido:\n";
    return o.str();
}

}  // namespace forge
