#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace forge {

// Convierte audios que miniaudio no lee (m4a, aac, ogg, opus, amr, 3gp) a WAV al importarlos.
// Android: lo hace MediaCodec (se conecta con audioConvHook). Windows: Media Foundation.
// Devuelve false si no se pudo (el editor avisa).
std::function<bool(const std::string& name, const std::vector<uint8_t>& in, std::vector<uint8_t>& wavOut)>& audioConvHook();
bool audioNeedsConversion(const std::string& name);   // true para m4a/aac/ogg/opus/amr/3gp
bool audioConvertToWav(const std::string& name, const std::vector<uint8_t>& in, std::vector<uint8_t>& wavOut);

// Arma un WAV de 16 bits a partir de muestras PCM16 intercaladas (lo usan los convertidores).
std::vector<uint8_t> makeWav16(const int16_t* samples, size_t count, int channels, int rate);

}  // namespace forge
