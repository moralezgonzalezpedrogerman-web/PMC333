#include "keymap.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace forge {

namespace {
struct KN { const char* n; int k; };
std::vector<KN>& table() {
    static std::vector<KN> t;
    if (!t.empty()) return t;
    static char letters[26][2], digits[10][2], fn[12][4];
    for (int i = 0; i < 26; i++) { letters[i][0] = (char)('A' + i); letters[i][1] = 0; t.push_back({letters[i], ImGuiKey_A + i}); }
    for (int i = 0; i < 10; i++) { digits[i][0] = (char)('0' + i); digits[i][1] = 0; t.push_back({digits[i], ImGuiKey_0 + i}); }
    for (int i = 0; i < 12; i++) { snprintf(fn[i], sizeof fn[i], "F%d", i + 1); t.push_back({fn[i], ImGuiKey_F1 + i}); }
    t.push_back({"Space", ImGuiKey_Space}); t.push_back({"Enter", ImGuiKey_Enter}); t.push_back({"Tab", ImGuiKey_Tab});
    t.push_back({"Up", ImGuiKey_UpArrow}); t.push_back({"Down", ImGuiKey_DownArrow});
    t.push_back({"Left", ImGuiKey_LeftArrow}); t.push_back({"Right", ImGuiKey_RightArrow});
    t.push_back({"LeftShift", ImGuiKey_LeftShift}); t.push_back({"RightShift", ImGuiKey_RightShift});
    t.push_back({"LeftCtrl", ImGuiKey_LeftCtrl}); t.push_back({"RightCtrl", ImGuiKey_RightCtrl});
    t.push_back({"LeftAlt", ImGuiKey_LeftAlt}); t.push_back({"RightAlt", ImGuiKey_RightAlt});
    t.push_back({"Backspace", ImGuiKey_Backspace}); t.push_back({"Comma", ImGuiKey_Comma}); t.push_back({"Period", ImGuiKey_Period});
    t.push_back({"MouseLeft", ImGuiKey_MouseLeft}); t.push_back({"MouseRight", ImGuiKey_MouseRight}); t.push_back({"MouseMiddle", ImGuiKey_MouseMiddle});
    return t;
}
const char* kLabels[KA_Count] = {"Adelante", "Atrás", "Izquierda", "Derecha", "Saltar", "Correr", "Agacharse", "Recargar", "Cambiar arma", "Interactuar", "Linterna", "Disparar"};
const char* kDefaults[KA_Count] = {"W", "S", "A", "D", "Space", "LeftShift", "LeftCtrl", "R", "Q", "E", "F", "MouseLeft"};
}  // namespace

const char* keyActLabel(int a) { return a >= 0 && a < KA_Count ? kLabels[a] : ""; }
const char* keyActDefault(int a) { return a >= 0 && a < KA_Count ? kDefaults[a] : ""; }

bool keyFromName(const std::string& name, int& key) {
    for (auto& e : table()) if (name == e.n) { key = e.k; return true; }
    return false;
}
const char* keyToName(int k) {
    for (auto& e : table()) if (e.k == k) return e.n;
    return nullptr;
}
int keyCaptureNext() {
    for (auto& e : table())
        if (ImGui::IsKeyPressed((ImGuiKey)e.k, false)) return e.k;
    return 0;
}
std::string keyEffective(const Project& p, int a) {
    if (a < 0 || a >= KA_Count) return "";
    int k;
    if (!p.keys[a].empty() && keyFromName(p.keys[a], k)) return p.keys[a];
    return kDefaults[a];
}

static float axis(ImGuiKey k) {
    ImGuiKeyData* d = ImGui::GetKeyData(k);
    return d ? d->AnalogValue : 0.f;
}

void pollKeys(const Project& p, Input& in, bool is3d, bool mouseShoot, bool gamepad) {
    ImGuiIO& io = ImGui::GetIO();
    bool typing = io.WantTextInput;
    if (typing) return;
    int k[KA_Count];
    for (int a = 0; a < KA_Count; a++) {
        k[a] = 0;
        keyFromName(keyEffective(p, a), k[a]);
    }
    auto down = [&](int a) {
        if (!k[a]) return false;
        if (k[a] == ImGuiKey_MouseLeft && a == KA_Shoot && !mouseShoot) return false;
        return ImGui::IsKeyDown((ImGuiKey)k[a]);
    };
    auto press = [&](int a) { return k[a] && ImGui::IsKeyPressed((ImGuiKey)k[a], false); };
    float mx = (down(KA_Right) ? 1.f : 0.f) - (down(KA_Left) ? 1.f : 0.f);
    float my = (down(KA_Fwd) ? 1.f : 0.f) - (down(KA_Back) ? 1.f : 0.f);
    bool jump = down(KA_Jump), sprint = down(KA_Sprint), crouch = down(KA_Crouch), shoot = down(KA_Shoot);
    bool reload = press(KA_Reload), weapon = press(KA_Weapon), flash = press(KA_Flash), inter = press(KA_Interact);
    if (gamepad) {  // mapeo automatico del control: palanca izq = mover, A saltar, X/gatillo disparar, B agacharse, LB correr
        float gx = axis(ImGuiKey_GamepadLStickRight) - axis(ImGuiKey_GamepadLStickLeft);
        float gy = axis(ImGuiKey_GamepadLStickUp) - axis(ImGuiKey_GamepadLStickDown);
        gx += (ImGui::IsKeyDown(ImGuiKey_GamepadDpadRight) ? 1.f : 0.f) - (ImGui::IsKeyDown(ImGuiKey_GamepadDpadLeft) ? 1.f : 0.f);
        gy += (ImGui::IsKeyDown(ImGuiKey_GamepadDpadUp) ? 1.f : 0.f) - (ImGui::IsKeyDown(ImGuiKey_GamepadDpadDown) ? 1.f : 0.f);
        mx += gx; my += gy;
        jump |= ImGui::IsKeyDown(ImGuiKey_GamepadFaceDown);
        shoot |= ImGui::IsKeyDown(ImGuiKey_GamepadFaceLeft) || axis(ImGuiKey_GamepadR2) > 0.4f;
        crouch |= ImGui::IsKeyDown(ImGuiKey_GamepadFaceRight);
        sprint |= ImGui::IsKeyDown(ImGuiKey_GamepadL1) || axis(ImGuiKey_GamepadL2) > 0.4f;
        weapon |= ImGui::IsKeyPressed(ImGuiKey_GamepadFaceUp, false);
        reload |= ImGui::IsKeyPressed(ImGuiKey_GamepadR1, false);
        inter |= ImGui::IsKeyPressed(ImGuiKey_GamepadFaceDown, false) && !is3d;
        float lx = axis(ImGuiKey_GamepadRStickRight) - axis(ImGuiKey_GamepadRStickLeft);
        float ly = axis(ImGuiKey_GamepadRStickDown) - axis(ImGuiKey_GamepadRStickUp);
        if (std::fabs(lx) > 0.15f) in.lookX += lx * 0.04f;
        if (std::fabs(ly) > 0.15f) in.lookY += ly * 0.04f;
    }
    in.moveX = std::max(-1.f, std::min(1.f, in.moveX + mx));
    in.moveY = std::max(-1.f, std::min(1.f, in.moveY + my));
    if (is3d && (ImGui::IsMouseDown(ImGuiMouseButton_Right) || axis(ImGuiKey_GamepadL2) > 0.4f)) in.aim = true;   // apuntar: clic derecho / gatillo izquierdo
    in.jump |= jump; in.sprint |= sprint; in.crouch |= crouch; in.shoot |= shoot && is3d;
    in.reload |= reload; in.nextWeapon |= weapon; in.flash |= flash;
    if (inter && !is3d) { in.tap = true; in.tapX = 0.5f; in.tapY = 0.5f; }
    else if (inter) in.tap = true;
    // escenas 2D: los mismos nombres que los botones tactiles
    if (!is3d && p.ctl2dEff() > 0) {
        if (mx < -0.3f) in.buttons.push_back("Izquierda");
        if (mx > 0.3f) in.buttons.push_back("Derecha");
        if (p.ctl2dEff() != 3 && my > 0.3f) in.buttons.push_back("Arriba");
        if (p.ctl2dEff() != 3 && my < -0.3f) in.buttons.push_back("Abajo");
        if (jump || ImGui::IsKeyDown(ImGuiKey_Z) || ImGui::IsKeyDown(ImGuiKey_J)) in.buttons.push_back("A");
        if (ImGui::IsKeyDown(ImGuiKey_X) || ImGui::IsKeyDown(ImGuiKey_K) || (shoot && mouseShoot && false)) in.buttons.push_back("B");
    }
}

}  // namespace forge
