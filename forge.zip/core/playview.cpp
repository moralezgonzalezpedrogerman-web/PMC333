#include "playview.h"
#include <cstdio>
#include <map>
#include <chrono>
#include <thread>
#include "imgui.h"
#include "renderer.h"
#include "brand.h"
#include "keymap.h"

namespace forge {

void PlayView::start(Project p) {
    dynScale_ = 1.f; dtAvg_ = 1.f / 60.f; dynT_ = upT_ = 0.f; warmFor_ = nullptr;
    tSum_ = tWorst_ = tTime_ = 0; tSlow_ = 0; tN_ = 0;
    splashT = splash ? 0.f : -1.f;
    hud.setup(p);
    ctl.hud = &hud;
    ctl.reset();
    if (audio) {
        audio->stopMusic();
        audio->setAssets(p.assets);  // los buffers de los vectores sobreviven al mover el proyecto
        game.onSound = [this](const std::string& n) { audio->play(n); };
        game.onSound3 = [this](const std::string& n, float v, float pn) { audio->play(n, v, pn); };
        game.onMusic = [this](const std::string& n, bool on) { if (on) audio->music(n); else audio->stopMusic(); };
        game.onStopSounds = [this]() { audio->stopAll(); };
        game.soundLen = [this](const std::string& n) { return audio->length(n); };
        game.onVolume = [this](float v) { audio->setVolume(v); };
        audio->setVolume(1.f);
    } else {
        game.onSound = nullptr;
        game.onSound3 = nullptr;
        game.onMusic = nullptr;
        game.onStopSounds = nullptr;
        game.soundLen = nullptr;
        game.onVolume = nullptr;
    }
    game.devVars.clear();
    game.onDevSave = nullptr;
    if (!devPath.empty()) {
        std::string path = devPath;
        if (FILE* f = std::fopen(path.c_str(), "rb")) {
            std::string all; char buf[1024]; size_t n;
            while ((n = std::fread(buf, 1, sizeof buf, f)) > 0) all.append(buf, n);
            std::fclose(f);
            size_t i = 0;
            while (i < all.size()) {
                size_t e = all.find('\n', i); if (e == std::string::npos) e = all.size();
                std::string ln = all.substr(i, e - i); i = e + 1;
                size_t t = ln.find('\t'); if (t == std::string::npos) continue;
                auto un = [](std::string s) { std::string r; for (size_t k = 0; k < s.size(); k++) { if (s[k] == '\\' && k + 1 < s.size()) { k++; r += s[k] == 'n' ? '\n' : s[k] == 't' ? '\t' : s[k]; } else r += s[k]; } return r; };
                game.devVars[un(ln.substr(0, t))] = un(ln.substr(t + 1));
            }
        }
        game.onDevSave = [path](const std::map<std::string, std::string>& m) {
            auto en = [](const std::string& s) { std::string r; for (char c : s) { if (c == '\n') r += "\\n"; else if (c == '\t') r += "\\t"; else if (c == '\\') r += "\\\\"; else r += c; } return r; };
            if (FILE* f = std::fopen(path.c_str(), "wb")) {
                for (auto& kv : m) { std::string l = en(kv.first) + "\t" + en(kv.second) + "\n"; std::fwrite(l.data(), 1, l.size(), f); }
                std::fclose(f);
            }
        };
    }
    game.onVibrate = onVibrate;
    game.onSpeak = onSpeak;
    game.onFlash = onFlash;
    game.onCamera = onCamera;
    game.camFrame = camFrame;
    game.load(std::move(p));
}

void PlayView::frame(Renderer* r, int w, int h, float dt, const Input* direct) {
    if (splashT >= 0.f) {  // pantalla de inicio: el juego espera a que termine
        splashT += dt;
        if (!r || splashT >= kSplashSeconds) splashT = -1.f;
        else {
            if (r) r->clear(w, h, 1.f, 1.f, 1.f);
            drawSplash(ImGui::GetForegroundDrawList(), r, w, h, splashT);
            ctl.reset();
            return;
        }
    }
    ctl.w = w;
    ctl.h = h;
    ctl.is3d = game.sc && game.sc->is3d;
    if (sensors) { float sv[7]; if (sensors(sv)) { for (int k = 0; k < 3; k++) { game.dev.accel[k] = sv[k]; game.dev.gyro[k] = sv[4 + k]; } game.dev.compass = sv[3]; } }
    game.proj.ctl2dNow = (game.sc && game.sc->ctl2d >= 0) ? game.sc->ctl2d : -1;   // controles de ESTA escena
    if (!ctl.is3d && hud.ctl2d() != game.proj.ctl2dEff()) { hud.setup(game.proj, hud.mode); ctl.reset(); }
    Input in = direct ? *direct : ctl.consume();
    if (keys) pollKeys(game.proj, in, ctl.is3d, !showButtons || direct, gamepad);
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    game.update(dt, in, aspect);
    {   // v11.5: los botones cambian al acercarse a un auto o al subirse a él
        int want = game.carIdx >= 0 ? 2 : (game.nearCar >= 0 ? 1 : 0);
        if (want != hud.mode && game.sc && game.sc->is3d) { hud.setup(game.proj, want); ctl.reset(); }
    }
    const auto& pf = game.proj.perf;
    if (r && pf.warm && game.sc && warmFor_ != game.sc) { warmFor_ = game.sc; r->warmup(game); }   // precarga: nada se carga a mitad de la partida
    {   // resolución dinámica y ahorro: se mide el tiempo real de cada cuadro
        const float tgt = 1.f / (pf.saver ? 30.f : (float)std::max(20, pf.dynTarget));
        const float maxS = pf.saver ? 0.8f : 1.f;
        if (dt > 0.f && dt < 0.5f) {
            dtAvg_ = dtAvg_ * 0.93f + dt * 0.07f;
            tN_++; tSum_ += dt; tTime_ += dt; tWorst_ = std::max(tWorst_, (double)dt);
            if (dt > std::max(0.034f, tgt * 1.6f)) tSlow_++;
        }
        if (pf.dynRes || pf.saver) {
            dynT_ += dt; upT_ += dt;
            if (dynT_ > 0.5f && dtAvg_ > tgt * 1.2f) { dynScale_ = std::max(0.5f, dynScale_ - 0.06f); dynT_ = 0.f; upT_ = 0.f; }
            else if (upT_ > 3.f && dtAvg_ < tgt * 1.06f) { dynScale_ = std::min(maxS, dynScale_ + 0.03f); upT_ = 0.f; }
            dynScale_ = std::min(dynScale_, maxS);
        } else dynScale_ = 1.f;
    }
    if (r) {
        int rh = game.proj.resH;
        if (dynScale_ < 0.995f) { int base = (rh > 0 && rh < h) ? rh : h; rh = std::max(240, (int)(base * dynScale_)); r->renderScaled(game, w, h, rh); }
        else if (useRes || game.proj.gfxFilter) r->renderScaled(game, w, h, rh);
        else r->render(game, w, h);
    }
    hud.draw(ImGui::GetForegroundDrawList(), game, r, w, h, showButtons);
    if ((game.proj.perf.fpsOn && game.proj.perf.fps > 0) || game.proj.perf.saver) {   // tope de FPS: se espera lo que falte del cuadro (ahorra batería)
        using clk = std::chrono::steady_clock;
        static clk::time_point last = clk::now();
        int capFps = game.proj.perf.saver ? 30 : game.proj.perf.fps;
        if (game.proj.perf.saver && game.proj.perf.fpsOn) capFps = std::min(capFps, game.proj.perf.fps);
        auto target = std::chrono::microseconds(1000000 / std::max(1, capFps));
        auto now = clk::now();
        if (now - last < target) std::this_thread::sleep_for(target - (now - last));
        last = clk::now();
    }
}

void PlayView::flushTelemetry() {
    if (telemPath.empty() || tN_ < 30) return;
    if (FILE* f = std::fopen(telemPath.c_str(), "ab")) {
        std::fprintf(f, "partida: %.0f s, FPS medio %.1f, peor cuadro %.0f ms, cuadros lentos %ld de %ld, resolucion final %.0f%%\n",
                     tTime_, tN_ / std::max(0.001, tSum_), tWorst_ * 1000.0, tSlow_, tN_, dynScale_ * 100.f);
        std::fclose(f);
    }
    tN_ = 0; tSum_ = tWorst_ = tTime_ = 0; tSlow_ = 0;
}

}  // namespace forge
