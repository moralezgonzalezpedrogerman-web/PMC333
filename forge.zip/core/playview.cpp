#include "playview.h"
#include <cstdio>
#include <map>
#include "imgui.h"
#include "renderer.h"
#include "brand.h"
#include "keymap.h"

namespace forge {

void PlayView::start(Project p) {
    splashT = splash ? 0.f : -1.f;
    hud.setup(p);
    ctl.hud = &hud;
    ctl.reset();
    if (audio) {
        audio->stopMusic();
        audio->setAssets(p.assets);  // los buffers de los vectores sobreviven al mover el proyecto
        game.onSound = [this](const std::string& n) { audio->play(n); };
        game.onMusic = [this](const std::string& n, bool on) { if (on) audio->music(n); else audio->stopMusic(); };
        game.onStopSounds = [this]() { audio->stopAll(); };
        game.soundLen = [this](const std::string& n) { return audio->length(n); };
        game.onVolume = [this](float v) { audio->setVolume(v); };
        audio->setVolume(1.f);
    } else {
        game.onSound = nullptr;
        game.onMusic = nullptr;
        game.onStopSounds = nullptr;
        game.soundLen = nullptr;
        game.onVolume = nullptr;
    }
    game.devVars.clear();
    game.onDevSave = nullptr;
    if (!devPath.empty()) {
        std::string path = devPath;
        if (FILE* f = std::fopen(path.c_str(), "rb")) {
            std::string all; char buf[1024]; size_t n;
            while ((n = std::fread(buf, 1, sizeof buf, f)) > 0) all.append(buf, n);
            std::fclose(f);
            size_t i = 0;
            while (i < all.size()) {
                size_t e = all.find('\n', i); if (e == std::string::npos) e = all.size();
                std::string ln = all.substr(i, e - i); i = e + 1;
                size_t t = ln.find('\t'); if (t == std::string::npos) continue;
                auto un = [](std::string s) { std::string r; for (size_t k = 0; k < s.size(); k++) { if (s[k] == '\\' && k + 1 < s.size()) { k++; r += s[k] == 'n' ? '\n' : s[k] == 't' ? '\t' : s[k]; } else r += s[k]; } return r; };
                game.devVars[un(ln.substr(0, t))] = un(ln.substr(t + 1));
            }
        }
        game.onDevSave = [path](const std::map<std::string, std::string>& m) {
            auto en = [](const std::string& s) { std::string r; for (char c : s) { if (c == '\n') r += "\\n"; else if (c == '\t') r += "\\t"; else if (c == '\\') r += "\\\\"; else r += c; } return r; };
            if (FILE* f = std::fopen(path.c_str(), "wb")) {
                for (auto& kv : m) { std::string l = en(kv.first) + "\t" + en(kv.second) + "\n"; std::fwrite(l.data(), 1, l.size(), f); }
                std::fclose(f);
            }
        };
    }
    game.onVibrate = onVibrate;
    game.onSpeak = onSpeak;
    game.onFlash = onFlash;
    game.load(std::move(p));
}

void PlayView::frame(Renderer* r, int w, int h, float dt, const Input* direct) {
    if (splashT >= 0.f) {  // pantalla de inicio: el juego espera a que termine
        splashT += dt;
        if (!r || splashT >= kSplashSeconds) splashT = -1.f;
        else {
            if (r) r->clear(w, h, 1.f, 1.f, 1.f);
            drawSplash(ImGui::GetForegroundDrawList(), r, w, h, splashT);
            ctl.reset();
            return;
        }
    }
    ctl.w = w;
    ctl.h = h;
    ctl.is3d = game.sc && game.sc->is3d;
    Input in = direct ? *direct : ctl.consume();
    if (keys) pollKeys(game.proj, in, ctl.is3d, !showButtons || direct, gamepad);
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    game.update(dt, in, aspect);
    {   // v11.5: los botones cambian al acercarse a un auto o al subirse a él
        int want = game.carIdx >= 0 ? 2 : (game.nearCar >= 0 ? 1 : 0);
        if (want != hud.mode && game.sc && game.sc->is3d) { hud.setup(game.proj, want); ctl.reset(); }
    }
    if (r) { if (useRes || game.proj.gfxFilter) r->renderScaled(game, w, h, game.proj.resH); else r->render(game, w, h); }
    hud.draw(ImGui::GetForegroundDrawList(), game, r, w, h, showButtons);
}

}  // namespace forge
