#pragma once
#include "scene.h"
#include <string>
#include <vector>

namespace forge {

// Programar con texto: cada bloque es una línea  nombre("texto", "formula1", ...)  y la sangría la pone el programa.
// Los argumentos van en el mismo orden que los huecos del bloque. Líneas vacías y comentarios (# o //) se ignoran.
// Se puede separar instrucciones con ';' fuera de las comillas.
std::string blocksToText(const std::vector<Block>& blocks);

// Lee el texto y devuelve los bloques. Si hay errores, 'err' lleva "línea N: ..." (una por línea) y devuelve false;
// los bloques válidos se devuelven igual.
bool textToBlocks(const std::string& text, std::vector<Block>& out, std::string& err);

// Instrucciones listas para pegar a una IA (estilo = 0 GDScript, 1 C#, 2 C++): explican el formato y todos los bloques.
std::string aiPromptText(int style);
const char* scriptStyleName(int style);

}  // namespace forge
