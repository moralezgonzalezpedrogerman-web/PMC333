// v10.7: multijugador local por UDP (Wi-Fi, punto de acceso/hotspot o red local, sin internet).
// Todos los dispositivos que abren el mismo juego en la misma red se ven solos: no hace falta servidor.
#pragma once
#include <map>
#include <string>
#include <vector>

namespace forge {

struct NetPeer {
    unsigned id = 0;
    std::string name, scene;
    float x = 0, y = 0, z = 0, yaw = 0;
    double seen = 0;
};

class Net {
public:
    ~Net() { stop(); }
    bool start(const std::string& room, const std::string& myName);   // abre el socket y empieza a anunciarse
    void stop();
    bool active() const { return sock_ >= 0; }
    void tick(double now, float x, float y, float z, float yaw, const std::string& scene);
    void sendMsg(const std::string& msg);
    void sendVar(const std::string& name, const std::string& value);
    // lo que llego desde la ultima vez
    std::vector<std::string> takeMsgs() { auto m = std::move(msgs_); msgs_.clear(); return m; }
    std::vector<std::pair<std::string, std::string>> takeVars() { auto m = std::move(vars_); vars_.clear(); return m; }
    int joined() { int j = joined_; joined_ = 0; return j; }   // jugadores nuevos
    int left() { int j = left_; left_ = 0; return j; }
    const std::map<unsigned, NetPeer>& peers() const { return peers_; }
    bool isHost() const;
    unsigned id() const { return id_; }
    const std::string& room() const { return room_; }
    // para pruebas: usa otro puerto
    void setPort(int p) { port_ = p; }
private:
    void sendRaw(const std::string& s);
    int sock_ = -1;
    int port_ = 47777;
    unsigned id_ = 0;
    std::string room_, name_;
    double lastSend_ = -1;
    std::map<unsigned, NetPeer> peers_;
    std::vector<std::string> msgs_;
    std::vector<std::pair<std::string, std::string>> vars_;
    int joined_ = 0, left_ = 0;
};

}  // namespace forge
