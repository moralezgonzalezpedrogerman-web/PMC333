#include <chrono>
#include <unordered_map>
#include "renderer.h"
#include <algorithm>
#include "model.h"
#include <cmath>
#include <cstring>
#include <functional>
#include <cstdlib>
#include <cstdio>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#include "stb_image.h"

#ifdef FORGE_GLES
#define SHV "#version 300 es\nprecision highp float;\nprecision highp int;\nprecision highp sampler2D;\nprecision highp sampler2DShadow;\n"
#else
#define SHV "#version 330 core\n"
#endif

namespace forge {

// ---------------------------------------------------------------- shaders
static const char* kMainVS = SHV R"(
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aN;
layout(location=2) in vec2 aUV;
uniform mat4 uVP, uM, uLVP;
uniform int uUV1;
uniform float uTile, uTime, uSway;
out vec3 vN; out vec3 vWP; out vec2 vUV; out vec4 vLP;
void main(){
  vec4 wp = uM * vec4(aPos, 1.0);
  if (uSway > 0.0) {
    float k = 1.0 - aUV.y;
    k = k * k;
    wp.x += sin(uTime * 1.9 + wp.x * 0.9 + wp.z * 0.6) * uSway * k;
    wp.z += cos(uTime * 1.5 + wp.z * 0.8 + wp.x * 0.3) * uSway * 0.6 * k;
  }
  vWP = wp.xyz;
  vN = normalize(mat3(uM) * aN);
  if (uUV1 == 1) vUV = aUV;
  else {
    vec3 n = abs(vN);
    vec2 uv = (n.y > 0.5) ? wp.xz : ((n.x > 0.5) ? wp.zy : wp.xy);
    vUV = uv / uTile;
  }
  vLP = uLVP * wp;
  gl_Position = uVP * wp;
}
)";

static const char* kMainFS = SHV R"(
in vec3 vN; in vec3 vWP; in vec2 vUV; in vec4 vLP;
out vec4 oColor;
uniform sampler2D uTex;
uniform sampler2DShadow uSh;
uniform samplerCube uEnv;
uniform int uEnvOn;
uniform vec3 uProbePos;
uniform vec4 uColor;
uniform vec3 uSunDir, uSunCol, uSkyTop, uSkyBot, uCam;
uniform float uRBlur;
uniform float uAmb, uFog, uTexel, uRefl, uTime, uGS, uShAmt;
uniform int uSpotOn, uCookieOn;
uniform vec3 uSpotPos, uSpotDir, uSpotCol;
uniform float uSpotCone, uSpotRange, uSpotTan;
uniform sampler2D uCookie;
uniform vec3 uTint, uFogCol, uColor2;
uniform int uUnlit, uNL, uShOn, uVeg, uRtx;
uniform float uGI, uSpec, uTone, uEv;
uniform int uSoft, uWS;
uniform vec4 uPL[4];
uniform vec3 uPC[4];
vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
void main(){
  vec4 t;
  if (uVeg == 3) {   // pintura de suelo: la textura sigue al mundo y la pincelada tiene borde suave
    vec4 tx = texture(uTex, vWP.xz * uGS);
    float m = 1.0 - smoothstep(0.28, 0.5, length(vUV - 0.5));
    t = vec4(tx.rgb * uColor.rgb, tx.a * m);
    if (t.a < 0.01) discard;
  } else if (uVeg == 1) {
    vec4 tx = texture(uTex, vUV);
    t = vec4(tx.rgb * mix(uColor2, uColor.rgb, clamp(vUV.y, 0.0, 1.0)), tx.a);
    if (t.a < 0.45) discard;
    t.a = 1.0;
  } else {
    t = texture(uTex, vUV) * uColor;
    if (t.a < 0.08) discard;
  }
  if (uUnlit == 1) { oColor = t; return; }
  vec3 n = normalize(vN);
  if (uVeg == 2) {
    float wk = uWS == 1 ? 0.012 : uWS == 3 ? 0.14 : (uWS == 2 || uWS == 5) ? 0.09 : uWS == 4 ? 0.04 : uWS == 6 ? 0.02 : 0.05;
    vec3 wv = vec3(sin(vWP.x * 0.9 + uTime * 1.3) + sin(vWP.z * 1.7 - uTime * 0.9), 0.0,
                   cos(vWP.z * 1.1 + uTime * 1.1) + cos(vWP.x * 1.9 + uTime * 0.7));
    if (uWS == 2 || uWS == 3 || uWS == 5)   // olas con más detalle (3 octavas)
      wv += vec3(sin(vWP.x * 2.7 - uTime * 2.1 + vWP.z * 1.3) + sin(vWP.z * 4.1 + uTime * 1.7), 0.0,
                 cos(vWP.z * 3.3 - uTime * 1.9 - vWP.x * 0.8) + cos(vWP.x * 5.3 + uTime * 2.3)) * 0.6
          + vec3(sin(vWP.x * 9.0 + uTime * 3.1 + sin(vWP.z * 7.0)), 0.0, cos(vWP.z * 8.3 - uTime * 2.7 + sin(vWP.x * 6.0))) * 0.25;
    n = normalize(n + wk * wv);
  }
  float ndl = max(dot(n, -uSunDir), 0.0);
  vec3 p = vLP.xyz / vLP.w * 0.5 + 0.5;
  float sh = 1.0;
  if (uShOn == 1 && p.z <= 1.0 && p.x > 0.0 && p.x < 1.0 && p.y > 0.0 && p.y < 1.0) {
    float b = 0.0008 + 0.0024 * (1.0 - ndl);   // sesgo según la inclinación: evita las manchas oscuras (acné de sombra) en superficies curvas
    if (uRtx == 1) {  // sombras suaves: 9 muestras
      sh = 0.0;
      for (int i = -1; i <= 1; i++)
        for (int j = -1; j <= 1; j++)
          sh += texture(uSh, vec3(p.xy + uTexel * 1.7 * vec2(float(i), float(j)), p.z - b));
      sh /= 9.0;
    } else if (uSoft > 0) {   // sombras suaves: disco de Poisson girado por pixel
      float ang = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
      float ca = cos(ang), sa = sin(ang);
      sh = 0.0;
      int nS = uSoft >= 2 ? 16 : 8;
      for (int i = 0; i < 16; i++) {
        if (i >= nS) break;
        float fi = float(i) + 0.5;
        float rr = sqrt(fi / float(nS)) * (uSoft >= 2 ? 2.4 : 2.0);
        float th = fi * 2.399963;
        vec2 o = vec2(cos(th), sin(th)) * rr;
        o = vec2(ca * o.x - sa * o.y, sa * o.x + ca * o.y);
        sh += texture(uSh, vec3(p.xy + uTexel * o, p.z - b));
      }
      sh /= float(nS);
    } else {
      sh = 0.25 * (texture(uSh, vec3(p.xy + uTexel * vec2(-0.5, -0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2( 0.5, -0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2(-0.5,  0.5), p.z - b))
                 + texture(uSh, vec3(p.xy + uTexel * vec2( 0.5,  0.5), p.z - b)));
    }
  }
  vec3 hemi = mix(uSkyBot * 0.5, uSkyTop, n.y * 0.5 + 0.5) * uAmb * 1.5;
  float shv = 1.0 - (1.0 - sh) * min(uShAmt, 1.0);                                   // sombras mas claras
  hemi *= 1.0 - clamp(uShAmt - 1.0, 0.0, 1.0) * (1.0 - sh) * 0.75;                   // sombras mas oscuras
  if (uGI > 0.0 && uVeg == 0) {   // iluminación global falsa pero barata: rebote del suelo, relleno del lado sombra, sombras con color de cielo y oclusión en la base de las paredes
    vec3 sunH = normalize(vec3(-uSunDir.x, 0.0, -uSunDir.z) + vec3(0.0001));
    vec3 bounce = (uSunCol * 0.45 + uSkyBot * 0.55) * max(-n.y, 0.0) * 0.35;
    vec3 fill = uSunCol * 0.16 * max(dot(n, -sunH), 0.0) * (1.0 - ndl);
    vec3 skyTint = normalize(uSkyTop + vec3(0.05));
    hemi = mix(hemi, hemi * skyTint * 1.7, (1.0 - sh) * 0.45 * uGI);
    float ao = mix(1.0, mix(0.55, 1.0, smoothstep(0.0, 1.1, vWP.y)), (1.0 - abs(n.y)) * uGI);
    hemi = (hemi + (bounce + fill) * uGI) * ao;
  }
  vec3 light = hemi + uSunCol * ndl * shv;
  if (uSpotOn == 1) {   // linterna
    vec3 d = vWP - uSpotPos;
    float dist = max(length(d), 0.05);
    vec3 L = d / dist;
    float cd = dot(L, uSpotDir);
    float cone = smoothstep(uSpotCone, mix(uSpotCone, 1.0, 0.45), cd);
    float at = clamp(1.0 - dist / uSpotRange, 0.0, 1.0);
    float pat = 1.0;
    if (uCookieOn == 1 && cd > 0.05) {
      vec3 rt = normalize(cross(uSpotDir, vec3(0.0, 1.0, 0.0)));
      vec3 up = cross(rt, uSpotDir);
      vec2 q = vec2(dot(d, rt), dot(d, up)) / (dot(d, uSpotDir) * uSpotTan);
      pat = (abs(q.x) < 1.0 && abs(q.y) < 1.0) ? texture(uCookie, q * 0.5 + 0.5).r : 0.0;
    }
    float nl = clamp(dot(n, -L), 0.0, 1.0) * 0.85 + 0.15;
    light += uSpotCol * nl * cone * at * at * pat * 1.6;
  }
  for (int i = 0; i < 4; i++) {
    if (i >= uNL) break;
    vec3 d = uPL[i].xyz - vWP;
    float dist = length(d);
    float at = clamp(1.0 - dist / uPL[i].w, 0.0, 1.0);
    light += uPC[i] * max(dot(n, d / max(dist, 0.001)), 0.0) * at * at * 1.5;
  }
  float wa = 1.0;
  vec3 c = t.rgb * light * uTint;
  vec3 v = normalize(uCam - vWP);
  float fresnel = pow(1.0 - max(dot(n, v), 0.0), 3.0);
  if (uVeg == 2) {
    vec3 r = reflect(-v, n);
    vec3 env = mix(uSkyBot * 0.7, uSkyTop, clamp(r.y, 0.0, 1.0));
    float ndv = max(dot(n, v), 0.0);
    float F5 = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
    float sd = max(dot(r, -uSunDir), 0.0);
    if (uWS == 1) {   // caricatura / anime: colores planos, espuma blanca y brillo en bloque
      float a1 = sin(vWP.x * 0.8 + sin(vWP.z * 0.6 + uTime * 0.6) * 1.6 + uTime * 0.8) * sin(vWP.z * 0.9 - uTime * 0.5 + sin(vWP.x * 0.5) * 1.4);
      float tone = step(0.0, a1);
      c = t.rgb * mix(0.88, 1.12, tone) * (0.75 + 0.25 * step(0.3, light.g));
      c = mix(c, vec3(1.0), step(0.8, a1) * 0.9);
      c = mix(c, mix(uSkyBot, vec3(1.0), 0.5), step(0.55, 1.0 - ndv) * 0.35);
      c += uSunCol * step(0.985, sd) * 0.9;
    } else if (uWS == 2) {   // realista
      vec3 deep = t.rgb * 0.45 * light;
      vec3 e2 = env + uSunCol * (pow(sd, 400.0) * 4.0 + pow(sd, 40.0) * 0.25);
      c = mix(deep, e2, clamp(F5 * 1.1 + 0.04, 0.0, 0.96));
      c += uSunCol * smoothstep(0.93, 1.0, sin(vWP.x * 21.0 + uTime * 3.0) * sin(vWP.z * 19.0 - uTime * 2.4)) * 0.18 * ndv;
    } else if (uWS == 3) {   // oscuro y cinematográfico (estilo ciudad de noche / puerto)
      vec3 deep = t.rgb * vec3(0.2, 0.28, 0.32) * light;
      env = pow(env, vec3(1.35)) * vec3(0.8, 0.95, 1.1);
      vec3 e2 = env + uSunCol * (pow(sd, 30.0) * 1.8 + pow(sd, 350.0) * 6.0);
      c = mix(deep, e2, clamp(0.18 + F5 * 1.2, 0.0, 0.97));
      c += vec3(0.7, 0.85, 1.0) * smoothstep(0.88, 1.0, sin(vWP.x * 5.0 + uTime * 1.2 + sin(vWP.z * 3.0)) * sin(vWP.z * 4.0 - uTime)) * 0.12;
    } else if (uWS == 4) {   // cristal transparente
      c = mix(t.rgb * light * 0.55, env, clamp(0.1 + F5, 0.0, 0.85)) + uSunCol * pow(sd, 150.0) * 1.2;
      wa = mix(0.22, 1.0, F5 * 0.8 + 0.1);
    } else if (uWS == 5) {   // tropical: turquesa con cáusticas
      vec2 q = vWP.xz * 1.4;
      float cs = abs(sin(q.x + sin(q.y * 1.3 + uTime) * 1.1 + uTime * 0.7)) * abs(sin(q.y * 1.2 + sin(q.x * 0.9 - uTime * 0.8) * 1.3));
      c = t.rgb * light * (1.0 + 0.9 * pow(1.0 - cs, 6.0)) + vec3(0.05, 0.12, 0.1);
      c = mix(c, env, clamp(0.12 + 0.55 * F5, 0.0, 0.8)) + uSunCol * pow(sd, 120.0);
      wa = mix(0.62, 1.0, F5);
    } else if (uWS == 6) {   // pantano: turbio y casi opaco
      float mk = 0.5 + 0.5 * sin(vWP.x * 1.7 + uTime * 0.3) * sin(vWP.z * 1.5 - uTime * 0.25);
      c = mix(t.rgb * light * 0.55, t.rgb * vec3(0.9, 1.1, 0.5) * light * 0.7, mk);
      c = mix(c, env, 0.1 + 0.25 * F5);
      wa = 1.0;
    } else {
      env += uSunCol * pow(sd, 120.0) * 1.5;
      c = mix(c, env, clamp(0.28 + 0.62 * fresnel, 0.0, 0.92));
    }
  } else if (uVeg == 0 && (uRefl > 0.0 || uRtx == 1)) {
    vec3 r = reflect(-v, n);
    float up = clamp(r.y * 0.5 + 0.5, 0.0, 1.0);
    vec3 env = mix(uSkyBot * 0.55, uSkyTop * 0.9, up * up);
    env *= mix(0.4, 1.0, smoothstep(-0.25, 0.25, r.y));          // abajo del horizonte: suelo oscuro
    env += uSunCol * pow(max(dot(r, -uSunDir), 0.0), 90.0) * 0.9;  // brillo pequeño del sol
    env *= mix(vec3(1.0), t.rgb * 1.5, 0.6);                      // el reflejo toma el color del material
    float amt = uRefl > 0.0 ? clamp((0.03 + 0.5 * fresnel) * uRefl, 0.0, 0.5) : 0.0;
    if (uRtx == 1) amt = max(amt, 0.04 + 0.22 * fresnel);
    vec3 envP = env;
    if (uEnvOn == 1) {   // reflejo real: cielo, nubes, modelos cercanos y el jugador (cubo que se redibuja en vivo)
      vec3 dirP = normalize(vWP + r * 7.0 - uProbePos);
      envP = texture(uEnv, dirP, uRBlur * 5.0).rgb;
      env = mix(env, envP * mix(vec3(1.0), t.rgb * 1.5, 0.6), 0.9);
    }
    c = mix(c, env, amt);
    if (uRefl > 1.5) {   // metálico: sin color difuso; refleja el entorno real teñido por su color (fresnel de metal)
      vec3 alb = max(t.rgb * uTint, vec3(0.05));
      vec3 F = alb + (vec3(1.0) - alb) * fresnel;
      vec3 raw = uEnvOn == 1 ? envP : env / mix(vec3(1.0), t.rgb * 1.5, 0.6);
      vec3 glint = uSunCol * pow(max(dot(r, -uSunDir), 0.0), 60.0) * F * 1.4;
      c = raw * F * 1.25 + c * 0.06 + glint + alb * 0.03;
    }
  }
  if (uSpec > 0.0 && uVeg == 0 && uRtx == 0) {   // brillo del sol (Blinn-Phong) con fresnel
    vec3 h = normalize(v - uSunDir);
    c += uSunCol * (pow(max(dot(n, h), 0.0), 40.0) * (0.35 + 0.65 * fresnel)) * uSpec * 0.55 * sh;
  }
  if (uRtx == 1 && uVeg == 0) {
    vec3 h = normalize(v - uSunDir);
    c += uSunCol * pow(max(dot(n, h), 0.0), 48.0) * 0.28 * sh;
    c *= mix(0.8, 1.0, n.y * 0.5 + 0.5);
    c = mix(c, aces(c * 1.12), 0.55);
  }
  if (uGI > 0.0 && uVeg == 0) {   // gráficos pro: tono de película, algo de contraste y color
    vec3 tm = aces(c * 1.1);
    c = mix(c, tm, 0.5 * min(uGI, 1.0));
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    c = mix(vec3(l), c, 1.0 + 0.12 * uGI);
  }
  c *= exp2(uEv);
  if (uTone > 0.0 && uVeg != 3) c = mix(c, aces(c * 1.1), uTone);
  float f = clamp(exp(-uFog * length(uCam - vWP)), 0.0, 1.0);
  oColor = vec4(mix(uFogCol, c, f), uVeg == 2 ? uColor.a * wa : (uVeg == 3 ? t.a : t.a));
}
)";

static const char* kDepthVS = SHV R"(
layout(location=0) in vec3 aPos;
layout(location=2) in vec2 aUV;
uniform mat4 uLVP, uM;
out vec2 vUV;
void main(){ vUV = aUV; gl_Position = uLVP * uM * vec4(aPos, 1.0); }
)";
static const char* kDepthFS = SHV R"(
in vec2 vUV;
uniform sampler2D uTex;
uniform float uAlpha;
void main(){ if (texture(uTex, vUV).a * uAlpha < 0.35) discard; }
)";

static const char* kSkyVS = SHV R"(
uniform vec3 uFwd, uRight, uUp;
uniform float uTX, uTY;
out vec3 vRay;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)) * 2.0 - 1.0;
  vRay = uFwd + uRight * p.x * uTX + uUp * p.y * uTY;
  gl_Position = vec4(p, 0.0, 1.0);
}
)";
static const char* kSkyFS = SHV R"(
in vec3 vRay;
out vec4 oColor;
uniform vec3 uTop, uBot, uSunDir, uSunCol;
uniform int uStyle, uSkyTexOn, uCloud;
uniform float uTime, uCovK, uWind;
uniform sampler2D uSkyTex, uCloudTex;
float h31(vec3 p){ p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float h21(vec2 p){ p = mod(p, 251.0); p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y); }
const mat2 RM = mat2(1.6, 1.2, -1.2, 1.6);
float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 6; i++) { s += a * vn(p); p = RM * p + 17.1; a *= 0.5; } return s * 1.03; }
float fbm3(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 3; i++) { s += a * vn(p); p = RM * p + 17.1; a *= 0.5; } return s; }
float fbm5(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 5; i++) { s += a * vn(p); p = RM * p + 17.1; a *= 0.5; } return s * 1.06; }
float cdens(vec2 p){ return fbm5(p + 1.3 * fbm3(p * 0.45 + 5.0)) * 0.78 + fbm3(p * 3.3 - 9.0) * 0.22; }
uniform int uSB;
uniform float uSZ;
// Astro del cielo (sol, luna, planetas): devuelve color y cobertura (a = 1 tapa el cielo, 0 = solo suma luz)
vec4 sbody(vec3 d){
  vec3 sd = -uSunDir;
  float s = dot(d, sd);
  if (s <= 0.2) return vec4(0.0);
  vec3 t1 = normalize(cross(vec3(0.0, 1.0, 0.0), sd) + vec3(0.0001, 0.0, 0.0));
  vec3 t2 = cross(sd, t1);
  vec2 p = vec2(dot(d, t1), dot(d, t2)) / s / (0.05 * uSZ);
  float r = length(p);
  float edge = smoothstep(1.0, 0.96, r);
  if (r > 2.5 && uSB >= 3 && uSB != 8) return vec4(0.0);   // lejos del disco no hay nada que calcular
  if (uSB == 1) return vec4(mix(uSunCol, vec3(1.0), 0.6) * (2.4 * edge * (1.0 - 0.3 * r * r)) + uSunCol * 0.45 / (1.0 + r * r * 1.2), 0.0);
  if (uSB == 2) {
    float ang = atan(p.y, p.x);
    float rays = pow(abs(sin(ang * 6.0 + uTime * 0.04)), 20.0) * exp(-r * 0.55) * 0.8 + pow(abs(sin(ang * 13.0 - uTime * 0.03)), 30.0) * exp(-r * 0.8) * 0.4;
    return vec4(mix(uSunCol, vec3(1.0), 0.5) * 2.2 * edge + uSunCol * (rays * smoothstep(0.7, 1.1, r) + 0.5 / (1.0 + r * r * 0.8)), 0.0);
  }
  if (uSB == 8) {
    float f = fbm(p * 3.0 + uTime * 0.03);
    vec3 sc = mix(vec3(0.55, 0.06, 0.02), vec3(1.0, 0.55, 0.15), f) * (1.4 - 0.5 * r * r);
    return vec4(sc * edge + vec3(1.0, 0.3, 0.08) * 0.6 / (1.0 + r * r * 0.7), 0.0);
  }
  vec3 L = normalize(vec3(-0.55, 0.45, 0.7));
  if (uSB == 4) L = normalize(vec3(-0.95, 0.05, 0.3));
  if (uSB == 5) {   // Saturno
    float ca = cos(-0.42), sa = sin(-0.42);
    vec2 pp = vec2(ca * p.x - sa * p.y, sa * p.x + ca * p.y);
    float rr = length(vec2(pp.x, pp.y / 0.3));
    float ring = step(0.66, rr) * step(rr, 1.0) * (0.55 + 0.45 * sin(rr * 70.0)) * (1.0 - step(0.84, rr) * step(rr, 0.87));
    vec3 ringCol = mix(vec3(0.75, 0.65, 0.5), vec3(0.95, 0.88, 0.7), 0.5 + 0.5 * sin(rr * 40.0));
    vec2 q = p / 0.5;
    float pr = length(q), pe = smoothstep(1.0, 0.95, pr);
    vec3 n = vec3(q, sqrt(max(1.0 - pr * pr, 0.0)));
    float bands = 0.5 + 0.5 * sin((pp.y / 0.5) * 11.0 + fbm(q * 2.0) * 2.0);
    vec3 pc = mix(vec3(0.72, 0.58, 0.38), vec3(0.95, 0.84, 0.6), bands) * (0.25 + 0.9 * max(dot(n, L), 0.0));
    float behind = ring * step(pp.y, 0.0), front = ring * step(0.0, pp.y);
    vec3 c = ringCol * behind * 0.9;
    float a = behind * 0.85;
    c = mix(c, pc, pe); a = max(a, pe);
    c = mix(c, ringCol * 1.0, front * 0.9); a = max(a, front * 0.9);
    return vec4(c, a);
  }
  vec3 n = vec3(p, sqrt(max(1.0 - r * r, 0.0)));
  float lam = max(dot(n, L), 0.0);
  vec3 c = vec3(0.0);
  if (uSB == 3 || uSB == 4) {   // luna
    float cr = fbm(p * 4.5 + 3.0), cr2 = fbm(p * 11.0);
    float alb = 0.62 + 0.38 * smoothstep(0.35, 0.65, cr) - 0.18 * smoothstep(0.55, 0.75, cr2);
    float ph = uSB == 4 ? smoothstep(0.0, 0.12, dot(n, L)) : (0.2 + 0.85 * lam);
    c = vec3(0.86, 0.87, 0.9) * alb * ph * 1.5 + vec3(0.07, 0.09, 0.14);
    return vec4(c * edge + vec3(0.5, 0.6, 0.8) * 0.12 / (1.0 + r * r * 3.0) * (1.0 - edge), edge);
  }
  if (uSB == 6) {   // Marte
    float f = fbm(p * 3.0 + 9.0);
    c = mix(vec3(0.6, 0.22, 0.12), vec3(0.88, 0.5, 0.28), f) * (0.2 + 1.0 * lam);
    c = mix(c, vec3(0.95), smoothstep(0.82, 0.95, n.y));
  } else if (uSB == 7) {   // Júpiter
    float b = 0.5 + 0.5 * sin(p.y * 13.0 + fbm(p * 3.0) * 3.0);
    c = mix(vec3(0.55, 0.38, 0.25), vec3(0.93, 0.85, 0.7), b);
    vec2 sp = (p - vec2(0.3, -0.28)) / vec2(0.2, 0.11);
    c = mix(c, vec3(0.75, 0.25, 0.12), smoothstep(1.0, 0.6, length(sp)));
    c *= 0.2 + 1.0 * lam;
  } else {   // 9: Tierra
    float land = smoothstep(0.5, 0.56, fbm(p * 2.6 + 4.0));
    float cl = smoothstep(0.5, 0.75, fbm(p * 3.5 + uTime * 0.01));
    c = mix(vec3(0.05, 0.2, 0.55), vec3(0.2, 0.5, 0.2), land);
    c = mix(c, vec3(0.95), cl * 0.8) * (0.15 + 1.1 * lam);
    c += vec3(0.25, 0.5, 1.0) * pow(1.0 - n.z, 3.0) * 0.6;
  }
  return vec4(c * edge + vec3(0.5, 0.6, 0.9) * 0.1 / (1.0 + r * r * 3.0) * (1.0 - edge) * (uSB == 9 ? 1.0 : 0.0), edge);
}
void main(){
  vec3 d = normalize(vRay);
  float t = clamp(d.y * 1.2 + 0.2, 0.0, 1.0);
  vec3 col = mix(uBot, uTop, pow(t, 0.7));
  float s = max(dot(d, -uSunDir), 0.0);
  float hz = smoothstep(0.0, 0.18, d.y);
  if (uSkyTexOn == 1) {
    float az = atan(d.x, -d.z) / 6.2831853 * 2.0;
    float u = abs(fract(az * 0.5) * 2.0 - 1.0);
    vec3 im = texture(uSkyTex, vec2(u, clamp(d.y * 0.92 + 0.08, 0.0, 1.0))).rgb;
    col = mix(col, im, smoothstep(-0.02, 0.12, d.y));
    oColor = vec4(col, 1.0);
    return;
  }
  if (uStyle > 0) {
    // 1 nubes de dia  2 nublado  3 noche luna  4 noche estrellas  5 nebulosa violeta  6 nebulosa azul
    // 7 atardecer dorado  8 amanecer rosa  9 crepusculo violeta  10 cumulonimbo
    float cov = 0.0, lit = 1.0, stars = 0.0, moon = 0.0;
    vec3 cLit = vec3(1.0), cSh = vec3(0.6, 0.65, 0.75), nebA = vec3(0.0), nebB = vec3(0.0);
    float nebAmt = 0.0, thr = 0.5, scl = 1.6, dark = 0.0;
    if (uStyle == 1) { thr = 0.44; cSh = vec3(0.62, 0.68, 0.8); }
    else if (uStyle == 2) { thr = 0.38; cSh = vec3(0.7, 0.74, 0.8); cLit = vec3(0.95, 0.96, 0.98); scl = 1.2; }
    else if (uStyle == 3) { thr = 0.52; cLit = vec3(0.45, 0.55, 0.8); cSh = vec3(0.07, 0.1, 0.2); stars = 0.5; moon = 1.0; }
    else if (uStyle == 4) { thr = 0.8; cLit = vec3(0.3, 0.35, 0.55); cSh = vec3(0.05, 0.06, 0.12); stars = 1.0; }
    else if (uStyle == 5) { thr = 0.9; stars = 1.0; nebA = vec3(0.3, 0.25, 0.95); nebB = vec3(0.7, 0.3, 0.9); nebAmt = 0.9; }
    else if (uStyle == 6) { thr = 0.9; stars = 0.8; nebA = vec3(0.05, 0.55, 0.95); nebB = vec3(0.4, 0.9, 1.0); nebAmt = 1.0; }
    else if (uStyle == 7) { thr = 0.48; cLit = vec3(1.0, 0.68, 0.3); cSh = vec3(0.55, 0.32, 0.25); scl = 1.3; }
    else if (uStyle == 8) { thr = 0.55; cLit = vec3(1.0, 0.62, 0.55); cSh = vec3(0.85, 0.45, 0.6); scl = 1.5; }
    else if (uStyle == 9) { thr = 0.62; cLit = vec3(0.45, 0.35, 0.55); cSh = vec3(0.04, 0.02, 0.08); stars = 0.9; }
    else if (uStyle == 10) { thr = 0.35; cLit = vec3(0.95, 1.0, 1.0); cSh = vec3(0.45, 0.6, 0.7); scl = 0.9; dark = 0.35; }
    if (d.y > 0.0) {
      vec2 uv = d.xz / (d.y + 0.22) * scl + vec2(uTime * 0.012, 0.0);
      bool realC = thr < 0.85 && (uCloud == 1 || uCloud >= 3);
      float n = 0.0;
      if (!realC) {   // nubes sencillas (en las realistas se calculan más abajo, así no se hace el trabajo dos veces)
        n = fbm(uv);
        cov = smoothstep(thr, thr + 0.28, n) * smoothstep(0.0, 0.2, d.y);
        float n2 = fbm(uv + normalize(vec2(-uSunDir.x, -uSunDir.z) + vec2(0.001)) * 0.12);
        lit = clamp(0.55 + (n - n2) * 5.0, 0.0, 1.0);
      }
      if (realC) {   // nubes realistas y variantes: cúmulos, tormenta, cirros, estratos, caricatura, atardecer
        vec2 wu = d.xz / (d.y * 0.85 + 0.1) * scl * 0.7 + vec2(uTime * 0.01 * uWind, uTime * 0.004 * uWind);
        float sft = 0.2, dk = 1.0, off = -0.04, mx = 1.0;
        bool toon = false, ridge = false;
        if (uCloud == 3) { sft = 0.12; off = 0.1; ridge = true; wu *= 0.85; }
        else if (uCloud == 4) { off = -0.1; dk = 3.0; cLit = vec3(0.42, 0.45, 0.52); cSh = vec3(0.06, 0.07, 0.1); col *= 0.55; }
        else if (uCloud == 5) { wu = vec2(wu.x * 0.3, wu.y * 2.0); off = 0.1; sft = 0.4; dk = 0.25; mx = 0.6; }
        else if (uCloud == 6) { wu = vec2(wu.x * 0.45, wu.y * 2.6); off = -0.2; sft = 0.3; dk = 0.6; mx = 0.95; }
        else if (uCloud == 7) { wu *= 0.6; sft = 0.025; off = 0.0; toon = true; cLit = vec3(1.0); cSh = vec3(0.66, 0.77, 0.95); }
        else if (uCloud == 8) { cLit = vec3(1.0, 0.62, 0.4); cSh = vec3(0.4, 0.22, 0.45); dk = 1.3; }
        float dn = cdens(wu);
        if (ridge) dn = mix(dn, 1.0 - abs(2.0 * fbm(wu * 1.3 + 3.0) - 1.0), 0.45);
        vec2 sl = normalize(vec2(-uSunDir.x, -uSunDir.z) + vec2(0.001)) * 0.09;
        float d1 = fbm3(wu + sl) * 0.85, d2 = fbm3(wu + sl * 2.8) * 0.85;
        float th2 = thr + off - uCovK;
        cov = smoothstep(th2, th2 + sft, dn) * smoothstep(0.0, 0.16, d.y) * mx;
        float thick = smoothstep(th2, th2 + 0.45, dn);
        lit = clamp(1.3 - max(d1 - dn * 0.85, 0.0) * 5.0 * dk - max(d2 - dn * 0.85, 0.0) * 3.0 * dk, 0.0, 1.0);
        lit *= mix(1.0, 0.7, thick * 0.6);
        if (toon) lit = step(0.5, lit);
        float edge = cov * (1.0 - thick);
        if (!toon) col += uSunCol * pow(s, 5.0) * edge * 1.4 * (stars > 0.0 ? 0.2 : 1.0);
      } else if (thr < 0.85 && uCloud == 2) {   // nubes con tu imagen
        vec2 tu = d.xz / (d.y + 0.25) * 0.3 + vec2(uTime * 0.004 * uWind, 0.0);
        tu = abs(fract(tu * 0.5) * 2.0 - 1.0);
        vec4 im = texture(uCloudTex, tu);
        float dn = im.a < 0.99 ? im.a : dot(im.rgb, vec3(0.299, 0.587, 0.114));
        float th2 = 0.45 - uCovK;
        cov = smoothstep(th2, th2 + 0.25, dn) * smoothstep(0.0, 0.18, d.y);
        float g = dot(im.rgb, vec3(0.333));
        lit = clamp(g * 1.1 + 0.1, 0.0, 1.0);
      } else if (thr < 0.85) {
        cov = clamp(smoothstep(thr - uCovK, thr - uCovK + 0.28, n) * smoothstep(0.0, 0.2, d.y), 0.0, 1.0);
      }
      if (nebAmt > 0.0) {
        vec2 q = d.xz / (abs(d.y) + 0.6) * 1.1;
        float a1 = fbm(q * 2.0 + 3.0), a2 = fbm(q * 3.1 - a1 * 1.7);
        float m = smoothstep(0.32, 0.85, a1 * 0.7 + a2 * 0.5);
        col = mix(col * 0.35, mix(nebA, nebB, a2) * (0.3 + m * 0.75), m * nebAmt);
        col += nebA * pow(max(a2 - 0.55, 0.0), 2.0) * 1.2 * nebAmt;
      }
      if (stars > 0.0) {
        vec3 qq = d * 150.0; vec3 id = floor(qq);
        float hh = h31(id);
        float st = step(0.985, hh) * smoothstep(0.5, 0.0, length(fract(qq) - 0.5));
        st *= 0.6 + 0.4 * sin(uTime * 2.0 + hh * 60.0);
        col += vec3(0.9, 0.95, 1.0) * st * 1.6 * stars * (1.0 - cov);
        vec3 q2 = d * 60.0; float h2 = h31(floor(q2) + 7.0);
        col += vec3(1.0, 0.9, 0.8) * step(0.99, h2) * smoothstep(0.5, 0.0, length(fract(q2) - 0.5)) * stars * (1.0 - cov);
      }
      vec3 cc = mix(cSh, cLit, lit);
      cc = mix(cc, cc * 0.5, dark * (1.0 - lit));
      col = mix(col, cc, cov * 0.92);
    }
    if (moon > 0.0) {
      float md = max(dot(d, -uSunDir), 0.0);
      col += vec3(0.8, 0.9, 1.0) * (smoothstep(0.9993, 0.9997, md) * 1.6 + pow(md, 60.0) * 0.35) * (1.0 - cov * 0.8);
    }
    // brillo de horizonte y glow del sol
    float gl = (uSB == 0 || uSB == 1 || uSB == 2 || uSB == 8) ? 1.0 : 0.12;
    col += uSunCol * pow(s, 24.0) * (uStyle >= 7 && uStyle <= 9 ? 0.45 : 0.18) * (1.0 - cov * 0.4) * gl;
    col += uSunCol * pow(s, 4.0) * 0.06 * (1.0 - hz * 0.5) * gl;
    if (uSB == 0) col += uSunCol * pow(s, 600.0) * 2.0 * (1.0 - cov * 0.9) * (moon > 0.0 || stars > 0.0 ? 0.0 : 1.0);
    else { vec4 bd = sbody(d); float vis = (1.0 - cov * 0.9) * smoothstep(-0.02, 0.05, d.y + 0.03); col = col * (1.0 - bd.a * vis) + bd.rgb * vis; }
    oColor = vec4(col, 1.0);
    return;
  }
  if (uSB == 0) col += uSunCol * (pow(s, 600.0) * 2.0 + pow(s, 8.0) * 0.12);
  else {
    float gl = (uSB == 1 || uSB == 2 || uSB == 8) ? 1.0 : 0.12;
    col += uSunCol * pow(s, 8.0) * 0.12 * gl;
    vec4 bd = sbody(d); float vis = smoothstep(-0.02, 0.05, d.y + 0.03);
    col = col * (1.0 - bd.a * vis) + bd.rgb * vis;
  }
  oColor = vec4(col, 1.0);
}
)";

static const char* kPostFS = SHV R"(
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uScene;
uniform vec2 uRes;
uniform int uType;
uniform float uAmt, uTime;
vec3 S(vec2 uv){ return texture(uScene, uv).rgb; }
float L(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }
void main(){
  vec2 uv = vUV, px = 1.0 / uRes;
  vec3 c = S(uv);
  float a = clamp(uAmt, 0.0, 1.0);
  if (uType == 1) {            // blanco y negro con contraste
    float l = L(c); l = clamp((l - 0.5) * (1.0 + a) + 0.5, 0.0, 1.0); c = vec3(l);
  } else if (uType == 2) {     // bandas de color
    float n = mix(10.0, 3.0, a); c = floor(c * n + 0.5) / n;
  } else if (uType == 3) {     // caricatura: bordes marcados + colores por bandas
    float tl = L(S(uv + px * vec2(-1, -1))), t = L(S(uv + px * vec2(0, -1))), tr = L(S(uv + px * vec2(1, -1)));
    float l0 = L(S(uv + px * vec2(-1, 0))), r0 = L(S(uv + px * vec2(1, 0)));
    float bl = L(S(uv + px * vec2(-1, 1))), b = L(S(uv + px * vec2(0, 1))), br = L(S(uv + px * vec2(1, 1)));
    float gx = -tl - 2.0 * l0 - bl + tr + 2.0 * r0 + br, gy = -tl - 2.0 * t - tr + bl + 2.0 * b + br;
    float e = smoothstep(0.18, 0.45, length(vec2(gx, gy)) * (0.8 + a));
    c = floor(c * 5.0 + 0.5) / 5.0;
    c = mix(c, vec3(0.03), e);
  } else if (uType == 4) {     // explosión: contraste, color y viñeta
    c = (c - 0.5) * (1.3 + a * 0.9) + 0.5;
    float l = L(c); c = mix(vec3(l), c, 1.3 + a * 0.8);
    vec2 d = uv - 0.5; c *= 1.0 - dot(d, d) * (0.6 + a);
    c = clamp(c, 0.0, 1.0);
  } else if (uType == 5) {     // texturas realzadas (afilado: parecen reescaladas y con relieve)
    vec3 bl = (S(uv + px * vec2(-1, 0)) + S(uv + px * vec2(1, 0)) + S(uv + px * vec2(0, -1)) + S(uv + px * vec2(0, 1))) * 0.25;
    c = c + (c - bl) * (1.5 + a * 3.0);
    c = clamp((c - 0.5) * (1.05 + a * 0.2) + 0.5, 0.0, 1.0);
  } else if (uType == 6) {     // borroso
    vec3 s = vec3(0.0); float r = mix(1.0, 5.0, a);
    for (int y = -2; y <= 2; y++) for (int x = -2; x <= 2; x++) s += S(uv + px * vec2(float(x), float(y)) * r);
    c = s / 25.0;
  } else if (uType == 7) {     // pixelado
    float n = mix(3.0, 14.0, a); vec2 cell = px * n;
    c = S((floor(uv / cell) + 0.5) * cell);
  } else if (uType == 8) {     // retro: líneas de pantalla, bandas y viñeta
    float n = 6.0; c = floor(c * n + 0.5) / n;
    c *= 0.85 + 0.15 * sin(uv.y * uRes.y * 1.6);
    vec2 d = uv - 0.5; c *= 1.0 - dot(d, d) * 0.9;
  } else if (uType == 9) {     // sepia
    float l = L(c); c = mix(c, vec3(l * 1.15, l * 0.95, l * 0.7), 0.5 + a * 0.5);
  }
  oColor = vec4(c, 1.0);
}
)";
static const char* kPostVS = SHV R"(
out vec2 vUV;
void main(){
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  vUV = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
)";

static const char* kMbFS = SHV R"(
in vec2 vUV;
out vec4 oColor;
uniform sampler2D uScene;
uniform vec2 uVel;
uniform float uZoom;
void main(){
  vec3 acc = vec3(0.0);
  float wsum = 0.0;
  for (int i = 0; i < 24; i++) {
    float t = float(i) / 23.0 - 0.5;
    vec2 uv = vUV + uVel * t + (vUV - 0.5) * uZoom * t;
    float wt = 1.0 - abs(t) * 0.9;
    acc += texture(uScene, clamp(uv, 0.001, 0.999)).rgb * wt;
    wsum += wt;
  }
  oColor = vec4(acc / wsum, 1.0);
}
)";

static const char* kFlareVS = SHV R"(
uniform vec2 uC, uS;
out vec2 vP;
void main(){
  vec2 p = vec2(float(gl_VertexID & 1), float((gl_VertexID >> 1) & 1)) * 2.0 - 1.0;
  vP = p;
  gl_Position = vec4(uC + p * uS, 0.0, 1.0);
}
)";
static const char* kFlareFS = SHV R"(
in vec2 vP;
out vec4 oColor;
uniform int uType;
uniform vec3 uCol;
uniform float uA;
void main(){
  float r = length(vP), a = 0.0;
  if (uType == 0) a = pow(max(1.0 - r, 0.0), 2.4);
  else if (uType == 1) a = smoothstep(1.0, 0.92, r) * (0.35 + 0.65 * smoothstep(0.5, 0.95, r));
  else if (uType == 2) a = smoothstep(0.16, 0.0, abs(r - 0.82));
  else if (uType == 3) { vec2 q = abs(vP); float d = max(q.x * 0.866 + q.y * 0.5, q.y); a = smoothstep(1.0, 0.88, d) * 0.55; }
  else a = exp(-abs(vP.y) * 40.0) * max(1.0 - abs(vP.x), 0.0);
  oColor = vec4(uCol * a * uA, 1.0);
}
)";

// ---------------------------------------------------------------- helpers
static GLuint compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetShaderInfoLog(s, sizeof log, nullptr, log);
        fprintf(stderr, "shader: %s\n", log);
    }
    return s;
}

static bool build(GLuint& prog, const char* vs, const char* fs) {
    GLuint v = compile(GL_VERTEX_SHADER, vs), f = compile(GL_FRAGMENT_SHADER, fs);
    prog = glCreateProgram();
    glAttachShader(prog, v);
    glAttachShader(prog, f);
    glLinkProgram(prog);
    glDeleteShader(v);
    glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(prog, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512];
        glGetProgramInfoLog(prog, sizeof log, nullptr, log);
        fprintf(stderr, "link: %s\n", log);
    }
    return ok != 0;
}

GLint Renderer::Prog::u(const char* n) {
    auto it = loc.find(n);
    if (it != loc.end()) return it->second;
    GLint l = glGetUniformLocation(id, n);
    loc[n] = l;
    return l;
}

// Atributos de vertice: posicion, normal, uv (32 bytes) sobre el VBO enlazado.
void Renderer::setupAttribs() {
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 32, (const void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 32, (const void*)12);
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 32, (const void*)24);
}

// ---------------------------------------------------------------- ajustes del motor grafico
void Renderer::applyGfx(const Project& pr) {
    static const int kRes[5] = {0, 512, 1024, 2048, 4096};
    int want = pr.gfxShadow > 0 ? kRes[std::max(0, std::min(4, pr.gfxShadow))] : shadowDefault_;
#if defined(__ANDROID__)
    if (pr.perf.rt) want = std::max(want, 1024);   // simulacion liviana: sombras algo mas nitidas sin pasarse
#else
    if (pr.perf.rt) want = std::max(want, 4096);   // Windows: sombras de maxima calidad
#endif
    if (want != shadowSize_ && shadowTex_) {
        shadowSize_ = want;
        glBindTexture(GL_TEXTURE_2D, shadowTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, nullptr);
    }
    float an = (float)std::max(1, pr.gfxAniso);
#if !defined(__ANDROID__)
    if (pr.perf.rt) an = std::max(an, 16.f);
#endif
    if (an != aniso_) {
        aniso_ = an;
        for (auto& kv : tex_) if (kv.second.id) {
            glBindTexture(GL_TEXTURE_2D, kv.second.id);
            glTexParameterf(GL_TEXTURE_2D, 0x84FE, aniso_);
        }
        while (glGetError() != GL_NO_ERROR) {}   // si el telefono no soporta anisotropico, no pasa nada
    }
}

// ---------------------------------------------------------------- init
bool Renderer::init(int shadowSize) {
    shadowSize_ = shadowDefault_ = shadowSize;
    if (!build(main_.id, kMainVS, kMainFS) || !build(sky_.id, kSkyVS, kSkyFS) ||
        !build(depth_.id, kDepthVS, kDepthFS) || !build(post_.id, kPostVS, kPostFS) || !build(flare_.id, kFlareVS, kFlareFS) || !build(mb_.id, kPostVS, kMbFS))
        return false;

    // Cubo unitario: 24 vertices + 36 indices de 16 bits.
    static const float F[6][9] = {  // n, u, v
        {1, 0, 0, 0, 0, -1, 0, 1, 0}, {-1, 0, 0, 0, 0, 1, 0, 1, 0}, {0, 1, 0, 1, 0, 0, 0, 0, -1},
        {0, -1, 0, 1, 0, 0, 0, 0, 1}, {0, 0, 1, 1, 0, 0, 0, 1, 0},  {0, 0, -1, -1, 0, 0, 0, 1, 0}};
    static const int S[4][2] = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
    float vtx[24 * 8];
    unsigned short idx[36];
    for (int f = 0; f < 6; f++) {
        const float* a = F[f];
        for (int k = 0; k < 4; k++) {
            float s = (float)S[k][0], t = (float)S[k][1];
            float* v = vtx + (f * 4 + k) * 8;
            for (int c = 0; c < 3; c++) v[c] = a[c] * 0.5f + (s * a[3 + c] + t * a[6 + c]) * 0.5f;
            v[3] = a[0]; v[4] = a[1]; v[5] = a[2];
            v[6] = (s + 1) * 0.5f; v[7] = (t + 1) * 0.5f;
        }
        unsigned short b = (unsigned short)(f * 4), *i = idx + f * 6;
        i[0] = b; i[1] = b + 1; i[2] = b + 2; i[3] = b; i[4] = b + 2; i[5] = b + 3;
    }
    glGenVertexArrays(1, &vao_);
    glBindVertexArray(vao_);
    glGenBuffers(1, &vbo_);
    glBindBuffer(GL_ARRAY_BUFFER, vbo_);
    glBufferData(GL_ARRAY_BUFFER, sizeof vtx, vtx, GL_STATIC_DRAW);
    glGenBuffers(1, &ibo_);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof idx, idx, GL_STATIC_DRAW);
    setupAttribs();
    glGenVertexArrays(1, &vaoEmpty_);

    // Textura blanca 1x1.
    unsigned char px[4] = {255, 255, 255, 255};
    glGenTextures(1, &white_);
    glBindTexture(GL_TEXTURE_2D, white_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Mapa de sombras de 16 bits (2 MB a 1024x1024).
    glGenTextures(1, &shadowTex_);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, shadowSize_, shadowSize_, 0, GL_DEPTH_COMPONENT,
                 GL_UNSIGNED_SHORT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glGenFramebuffers(1, &fbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, shadowTex_, 0);
    GLenum none = GL_NONE;
    glDrawBuffers(1, &none);
    glReadBuffer(GL_NONE);
    bool ok = glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    return ok;
}

void Renderer::shutdown() {
    // Al perder el contexto GL (Android) los objetos ya no existen: solo olvidamos los ids.
    main_ = Prog(); sky_ = Prog(); depth_ = Prog(); post_ = Prog(); flare_ = Prog(); mb_ = Prog();
    scFbo_ = scTex_ = scDepth_ = 0; scW_ = scH_ = 0;
    mbTex_ = 0; mbW_ = mbH_ = 0; envTex_ = envFbo_ = envDepth_ = 0; envValid_ = false; probeFace_ = 0; probeObj_ = -1; probing_ = false; flareVis_ = 0.f; mbHave_ = false;
    vao_ = vbo_ = ibo_ = vaoEmpty_ = fbo_ = shadowTex_ = white_ = 0;
    tex_.clear();
    models_.clear();
}

Renderer::TexInfo& Renderer::texture(const Game& g, const std::string& name) {
    static TexInfo none;
    if (name == "::cam") { auto ci = tex_.find(name); if (ci != tex_.end()) return ci->second; none.id = white_; return none; }   // la cámara no se guarda como blanca
    if (name.empty()) { none.id = white_; return none; }
    auto it = tex_.find(name);
    if (it != tex_.end()) return it->second;
    TexInfo ti;
    ti.id = white_;
    auto a = g.proj.assets.find(name);
    if (a == g.proj.assets.end()) { none.id = white_; return none; }   // todavía no existe (se está importando): no se guarda, así no se queda blanca para siempre
    if (a != g.proj.assets.end()) {
        int w, h, c;
        // OJO: la bandera global de stb NUNCA se pone en 1 (otros hilos, como el de importar, también cargan imágenes y quedaban volteadas al azar).
        // La imagen se voltea a mano aquí para que OpenGL la vea con la fila de abajo primero.
        stbi_set_flip_vertically_on_load(0);
        unsigned char* d = stbi_load_from_memory(a->second.data(), (int)a->second.size(), &w, &h, &c, 4);
        if (d) {
            {
                const size_t rowB = (size_t)w * 4;
                std::vector<unsigned char> tmpRow(rowB);
                for (int y = 0; y < h / 2; y++) {
                    unsigned char* r0 = d + (size_t)y * rowB; unsigned char* r1 = d + (size_t)(h - 1 - y) * rowB;
                    std::memcpy(tmpRow.data(), r0, rowB); std::memcpy(r0, r1, rowB); std::memcpy(r1, tmpRow.data(), rowB);
                }
            }
            {   // los píxeles transparentes toman el color de sus vecinos: así no salen bordes negros al suavizar la imagen
                bool anyT = false;
                for (size_t k = 3; k < (size_t)w * h * 4 && !anyT; k += 4) anyT = d[k] < 255;
                if (anyT && (size_t)w * h <= 4096u * 4096u) {
                    std::vector<unsigned char> src;
                    for (int pass = 0; pass < 3; pass++) {
                        src.assign(d, d + (size_t)w * h * 4);
                        for (int y = 0; y < h; y++)
                            for (int x = 0; x < w; x++) {
                                unsigned char* q = d + ((size_t)y * w + x) * 4;
                                if (q[3] != 0 || (q[0] | q[1] | q[2]) != 0) continue;
                                int sr = 0, sg = 0, sb = 0, n = 0;
                                for (int dy = -1; dy <= 1; dy++)
                                    for (int dx = -1; dx <= 1; dx++) {
                                        int xx = x + dx, yy = y + dy;
                                        if (xx < 0 || yy < 0 || xx >= w || yy >= h) continue;
                                        const unsigned char* r = &src[((size_t)yy * w + xx) * 4];
                                        if (r[3] > 0) { sr += r[0]; sg += r[1]; sb += r[2]; n++; }
                                    }
                                if (n) { q[0] = (unsigned char)(sr / n); q[1] = (unsigned char)(sg / n); q[2] = (unsigned char)(sb / n); }
                            }
                    }
                }
            }
            ti.w = w; ti.h = h;
            std::vector<unsigned char> small; const unsigned char* d2use = nullptr;
            int uw = w, uh = h;
            if (g.proj.perf.texOn || std::max(w, h) > 4096) {   // ahorro de memoria (o imagen enorme que algunos teléfonos no aceptan: se ponía en blanco)
                int maxD = !g.proj.perf.texOn ? 4096 : g.proj.perf.tex >= 3 ? 256 : g.proj.perf.tex == 2 ? 512 : 1024;
                const unsigned char* cur = d;
                while (std::max(uw, uh) > maxD && uw > 1 && uh > 1) {
                    int nw = uw / 2, nh = uh / 2;
                    std::vector<unsigned char> nx((size_t)nw * nh * 4);
                    for (int y = 0; y < nh; y++)
                        for (int x = 0; x < nw; x++)
                            for (int c = 0; c < 4; c++) {
                                int s = cur[((size_t)(2 * y) * uw + 2 * x) * 4 + c] + cur[((size_t)(2 * y) * uw + 2 * x + 1) * 4 + c] +
                                        cur[((size_t)(2 * y + 1) * uw + 2 * x) * 4 + c] + cur[((size_t)(2 * y + 1) * uw + 2 * x + 1) * 4 + c];
                                nx[((size_t)y * nw + x) * 4 + c] = (unsigned char)(s / 4);
                            }
                    small.swap(nx); cur = small.data(); uw = nw; uh = nh;
                }
                if (!small.empty()) d2use = small.data();
            }
            glGenTextures(1, &ti.id);
            glBindTexture(GL_TEXTURE_2D, ti.id);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, uw, uh, 0, GL_RGBA, GL_UNSIGNED_BYTE, d2use ? d2use : d);
            glGenerateMipmap(GL_TEXTURE_2D);
            if (aniso_ > 1.f) glTexParameterf(GL_TEXTURE_2D, 0x84FE, aniso_);   // GL_TEXTURE_MAX_ANISOTROPY_EXT (se ignora si no existe)
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
            ti.w = w; ti.h = h;
            stbi_image_free(d);  // la copia en RAM se libera: solo queda la de la GPU
        }
    }
    if (ti.id == white_) {   // no se pudo leer: se reintenta unas veces en vez de quedarse en blanco para siempre
        static std::map<std::string, int> fails;
        if (++fails[name] <= 4) { none.id = white_; return none; }
    }
    return tex_[name] = ti;
}

unsigned Renderer::uploadRGBA(const std::string& key, int w, int h, const uint8_t* px) {
    auto it = tex_.find(key);
    if (it != tex_.end()) return it->second.id;
    TexInfo ti;
    glGenTextures(1, &ti.id);
    glBindTexture(GL_TEXTURE_2D, ti.id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    ti.w = w; ti.h = h;
    tex_[key] = ti;
    return ti.id;
}

unsigned Renderer::updateRGBA(const std::string& key, int w, int h, const uint8_t* px) {
    auto it = tex_.find(key);
    if (it == tex_.end()) return uploadRGBA(key, w, h, px);
    glBindTexture(GL_TEXTURE_2D, it->second.id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, px);
    it->second.w = w; it->second.h = h;
    return it->second.id;
}

unsigned Renderer::rawTexture(const std::string& key, int* w, int* h) const {
    auto it = tex_.find(key);
    if (it == tex_.end()) return 0;
    if (w) *w = it->second.w;
    if (h) *h = it->second.h;
    return it->second.id;
}

void Renderer::forget(const std::string& name) {
    auto it = tex_.find(name);
    if (it == tex_.end()) return;
    if (it->second.id && it->second.id != white_) glDeleteTextures(1, &it->second.id);
    tex_.erase(it);
}

unsigned Renderer::textureId(const Game& g, const std::string& name, int* w, int* h) {
    if (name.empty() || !g.proj.assets.count(name)) return 0;
    TexInfo& t = texture(g, name);
    if (t.id == white_) return 0;
    if (w) *w = t.w;
    if (h) *h = t.h;
    return t.id;
}

Renderer::ModelGL* Renderer::model(const Game& g, const std::string& name) {
    auto it = models_.find(name);
    if (it != models_.end()) return it->second.ok ? &it->second : nullptr;
    auto a = g.proj.assets.find(name);
    if (a == g.proj.assets.end()) return nullptr;   // aún no está: se vuelve a intentar en el siguiente cuadro (antes quedaba invisible para siempre)
    ModelGL& m = models_[name];
    ModelData md;
    if (!modelRead(a->second.data(), a->second.size(), md)) return nullptr;
    glGenVertexArrays(1, &m.vao);
    glBindVertexArray(m.vao);
    glGenBuffers(1, &m.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(md.v.size() * 4), md.v.data(), GL_STATIC_DRAW);
    glGenBuffers(1, &m.ibo);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
    if (md.v.size() / 8 > 65535) {
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(md.idx.size() * 4), md.idx.data(), GL_STATIC_DRAW);
        m.itype = GL_UNSIGNED_INT;
    } else {
        std::vector<unsigned short> s(md.idx.begin(), md.idx.end());
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(s.size() * 2), s.data(), GL_STATIC_DRAW);
        m.itype = GL_UNSIGNED_SHORT;
    }
    setupAttribs();
    m.count = (int)md.idx.size();
    if (md.v.size() >= 8) {
        for (int c = 0; c < 3; c++) { m.bmin[c] = 1e30f; m.bmax[c] = -1e30f; }
        for (size_t i = 0; i + 7 < md.v.size(); i += 8)
            for (int c = 0; c < 3; c++) { m.bmin[c] = std::min(m.bmin[c], md.v[i + c]); m.bmax[c] = std::max(m.bmax[c], md.v[i + c]); }
    }
    m.tex = md.tex;
    for (int i = 0; i < 3; i++) m.color[i] = md.color[i];
    {   // LOD: versiones con menos triángulos (agrupando vértices cercanos en una cuadrícula) para cuando el modelo está lejos
        const size_t nv = md.v.size() / 8, nt = md.idx.size() / 3;
        float mx = std::max(m.bmax[0] - m.bmin[0], std::max(m.bmax[1] - m.bmin[1], m.bmax[2] - m.bmin[2]));
        if (nt >= 1200 && nv > 0 && mx > 1e-6f) {
            static const int kRes[2] = {64, 24};
            for (int L = 0; L < 2; L++) {
                const float cell = mx / (float)kRes[L];
                std::unordered_map<unsigned long long, uint32_t> grid;
                grid.reserve(nv);
                std::vector<uint32_t> rep(nv);
                for (size_t v = 0; v < nv; v++) {
                    unsigned long long k = 0;
                    for (int c = 0; c < 3; c++) k = k * 4099ULL + (unsigned long long)std::max(0.f, (md.v[v * 8 + c] - m.bmin[c]) / cell);
                    rep[v] = grid.emplace(k, (uint32_t)v).first->second;
                }
                std::vector<uint32_t> id2;
                id2.reserve(md.idx.size() / 2);
                for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
                    uint32_t a = rep[md.idx[t]], b = rep[md.idx[t + 1]], c = rep[md.idx[t + 2]];
                    if (a != b && b != c && a != c) { id2.push_back(a); id2.push_back(b); id2.push_back(c); }
                }
                if (id2.size() * 10 > md.idx.size() * 8 || id2.empty()) continue;   // casi no ahorra: no se usa
                glGenVertexArrays(1, &m.lodVao[L]);
                glBindVertexArray(m.lodVao[L]);
                glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
                glGenBuffers(1, &m.lodIbo[L]);
                glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.lodIbo[L]);
                if (m.itype == GL_UNSIGNED_INT) glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(id2.size() * 4), id2.data(), GL_STATIC_DRAW);
                else { std::vector<unsigned short> s16(id2.begin(), id2.end()); glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(s16.size() * 2), s16.data(), GL_STATIC_DRAW); }
                setupAttribs();
                m.lodCount[L] = (int)id2.size();
            }
        }
    }
    m.ok = true;
    glBindVertexArray(vao_);
    return &m;
}

// Malla que cambia (terreno, modelos con esqueleto): se vuelve a subir solo si cambió su firma.
Renderer::ModelGL* Renderer::dynModel(const std::string& key, const std::vector<float>& v, const std::vector<uint32_t>& idx, unsigned long long sig) {
    ModelGL& m = models_[key];
    if (!m.vao) {
        glGenVertexArrays(1, &m.vao);
        glBindVertexArray(m.vao);
        glGenBuffers(1, &m.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glGenBuffers(1, &m.ibo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
        m.sig = ~sig;
        m.itype = GL_UNSIGNED_INT;
    }
    if (m.sig != sig) {
        glBindVertexArray(m.vao);
        glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
        glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(v.size() * 4), v.data(), GL_DYNAMIC_DRAW);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ibo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, (GLsizeiptr)(idx.size() * 4), idx.data(), GL_DYNAMIC_DRAW);
        setupAttribs();
        m.count = (int)idx.size();
        m.sig = sig;
        m.ok = true;
    }
    glBindVertexArray(vao_);
    return &m;
}

// Suelo deformable: rejilla de alturas en coordenadas relativas al objeto (la matriz solo lo traslada).
Renderer::ModelGL* Renderer::terrainMesh(const Game& g, int idx) {
    const Obj& o = g.sc->objs[idx];
    unsigned long long sig = (unsigned long long)o.terrVer * 1000003ULL;
    {
        float a[3] = {o.scale.x, o.scale.y, o.scale.z};
        unsigned u[3];
        std::memcpy(u, a, sizeof u);
        sig ^= ((unsigned long long)u[0] << 1) ^ ((unsigned long long)u[1] << 17) ^ ((unsigned long long)u[2] << 33);
        sig ^= std::hash<std::string>()(o.name + "|" + g.sc->name) << 3;
    }
    std::string key = "::terr:" + std::to_string(idx);
    auto it = models_.find(key);
    if (it != models_.end() && it->second.sig == sig) return &it->second;
    int n = o.tn;
    std::vector<float> v((size_t)n * n * 8);
    auto H = [&](int i, int j) { i = std::max(0, std::min(n - 1, i)); j = std::max(0, std::min(n - 1, j)); return o.heights[(size_t)j * n + i]; };
    float dx = o.scale.x / (n - 1), dz = o.scale.z / (n - 1);
    for (int j = 0; j < n; j++)
        for (int i = 0; i < n; i++) {
            float* q = &v[((size_t)j * n + i) * 8];
            q[0] = ((float)i / (n - 1) - 0.5f) * o.scale.x;
            q[1] = o.scale.y * 0.5f + H(i, j);
            q[2] = ((float)j / (n - 1) - 0.5f) * o.scale.z;
            float gx = (H(i + 1, j) - H(i - 1, j)) / (2 * dx), gz = (H(i, j + 1) - H(i, j - 1)) / (2 * dz);
            float l = std::sqrt(gx * gx + 1.f + gz * gz);
            q[3] = -gx / l; q[4] = 1.f / l; q[5] = -gz / l;
            q[6] = (float)i / (n - 1); q[7] = (float)j / (n - 1);
        }
    std::vector<uint32_t> id;
    id.reserve((size_t)(n - 1) * (n - 1) * 6);
    for (int j = 0; j < n - 1; j++)
        for (int i = 0; i < n - 1; i++) {
            uint32_t a = j * n + i, b = a + 1, c = a + n, d = c + 1;
            id.insert(id.end(), {a, c, b, b, c, d});
        }
    return dynModel(key, v, id, sig);
}

// Si el objeto tiene una animacion de esqueleto activa, devuelve el modelo ya deformado; si no, 'base'.
Renderer::ModelGL* Renderer::skinned(Game& g, int idx, const std::string& model, ModelGL* base) {
    if (!base || model.empty()) return base;
    const std::vector<float>* sv = nullptr;
    const std::vector<uint32_t>* si = nullptr;
    unsigned long long sg = 0;
    if (!g.skinVerts(idx, model, sv, si, sg)) return base;
    ModelGL* dm = dynModel("::skin:" + std::to_string(idx), *sv, *si, sg);
    dm->tex = base->tex;
    for (int k = 0; k < 3; k++) dm->color[k] = base->color[k];
    return dm;
}

void Renderer::warmup(Game& g) {
    if (!g.sc) return;
    for (auto& o : g.sc->objs) {
        if (!o.model.empty()) model(g, o.model);
        if (!o.tex.empty()) texture(g, o.tex);
        for (auto& l : o.looks) if (!l.empty()) texture(g, l);
        if (!o.handItem.empty()) model(g, o.handItem);
    }
    const PlayerCfg& pc = g.proj.player;
    if (!pc.model.empty()) model(g, pc.model);
    auto w = [&](const Weapon& wp) { if (!wp.model.empty()) model(g, wp.model); if (!wp.tex.empty()) texture(g, wp.tex); if (!wp.projModel.empty()) model(g, wp.projModel); };
    w(g.proj.weapon);
    for (auto& wp : g.proj.extraWeapons) w(wp);
}

void Renderer::box(Prog& p, V3 pos, V3 scale, float r, float g, float b, float a) {
    M4 m = modelMat(pos, 0, scale);
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
    glUniform4f(p.u("uColor"), r, g, b, a);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, white_);
    glBindVertexArray(vao_);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
}

// Un objeto (arma, herramienta...) sujeto a la mano del modelo con esqueleto; rot = giro (grados), off = desplazamiento.
bool Renderer::drawHeld(Game& g, Prog& p, int idx, const std::string& skinModel, const M4& mm, float yawDeg, const std::string& item, int side, const float* rot, const float* off, float size) {
    V3 lp;
    if (item.empty() || !g.boneLocal(idx, skinModel, side, lp)) return false;
    V3 w{mm.m[0] * lp.x + mm.m[4] * lp.y + mm.m[8] * lp.z + mm.m[12], mm.m[1] * lp.x + mm.m[5] * lp.y + mm.m[9] * lp.z + mm.m[13], mm.m[2] * lp.x + mm.m[6] * lp.y + mm.m[10] * lp.z + mm.m[14]};
    float a = yawDeg * 0.0174532925f, c = std::cos(a), sn = std::sin(a);
    V3 oo{c * off[0] + sn * off[2], off[1], -sn * off[0] + c * off[2]};
    M4 im = modelMatTilt(w + oo, yawDeg + rot[1], rot[0], rot[2], V3{size, size, size});
    forceM_ = &im;
    drawModelAt(g, p, item, "", w, 0.f, V3{1, 1, 1}, 1.f, 1.f, 1.f, 1.f);
    return true;
}

void Renderer::drawModelAt(Game& g, Prog& p, const std::string& model, const std::string& tex, V3 pos, float yawDeg, V3 scale,
                           float r, float gg, float b, float a) {
    ModelGL* md = forceMd_ ? forceMd_ : (model.empty() ? nullptr : this->model(g, model));
    forceMd_ = nullptr;
    M4 m = forceM_ ? *forceM_ : modelMat(pos, yawDeg, scale);
    forceM_ = nullptr;
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
    float c[3] = {r * (md ? md->color[0] : 1.f), gg * (md ? md->color[1] : 1.f), b * (md ? md->color[2] : 1.f)};
    glUniform4f(p.u("uColor"), c[0], c[1], c[2], a);
    glActiveTexture(GL_TEXTURE0);
    const std::string& tn = !tex.empty() ? tex : (md ? md->tex : tex);
    glBindTexture(GL_TEXTURE_2D, ovTex_ ? ovTex_ : texture(g, tn).id);
    glUniform1i(p.u("uUV1"), 1);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, additive_ ? GL_ONE : GL_ONE_MINUS_SRC_ALPHA);
    glBindVertexArray(md ? md->vao : vao_);
    if (md) glDrawElements(GL_TRIANGLES, md->count, md->itype, nullptr);
    else if (g.sc && !g.sc->is3d) glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (const void*)(24 * sizeof(unsigned short)));   // 2D: solo la cara de enfrente
    else glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
    glDisable(GL_BLEND);
    glBindVertexArray(vao_);
}

unsigned Renderer::softDot() {
    if (tex_.count("::softdot")) return tex_["::softdot"].id;
    const int N = 32;
    std::vector<uint8_t> px((size_t)N * N * 4);
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float dx = (x + .5f) / N * 2.f - 1.f, dy = (y + .5f) / N * 2.f - 1.f;
            float d = std::sqrt(dx * dx + dy * dy), a = std::max(0.f, 1.f - d);
            a = a * a * (3.f - 2.f * a);
            uint8_t* o = &px[((size_t)y * N + x) * 4];
            o[0] = o[1] = o[2] = 255;
            o[3] = (uint8_t)(a * 255.f);
        }
    return uploadRGBA("::softdot", N, N, px.data());
}

// Particulas: puntos suaves (o la imagen elegida) que miran a la camara, con color que cambia y se desvanecen.
void Renderer::drawParticles(Game& g, Prog& p, bool is3) {
    if (g.parts.empty()) return;
    unsigned dot = softDot();
    for (int pass = 0; pass < 2; pass++) {  // primero las normales, luego las que brillan
        for (auto& q : g.parts) {
            if ((q.glow ? 1 : 0) != pass) continue;
            float t = 1.f - q.life / q.max;  // 0 recien nacida, 1 por morir
            float r = q.c0[0] + (q.c1[0] - q.c0[0]) * t, gg = q.c0[1] + (q.c1[1] - q.c0[1]) * t, b = q.c0[2] + (q.c1[2] - q.c0[2]) * t;
            float a = q.a0 * (1.f - t) * std::min(1.f, t * 12.f + 0.15f);
            float s = std::max(0.01f, q.size * (1.f + q.grow * t));
            additive_ = q.glow;
            ovTex_ = 0;
            if (!q.tex.empty()) {
                drawModelAt(g, p, "", q.tex, q.p, 0.f, V3{s, s, 0.02f}, r, gg, b, a);
                continue;
            }
            ovTex_ = dot;
            if (is3) {
                float yaw = std::atan2(camE_.x - q.p.x, camE_.z - q.p.z) / 0.0174532925f;
                drawModelAt(g, p, "", "", q.p, yaw, V3{s, s, 0.02f}, r, gg, b, a);
            } else {
                drawModelAt(g, p, "", "", q.p, 0.f, V3{s, s, 1.f}, r, gg, b, a);
            }
        }
    }
    ovTex_ = 0;
    additive_ = false;
}

// Imagen plana que siempre mira a la camara.
void Renderer::drawSprite(Game& g, Prog& p, const std::string& tex, V3 pos, float w, float h, float r, float gg, float b) {
    float yaw = std::atan2(camE_.x - pos.x, camE_.z - pos.z) / 0.0174532925f;
    drawModelAt(g, p, "", tex, pos, yaw, V3{w, h, 0.02f}, r, gg, b, 1.f);
}

// ---------------------------------------------------------------- vegetacion (pasto pintado)
static unsigned vegRnd(unsigned& st) { st = st * 1664525u + 1013904223u; return st >> 8; }
static float vegF(unsigned& st) { return (float)(vegRnd(st) & 0xFFFF) / 65535.f; }

// Texturas de pasto hechas por codigo (en gris: el color lo pone la capa).
// Texturas de vegetación a color (flores, helechos, arbustos, cañas, hongos...), dibujadas por código.
unsigned Renderer::vegColorTexture(int style) {
    std::string key = "::veg" + std::to_string(style);
    const int N = 128;
    std::vector<float> px((size_t)N * N * 4, 0.f);
    unsigned st = 777u + style * 131u;
    auto put = [&](int x, int y, float r, float g, float b, float a) {
        if (x < 0 || y < 0 || x >= N || y >= N || a <= 0.f) return;
        float* o = &px[((size_t)y * N + x) * 4];
        if (a >= o[3] * 0.98f) { o[0] = r; o[1] = g; o[2] = b; }
        o[3] = std::max(o[3], std::min(1.f, a));
    };
    auto disc = [&](float cx, float cy, float rx, float ry, float r, float g, float b) {
        for (int y = (int)((cy - ry) * N) - 1; y <= (int)((cy + ry) * N) + 1; y++)
            for (int x = (int)((cx - rx) * N) - 1; x <= (int)((cx + rx) * N) + 1; x++) {
                float u = ((x + 0.5f) / N - cx) / rx, v = ((y + 0.5f) / N - cy) / ry, d = std::sqrt(u * u + v * v);
                float a = std::max(0.f, std::min(1.f, (1.f - d) * std::min(rx, ry) * N * 0.9f + 0.5f));
                float sh = 0.85f + 0.2f * (1.f - (v * 0.5f + 0.5f));
                put(x, y, r * sh, g * sh, b * sh, a);
            }
    };
    // hoja / brizna curva: base (x0,1) hasta la punta a altura hh, con inclinación lean
    auto blade = [&](float x0, float lean, float hh, float bw, float r0, float g0, float b0, float r1, float g1, float b1) {
        for (int y = 0; y < N; y++) {
            float v = (y + 0.5f) / N;
            if (v < 1.f - hh) continue;
            float t = (v - (1.f - hh)) / hh;                       // 0 punta, 1 base
            float cx = x0 + lean * (1.f - t) * (1.f - t) * 1.6f;
            float hw = bw * std::pow(t, 0.8f) + 0.004f;
            for (int x = 0; x < N; x++) {
                float u = (x + 0.5f) / N, d = std::fabs(u - cx);
                if (d > hw + 0.02f) continue;
                float a = std::max(0.f, std::min(1.f, (hw - d) * N * 0.9f + 0.5f));
                put(x, y, r1 + (r0 - r1) * t, g1 + (g0 - g1) * t, b1 + (b0 - b1) * t, a);
            }
        }
    };
    auto flower = [&](float cx, float cy, float rad, float r, float g, float b, float cr, float cg, float cb, int petals) {
        for (int k = 0; k < petals; k++) {
            float a = 6.2831853f * k / petals;
            disc(cx + std::cos(a) * rad * 0.7f, cy + std::sin(a) * rad * 0.7f, rad * 0.55f, rad * 0.55f, r, g, b);
        }
        disc(cx, cy, rad * 0.45f, rad * 0.45f, cr, cg, cb);
    };
    const float FC[6][3] = {{1.f, 1.f, 0.95f}, {1.f, 0.85f, 0.15f}, {1.f, 0.45f, 0.65f}, {0.65f, 0.4f, 0.95f}, {0.95f, 0.2f, 0.15f}, {0.35f, 0.6f, 1.f}};
    if (style == 4) {   // pradera: pasto con florecitas
        for (int b = 0; b < 10; b++) {
            float sh = 0.8f + 0.3f * vegF(st);
            blade(0.06f + 0.88f * vegF(st), (vegF(st) - 0.5f) * 0.3f, 0.35f + 0.4f * vegF(st), 0.03f + 0.015f * vegF(st), 0.15f * sh, 0.38f * sh, 0.1f * sh, 0.45f * sh, 0.8f * sh, 0.25f * sh);
        }
        for (int f = 0; f < 5; f++) {
            float cx = 0.12f + 0.76f * (f + vegF(st) * 0.6f) / 5.f, top = 0.12f + 0.3f * vegF(st);
            blade(cx, (vegF(st) - 0.5f) * 0.1f, 1.f - top, 0.012f, 0.2f, 0.45f, 0.15f, 0.35f, 0.65f, 0.2f);
            const float* c = FC[(f + (int)(vegF(st) * 3)) % 6];
            flower(cx, top, 0.055f, c[0], c[1], c[2], 1.f, 0.85f, 0.2f, 5);
        }
    } else if (style == 5) {   // flores silvestres altas
        for (int f = 0; f < 5; f++) {
            float cx = 0.1f + 0.8f * (f + 0.5f) / 5.f, top = 0.1f + 0.28f * vegF(st);
            blade(cx, (vegF(st) - 0.5f) * 0.12f, 1.f - top, 0.014f, 0.15f, 0.4f, 0.12f, 0.3f, 0.6f, 0.18f);
            blade(cx, 0.1f, 0.3f, 0.04f, 0.15f, 0.4f, 0.12f, 0.3f, 0.65f, 0.2f);
            const float* c = FC[(f * 2 + 1) % 6];
            flower(cx, top, 0.085f, c[0], c[1], c[2], f % 2 ? 0.25f : 1.f, f % 2 ? 0.15f : 0.8f, 0.1f, f % 2 ? 8 : 6);
        }
    } else if (style == 6) {   // helecho
        for (int s = 0; s < 3; s++) {
            float lean = (s - 1) * 0.22f, x0 = 0.5f + (s - 1) * 0.08f;
            blade(x0, lean, 0.95f - s * 0.08f, 0.012f, 0.15f, 0.35f, 0.1f, 0.2f, 0.5f, 0.15f);
            for (int k = 0; k < 14; k++) {
                float t = 0.08f + 0.85f * k / 14.f;                  // 0 punta .. 1 base
                float y = (1.f - (0.95f - s * 0.08f)) + t * (0.95f - s * 0.08f);
                float cx = x0 + lean * (1.f - t) * (1.f - t) * 1.6f;
                float len = 0.22f * std::sin(t * 3.0f) * (1.f - 0.4f * t) + 0.04f;
                for (int side = -1; side <= 1; side += 2) {
                    float ex = cx + side * len * 0.55f, ey = y - len * 0.2f;
                    disc(ex, ey, len * 0.55f, 0.022f, 0.12f + 0.1f * t, 0.38f + 0.2f * (1.f - t), 0.1f);
                }
            }
        }
    } else if (style == 7) {   // arbusto frondoso
        for (int k = 0; k < 70; k++) {
            float ang = vegF(st) * 6.2831853f, rr = std::sqrt(vegF(st)) * 0.38f;
            float cx = 0.5f + std::cos(ang) * rr, cy = 0.5f + std::sin(ang) * rr * 0.9f - 0.02f;
            if (cy > 0.97f) continue;
            float sh = 0.7f + 0.5f * (1.f - cy) * vegF(st);
            disc(cx, cy, 0.075f, 0.045f, 0.12f * sh, 0.4f * sh, 0.1f * sh);
        }
        for (int k = 0; k < 9; k++) disc(0.3f + 0.4f * vegF(st), 0.25f + 0.5f * vegF(st), 0.03f, 0.03f, 0.95f, 0.35f + 0.4f * vegF(st), 0.45f);   // bayas / flores pequeñas
    } else if (style == 8) {   // pasto seco / paja
        for (int b = 0; b < 12; b++) {
            float sh = 0.8f + 0.3f * vegF(st);
            blade(0.06f + 0.88f * vegF(st), (vegF(st) - 0.5f) * 0.45f, 0.5f + 0.5f * vegF(st), 0.022f + 0.012f * vegF(st), 0.55f * sh, 0.4f * sh, 0.15f * sh, 0.92f * sh, 0.8f * sh, 0.4f * sh);
        }
    } else if (style == 9) {   // cañas y juncos
        for (int b = 0; b < 5; b++) {
            float cx = 0.14f + 0.72f * (b + 0.5f) / 5.f, top = 0.04f + 0.22f * vegF(st);
            blade(cx, (vegF(st) - 0.5f) * 0.1f, 1.f - top, 0.014f, 0.25f, 0.42f, 0.15f, 0.5f, 0.65f, 0.25f);
            if (b % 2 == 0) disc(cx, top + 0.07f, 0.022f, 0.08f, 0.38f, 0.22f, 0.1f);   // espiga de totora
            blade(cx + 0.03f, 0.2f, 0.55f, 0.025f, 0.2f, 0.4f, 0.12f, 0.45f, 0.65f, 0.22f);
        }
    } else if (style == 10) {  // trébol: césped bajo con tréboles y florecitas blancas
        for (int k = 0; k < 26; k++) {
            float cx = 0.05f + 0.9f * vegF(st), cy = 0.25f + 0.7f * vegF(st), r = 0.045f + 0.02f * vegF(st), sh = 0.75f + 0.4f * vegF(st);
            for (int l = 0; l < 3; l++) { float a = 6.2831853f * l / 3.f + 0.5f; disc(cx + std::cos(a) * r * 0.9f, cy + std::sin(a) * r * 0.9f, r, r, 0.14f * sh, 0.45f * sh, 0.12f * sh); }
        }
        for (int k = 0; k < 5; k++) flower(0.1f + 0.8f * vegF(st), 0.15f + 0.6f * vegF(st), 0.035f, 1.f, 1.f, 0.97f, 1.f, 0.9f, 0.3f, 6);
    } else {                   // 11: hongos
        for (int m = 0; m < 3; m++) {
            float cx = 0.2f + 0.3f * m + (vegF(st) - 0.5f) * 0.06f, cap = 0.12f + 0.07f * vegF(st), top = 0.35f + 0.25f * (m % 2) * vegF(st);
            blade(cx, 0.f, 0.85f - top, 0.03f, 0.88f, 0.82f, 0.68f, 0.95f, 0.9f, 0.78f);
            bool red = m != 1;
            disc(cx, top + 0.02f, cap, cap * 0.62f, red ? 0.85f : 0.55f, red ? 0.12f : 0.35f, red ? 0.1f : 0.2f);
            if (red) for (int d = 0; d < 4; d++) disc(cx - cap * 0.6f + cap * 1.2f * vegF(st), top - cap * 0.2f + cap * 0.5f * vegF(st), 0.018f, 0.018f, 1.f, 1.f, 0.95f);
        }
    }
    std::vector<uint8_t> out((size_t)N * N * 4);
    for (size_t i = 0; i < px.size(); i++) out[i] = (uint8_t)std::max(0.f, std::min(255.f, px[i] * 255.f));
    return uploadRGBA(key, N, N, out.data());
}

unsigned Renderer::vegTexture(int style) {
    std::string key = "::veg" + std::to_string(style);
    if (tex_.count(key)) return tex_[key].id;
    const int N = 64;
    std::vector<uint8_t> px((size_t)N * N * 4, 0);
    unsigned st = 12345u + style * 77u;
    auto put = [&](int x, int y, float lum, float a) {
        if (x < 0 || y < 0 || x >= N || y >= N) return;
        uint8_t* o = &px[((size_t)y * N + x) * 4];
        float na = std::max((float)o[3] / 255.f, a);
        if (a >= (float)o[3] / 255.f) { o[0] = o[1] = o[2] = (uint8_t)std::max(0.f, std::min(255.f, lum * 255.f)); }
        o[3] = (uint8_t)(na * 255.f);
    };
    if (style >= 4) return vegColorTexture(style);
    if (style == 2) {
        for (size_t i = 0; i < px.size(); i += 4) { px[i] = px[i + 1] = px[i + 2] = 255; px[i + 3] = 255; }
    } else {
        int blades = style == 1 ? 3 : 11;
        for (int b = 0; b < blades; b++) {
            float x0 = style == 1 ? 0.22f + 0.28f * b : 0.08f + 0.84f * vegF(st);
            float lean = style == 1 ? (b - 1) * 0.12f : (vegF(st) - 0.5f) * 0.38f;
            float hh = style == 1 ? (b == 1 ? 0.98f : 0.8f) : 0.45f + 0.55f * vegF(st);
            float var = 0.82f + 0.2f * vegF(st);
            float bw = style == 1 ? 0.085f : 0.03f + 0.02f * vegF(st);
            for (int y = 0; y < N; y++) {
                float v = (y + 0.5f) / N;
                if (v < 1.f - hh) continue;
                float t = (v - (1.f - hh)) / hh;                        // 0 punta, 1 base
                float cx = x0 + lean * (1.f - t) * (1.f - t) * 1.6f;     // la punta se dobla
                float hw = bw * std::pow(t, style == 1 ? 0.55f : 0.8f) + 0.004f;
                for (int x = 0; x < N; x++) {
                    float u = (x + 0.5f) / N, d = std::fabs(u - cx);
                    if (d > hw + 0.02f) continue;
                    float a = std::max(0.f, std::min(1.f, (hw - d) * N * 0.9f + 0.5f));
                    if (a <= 0.f) continue;
                    float lum = style == 1 ? ((hw - d) * N < 1.6f ? 0.42f : 0.97f) : (0.62f + 0.38f * (1.f - t)) * var * (d < hw * 0.18f ? 0.9f : 1.f);
                    put(x, y, lum, a);
                }
            }
        }
    }
    return uploadRGBA(key, N, N, px.data());
}

// ---------------------------------------------------------------- pintura de suelo
static float gHash(int x, int y, int seed) {
    unsigned h = (unsigned)(x * 374761393 + y * 668265263 + seed * 2147483647u);
    h = (h ^ (h >> 13)) * 1274126177u;
    return (float)((h ^ (h >> 16)) & 0xFFFF) / 65535.f;
}
// ruido de valor que se repite (para que la textura no tenga costuras)
static float gNoise(float x, float y, int period, int seed) {
    int xi = (int)std::floor(x), yi = (int)std::floor(y);
    float fx = x - xi, fy = y - yi;
    fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
    auto v = [&](int a, int b) { return gHash(((a % period) + period) % period, ((b % period) + period) % period, seed); };
    float a = v(xi, yi) + (v(xi + 1, yi) - v(xi, yi)) * fx, b = v(xi, yi + 1) + (v(xi + 1, yi + 1) - v(xi, yi + 1)) * fx;
    return a + (b - a) * fy;
}
static float gFbm(float u, float v, int base, int oct, int seed) {
    float a = 0.5f, sum = 0.f, nrm = 0.f;
    int per = base;
    for (int o = 0; o < oct; o++) { sum += a * gNoise(u * per, v * per, per, seed + o); nrm += a; a *= 0.5f; per *= 2; }
    return sum / nrm;
}

unsigned Renderer::groundTexture(int preset) {
    std::string key = "::gnd" + std::to_string(preset);
    if (tex_.count(key)) return tex_[key].id;
    const int N = 128;
    std::vector<uint8_t> px((size_t)N * N * 4);
    for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++) {
            float u = (float)x / N, v = (float)y / N, r, g, b;
            float n1 = gFbm(u, v, 4, 5, preset * 11), n2 = gFbm(u, v, 16, 3, preset * 11 + 5);
            switch (preset) {
                case 0: { float k = 0.78f + 0.22f * n1 + (n2 - 0.5f) * 0.12f; r = 0.86f * k; g = 0.74f * k; b = 0.50f * k; break; }   // arena
                case 1: { float k = 0.65f + 0.5f * n1; float st = gFbm(u * 2.f, v * 0.25f, 8, 3, 91); r = (0.20f + 0.18f * st) * k; g = (0.48f + 0.22f * st) * k; b = 0.12f * k; break; }  // pasto
                case 2: { float c = std::fabs(gFbm(u, v, 6, 4, 33) - 0.5f) * 2.f; float k = 0.42f + 0.3f * n1 - (c < 0.06f ? 0.18f : 0.f); r = k; g = k * 0.98f; b = k * 0.94f; break; }  // roca
                case 3: { float k = 0.92f + 0.08f * n2; r = k * 0.94f; g = k * 0.97f; b = k; break; }                                      // nieve
                default: { float k = 0.55f + 0.6f * n1; r = 0.42f * k; g = 0.29f * k; b = 0.18f * k; break; }                              // tierra
            }
            uint8_t* o = &px[((size_t)y * N + x) * 4];
            o[0] = (uint8_t)std::max(0.f, std::min(255.f, r * 255.f));
            o[1] = (uint8_t)std::max(0.f, std::min(255.f, g * 255.f));
            o[2] = (uint8_t)std::max(0.f, std::min(255.f, b * 255.f));
            o[3] = 255;
        }
    return uploadRGBA(key, N, N, px.data());
}

// Pinceladas de textura sobre el suelo: cuadritos suaves que siguen el relieve del terreno.
void Renderer::drawGround(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.gnd.empty()) return;
    std::vector<const Obj*> terr, flats;
    for (auto& o : S.objs) if (o.alive && o.kind == Kind::Floor && o.solid) (o.tn >= 2 ? terr : flats).push_back(&o);
    const bool haveSurf = !terr.empty() || !flats.empty();
    // La pintura solo se dibuja sobre superficie con colisión (terreno o suelo): fuera de ella no hay nada que pintar.
    auto surfY = [&](float x, float z, float fallback) -> float {
        float best = -1e9f;
        for (auto* o : terr) { float ty = terrainSurface(*o, x, z); if (ty > best) best = ty; }
        for (auto* o : flats) {
            float a = o->yaw * 0.0174532925f, c = std::cos(a), sn = std::sin(a), dx = x - o->pos.x, dz = z - o->pos.z;
            float lx = c * dx - sn * dz, lz = sn * dx + c * dz;
            if (std::fabs(lx) <= o->scale.x * 0.5f && std::fabs(lz) <= o->scale.z * 0.5f) best = std::max(best, o->pos.y + o->scale.y * 0.5f);
        }
        if (best > -1e8f) return best;
        return haveSurf ? -1e9f : fallback;
    };
    unsigned long long terrSig = 1469598103934665603ULL;
    {
        auto mix = [&](float f) { unsigned u; std::memcpy(&u, &f, 4); terrSig = (terrSig ^ u) * 1099511628211ULL; };
        for (auto* o : terr) { mix(o->pos.x); mix(o->pos.y); mix(o->pos.z); mix(o->scale.x); mix(o->scale.z); mix(o->yaw); mix((float)o->terrVer); }
        for (auto* o : flats) { mix(o->pos.x); mix(o->pos.y); mix(o->pos.z); mix(o->scale.x); mix(o->scale.y); mix(o->scale.z); mix(o->yaw); }
        terrSig ^= std::hash<std::string>()(S.name);
    }
    glUniform1i(p.u("uVeg"), 3);
    glUniform1i(p.u("uUV1"), 1);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1f(p.u("uRefl"), 0.f);
    M4 id = modelMat(V3{0, 0, 0}, 0.f, V3{1, 1, 1});
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, id.m);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glDepthFunc(GL_LEQUAL);
    struct GCache { unsigned long long terr = 0; size_t done = 0; float lastP[4] = {0, 0, 0, 0}; std::vector<float> v; std::vector<uint32_t> idx; unsigned long long gen = 0; };
    static std::unordered_map<std::string, GCache> gcache;
    static std::unordered_map<std::string, double> lastBuild;
    for (size_t li = 0; li < S.gnd.size(); li++) {
        const GroundLayer& L = S.gnd[li];
        size_t n = L.pts.size() / 4;
        if (!n) continue;
        std::string key = "::gnd:" + std::to_string(li);
        GCache& gc = gcache[key];
        // ¿se puede seguir sumando? (mismo suelo, no se borró nada)
        bool same = gc.terr == terrSig && gc.done > 0 && gc.done <= n && std::memcmp(gc.lastP, &L.pts[(gc.done - 1) * 4], 16) == 0;
        if (!same) { gc.v.clear(); gc.idx.clear(); gc.done = 0; gc.terr = terrSig; gc.gen++; }
        if (gc.done < n) {
            for (size_t i = gc.done; i < n; i++) {
                const float* P = &L.pts[i * 4];
                float sz = std::max(0.2f, P[3]);
                int C = 2;
                for (int pass = 0; pass < 2; pass++) {
                    int G = C + 1;
                    std::vector<float> ys((size_t)G * G), xs((size_t)G * G), zs((size_t)G * G);
                    bool allOk = true;
                    for (int a = 0; a < G; a++) for (int b = 0; b < G; b++) {
                        float x = P[0] + ((float)a / C - 0.5f) * 2.f * sz, z = P[2] + ((float)b / C - 0.5f) * 2.f * sz;
                        float y = surfY(x, z, P[1]);
                        xs[a * G + b] = x; zs[a * G + b] = z; ys[a * G + b] = y;
                        if (y < -1e8f) allOk = false;
                    }
                    if (!allOk && pass == 0 && C == 2) { C = 6; continue; }   // borde del suelo: más fino para recortar bien
                    uint32_t base = (uint32_t)(gc.v.size() / 8);
                    for (int a = 0; a < G; a++) for (int b = 0; b < G; b++)
                        gc.v.insert(gc.v.end(), {xs[a * G + b], ys[a * G + b] > -1e8f ? ys[a * G + b] + 0.025f + li * 0.004f : 0.f, zs[a * G + b], 0, 1, 0, (float)a / C, (float)b / C});
                    for (int a = 0; a < C; a++) for (int b = 0; b < C; b++) {
                        uint32_t i0 = base + a * G + b, i1 = i0 + 1, i2 = i0 + G, i3 = i2 + 1;
                        if (ys[a * G + b] < -1e8f || ys[a * G + b + 1] < -1e8f || ys[(a + 1) * G + b] < -1e8f || ys[(a + 1) * G + b + 1] < -1e8f) continue;   // no pinta la nada
                        gc.idx.insert(gc.idx.end(), {i0, i2, i1, i1, i2, i3});
                    }
                    break;
                }
            }
            gc.done = n;
            std::memcpy(gc.lastP, &L.pts[(n - 1) * 4], 16);
            gc.gen++;
        }
        if (gc.idx.empty()) continue;
        unsigned long long sig = gc.gen * 1000003ULL ^ (gc.done * 7919ULL);
        auto it = models_.find(key);
        ModelGL* md = nullptr;
        double nowT = (double)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        if (it != models_.end() && it->second.sig == sig) md = &it->second;
        else if (it != models_.end() && nowT - lastBuild[key] < 120.0) md = &it->second;   // mientras pintas: sube la malla poco a poco
        else { lastBuild[key] = nowT; md = dynModel(key, gc.v, gc.idx, sig); }
        glBindVertexArray(md->vao);
        float col[3] = {1.f, 1.f, 1.f};
        glUniform4f(p.u("uColor"), col[0], col[1], col[2], 1.f);
        glUniform1f(p.u("uGS"), L.scale);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, L.preset == 5 ? texture(g, L.tex).id : groundTexture(L.preset));
        glDrawElements(GL_TRIANGLES, md->count, md->itype, nullptr);
    }
    glBindVertexArray(vao_);
    glDepthFunc(GL_LESS);
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    glEnable(GL_CULL_FACE);
    glUniform1i(p.u("uVeg"), 0);
    glUniform1i(p.u("uUV1"), 0);
}

void Renderer::drawVeg(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.veg.empty()) return;
    const int q = g.proj.quality;
    const float frac = q == 0 ? 0.35f : q == 1 ? 0.7f : 1.f;
    glDisable(GL_CULL_FACE);
    glUniform1i(p.u("uVeg"), 1);
    glUniform1i(p.u("uUV1"), 1);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1f(p.u("uRefl"), 0.f);
    M4 id = modelMat(V3{0, 0, 0}, 0.f, V3{1, 1, 1});
    glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, id.m);
    for (size_t li = 0; li < S.veg.size(); li++) {
        const VegLayer& L = S.veg[li];
        size_t n = L.pts.size() / 5;
        if (!n) continue;
        auto cardsOf = [](int s) { return s == 0 || s == 4 || s == 6 || s == 7 || s == 8 ? 3 : 2; };
        const int vpt = L.style == 2 ? 9 : cardsOf(L.style) * 6;
        unsigned long long sig = (unsigned long long)L.ver * 1000003ULL ^ (n * 7919ULL) ^ ((unsigned long long)L.style << 40);
        { float a[2] = {L.h, L.w}; unsigned u[2]; std::memcpy(u, a, sizeof u); sig ^= ((unsigned long long)u[0] << 8) ^ ((unsigned long long)u[1] << 24); }
        sig ^= std::hash<std::string>()(S.name) << 5;
        std::string key = "::veg:" + std::to_string(li);
        auto it = models_.find(key);
        ModelGL* md = nullptr;
        static std::unordered_map<std::string, double> lastBuildV;
        double nowT = (double)std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        if (it != models_.end() && it->second.sig == sig) md = &it->second;
        else if (it != models_.end() && nowT - lastBuildV[key] < 160.0) md = &it->second;
        else {
            lastBuildV[key] = nowT;
            std::vector<float> v;
            v.reserve(n * vpt * 8);
            auto vert = [&](float x, float y, float z, float nx, float ny, float nz, float u, float w) {
                v.insert(v.end(), {x, y, z, nx, ny, nz, u, w});
            };
            for (size_t i = 0; i < n; i++) {
                const float* P = &L.pts[i * 5];
                float x = P[0], y = P[1], z = P[2], sz = std::max(0.1f, P[3]), rot = P[4] * 0.0174532925f;
                unsigned st = (unsigned)(i * 2654435761u) ^ 0x9e3779b9u;
                float hh = L.h * sz, hw = L.w * sz * 0.5f;
                if (L.style == 2) {  // lowpoly: tres hojas en triangulo
                    for (int b = 0; b < 3; b++) {
                        float a = rot + b * 2.0944f + vegF(st) * 0.5f;
                        float ca = std::cos(a), sa = std::sin(a), off = 0.10f * L.w * sz;
                        float bx = x + ca * off, bz = z + sa * off, wb = L.w * sz * 0.14f;
                        float tx = -sa * wb, tz = ca * wb;
                        float h2 = hh * (0.7f + 0.3f * vegF(st));
                        float px = bx + ca * 0.2f * h2, pz = bz + sa * 0.2f * h2;
                        V3 e1{2 * tx, 0, 2 * tz}, e2{px - (bx - tx), h2, pz - (bz - tz)};
                        V3 nn = cross(e1, e2);
                        float nl = std::sqrt(nn.x * nn.x + nn.y * nn.y + nn.z * nn.z);
                        if (nl > 1e-6f) nn = nn * (1.f / nl); else nn = V3{0, 1, 0};
                        if (nn.y < 0) nn = nn * -1.f;
                        vert(bx - tx, y, bz - tz, nn.x, nn.y, nn.z, 0.f, 1.f);
                        vert(bx + tx, y, bz + tz, nn.x, nn.y, nn.z, 1.f, 1.f);
                        vert(px, y + h2, pz, nn.x, nn.y, nn.z, 0.5f, 0.f);
                    }
                } else {
                    int cards = cardsOf(L.style);
                    for (int k = 0; k < cards; k++) {
                        float a = rot + k * (3.14159265f / cards);
                        float dx = std::cos(a) * hw, dz = std::sin(a) * hw;
                        float hv = hh * (0.85f + 0.3f * vegF(st));
                        // base izquierda, derecha, punta derecha, punta izquierda
                        vert(x - dx, y, z - dz, 0, 1, 0, 0.f, 1.f); vert(x + dx, y, z + dz, 0, 1, 0, 1.f, 1.f); vert(x + dx, y + hv, z + dz, 0, 1, 0, 1.f, 0.f);
                        vert(x - dx, y, z - dz, 0, 1, 0, 0.f, 1.f); vert(x + dx, y + hv, z + dz, 0, 1, 0, 1.f, 0.f); vert(x - dx, y + hv, z - dz, 0, 1, 0, 0.f, 0.f);
                    }
                }
            }
            std::vector<uint32_t> idx(v.size() / 8);
            for (size_t i = 0; i < idx.size(); i++) idx[i] = (uint32_t)i;
            md = dynModel(key, v, idx, sig);
        }
        glBindVertexArray(md->vao);
        glUniform4f(p.u("uColor"), L.col[0], L.col[1], L.col[2], 1.f);
        glUniform3f(p.u("uColor2"), L.col2[0], L.col2[1], L.col2[2]);
        glUniform1f(p.u("uSway"), L.sway * (L.style == 1 ? 0.34f : 0.2f) * L.h);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, L.style == 3 ? texture(g, L.tex).id : vegTexture(L.style));
        size_t cnt = std::max<size_t>(1, (size_t)(n * frac)) * vpt;
        glDrawElements(GL_TRIANGLES, (GLsizei)std::min<size_t>(cnt, md->count), md->itype, nullptr);
    }
    glBindVertexArray(vao_);
    glUniform1f(p.u("uSway"), 0.f);
    glUniform1i(p.u("uVeg"), 0);
    glUniform1i(p.u("uUV1"), 0);
    glEnable(GL_CULL_FACE);
}

// Mar: un plano grande y translucido que sigue a la camara y refleja el cielo.
void Renderer::drawSea(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (!S.sea) return;
    glUniform1i(p.u("uVeg"), 2);
    glUniform1i(p.u("uWS"), std::max(0, std::min(6, S.seaStyle)));
    glUniform1i(p.u("uUV1"), 0);
    glUniform1i(p.u("uUnlit"), 0);
    glBindTexture(GL_TEXTURE_2D, white_);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    box(p, V3{camE_.x, S.seaY - 0.01f, camE_.z}, V3{360.f, 0.02f, 360.f}, S.seaCol[0], S.seaCol[1], S.seaCol[2], S.seaStyle == 6 ? 1.f : std::max(0.1f, std::min(1.f, S.seaAlpha)));
    glDisable(GL_BLEND);
    glUniform1i(p.u("uVeg"), 0);
}

// Clima en el aire: lluvia, arena, nieve, niebla con particulas, personalizado. Estilo 0 = cajitas (clasico), 1 = realista.
void Renderer::drawAtmo(Game& g, Prog& p) {
    const Scene& S = *g.sc;
    if (S.atmo == 0 || (S.atmo == 1 && S.atmoStyle == 0)) return;
    float ac[3], aa;
    atmoDefaults(S.atmo, ac, aa);
    const float* col = S.atmo == 5 ? S.atmoCol : ac;
    const V3 e = camE_;
    const int qn = g.proj.quality == 0 ? 70 : g.proj.quality == 1 ? 180 : 360;
    int n = (int)(qn * (0.25f + std::min(S.atmoAmt, 3.f) * 1.5f));
    n = std::min(n, g.proj.quality == 0 ? 500 : 1400);
    const float t = g.time;
    const bool real = S.atmoStyle == 1;
    glUniform1i(p.u("uUnlit"), 1);
    glUniform1i(p.u("uUV1"), 1);
    if (!real) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    }
    unsigned dot = real ? softDot() : 0;
    for (int i = 0; i < n; i++) {
        auto h = [&](int k) { float x = std::sin((float)(i * 12.9898f + k * 78.233f)) * 43758.5453f; return x - std::floor(x); };
        float x = e.x + (h(1) - 0.5f) * 36.f, z = e.z + (h(2) - 0.5f) * 36.f, y, sx = 0.05f, sy = 0.05f, a = 0.7f;
        if (!real) {
            if (S.atmo == 2) { y = e.y + 14.f - std::fmod(t * 20.f + h(3) * 28.f, 28.f); sx = 0.02f; sy = 0.7f; a = 0.45f; }
            else if (S.atmo == 3) { x = e.x + 18.f - std::fmod(t * 14.f + h(1) * 36.f, 36.f); y = e.y - 2.f + h(3) * 8.f; sx = 0.14f; sy = 0.03f; a = 0.6f; }
            else { y = e.y + 12.f - std::fmod(t * 1.6f + h(3) * 24.f, 24.f); x += std::sin(t + h(4) * 6.28f) * 0.6f; sx = sy = 0.07f; }
            box(p, V3{x, y, z}, V3{sx, sy, sx}, col[0], col[1], col[2], a);
            continue;
        }
        float cr = col[0], cg = col[1], cb = col[2];
        float depth = 0.6f + 0.4f * h(7);
        if (S.atmo == 2) {          // lluvia: rayas finas que caen rapido, las cercanas se ven mas claras
            float sp = 24.f + 14.f * h(5);
            y = e.y + 14.f - std::fmod(t * sp + h(3) * 28.f, 28.f);
            x += (14.f - (y - e.y)) * 0.12f;           // un poco de viento
            float len = 0.7f + 0.8f * h(6);
            sx = 0.018f + 0.01f * h(8); sy = len; a = 0.22f + 0.28f * depth;
            cr = cr * 0.8f + 0.2f; cg = cg * 0.8f + 0.2f; cb = cb * 0.8f + 0.22f;
        } else if (S.atmo == 3) {   // arena: rafagas horizontales y polvo fino
            float sp = 9.f + 12.f * h(5);
            x = e.x + 18.f - std::fmod(t * sp + h(1) * 36.f, 36.f);
            y = e.y - 2.5f + h(3) * 9.f + std::sin(t * 1.3f + h(4) * 6.28f) * 0.3f;
            z += std::sin(t * 0.7f + h(2) * 6.28f) * 0.8f;
            bool streak = h(9) < 0.4f;
            sx = streak ? 0.9f + 1.4f * h(6) : 0.05f + 0.07f * h(6); sy = streak ? 0.035f : sx; a = streak ? 0.10f + 0.1f * depth : 0.35f + 0.3f * depth;
        } else if (S.atmo == 4) {   // nieve: copos de distinto tamaño que flotan
            y = e.y + 12.f - std::fmod(t * (0.9f + 1.4f * h(5)) + h(3) * 24.f, 24.f);
            x += std::sin(t * (0.6f + h(4)) + h(4) * 6.28f) * 0.9f;
            z += std::cos(t * (0.5f + h(6)) + h(2) * 6.28f) * 0.7f;
            sx = sy = 0.035f + 0.1f * h(6) * h(6) + 0.02f; a = 0.5f + 0.45f * depth;
        } else if (S.atmo == 1) {   // niebla con particulas en el aire (polvo / ceniza flotando) y jirones bajos
            bool wisp = i % 9 == 0;
            if (wisp) {
                x = e.x + (h(1) - 0.5f) * 30.f + std::sin(t * 0.08f + h(4) * 6.28f) * 2.f; z = e.z + (h(2) - 0.5f) * 30.f;
                y = e.y - 1.2f + h(3) * 1.8f;
                sx = sy = 3.f + 4.f * h(6); a = 0.035f + 0.04f * h(8);
            } else {
                y = e.y + 7.f - std::fmod(t * (0.12f + 0.2f * h(5)) + h(3) * 14.f, 14.f);
                x += std::sin(t * 0.25f + h(4) * 6.28f) * 1.2f; z += std::cos(t * 0.2f + h(2) * 6.28f) * 1.2f;
                sx = sy = 0.03f + 0.09f * h(6) * h(6); a = 0.25f + 0.4f * depth;
            }
        } else {                    // personalizado: puntos suaves flotando
            y = e.y + 10.f - std::fmod(t * (0.8f + h(5)) + h(3) * 20.f, 20.f);
            x += std::sin(t * 0.7f + h(4) * 6.28f) * 0.6f;
            sx = sy = 0.05f + 0.08f * h(6); a = 0.4f + 0.4f * depth;
        }
        float yaw = std::atan2(e.x - x, e.z - z) / 0.0174532925f;
        ovTex_ = dot;
        drawModelAt(g, p, "", "", V3{x, y, z}, yaw, V3{sx, sy, 0.01f}, cr, cg, cb, std::min(1.f, a));
    }
    ovTex_ = 0;
    glDisable(GL_BLEND);
    glUniform1i(p.u("uUnlit"), 0);
    glUniform1i(p.u("uUV1"), 0);
}

// El cuerpo del jugador (tercera persona) también proyecta sombra.
void Renderer::drawPlayerShadow(Game& g, Prog& p, const EditorView* ev) {
    if (ev || g.camMode == kFirstPerson || !g.sc || g.carIdx >= 0) return;
    const Scene& S = *g.sc;
    int pi = playerIndex(S);
    if (pi < 0) return;
    glUniform1f(p.u("uAlpha"), 1.f);
    V3 sc = S.objs[pi].scale;
    const PlayerCfg& pcg = g.proj.player;
    float yawDeg = g.bodyYaw / 0.0174532925f;
    yawDeg = 180.f - yawDeg;
    V3 rgtB{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fwdB{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
    V3 mid{g.pos.x, g.pos.y + sc.y * 0.5f, g.pos.z};
    V3 midM = mid + rgtB * pcg.mox + V3{0, pcg.moy, 0} + fwdB * pcg.moz;
    if (!pcg.model.empty()) {
        forceMd_ = skinned(g, pi, pcg.model, model(g, pcg.model));
        drawModelAt(g, p, pcg.model, "", midM, yawDeg + pcg.myaw, plScaleOf(g, pcg.model, sc, pcg), 1.f, 1.f, 1.f, 1.f);
    } else {
        box(p, V3{g.pos.x, g.pos.y + sc.y * 0.5f, g.pos.z}, V3{sc.x * 0.7f, sc.y, sc.z * 0.5f}, 1.f, 1.f, 1.f, 1.f);
    }
}

// Escala del modelo del jugador: con «fit» se escala parejo para caber en la caja de colisión (sin deformarse).
V3 Renderer::plScaleOf(const Game& g, const std::string& mdl, V3 sc, const PlayerCfg& pc) {
    if (pc.fit && !mdl.empty()) {
        if (auto* m = model(g, mdl)) {
            float ex = std::max(0.001f, m->bmax[0] - m->bmin[0]), ey = std::max(0.001f, m->bmax[1] - m->bmin[1]), ez = std::max(0.001f, m->bmax[2] - m->bmin[2]);
            float k = std::min(sc.x / ex, std::min(sc.y / ey, sc.z / ez));
            return V3{k, k, k} * pc.mscale;
        }
    }
    return sc * pc.mscale;
}

// Cosas que se mueven y no son objetos de la escena: cuerpo del jugador y proyectiles.
void Renderer::drawDynamic(Game& g, Prog& p, const EditorView* ev) {
    const Scene& S = *g.sc;
    int pi = playerIndex(S);
    glUniform1i(p.u("uUnlit"), 0);
    if (!ev && (g.camMode != kFirstPerson || g.proj.player.fpBody) && g.carIdx < 0) {  // el jugador se ve en tercera persona (o su cuerpo en primera, si se pide)
        V3 sc = pi >= 0 ? S.objs[pi].scale : V3{0.6f, 1.7f, 0.6f};
        float yawDeg = g.bodyYaw / 0.0174532925f;
        yawDeg = 180.f - yawDeg;   // v10.7: el frente del modelo (+Z) apunta hacia donde mira/avanza
        Game::ObjVis pv;
        if (pi >= 0) pv = g.vis(pi);
        V3 mid{g.pos.x, g.pos.y + sc.y * 0.5f + pv.bob, g.pos.z};
        const PlayerCfg& pcg = g.proj.player;
        V3 rgtB{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fwdB{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
        V3 midF = mid;
        {   // el modelo apoya los pies en el suelo según su altura real (antes flotaba si no era tan alto como ancho)
            const std::string& pmn = (pv.billboard ? std::string() : (!pv.model.empty() ? pv.model : pcg.model));
            if (!pmn.empty()) if (ModelGL* pm = model(g, pmn)) midF.y = g.pos.y + pv.bob - pm->bmin[1] * plScaleOf(g, pmn, sc, pcg).y;
        }
        V3 midM = midF + rgtB * pcg.mox + V3{0, pcg.moy, 0} + fwdB * pcg.moz;
        const float lean = pcg.vehicle ? -g.carLean_ * 14.f : 0.f;   // al girar el coche del jugador se ve rotar hacia ese lado
        bool hasAnim = pi >= 0 && (!pv.tex.empty() || !pv.model.empty() || pv.billboard);
        if (pv.billboard && !pv.tex.empty()) {  // imagen plana que mira a la camara
            drawSprite(g, p, pv.tex, mid, sc.x * 1.6f, sc.y, 1.f, 1.f, 1.f);
        } else if (hasAnim && !pv.model.empty()) {
            drawModelAt(g, p, pv.model, "", midM, yawDeg + pcg.myaw + pv.sway + lean, plScaleOf(g, pv.model, sc, pcg), 1.f, 1.f, 1.f, 1.f);
        } else if (!g.proj.player.model.empty()) {
            if (pi >= 0) forceMd_ = skinned(g, pi, g.proj.player.model, model(g, g.proj.player.model));
            drawModelAt(g, p, g.proj.player.model, "", midM, yawDeg + pcg.myaw + pv.sway + lean, [&] { V3 q = plScaleOf(g, g.proj.player.model, sc, pcg); return V3{q.x, q.y * pv.squash, q.z}; }(), 1.f, 1.f, 1.f, 1.f);
        } else {  // muneco basico
            float H = sc.y;
            box(p, V3{g.pos.x, g.pos.y + H * 0.34f, g.pos.z}, V3{sc.x * 0.8f, H * 0.34f, sc.z * 0.5f}, 0.2f, 0.45f, 0.9f, 1.f);
            box(p, V3{g.pos.x, g.pos.y + H * 0.8f, g.pos.z}, V3{sc.x * 0.55f, H * 0.18f, sc.x * 0.55f}, 1.f, 0.8f, 0.65f, 1.f);
            box(p, V3{g.pos.x, g.pos.y + H * 0.12f, g.pos.z}, V3{sc.x * 0.6f, H * 0.24f, sc.z * 0.45f}, 0.2f, 0.2f, 0.35f, 1.f);
        }
    }
    if (!ev && g.punchT_ > 0.f && g.camMode != kFirstPerson) {   // v10.9: puño visible al golpear
        float H = pi >= 0 ? S.objs[pi].scale.y : 1.7f;
        float k = std::sin((1.f - g.punchT_ / 0.22f) * 3.14159f);   // sale y vuelve
        V3 fw{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
        V3 fist = V3{g.pos.x, g.pos.y + H * 0.62f, g.pos.z} + fw * (0.3f + 1.1f * k);
        box(p, fist, V3{0.17f, 0.15f, 0.17f}, 1.f, 0.78f, 0.62f, 1.f);
        box(p, fist - fw * 0.35f, V3{0.09f, 0.09f, 0.09f}, 1.f, 0.78f, 0.62f, 1.f);
    }
    if (!ev && g.net_.active() && S.is3d) {   // v10.7: otros jugadores de la red local
        V3 psc = pi >= 0 ? S.objs[pi].scale : V3{0.6f, 1.7f, 0.6f};
        const PlayerCfg& pc2 = g.proj.player;
        for (auto& kv : g.net_.peers()) {
            const NetPeer& q = kv.second;
            if (q.scene != S.name) continue;
            float yd = 180.f - q.yaw / 0.0174532925f;
            V3 mid{q.x, q.y + psc.y * 0.5f + pc2.moy * 0.f, q.z};
            if (!pc2.model.empty()) drawModelAt(g, p, pc2.model, "", mid + V3{0, pc2.moy, 0}, yd + pc2.myaw, psc * pc2.mscale, 0.9f, 0.9f, 1.f, 1.f);
            else box(p, mid, V3{psc.x * 0.8f, psc.y, psc.z * 0.5f}, 0.95f, 0.45f, 0.2f, 1.f);
        }
    }
    if (!ev && g.camMode != kFirstPerson && g.curWeapon() && g.curWeapon()->enabled) {  // arma en la mano (tercera persona)
        const Weapon& wp = *g.curWeapon();
        float H = pi >= 0 ? S.objs[pi].scale.y : 1.7f;
        V3 rg{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fw{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
        float yawW = 180.f - g.bodyYaw / 0.0174532925f;
        V3 hand = V3{g.pos.x, g.pos.y + H * 0.55f, g.pos.z} + rg * (0.28f * H * 0.6f) + fw * (0.32f * H * 0.6f);
        float sz = std::max(0.25f, wp.scale) * H * 0.55f;
        glUniform1i(p.u("uUnlit"), 0);
        bool held = false;
        if (wp.inHand && !wp.model.empty() && pi >= 0 && !g.proj.player.model.empty() && g.carIdx < 0) {   // en la mano del modelo (hueso de la mano)
            const PlayerCfg& pcg = g.proj.player;
            V3 psc = S.objs[pi].scale;
            Game::ObjVis pv = g.vis(pi);
            V3 rgtB{std::cos(g.bodyYaw), 0, std::sin(g.bodyYaw)}, fwdB{std::sin(g.bodyYaw), 0, -std::cos(g.bodyYaw)};
            V3 mid{g.pos.x, g.pos.y + psc.y * 0.5f + pv.bob, g.pos.z};
            const std::string& pmn = !pv.model.empty() ? pv.model : pcg.model;
            if (ModelGL* pm = model(g, pmn)) mid.y = g.pos.y + pv.bob - pm->bmin[1] * plScaleOf(g, pmn, psc, pcg).y;
            V3 midM = mid + rgtB * pcg.mox + V3{0, pcg.moy, 0} + fwdB * pcg.moz;
            held = drawHeld(g, p, pi, pmn, modelMat(midM, yawW + pcg.myaw + pv.sway, plScaleOf(g, pmn, psc, pcg)), yawW + pcg.myaw + pv.sway, wp.model, wp.handSide, wp.hrot, wp.hoff, sz * wp.hscale);
        }
        if (held) {}
        else if (!wp.model.empty()) drawModelAt(g, p, wp.model, "", hand, yawW, V3{sz, sz, sz}, 1.f, 1.f, 1.f, 1.f);
        else if (wp.type == 1) drawModelAt(g, p, "", "", hand + fw * 0.15f, yawW, V3{0.04f, 0.04f, sz * 0.9f}, 0.75f, 0.78f, 0.85f, 1.f);  // hoja
        else if (wp.type >= 2) drawModelAt(g, p, "", "", hand, yawW, V3{0.09f, 0.09f, 0.09f}, 0.25f, 0.3f, 0.2f, 1.f);
        else drawModelAt(g, p, "", "", hand, yawW, V3{0.05f, 0.07f, sz * 0.8f}, 0.12f, 0.12f, 0.14f, 1.f);
    }
    for (auto& b : g.booms) {   // explosiones (imágenes en orden, modelo 3D o el destello por defecto)
        float k = std::min(1.f, b.t / b.max), fade = 1.f - k * k;
        const BoomCfg& bc = g.proj.boom;
        if (bc.mode == 1 && !bc.frames.empty()) {
            size_t fi = std::min(bc.frames.size() - 1, (size_t)(k * bc.frames.size()));
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            drawSprite(g, p, bc.frames[fi], b.p, b.size, b.size, 1.f, 1.f, 1.f);
        } else if (bc.mode == 2 && !bc.model.empty() && b.is3) {
            float sc2 = b.size * (0.3f + 0.9f * std::sqrt(k));
            drawModelAt(g, p, bc.model, "", b.p, k * 90.f, V3{sc2, sc2, sc2}, 1.f, 1.f, 1.f, 1.f);
        } else if (bc.mode == 0) {   // destello: esfera de fuego que se expande
            float sc2 = b.size * (0.4f + 1.1f * std::sqrt(k));
            glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE);
            box(p, b.p, V3{sc2, sc2, sc2}, 1.f, 0.6f + 0.3f * (1.f - k), 0.15f, 0.5f * fade);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        }
    }
    for (auto& d : g.debris) {  // pedazos de objetos rotos
        float a = std::min(1.f, d.life * 2.f);
        drawModelAt(g, p, "", d.tex, d.p, d.ang, V3{d.size, d.size, d.size}, d.col[0], d.col[1], d.col[2], a);
    }
    for (auto& pr : g.projs) {
        float s = pr.size;
        if (pr.shape == 2 && !pr.model.empty()) {
            float yaw = 180.f - std::atan2(pr.v.x, -pr.v.z) / 0.0174532925f;
            drawModelAt(g, p, pr.model, "", pr.p, yaw, V3{s * 2.f, s * 2.f, s * 2.f}, 1.f, 1.f, 1.f, 1.f);
        } else if (pr.shape == 1 && !pr.tex.empty()) {
            drawSprite(g, p, pr.tex, pr.p, s * 2.f, s * 2.f, 1.f, 1.f, 1.f);
        } else {
            glUniform1i(p.u("uUnlit"), 1);
            box(p, pr.p, V3{s, s, s}, pr.col[0], pr.col[1], pr.col[2], 1.f);
            glUniform1i(p.u("uUnlit"), 0);
        }
    }
}

// Desplaza el tono de un color (0..200 como en Pocket Code = vuelta completa).
static void hueShift(float c[3], float amount) {
    if (amount == 0) return;
    float a = amount / 200.f * 6.2831853f, cs = std::cos(a), sn = std::sin(a);
    float r = c[0], g = c[1], b = c[2];
    // rotacion alrededor del eje gris
    c[0] = (.299f + .701f * cs + .168f * sn) * r + (.587f - .587f * cs + .330f * sn) * g + (.114f - .114f * cs - .497f * sn) * b;
    c[1] = (.299f - .299f * cs - .328f * sn) * r + (.587f + .413f * cs + .035f * sn) * g + (.114f - .114f * cs + .292f * sn) * b;
    c[2] = (.299f - .300f * cs + 1.25f * sn) * r + (.587f - .588f * cs - 1.05f * sn) * g + (.114f + .886f * cs - .203f * sn) * b;
    for (int i = 0; i < 3; i++) c[i] = std::max(0.f, std::min(1.f, c[i]));
}

void Renderer::drawObjs(Game& g, Prog& p, bool shadow) {
    const bool is3 = g.sc->is3d;
    std::vector<int> order;
    order.reserve(g.sc->objs.size());
    for (int i = 0; i < (int)g.sc->objs.size(); i++) order.push_back(i);
    if (!is3)  // 2D: el fondo primero y despues por capa
        std::stable_sort(order.begin(), order.end(), [&](int a, int b) {
            const Obj &x = g.sc->objs[a], &y = g.sc->objs[b];
            long long lx = x.bg ? -2000000000LL : (long long)x.layer * 2 + (x.ghost ? 0 : 1), ly = y.bg ? -2000000000LL : (long long)y.layer * 2 + (y.ghost ? 0 : 1);   // la estela va en la misma capa pero detrás del objeto
            return lx < ly;
        });
    for (int idx : order) {
        const Obj& o = g.sc->objs[idx];
        if (!o.alive || !o.visible) continue;
        if (o.kind == Kind::Light || o.kind == Kind::Player) continue;
        if (probing_ && idx == probeObj_) continue;   // el objeto del que sale el reflejo no se ve a sí mismo
        if (is3 && o.kind != Kind::Floor) {   // v11.5: no se dibuja lo que no se puede ver (mismo resultado, menos trabajo)
            float rad = std::max(o.scale.x, std::max(o.scale.y, o.scale.z)) * 1.1f + 1.5f;
            if (shadow && shOn_) {
                V3 d = o.pos - shC_;
                float t = dot(d, shD_);
                V3 q = d - shD_ * t;
                float lat = std::sqrt(dot(q, q));
                if (lat > 24.f * 1.4143f + rad || std::fabs(t) > 110.f + rad) continue;
            } else if (!shadow && cullOn_) {
                bool out = false;
                if (perfDist_ > 0.f) { V3 dd = o.pos - perfEye_; if (dot(dd, dd) > (perfDist_ + rad) * (perfDist_ + rad)) continue; }
                for (int pl = 0; pl < 5 && !out && perfCull_; pl++) {
                    float a, b, c2, d2;
                    const float* m = cullVP_.m;
                    float s0 = pl == 0 ? 1.f : pl == 1 ? -1.f : 0.f, s1 = pl == 2 ? 1.f : pl == 3 ? -1.f : 0.f, s2 = pl == 4 ? 1.f : 0.f;
                    a = m[3] + s0 * m[0] + s1 * m[1] + s2 * m[2];
                    b = m[7] + s0 * m[4] + s1 * m[5] + s2 * m[6];
                    c2 = m[11] + s0 * m[8] + s1 * m[9] + s2 * m[10];
                    d2 = m[15] + s0 * m[12] + s1 * m[13] + s2 * m[14];
                    float nl = std::sqrt(a * a + b * b + c2 * c2);
                    if (nl > 1e-6f && (a * o.pos.x + b * o.pos.y + c2 * o.pos.z + d2) / nl < -rad) out = true;
                }
                if (out) continue;
            }
        }
        if (is3 && g.sc->drawDist > 0.f && o.kind != Kind::Floor) {  // lejos de la camara: ni se dibuja (mas rendimiento)
            float dx = o.pos.x - camE_.x, dz = o.pos.z - camE_.z, lim = g.sc->drawDist + std::max(o.scale.x, std::max(o.scale.y, o.scale.z)) * 2.f;
            if (dx * dx + dz * dz > lim * lim) continue;
        }
        float alpha = 1.f - std::max(0.f, std::min(100.f, o.transp)) / 100.f;
        if (shadow && alpha < 0.5f) continue;
        if (o.noColor && o.tex.empty() && o.video.empty() && o.kind != Kind::Model && !(o.ai.type != AiType::None && is3)) continue;  // sin color y sin imagen: no se dibuja
        M4 m;
        Game::ObjVis vv;
        if (is3) vv = g.vis(idx);
        if (vv.billboard && shadow) continue;
        ModelGL* terr = (is3 && o.kind == Kind::Floor && o.tn >= 2 && o.heights.size() == (size_t)o.tn * o.tn) ? terrainMesh(g, idx) : nullptr;
        if (terr) {
            m = modelMat(o.pos, 0.f, V3{1, 1, 1});
        } else if (is3) {
            float yaw = o.yaw + (o.spin ? g.time * 90.f : 0.f);
            V3 pp = o.pos, sc3 = o.scale;
            if (vv.billboard) {
                yaw = std::atan2(camE_.x - o.pos.x, camE_.z - o.pos.z) / 0.0174532925f;
                sc3.z = 0.02f;
            } else {
                yaw += vv.sway;
                float a = o.yaw * 0.0174532925f;
                pp.x += std::sin(a) * vv.lunge; pp.z -= std::cos(a) * vv.lunge;
            }
            pp.y += vv.bob;
            sc3.y *= vv.squash;
            if (o.kind == Kind::Model && o.ai.type != AiType::None && !vv.billboard) yaw = 180.f - yaw;   // v10.7: el frente del enemigo mira hacia donde va
            m = (o.pitch != 0.f || o.roll != 0.f) ? modelMatTilt(pp, yaw, o.pitch, o.roll, sc3) : modelMat(pp, yaw, sc3);
        } else if (o.bg) {
            m = modelMatZ(V3{g.cam2x, g.cam2y, 0}, 0.f, V3{g.view2W(), g.view2H(), 1.f});   // el fondo acompaña a la cámara
        } else {
            m = modelMatZ(o.pos, -(o.yaw - 90.f) + (o.spin ? -g.time * 90.f : 0.f), V3{o.scale.x * (o.flipX ? -1.f : 1.f), o.scale.y * (o.flipY ? -1.f : 1.f), 1.f});
        }
        glUniformMatrix4fv(p.u("uM"), 1, GL_FALSE, m.m);
        const std::string& mname = !vv.model.empty() ? vv.model : o.model;
        ModelGL* md = terr ? terr : (((o.kind == Kind::Model || !vv.model.empty()) && !mname.empty()) ? model(g, mname) : nullptr);
        if (md && !terr && is3 && !vv.billboard) md = skinned(g, idx, mname, md);
        GLuint useVao = md ? md->vao : vao_; int useCount = md ? md->count : 36;
        if (md && lodOn_ && is3 && md->lodCount[0] > 0) {   // más lejos = menos triángulos
            V3 dv = o.pos - camE_;
            float rad = std::max(0.3f, 0.5f * std::sqrt(o.scale.x * o.scale.x + o.scale.y * o.scale.y + o.scale.z * o.scale.z) * std::max(md->bmax[0] - md->bmin[0], std::max(md->bmax[1] - md->bmin[1], md->bmax[2] - md->bmin[2])));
            float ratio = std::sqrt(dv.x * dv.x + dv.y * dv.y + dv.z * dv.z) / rad;
            int L = ratio > 24.f ? 1 : ratio > 10.f ? 0 : -1;
            if (L == 1 && md->lodCount[1] == 0) L = 0;
            if (L >= 0) { useVao = md->lodVao[L]; useCount = md->lodCount[L]; }
        }
        glBindVertexArray(useVao);
        if (shadow) {   // las partes transparentes de la imagen no dan sombra
            const std::string& tn = !vv.tex.empty() ? vv.tex : (!o.tex.empty() ? o.tex : (md ? md->tex : o.tex));
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, texture(g, tn).id);
            glUniform1f(p.u("uAlpha"), alpha);
        }
        if (!shadow) {
            float col[3] = {o.color[0] * (md ? md->color[0] : 1.f), o.color[1] * (md ? md->color[1] : 1.f),
                            o.color[2] * (md ? md->color[2] : 1.f)};
            if (o.noColor || vv.billboard) col[0] = col[1] = col[2] = 1.f;  // sin color: la imagen se ve tal cual
            hueShift(col, o.hue);
            float br = o.bright / 100.f;
            glUniform4f(p.u("uColor"), col[0] * br, col[1] * br, col[2] * br, alpha);
            if (is3) { glUniform1f(p.u("uRefl"), o.metal ? 2.f : o.reflect ? 1.f : 0.f); glUniform1f(p.u("uRBlur"), o.reflBlur); }
            glActiveTexture(GL_TEXTURE0);
            std::string vname;
            if (o.tex == "::cam" && !shadow) {   // cámara de fondo: el cuadro más nuevo (se voltea a mano como las demás imágenes)
                int cw = 0, ch2 = 0;
                if (g.cameraFrame(cw, ch2, camPx_) && cw > 0 && ch2 > 0 && camPx_.size() >= (size_t)cw * ch2 * 4) {
                    std::vector<uint8_t> fl(camPx_.size());
                    for (int yy = 0; yy < ch2; yy++) std::memcpy(&fl[(size_t)(ch2 - 1 - yy) * cw * 4], &camPx_[(size_t)yy * cw * 4], (size_t)cw * 4);
                    updateRGBA("::cam", cw, ch2, fl.data());
                }
                if (rawTexture("::cam")) vname = "::cam";
            }
            if (!o.video.empty() && !shadow) {
                int vw, vh;
                if (g.videoFrame(idx, vw, vh, vidPx_) && vw > 0 && vh > 0) updateRGBA("::vid" + std::to_string(idx), vw, vh, vidPx_.data());
                if (rawTexture("::vid" + std::to_string(idx))) vname = "::vid" + std::to_string(idx);
            }
            const std::string& tn = !vname.empty() ? vname : !vv.tex.empty() ? vv.tex : (!o.tex.empty() ? o.tex : (md ? md->tex : o.tex));
            glBindTexture(GL_TEXTURE_2D, texture(g, tn).id);
            glUniform1i(p.u("uUV1"), (!is3 || (md && !terr) || vv.billboard || !o.texTile) ? 1 : 0);  // 1 = la imagen se estira a cada cara
            if (is3 && (alpha < 1.f || !tn.empty() || vv.billboard)) { glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); }
        }
        if (md) glDrawElements(GL_TRIANGLES, useCount, md->itype, nullptr);
        else if (!is3) glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_SHORT, (const void*)(24 * sizeof(unsigned short)));   // 2D: solo la cara de ENFRENTE (la de atrás se dibujaba encima como un espejo de la imagen)
        else glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
        if (!shadow && is3 && (alpha < 1.f || !o.tex.empty() || md || vv.billboard)) glDisable(GL_BLEND);
        if (!shadow && is3 && !o.handItem.empty() && md && !terr && !vv.billboard)   // objeto sostenido en la mano del modelo
            drawHeld(g, p, idx, mname, m, std::atan2(-m.m[2], m.m[0]) / 0.0174532925f, o.handItem, o.handSide, o.hrot, o.hoff, std::max(0.1f, o.scale.y) * 0.45f * o.hscale);
    }
    glBindVertexArray(vao_);
}

void Renderer::render(Game& g, int w, int h, const EditorView* ev) {
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, w, h);
    if (!g.sc) {
        glClearColor(0, 0, 0, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        return;
    }
    if (g.sc->is3d) render3D(g, w, h, ev);
    else render2D(g, w, h, ev);
}

void Renderer::renderScaled(Game& g, int w, int h, int rh) {
    const bool fx = g.proj.gfxFilter > 0 && w >= 8 && h >= 8;
    if (fx && (rh <= 0 || rh > h)) rh = h;
    if (rh <= 0 || w < 8 || h < 8 || (rh == h && !fx)) { render(g, w, h); return; }
    int rw = (int)((double)rh * w / h + 0.5);
    if (rw < 8) rw = 8;
    if (rw > 8192) rw = 8192;
    if (rh > 8192) rh = 8192;
    if (!scFbo_ || scW_ != rw || scH_ != rh) {
        if (scFbo_) glDeleteFramebuffers(1, &scFbo_);
        if (scTex_) glDeleteTextures(1, &scTex_);
        if (scDepth_) glDeleteTextures(1, &scDepth_);
        glGenTextures(1, &scTex_);
        glBindTexture(GL_TEXTURE_2D, scTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, rw, rh, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glGenTextures(1, &scDepth_);
        glBindTexture(GL_TEXTURE_2D, scDepth_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, rw, rh, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glGenFramebuffers(1, &scFbo_);
        glBindFramebuffer(GL_FRAMEBUFFER, scFbo_);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, scTex_, 0);
        glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, scDepth_, 0);
        scW_ = rw; scH_ = rh;
        if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {  // no se pudo: dibujar normal
            glBindFramebuffer(GL_FRAMEBUFFER, 0);
            glDeleteFramebuffers(1, &scFbo_);
            scFbo_ = 0; scW_ = scH_ = 0;
            render(g, w, h);
            return;
        }
    }
    glBindFramebuffer(GL_FRAMEBUFFER, scFbo_);
    target_ = scFbo_;
    render(g, rw, rh);
    target_ = 0;
    glBindFramebuffer(GL_READ_FRAMEBUFFER, scFbo_);
    glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, w, h);
    if (fx) {   // filtro de pantalla (blanco y negro, caricatura, pixelado...)
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
        glUseProgram(post_.id);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, scTex_);
        glUniform1i(post_.u("uScene"), 0);
        glUniform2f(post_.u("uRes"), (float)rw, (float)rh);
        glUniform1i(post_.u("uType"), g.proj.gfxFilter);
        glUniform1f(post_.u("uAmt"), g.proj.gfxFilterAmt);
        glUniform1f(post_.u("uTime"), g.time);
        glBindVertexArray(vaoEmpty_);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glEnable(GL_DEPTH_TEST); glEnable(GL_CULL_FACE);
    } else {
        glBlitFramebuffer(0, 0, rw, rh, 0, 0, w, h, GL_COLOR_BUFFER_BIT, GL_LINEAR);
    }
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::clear(int w, int h, float r, float g, float b) {
    glDisable(GL_BLEND);
    glDisable(GL_SCISSOR_TEST);
    glViewport(0, 0, w, h);
    glClearColor(r, g, b, 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

// Desenfoque de movimiento real: se difumina la imagen a lo largo de la dirección en que se movió la cámara
// (giro + desplazamiento + avance), con una "exposición" proporcional a la velocidad. Cantidad 0 = apagado, 3 = brutal.
void Renderer::motionBlur(Game& g, int w, int h, V3 eye, V3 fwd, const M4& vp) {
    float amt = g.proj.mblur;
    if (amt <= 0.f || w < 8 || h < 8) { mbHave_ = false; mbVx_ = mbVy_ = mbZoom_ = 0.f; return; }
    // la copia de pantalla debe ser RGB: en Android la pantalla no tiene alfa y copiar a una textura RGBA da error (todo salía negro al mover)
    GLint vpt[4] = {0, 0, w, h};
    glGetIntegerv(GL_VIEWPORT, vpt);   // la imagen puede no empezar en (0,0) (barras negras, pantalla recortada)
    w = std::max(8, (int)vpt[2]); h = std::max(8, (int)vpt[3]);
    if (!mbTex_ || mbW_ != w || mbH_ != h) {
        if (!mbTex_) glGenTextures(1, &mbTex_);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, mbTex_);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, w, h, 0, GL_RGB, GL_UNSIGNED_BYTE, nullptr);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        mbW_ = w; mbH_ = h;
        mbHave_ = false;
    }
    unsigned id = mbTex_;
    float vx = 0.f, vy = 0.f, zoom = 0.f;
    if (mbHave_) {
        float dt = std::max(0.004f, std::min(0.1f, g.dt_));
        V3 p = mbEye_ + mbFwd_ * 12.f;   // dónde estaba el centro de la pantalla en el cuadro anterior
        const float* m = vp.m;
        float cx = m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12], cy = m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13], cw = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15];
        if (cw > 0.05f) { vx = -cx / cw * 0.5f; vy = -cy / cw * 0.5f; }   // movimiento por cuadro en UV (centro anterior -> centro actual)
        zoom = dot(eye - mbEye_, fwd) / 12.f;                              // avanzar = desenfoque radial
        float k = amt * 0.05f / dt;                                        // exposición: más cantidad = obturador más abierto
        vx *= k; vy *= k; zoom *= k;
    }
    // se suaviza para que no parpadee entre cuadros
    mbVx_ += (vx - mbVx_) * 0.55f; mbVy_ += (vy - mbVy_) * 0.55f; mbZoom_ += (zoom - mbZoom_) * 0.55f;
    float L = std::sqrt(mbVx_ * mbVx_ + mbVy_ * mbVy_), cap = 0.18f + 0.12f * std::min(amt, 3.f);
    float sc = L > cap ? cap / L : 1.f;
    float zc = std::max(-cap, std::min(cap, mbZoom_));
    if (mbHave_ && (L * sc > 0.0015f || std::fabs(zc) > 0.0015f)) {
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, id);
        glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, vpt[0], vpt[1], w, h);   // copia de la imagen ya dibujada
        glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE); glDisable(GL_BLEND);
        glUseProgram(mb_.id);
        glUniform1i(mb_.u("uScene"), 0);
        glUniform2f(mb_.u("uVel"), mbVx_ * sc, mbVy_ * sc);
        glUniform1f(mb_.u("uZoom"), zc);
        glBindVertexArray(vaoEmpty_);
        glDrawArrays(GL_TRIANGLES, 0, 3);
        glBindVertexArray(vao_);
        glEnable(GL_DEPTH_TEST); glEnable(GL_CULL_FACE);
    }
    mbEye_ = eye; mbFwd_ = fwd; mbHave_ = true;
}

void Renderer::ensureEnv() {
    if (envTex_) return;
    const int N = 128;
    glGenTextures(1, &envTex_);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_CUBE_MAP, envTex_);
    for (int i = 0; i < 6; i++) glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL_RGBA8, N, N, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glActiveTexture(GL_TEXTURE0);
    glGenTextures(1, &envDepth_);
    glBindTexture(GL_TEXTURE_2D, envDepth_);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT16, N, N, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_SHORT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glGenFramebuffers(1, &envFbo_);
    glBindFramebuffer(GL_FRAMEBUFFER, envFbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, envDepth_, 0);
    glBindFramebuffer(GL_FRAMEBUFFER, target_);
    glUseProgram(main_.id);
    glUniform1i(main_.u("uEnv"), 4);
}

// Reflejos en vivo: dibuja la escena en una cara del cubo por cuadro, desde el objeto metálico/reflectante más cercano.
void Renderer::updateProbe(Game& g) {
    const Scene& S = *g.sc;
    // Se elige el objeto reflectante más cercano, pero el cubo no salta entre objetos a cada cuadro:
    // solo cambia al empezar un ciclo de 6 caras y si el nuevo está claramente más cerca (así el reflejo no se voltea ni parpadea).
    int cand = -1;
    float best = 1e30f, curD = 1e30f;
    for (int i = 0; i < (int)S.objs.size(); i++) {
        const Obj& o = S.objs[i];
        if (!o.alive || !o.visible || !(o.metal || o.reflect)) continue;
        V3 d = o.pos - g.camEye;
        float l = dot(d, d);
        if (l < best) { best = l; cand = i; }
        if (i == probeObj_) curD = l;
    }
    if (cand < 0) { envValid_ = false; probeFace_ = 0; probeObj_ = -1; return; }
    if (probeObj_ < 0 || probeObj_ >= (int)S.objs.size() || curD > 1e29f) { probeObj_ = cand; probeFace_ = 0; envValid_ = false; }
    else if (probeFace_ % 6 == 0 && cand != probeObj_ && best < curD * 0.5f) { probeObj_ = cand; probeFace_ = 0; }
    V3 bp = S.objs[probeObj_].pos;
    static const float D[6][6] = {{1, 0, 0, 0, -1, 0}, {-1, 0, 0, 0, -1, 0}, {0, 1, 0, 0, 0, 1}, {0, -1, 0, 0, 0, -1}, {0, 0, 1, 0, -1, 0}, {0, 0, -1, 0, -1, 0}};
    int face = probeFace_ % 6;
    probeFace_++;
    V3 eye0 = g.camEye, fwd0 = g.camFwd;
    int mode0 = g.camMode;
    float shake0 = g.shakeT, roll0 = g.camRollTotal;
    probePos_ = bp;
    g.camEye = bp; g.camFwd = V3{D[face][0], D[face][1], D[face][2]};
    g.camMode = 1; g.shakeT = 0; g.camRollTotal = 0;
    probeUp_ = V3{D[face][3], D[face][4], D[face][5]};
    probing_ = true;
    GLuint prev = target_;
    glBindFramebuffer(GL_FRAMEBUFFER, envFbo_);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_CUBE_MAP_POSITIVE_X + face, envTex_, 0);
    target_ = envFbo_;
    render3D(g, 128, 128, nullptr);
    target_ = prev;
    probing_ = false;
    g.camEye = eye0; g.camFwd = fwd0; g.camMode = mode0; g.shakeT = shake0; g.camRollTotal = roll0;
    glBindTexture(GL_TEXTURE_CUBE_MAP, envTex_);
    glGenerateMipmap(GL_TEXTURE_CUBE_MAP);   // niveles más borrosos para el desenfoque del reflejo
    glBindFramebuffer(GL_FRAMEBUFFER, target_);
    envValid_ = probeFace_ >= 6;
}

// Destellos del sol (círculos de luz) cuando se mira hacia él y nada lo tapa.
void Renderer::drawFlare(Game& g, const M4& vp, V3 eye, V3 fwd, int w, int h) {
    const Scene& S = *g.sc;
    if (!S.flare || !(S.sunBody == 0 || S.sunBody == 1 || S.sunBody == 2 || S.sunBody == 8)) return;
    V3 ts = norm(V3{-S.sunDir.x, -S.sunDir.y, -S.sunDir.z});
    float target = 0.f;
    if (ts.y > 0.02f && dot(fwd, ts) > 0.05f) {
        target = 1.f;
        for (const Obj& o : S.objs) {   // algo tapa al sol
            if (!o.alive || !o.visible || o.kind == Kind::Light || o.kind == Kind::Player || o.kind == Kind::Item) continue;
            if (o.kind == Kind::Floor && o.tn >= 2) continue;
            if (o.ai.type != AiType::None) continue;
            float t;
            if (rayBoxYaw(eye, ts, o.pos, o.scale * 0.5f, o.yaw, t) && t > 0.f) { target = 0.f; break; }
        }
    }
    flareVis_ += (target - flareVis_) * 0.18f;
    if (flareVis_ < 0.01f) return;
    V3 p = eye + ts * 100.f;
    const float* m = vp.m;
    float cx = m[0] * p.x + m[4] * p.y + m[8] * p.z + m[12], cy = m[1] * p.x + m[5] * p.y + m[9] * p.z + m[13], cw = m[3] * p.x + m[7] * p.y + m[11] * p.z + m[15];
    if (cw <= 0.05f) return;
    float nx = cx / cw, ny = cy / cw;
    float edge = std::max(0.f, std::min(1.f, 1.5f - std::max(std::fabs(nx), std::fabs(ny)) * 1.0f));
    float k = flareVis_ * edge * (S.skyStyle >= 3 && S.skyStyle <= 6 ? 0.3f : 1.f);
    if (k < 0.01f) return;
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    glDisable(GL_DEPTH_TEST); glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND); glBlendFunc(GL_ONE, GL_ONE);
    glUseProgram(flare_.id);
    glBindVertexArray(vaoEmpty_);
    struct El { float t, sz; int type; float r, g, b, a; };
    static const El E[] = {
        {0.f, 0.60f, 0, 1.0f, 0.85f, 0.6f, 0.55f}, {0.f, 0.20f, 0, 1.f, 1.f, 1.f, 0.6f}, {0.f, 0.9f, 4, 1.f, 0.9f, 0.7f, 0.22f},
        {0.35f, 0.07f, 2, 0.5f, 0.8f, 1.f, 0.45f}, {0.62f, 0.045f, 1, 1.f, 0.6f, 0.3f, 0.55f}, {0.85f, 0.10f, 3, 0.6f, 1.f, 0.6f, 0.35f},
        {1.15f, 0.06f, 1, 0.9f, 0.5f, 1.f, 0.5f}, {1.45f, 0.15f, 2, 1.f, 0.7f, 0.4f, 0.3f}, {1.8f, 0.08f, 3, 0.5f, 0.7f, 1.f, 0.4f}, {2.1f, 0.24f, 0, 1.f, 0.8f, 0.6f, 0.18f}};
    for (const El& e : E) {
        float px = nx * (1.f - e.t), py = ny * (1.f - e.t);
        glUniform2f(flare_.u("uC"), px, py);
        if (e.type == 4) glUniform2f(flare_.u("uS"), e.sz, 0.06f * aspect * 0.4f); else glUniform2f(flare_.u("uS"), e.sz / aspect, e.sz);
        glUniform1i(flare_.u("uType"), e.type);
        glUniform3f(flare_.u("uCol"), e.r * (0.5f + 0.5f * S.sun[0]), e.g * (0.5f + 0.5f * S.sun[1]), e.b * (0.5f + 0.5f * S.sun[2]));
        glUniform1f(flare_.u("uA"), e.a * k);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
    }
    glDisable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_DEPTH_TEST); glEnable(GL_CULL_FACE);
}

void Renderer::render3D(Game& g, int w, int h, const EditorView* ev) {
    const Scene& S = *g.sc;
    ensureEnv();
    if (!probing_ && !ev && g.proj.quality >= 1) updateProbe(g);
    else if (!probing_ && (ev || g.proj.quality < 1)) envValid_ = false;
    V3 sd = norm(S.sunDir);
    V3 e = ev ? ev->eye : g.camEye, f = ev ? ev->fwd : g.camFwd;
    if (!ev && g.shakeT > 0) {  // temblor de camara
        float k = std::min(1.f, g.shakeT) * g.shakeAmp;
        e = e + V3{((float)std::rand() / RAND_MAX - .5f) * k, ((float)std::rand() / RAND_MAX - .5f) * k, ((float)std::rand() / RAND_MAX - .5f) * k};
    }
    camE_ = e;
    lodOn_ = !ev && g.proj.perf.lod;
    applyGfx(g.proj);

    // 1) Mapa de sombras alrededor del jugador (o del punto que mira el editor).
    V3 c = ev ? ev->target : g.pos;
    V3 up = std::fabs(sd.y) < 0.99f ? V3{0, 1, 0} : V3{0, 0, 1};
    M4 lvp = mul(ortho(-24, 24, -24, 24, 1, 90), lookAt(c - sd * 40.f, c, up));
    if (!probing_) {   // (el cubo de reflejos reutiliza el mapa de sombras del cuadro anterior)
    glBindFramebuffer(GL_FRAMEBUFFER, fbo_);
    glViewport(0, 0, shadowSize_, shadowSize_);
    glClear(GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(2.f, 4.f);
    glUseProgram(depth_.id);
    glUniformMatrix4fv(depth_.u("uLVP"), 1, GL_FALSE, lvp.m);
    if (g.proj.quality > 0) {
        glUniform1i(depth_.u("uTex"), 0);
        shC_ = c; shD_ = sd; shOn_ = true;
        drawObjs(g, depth_, true);
        shOn_ = false;
        drawPlayerShadow(g, depth_, ev);
    }
    glDisable(GL_POLYGON_OFFSET_FILL);
    glBindFramebuffer(GL_FRAMEBUFFER, target_);   // volver al destino real (pantalla o el buffer de resolución/filtros)
    }

    // 2) Escena principal.
    glViewport(0, 0, w, h);
    glClearColor(S.skyBot[0], S.skyBot[1], S.skyBot[2], 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    float aspect = h > 0 ? (float)w / (float)h : 1.f, fov = probing_ ? 1.5707963f : g.curFov() * 0.0174532925f;
    V3 r = norm(cross(f, probing_ ? probeUp_ : V3{0, 1, 0})), u = cross(r, f);
    V3 upv = probing_ ? probeUp_ : V3{0, 1, 0};
    if (!ev && std::fabs(g.camRollTotal) > 1e-4f) upv = V3{0, 1, 0} * std::cos(g.camRollTotal) + r * std::sin(g.camRollTotal);  // camara inclinada
    M4 vp = mul(perspective(fov, aspect, 0.1f, S.drawDist > 0.f ? std::max(10.f, S.drawDist) : 200.f), lookAt(e, e + f, upv));

    glDisable(GL_DEPTH_TEST);
    glUseProgram(sky_.id);
    glUniform3f(sky_.u("uFwd"), f.x, f.y, f.z);
    glUniform3f(sky_.u("uRight"), r.x, r.y, r.z);
    glUniform3f(sky_.u("uUp"), u.x, u.y, u.z);
    float ty = std::tan(fov * 0.5f);
    glUniform1f(sky_.u("uTY"), ty);
    glUniform1f(sky_.u("uTX"), ty * aspect);
    glUniform3f(sky_.u("uTop"), S.skyTop[0], S.skyTop[1], S.skyTop[2]);
    float fc[3] = {S.skyBot[0], S.skyBot[1], S.skyBot[2]}, fogD = S.fog;
    atmoDensity_ = 0.f;
    if (S.fogMode == 1) { for (int q = 0; q < 3; q++) fc[q] = S.fogCol[q]; }
    if (S.atmo > 0) {
        float ac[3], aa;
        atmoDefaults(S.atmo, ac, aa);
        const float* col = S.atmo == 5 ? S.atmoCol : ac;
        float k = std::min(S.atmoAmt, 3.f);
        float add = (S.atmo == 1 ? 0.05f : S.atmo == 3 ? 0.07f : S.atmo == 5 ? 0.05f : 0.015f) * k;
        if (S.atmoStyle == 1 && S.atmo == 1) add *= 0.8f;
        fogD += add;
        if (!(S.atmo == 1 && S.fogMode == 1))  // la niebla con color propio no se mezcla con el color de la atmósfera
            for (int q = 0; q < 3; q++) fc[q] = fc[q] * 0.35f + col[q] * 0.65f;
        atmoDensity_ = k;
    }
    // el horizonte del cielo toma el color de la niebla para que no se vea un corte
    float hz = (S.fogMode == 1 || S.atmo > 0) ? std::min(1.f, 0.55f + fogD * 6.f) : 0.f;
    glUniform3f(sky_.u("uBot"), S.skyBot[0] + (fc[0] - S.skyBot[0]) * hz, S.skyBot[1] + (fc[1] - S.skyBot[1]) * hz, S.skyBot[2] + (fc[2] - S.skyBot[2]) * hz);
    glUniform3f(sky_.u("uSunDir"), sd.x, sd.y, sd.z);
    glUniform3f(sky_.u("uSunCol"), S.sun[0], S.sun[1], S.sun[2]);
    glUniform1i(sky_.u("uStyle"), S.skyStyle);
    glUniform1i(sky_.u("uSB"), S.sunBody);
    glUniform1f(sky_.u("uSZ"), std::max(0.1f, std::min(30.f, S.sunSize)));
    glUniform1f(sky_.u("uTime"), g.time);
    {
        bool ct = S.cloudStyle == 2 && !S.cloudTex.empty() && g.proj.assets.count(S.cloudTex);
        glUniform1i(sky_.u("uCloud"), S.cloudStyle == 2 ? (ct ? 2 : 0) : S.cloudStyle);
        glUniform1f(sky_.u("uCovK"), (S.cloudAmt - 0.5f) * 0.5f);
        glUniform1f(sky_.u("uWind"), S.cloudWind);
        glActiveTexture(GL_TEXTURE5);
        glBindTexture(GL_TEXTURE_2D, ct ? texture(g, S.cloudTex).id : white_);
        glUniform1i(sky_.u("uCloudTex"), 5);
        glActiveTexture(GL_TEXTURE0);
    }
    {
        bool st = !S.skyTex.empty() && g.proj.assets.count(S.skyTex);
        glUniform1i(sky_.u("uSkyTexOn"), st ? 1 : 0);
        if (st) {
            glActiveTexture(GL_TEXTURE3);
            glBindTexture(GL_TEXTURE_2D, texture(g, S.skyTex).id);
            glUniform1i(sky_.u("uSkyTex"), 3);
            glActiveTexture(GL_TEXTURE0);
        }
    }
    glBindVertexArray(vaoEmpty_);
    glDrawArrays(GL_TRIANGLES, 0, 3);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glUseProgram(main_.id);
    glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, vp.m);
    glUniformMatrix4fv(main_.u("uLVP"), 1, GL_FALSE, lvp.m);
    glUniform1i(main_.u("uTex"), 0);
    glUniform1i(main_.u("uSh"), 1);
    glUniform1i(main_.u("uEnv"), 4);
    glActiveTexture(GL_TEXTURE4);
    glBindTexture(GL_TEXTURE_CUBE_MAP, envTex_);
    glActiveTexture(GL_TEXTURE0);
    glUniform1i(main_.u("uEnvOn"), (!probing_ && !ev && envValid_) ? 1 : 0);
    glUniform1f(main_.u("uRBlur"), 0.3f);
    glUniform3f(main_.u("uProbePos"), probePos_.x, probePos_.y, probePos_.z);
    glUniform1i(main_.u("uUV1"), 0);
    glUniform1i(main_.u("uUnlit"), 0);
    glUniform1f(main_.u("uTile"), 1.f);
    glUniform1f(main_.u("uTexel"), 1.f / (float)shadowSize_);
    glUniform3f(main_.u("uSunDir"), sd.x, sd.y, sd.z);
    glUniform3f(main_.u("uSunCol"), S.sun[0], S.sun[1], S.sun[2]);
    glUniform3f(main_.u("uSkyTop"), S.skyTop[0], S.skyTop[1], S.skyTop[2]);
    glUniform3f(main_.u("uSkyBot"), S.skyBot[0], S.skyBot[1], S.skyBot[2]);
    glUniform3f(main_.u("uCam"), e.x, e.y, e.z);
    glUniform1f(main_.u("uAmb"), S.ambient);
    {
        float tint[3];
        toneTint(S.tone, tint);
        glUniform3f(main_.u("uTint"), tint[0], tint[1], tint[2]);
        glUniform3f(main_.u("uFogCol"), fc[0], fc[1], fc[2]);
        glUniform1f(main_.u("uFog"), fogD);
        glUniform1f(main_.u("uRefl"), 0.f);
        glUniform1f(main_.u("uTime"), g.time);
        glUniform1f(main_.u("uSway"), 0.f);
        glUniform1i(main_.u("uVeg"), 0);
        glUniform1i(main_.u("uRtx"), g.proj.rtx ? 1 : 0);
        glUniform1i(main_.u("uSoft"), g.proj.gfxSoft);
        glUniform1f(main_.u("uSpec"), g.proj.gfxSpec);
        glUniform1f(main_.u("uTone"), g.proj.gfxTone);
        glUniform1f(main_.u("uEv"), g.proj.gfxEv);
        glUniform1f(main_.u("uGI"), g.proj.gi);
        glUniform1f(main_.u("uShAmt"), S.shadowAmt);
        {   // linterna del jugador
            const PlayerCfg& pc = g.proj.player;
            bool on = !ev && g.flashOn_ && pc.flashlight;
            glUniform1i(main_.u("uSpotOn"), on ? 1 : 0);
            glUniform1i(main_.u("uCookieOn"), 0);
            if (on) {
                float flick = 1.f;
                if (pc.flashFlicker) flick = 0.75f + 0.25f * std::sin(g.time * 37.f) * std::sin(g.time * 11.f) + (std::sin(g.time * 3.1f) > 0.93f ? -0.6f : 0.f);
                float ang = std::max(5.f, std::min(70.f, pc.flashAngle)) * 0.0174533f;
                glUniform3f(main_.u("uSpotPos"), e.x, e.y, e.z);
                glUniform3f(main_.u("uSpotDir"), f.x, f.y, f.z);
                glUniform3f(main_.u("uSpotCol"), pc.flashCol[0] * pc.flashInt * flick, pc.flashCol[1] * pc.flashInt * flick, pc.flashCol[2] * pc.flashInt * flick);
                glUniform1f(main_.u("uSpotCone"), std::cos(ang));
                glUniform1f(main_.u("uSpotTan"), std::tan(ang));
                glUniform1f(main_.u("uSpotRange"), std::max(3.f, pc.flashRange));
                if (!pc.flashTex.empty()) {
                    glActiveTexture(GL_TEXTURE2);
                    glBindTexture(GL_TEXTURE_2D, texture(g, pc.flashTex).id);
                    glUniform1i(main_.u("uCookie"), 2);
                    glUniform1i(main_.u("uCookieOn"), 1);
                    glActiveTexture(GL_TEXTURE0);
                }
            }
        }
        glUniform1i(main_.u("uShOn"), g.proj.quality > 0 ? 1 : 0);
    }

    float pl[16] = {0}, pc[12] = {0};
    int nl = 0;
    for (auto& o : S.objs) {
        if (o.kind != Kind::Light || !o.alive || !o.visible || nl >= (g.proj.perf.lightOn ? std::max(1, std::min(4, g.proj.perf.light)) : 4)) continue;
        pl[nl * 4] = o.pos.x; pl[nl * 4 + 1] = o.pos.y; pl[nl * 4 + 2] = o.pos.z; pl[nl * 4 + 3] = o.scale.x;
        pc[nl * 3] = o.color[0]; pc[nl * 3 + 1] = o.color[1]; pc[nl * 3 + 2] = o.color[2];
        nl++;
    }
    glUniform4fv(main_.u("uPL"), 4, pl);
    glUniform3fv(main_.u("uPC"), 4, pc);
    glUniform1i(main_.u("uNL"), nl);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    cullVP_ = vp; cullOn_ = true; perfCull_ = g.proj.perf.cull; perfDist_ = g.proj.perf.distOn ? g.proj.perf.dist : 0.f; perfEye_ = g.camEye;
    drawObjs(g, main_, false);
    cullOn_ = false;
    glActiveTexture(GL_TEXTURE0);
    drawDynamic(g, main_, ev);
    drawGround(g, main_);
    drawVeg(g, main_);
    drawSea(g, main_);
    drawParticles(g, main_, true);
    if (!ev && g.camMode == kFirstPerson && g.curWeapon() && g.curWeapon()->enabled && !g.curWeapon()->model.empty()) {
        // Arma 3D en la mano: se dibuja en el espacio de la camara, encima de todo.
        const Weapon& wp = *g.curWeapon();
        glClear(GL_DEPTH_BUFFER_BIT);
        M4 proj = perspective(fov, aspect, 0.05f, 10.f);
        glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, proj.m);
        glUniform3f(main_.u("uCam"), 0.f, 0.f, 0.f);
        glUniform1i(main_.u("uUnlit"), 1);
        float sz = wp.scale * 0.9f;
        const PlayerCfg& apc = g.proj.player;
        float ak = g.aimK;
        V3 at{(0.28f + wp.ox) * (1.f - ak) + apc.aimWx * ak, (-0.26f + wp.oy * 0.5f) * (1.f - ak) + apc.aimWy * ak + g.recoil * 0.03f,
              -0.7f * (1.f - ak) + apc.aimWz * ak + g.recoil * 0.06f};
        drawModelAt(g, main_, wp.model, "", at, 8.f + apc.aimRoll * ak, V3{sz, sz, sz}, 1.f, 1.f, 1.f, 1.f);
        glUniform1i(main_.u("uUnlit"), 0);
    }

    drawAtmo(g, main_);

    if (ev) {
        // Marcadores del editor: luces, inicio del jugador y objeto seleccionado.
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glUniform1i(main_.u("uUnlit"), 1);
        glUniform1i(main_.u("uUV1"), 1);
        for (auto& o : S.objs)
            if (o.kind == Kind::Light) box(main_, o.pos, V3{0.35f, 0.35f, 0.35f}, o.color[0], o.color[1], o.color[2], 1.f);
        for (auto& o : S.objs)  // objetos transparentes: se ven como un cristal tenue solo en el editor
            if (o.noColor && o.tex.empty() && o.alive && o.visible && o.kind != Kind::Light && o.kind != Kind::Model)
                box(main_, o.pos, o.scale, 0.8f, 0.9f, 1.f, 0.15f);
        {   // el jugador se ve con su modelo (si tiene); si no, el cubo verde
            const PlayerCfg& pcg = g.proj.player;
            int pIdx = playerIndex(S);
            V3 psc = pIdx >= 0 ? S.objs[pIdx].scale : V3{0.6f, 1.7f, 0.6f};
            ModelGL* pm = pcg.model.empty() ? nullptr : model(g, pcg.model);
            if (pm) {
                glUniform1i(main_.u("uUnlit"), 0);
                V3 pss = plScaleOf(g, pcg.model, psc, pcg);
                float sy = pss.y;
                V3 at{S.start.x, S.start.y + psc.y * 0.5f - pm->bmin[1] * sy + pcg.moy, S.start.z};
                drawModelAt(g, main_, pcg.model, "", at, 180.f + pcg.myaw, pss, 1.f, 1.f, 1.f, 1.f);
                glUniform1i(main_.u("uUnlit"), 1);
            } else box(main_, V3{S.start.x, S.start.y + 0.85f, S.start.z}, V3{0.6f, 1.7f, 0.6f}, 0.2f, 1.f, 0.3f, 0.5f);
        }
        if (S.is3d) {   // altura de la cámara en primera persona (solo editor): marcador cian a la altura de los ojos
            const PlayerCfg& pc2 = g.proj.player;
            float eyeY = S.start.y + 1.6f + pc2.eyeH;
            box(main_, V3{S.start.x, eyeY, S.start.z}, V3{0.28f, 0.06f, 0.28f}, 0.1f, 0.9f, 1.f, 0.85f);
            box(main_, V3{S.start.x, eyeY, S.start.z}, V3{0.06f, 0.06f, 0.5f}, 0.1f, 0.9f, 1.f, 0.85f);
        }
        if (S.is3d && (S.limMode || !S.zones.empty())) {   // límites y zonas prohibidas: solo se ven en el editor (postes de colores)
            float ytop = S.start.y;
            auto post = [&](float x, float z, float r, float gg, float b) { box(main_, V3{x, ytop + 10.f, z}, V3{0.35f, 60.f, 0.35f}, r, gg, b, 0.38f); };
            auto line = [&](float x0, float z0, float x1, float z1, float r, float gg, float b, float step) {
                float L = std::sqrt((x1 - x0) * (x1 - x0) + (z1 - z0) * (z1 - z0));
                int n = std::max(1, (int)(L / step));
                for (int k = 0; k <= n; k++) { float t = (float)k / n; post(x0 + (x1 - x0) * t, z0 + (z1 - z0) * t, r, gg, b); }
            };
            if (S.limMode == 1) {
                int n = std::max(24, std::min(260, (int)(S.limR * 2.f)));
                for (int k = 0; k < n; k++) { float a = k * 6.2831853f / n; post(S.limCx + std::cos(a) * S.limR, S.limCz + std::sin(a) * S.limR, 0.2f, 1.f, 0.5f); }
            } else if (S.limMode == 2) {
                float R = S.limR, st = std::max(1.5f, R * 0.04f);
                line(S.limCx - R, S.limCz - R, S.limCx + R, S.limCz - R, 0.2f, 1.f, 0.5f, st);
                line(S.limCx + R, S.limCz - R, S.limCx + R, S.limCz + R, 0.2f, 1.f, 0.5f, st);
                line(S.limCx + R, S.limCz + R, S.limCx - R, S.limCz + R, 0.2f, 1.f, 0.5f, st);
                line(S.limCx - R, S.limCz + R, S.limCx - R, S.limCz - R, 0.2f, 1.f, 0.5f, st);
            }
            for (auto& z : S.zones) {
                size_t n = z.pts.size() / 2;
                for (size_t k = 0; k < n; k++) { size_t m = (k + 1) % n; line(z.pts[k * 2], z.pts[k * 2 + 1], z.pts[m * 2], z.pts[m * 2 + 1], 1.f, 0.25f, 0.2f, 1.2f); }
            }
        }
        if (g.proj.player.cam == kFixed) box(main_, S.cam, V3{0.7f, 0.5f, 0.9f}, 0.3f, 0.6f, 1.f, 0.8f);
        if (ev->sel >= 0 && ev->sel < (int)S.objs.size()) {
            const Obj& o = S.objs[ev->sel];
            V3 sc = o.kind == Kind::Light ? V3{0.5f, 0.5f, 0.5f} : o.scale * 1.04f + V3{0.02f, 0.02f, 0.02f};
            V3 bc = o.pos;
            if (o.kind == Kind::Model && !o.model.empty()) {   // el recuadro se ajusta al modelo real, no a un cubo
                if (ModelGL* mg = model(g, o.model)) {
                    float lx = (mg->bmax[0] - mg->bmin[0]) * o.scale.x, ly = (mg->bmax[1] - mg->bmin[1]) * o.scale.y, lz = (mg->bmax[2] - mg->bmin[2]) * o.scale.z;
                    float cx = (mg->bmax[0] + mg->bmin[0]) * 0.5f * o.scale.x, cz = (mg->bmax[2] + mg->bmin[2]) * 0.5f * o.scale.z;
                    float a = o.yaw * 0.0174532925f, c = std::fabs(std::cos(a)), s2 = std::fabs(std::sin(a));
                    sc = V3{lx * c + lz * s2 + 0.04f, ly + 0.04f, lx * s2 + lz * c + 0.04f};
                    float ca = std::cos(a), sa = std::sin(a);   // centro girado con el modelo (mismo giro que modelMat)
                    bc = V3{o.pos.x + ca * cx + sa * cz, o.pos.y + (mg->bmax[1] + mg->bmin[1]) * 0.5f * o.scale.y, o.pos.z - sa * cx + ca * cz};
                }
            }
            if (!(o.kind == Kind::Player && !g.proj.player.model.empty())) box(main_, bc, sc, 1.f, 0.9f, 0.2f, o.kind == Kind::Model ? 0.12f : 0.35f);
        }
        glDisable(GL_BLEND);
        glUniform1i(main_.u("uUnlit"), 0);
        glUniform1i(main_.u("uUV1"), 0);
    } else if (!probing_) {
        // Mira central sin shaders extra: dos recortes con glClear (no se dibuja dentro del cubo de reflejos).
        glEnable(GL_SCISSOR_TEST);
        glClearColor(1, 1, 1, 1);
        glScissor(w / 2 - 1, h / 2 - 8, 2, 16);
        glClear(GL_COLOR_BUFFER_BIT);
        glScissor(w / 2 - 8, h / 2 - 1, 16, 2);
        glClear(GL_COLOR_BUFFER_BIT);
        glDisable(GL_SCISSOR_TEST);
    }
    if (!ev && !probing_) { motionBlur(g, w, h, e, f, vp); drawFlare(g, vp, e, f, w, h); }
}

void Renderer::render2D(Game& g, int w, int h, const EditorView* ev) {
    const Scene& S = *g.sc;
    if (ev) glClearColor(0.10f, 0.11f, 0.14f, 1.f); else glClearColor(S.skyBot[0], S.skyBot[1], S.skyBot[2], 1.f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    float aspect = h > 0 ? (float)w / (float)h : 1.f;
    float vh = ev ? ev->h2d : g.view2H(), cx = ev ? ev->cx : g.cam2x, cy = ev ? ev->cy : g.cam2y;
    if (!ev && g.shakeT > 0) {
        float k = std::min(1.f, g.shakeT) * g.shakeAmp;
        cx += ((float)std::rand() / RAND_MAX - .5f) * k;
        cy += ((float)std::rand() / RAND_MAX - .5f) * k;
    }
    float hw = vh * 0.5f * aspect, hh = vh * 0.5f;
    M4 vp = ortho(cx - hw, cx + hw, cy - hh, cy + hh, -20, 20);

    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glUseProgram(main_.id);
    glUniformMatrix4fv(main_.u("uVP"), 1, GL_FALSE, vp.m);
    glUniform1i(main_.u("uTex"), 0);
    glUniform1i(main_.u("uSh"), 1);
    glUniform1i(main_.u("uUV1"), 1);
    glUniform1i(main_.u("uUnlit"), 1);
    glUniform3f(main_.u("uTint"), 1.f, 1.f, 1.f);
    glUniform1f(main_.u("uRefl"), 0.f);
    glUniform1i(main_.u("uShOn"), 0);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, shadowTex_);
    if (ev) {   // fondo SOLO del editor: gris oscuro con cuadrícula; el recuadro claro es lo que verá el jugador en pantalla
        float stw = kView2DHeight * aspect;
        box(main_, V3{0, 0, 0}, V3{stw, kView2DHeight, 1.f}, S.skyBot[0] * 0.5f + 0.12f, S.skyBot[1] * 0.5f + 0.12f, S.skyBot[2] * 0.5f + 0.12f, 1.f);
        float gx0 = std::floor((cx - hw) / 100.f) * 100.f, gy0 = std::floor((cy - hh) / 100.f) * 100.f;
        float th = std::max(1.f, vh * 0.0018f);
        for (float x = gx0; x <= cx + hw; x += 100.f) box(main_, V3{x, cy, 0}, V3{th * (x == 0.f ? 2.f : 1.f), vh, 1.f}, 1.f, 1.f, 1.f, x == 0.f ? 0.28f : 0.10f);
        for (float y = gy0; y <= cy + hh; y += 100.f) box(main_, V3{cx, y, 0}, V3{vh * aspect, th * (y == 0.f ? 2.f : 1.f), 1.f}, 1.f, 1.f, 1.f, y == 0.f ? 0.28f : 0.10f);
        float bt = th * 3.f;   // marco de la pantalla
        box(main_, V3{0, kView2DHeight * 0.5f, 0}, V3{stw, bt, 1.f}, 1.f, 0.85f, 0.3f, 0.8f);
        box(main_, V3{0, -kView2DHeight * 0.5f, 0}, V3{stw, bt, 1.f}, 1.f, 0.85f, 0.3f, 0.8f);
        box(main_, V3{-stw * 0.5f, 0, 0}, V3{bt, kView2DHeight, 1.f}, 1.f, 0.85f, 0.3f, 0.8f);
        box(main_, V3{stw * 0.5f, 0, 0}, V3{bt, kView2DHeight, 1.f}, 1.f, 0.85f, 0.3f, 0.8f);
    }
    drawObjs(g, main_, false);  // el orden de la lista = orden de capas
    for (auto& d : g.debris) box(main_, d.p, V3{d.size, d.size, 1.f}, d.col[0], d.col[1], d.col[2], std::min(1.f, d.life * 2.f));
    drawParticles(g, main_, false);
    if (ev)
        for (auto& o : S.objs)
            if (o.noColor && o.tex.empty() && o.alive && o.visible && !o.bg)
                box(main_, o.pos, V3{o.scale.x, o.scale.y, 1.f}, 0.8f, 0.9f, 1.f, 0.15f);
    if (ev && ev->sel >= 0 && ev->sel < (int)S.objs.size()) {
        const Obj& o = S.objs[ev->sel];
        if (o.bg) box(main_, V3{0, 0, 0}, V3{g.stageW(), kView2DHeight, 1.f}, 1.f, 0.9f, 0.2f, 0.35f);
        else {   // marco amarillo: gira con el objeto y se ajusta a lo que se ve de la imagen (el mismo recuadro de las colisiones)
            float ox = 0.f, oy = 0.f, fw = 1.f, fh = 1.f;
            if (o.kind != Kind::Model && !o.tex.empty()) { auto r = g.spriteRect(o.tex); ox = (r[0] - 0.5f) * o.scale.x; oy = (0.5f - r[1]) * o.scale.y; fw = r[2]; fh = r[3]; }
            float a = -(o.yaw - 90.f) * 0.0174532925f, ca = std::cos(a), sa = std::sin(a);
            M4 m2 = modelMatZ(V3{o.pos.x + ca * ox - sa * oy, o.pos.y + sa * ox + ca * oy, o.pos.z}, -(o.yaw - 90.f), V3{o.scale.x * fw, o.scale.y * fh, 1.f});
            glUniformMatrix4fv(main_.u("uM"), 1, GL_FALSE, m2.m);
            glUniform4f(main_.u("uColor"), 1.f, 0.9f, 0.2f, 0.28f);
            glBindTexture(GL_TEXTURE_2D, white_);
            glBindVertexArray(vao_);
            glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_SHORT, nullptr);
        }
    }
    glActiveTexture(GL_TEXTURE0);
    glDisable(GL_BLEND);
}

}  // namespace forge
