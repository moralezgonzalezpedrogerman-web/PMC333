#pragma once
#include "imgui.h"
namespace forge {
extern const unsigned char kUiFontData[];
extern const unsigned kUiFontLen;
// Agrega la tipografía de la interfaz (Roboto) con letras latinas, acentos, ñ, ¿ ¡ y signos comunes.
inline ImFont* addUiFont(ImGuiIO& io, float px) {
    static const ImWchar ranges[] = {0x0020, 0x00FF, 0x2013, 0x203A, 0x20AC, 0x20AC, 0x2190, 0x2193, 0};
    ImFontConfig fc;
    fc.FontDataOwnedByAtlas = false;
    fc.OversampleH = 2;
    fc.OversampleV = 2;
    return io.Fonts->AddFontFromMemoryTTF((void*)kUiFontData, (int)kUiFontLen, px, &fc, ranges);
}
}  // namespace forge
