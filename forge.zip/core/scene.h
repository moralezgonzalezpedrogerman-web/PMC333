#pragma once
#include "vec.h"
#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace forge {

enum class Kind { Cube, Floor, Wall, Item, Model, Light, Player };

// ---------------------------------------------------------------- bloques (como Pocket Code)
// Los bloques de un objeto son una lista PLANA. Un bloque de evento (sombrero) empieza un guion y termina
// en el siguiente evento. Los bucles y los "si" se cierran con bloques propios (Fin del bucle, Fin del si).
enum class Op : int {
    // Eventos
    WhenStart, WhenTap, WhenReceive, WhenCollide, WhenTrue, WhenShot, WhenNear,
    // Control
    Wait, BroadcastWait, Broadcast, Forever, Repeat, LoopEnd, Note, If, Else, EndIf, StartScene,
    // Movimiento
    PlaceAt, SetX, SetY, ChangeX, ChangeY, BounceEdge, Move, TurnLeft, TurnRight, PointDir, PointTowards,
    GlideTo, GoBack, GoFront, Vibrate,
    PhysDynamic, PhysStatic, PhysNone, SetForce, SpinLeft, SpinRight, SetGravity, SetMass, SetBounce, SetFriction,
    PlaceAt3, SetZ, ChangeZ,
    // Sonido
    StartSound, StopSounds, SetVolume, ChangeVolume, Speak, Music,
    // Apariencia
    NextLook, SetSize, ChangeSize, Show, Hide, SetTransp, ChangeTransp, SetBright, ChangeBright, ClearFx,
    SetLook, Flash, ChangeColor, Say, Destroy,
    // Datos
    SetVar, ChangeVar, ShowVar, HideVar,
    // Extras 3D (juego en primera persona)
    WhenInteract, SetSolid, TeleportPlayer, MoveToPlayer,
    // Juego (v3): sonido con espera, camara, combate, utilidades
    PlaySoundWait, SetCamera, WaitUntil, StopScript, ShootPlayer, HurtPlayer, SetSpeed, SetJump, PlayAnim, MoveRandom,
    CreateClone, DeleteClone, WhenCloneStart, BreakApart, GoToObject, MoveTowards, ShakeScreen, StopAll,
    SetFx, BurstFx, SetScreenFx,
    // v6: eventos nuevos
    WhenPlayerShoots, WhenButton, WhenObjMoves, WhenPlayerMoves, WhenPlayerHurt, WhenPlayerJumps,
    GoToPlayer, PlayClip, StopClip,
    // v8
    While, RepeatUntil, SetTarget, ClearTarget,
    PlayVideo, PauseVideo, ResumeVideo, LoopVideo, PlayVideoTimes, RestartVideo, StopVideo,
    // v9
    KeepOnScreen, KeepAllOnScreen, AllowLeaveScreen, TiltCamRight, TiltCamLeft, LevelCam,
    FlashOn, FlashOff, FlashToggle, FreezeWorld, UnfreezeWorld, FreezePlayer, UnfreezePlayer,
    // v10
    EnemiesFightAll, EnemiesFightEachOther, EnemiesAttackYou,
    // v10.3: físicas avanzadas
    PhysImpulse, PhysBlast, SetDrag, SetGravScale, SetPushable, SetPlayerYaw,
    // v10.7: multijugador local (Wi-Fi / hotspot, sin internet)
    NetAuto, NetHost, NetJoin, NetSend, NetShare, NetStop,
    // v11.2
    PushedBy, PushOther, SolidWall,
    Count
};

enum class Cat { Eventos, Control, Movimiento, Sonido, Apariencia, Datos, Forge3D, Multijugador };

// Descripcion de un bloque para el editor y el archivo del proyecto.
// title: texto con huecos {0} {1} {2} (formulas) y {t} (texto: nombre de mensaje, objeto, sonido, variable...).
struct OpInfo {
    Op op;
    const char* key;    // nombre en el archivo
    Cat cat;
    const char* title;
    const char* help;
    const char* t;      // valores por defecto: texto y formulas
    const char* f0;
    const char* f1;
    const char* f2;
    int indent;         // +1 abre, -1 cierra, 0 normal; 2 = evento (sombrero)
};
const OpInfo& opInfo(Op op);
const OpInfo* opInfoByKey(const std::string& key);
const char* catName(Cat c);
bool isHat(Op op);

struct Block {
    Op op = Op::Wait;
    std::string t;       // texto (mensaje, nombre de objeto/sonido/variable/apariencia/escena)
    std::string f[3];    // formulas
};

// Voces del bloque "Hablar": cada una cambia tono, velocidad y la voz del sistema que se usa.
struct VoiceDef { const char* name; float pitch, rate; int idx; };
extern const VoiceDef kVoices[10];
std::string speakCode(const std::string& voiceName);   // prefijo \x1e tono;velocidad;voz \x1f que lee la plataforma

enum class Phys { None, Dynamic, Static };

// ---------------------------------------------------------------- enemigos y monstruos
// Estados de animacion de un enemigo: 0 quieto, 1 caminar, 2 atacar, 3 recibir dano.
// "frames" son imagenes (sprites) o modelos .fmdl que se van alternando; los numeros son una animacion
// sencilla para modelos 3D (subir/bajar, balanceo, embestida, aplastar).
enum AnimId { kIdle = 0, kWalk = 1, kAttack = 2, kHurt = 3, kRun = 4, kJump = 5, kShoot = 6, kAnimCount = 7 };
struct AnimState {
    std::vector<std::string> frames;
    float fps = 6.f;
    float bob = 0.f, sway = 0.f, lunge = 0.f, squash = 0.f;
    std::string clip;                   // animacion de esqueleto de este estado ("" = ninguna)
};
// Emisor de particulas (humo, fuego, chispas, nieve...). Medidas en metros (en 2D se multiplican por 100).
struct FxCfg {
    bool on = false;
    int kind = 0;                       // solo para recordar que preset se uso
    float rate = 20.f, life = 1.2f, size = 0.3f, speed = 1.5f, spread = 0.5f, gravity = 0.f, grow = 0.f, a0 = 0.8f;
    bool glow = false;                  // brillo (se suma a lo de atras)
    float c0[3] = {1, 1, 1}, c1[3] = {1, 1, 1};  // color al nacer -> color al morir
    std::string tex;                    // imagen propia (si no, un punto suave)
};
void fxPreset(FxCfg& f, int id);        // 0 humo, 1 fuego, 2 chispas, 3 nieve, 4 energia

// Capa de la camara: imagenes fijas en pantalla y efectos (VHS, camara de video...).
struct Overlay { std::string tex; float x = 0.5f, y = 0.5f, w = 0.3f, h = 0.3f, alpha = 1.f; };
struct ScreenFx {
    float scan = 0, noise = 0, vignette = 0, tint = 0, track = 0;
    float tintC[3] = {0, 0, 0};
    bool rec = false;
    bool any() const { return scan > 0 || noise > 0 || vignette > 0 || tint > 0 || track > 0 || rec; }
};
void sfxPreset(ScreenFx& f, int id);    // 0 ninguno, 1 VHS, 2 camara de video, 3 vision nocturna, 4 pelicula vieja

enum class AiType { None, Shooter, Melee };
struct AiCfg {
    AiType type = AiType::None;
    bool sprite = false;           // true = imagen plana que mira al jugador; false = modelo 3D / cubo
    float hp = 3.f, speed = 2.f, sight = 14.f, dmg = 1.f, rate = 1.2f, reach = 1.3f;
    std::string projTex, projModel;  // proyectil del enemigo (solo Shooter)
    float projSize = 0.25f, projSpeed = 12.f, projColor[3] = {1.f, 0.3f, 0.2f};
    AnimState anim[kAnimCount];
    int face = 0;                  // v8: 0 gira hacia donde se mueve/mira, 1 estatico (siempre al frente)
};

struct Obj {
    std::string name = "objeto";
    Kind kind = Kind::Cube;
    V3 pos, scale{1, 1, 1};
    float pitch = 0, roll = 0;   // v10.9d: inclinación (grados) adelante/atrás y de lado (solo 3D)
    float yaw = 0;      // direccion en grados (2D: 90 = derecha, 0 = arriba; 3D: 0 = hacia -Z)
    float color[3] = {1, 1, 1};
    std::string tex;    // asset png/jpg actual ("" = sin textura)
    std::string model;  // asset .fmdl (modelo 3D importado)
    bool solid = true, visible = true, alive = true, spin = false;
    std::vector<Block> blocks;          // guiones (lista plana)
    std::vector<std::string> looks;     // apariencias (assets de imagen)
    std::vector<std::string> sounds;    // sonidos (assets de audio)
    std::vector<std::string> localVars; // variables solo de este objeto
    Phys phys = Phys::None;
    float mass = 1.f, bounce = 0.5f, friction = 0.2f;
    float transp = 0.f, bright = 100.f, hue = 0.f;  // efectos: transparencia %, brillo %, color
    int layer = 0;                      // orden de dibujo en 2D
    bool bg = false;                    // es el "Fondo" de una escena 2D
    bool noColor = false;               // sin color: transparente (si tiene imagen, solo se ve la imagen)
    bool texTile = false;               // 3D: repetir la imagen cada metro (false = estirarla a toda la cara)
    FxCfg fx;                           // particulas que lanza este objeto
    AiCfg ai;                           // enemigo / monstruo (type None = objeto normal)
    std::string rig;                    // archivo de esqueleto (.fanim) de este objeto ("" = buscar el de su modelo)
    std::string clip;                   // animacion de esqueleto que se reproduce por defecto
    bool pushable = false;              // v10.3: el jugador lo puede empujar al caminar contra él (objeto dinámico)
    bool bulletPush = false;            // v10.3: las balas y golpes lo empujan
    float gravScale = 1.f;              // v10.3: cuánto le afecta la gravedad (0 = flota, 1 normal, 2 pesado)
    float drag = 0.f;                   // v10.3: resistencia del aire (frena poco a poco)
    bool deform = false;                // v10.3: se abolla con balas, golpes, explosiones y choques
    float deformAmt = 0.5f;             // cuánto se abolla (0.1 poco .. 1 mucho)
    int tn = 0;                         // suelo deformable: puntos por lado (0 = suelo plano)
    std::vector<float> heights;         // tn*tn alturas (metros) sobre la cara superior del suelo
    unsigned terrVer = 1;               // sube cada vez que cambia (para volver a subir la malla)
    std::string video;                  // v8: video que se ve en este objeto (asset)
    bool videoAuto = false, videoLoop = false;
    std::string giveWeapon;             // v8: al tocarlo, el jugador recibe esta arma (por nombre)
    bool locked = false;                // editor: no se puede seleccionar ni mover tocando la escena
    bool clone = false;                 // solo en juego: este objeto es un clon (no se guarda)
    bool metal = false;                 // v11.2: aspecto metálico (mismos colores, brillo de metal)
    bool reflect = false;               // v8: reflejos (cielo y sol sobre su superficie); apagado por defecto
};

// Suelo deformable (montañas): rejilla de alturas centrada en el objeto.
void terrainInit(Obj& o, int n);
float terrainSurface(const Obj& o, float x, float z);  // altura mundial en (x,z); -1e9 si queda fuera del suelo
bool rayTerrain(const Obj& o, V3 e, V3 d, float maxT, float& t);
// modo: 0 subir, 1 bajar, 2 aplanar (hacia 'target'), 3 suavizar. 'k' es la cantidad de este toque.
void terrainBrush(Obj& o, float wx, float wz, float radius, float k, int mode, float target = 0.f);

// v8: color de ambientacion (multiplica la luz) y color/densidad por defecto de cada atmosfera.
void toneTint(int tone, float out[3]);
void atmoDefaults(int atmo, float col[3], float& amt);
extern const char* const kToneNames[3];
extern const char* const kAtmoNames[6];
extern const char* const kQualityNames[3];

// v9: capa de vegetacion pintada sobre el suelo (puntos x,y,z,tamano,giro).
struct VegLayer {
    std::string name = "Pasto";
    int style = 0;                      // 0 realista, 1 animado (dibujo), 2 lowpoly, 3 textura propia
    float col[3] = {0.28f, 0.50f, 0.16f};   // color de la base
    float col2[3] = {0.62f, 0.78f, 0.30f};  // color de la punta
    std::string tex;                    // textura propia (estilo 3)
    float h = 0.6f, w = 0.5f, sway = 0.5f;
    std::vector<float> pts;             // 5 numeros por mata: x y z tamano giro
    unsigned ver = 0;
};

// v9: pintura de texturas sobre el suelo (arena, pasto, roca, nieve, tierra o una propia). 4 numeros por pincelada: x y z tamano.
struct GroundLayer {
    std::string name = "Arena";
    int preset = 0;                     // 0 arena, 1 pasto, 2 roca, 3 nieve, 4 tierra, 5 textura propia
    std::string tex;
    float scale = 0.25f;                // repeticiones de la textura por unidad
    std::vector<float> pts;
    unsigned ver = 0;
};

struct Scene {
    std::string name = "main";
    bool is3d = true;
    bool side25 = false;            // v10.9: escena 2.5D (mundo 3D, camara de lado, solo se camina en X y se salta)
    V3 sunDir{-0.4f, -1.f, -0.3f};
    float sun[3] = {1.f, 0.95f, 0.85f};
    int skyStyle = 0;               // v11: diseño del cielo (0 degradado, 1.. nubes, estrellas, nebulosas, atardeceres)
    bool flare = true;              // v11.3: destellos al mirar al Sol
    int cloudStyle = 0;             // v11.4: 0 actuales, 1 realistas, 2 con tu imagen
    float cloudAmt = 0.5f, cloudWind = 1.f;
    std::string cloudTex;
    std::string skyTex;             // v11: imagen propia para el cielo (vacío = ninguna)
    float skyTop[3] = {0.25f, 0.45f, 0.8f};
    float skyBot[3] = {0.75f, 0.85f, 0.95f};
    float ambient = 0.35f;
    float fog = 0.012f;
    int tone = 0;                   // v8: ambientacion 0 por defecto, 1 amarillenta, 2 azulada
    int atmo = 0;                   // v8: 0 ninguna, 1 niebla, 2 lluvia, 3 tormenta de arena, 4 nieve, 5 personalizado
    float atmoAmt = 0.5f;           // cantidad 0..1
    float atmoCol[3] = {0.8f, 0.8f, 0.85f};
    // v9
    float drawDist = 0.f;           // v10: distancia de dibujado (0 = normal; menor = mas rendimiento en mapas grandes)
    float shadowAmt = 1.f;          // v9: oscuridad de las sombras (0 = muy claras, 1 = normal, 1.6 = muy oscuras)
    int atmoStyle = 0;              // 0 clasico, 1 realista
    int fogMode = 0;                // 0 automatica, 1 color propio
    float fogCol[3] = {0.72f, 0.75f, 0.80f};
    bool sea = false;               // mar / agua
    int seaStyle = 0;               // v11.4: 0 actual, 1 anime, 2 realista, 3 oscuro, 4 cristal, 5 tropical, 6 pantano
    float seaY = 0.f, seaCol[3] = {0.08f, 0.32f, 0.45f}, seaAlpha = 0.72f;
    std::vector<VegLayer> veg;
    std::vector<GroundLayer> gnd;
    V3 start{0, 0.05f, 0};
    V3 cam{0, 8.f, 10.f};   // camara fija (vista fija en tercera persona)
    std::vector<Overlay> overlays;  // imagenes fijas en pantalla
    ScreenFx sfx;                   // efectos de pantalla
    std::vector<Obj> objs;
};

// Botones tactiles en pantalla (escenas 3D).
enum class HudAct { None, Jump, Shoot, Interact, Script, NextWeapon, Reload, Flashlight, Hold, Sprint, Crouch };  // Script: solo lanza el evento "Cuando se presione el botón"
struct HudBtn {
    std::string label = "OK";
    float x = 0.5f, y = 0.5f, r = 0.08f;  // centro (0..1) y radio (fraccion del alto)
    HudAct act = HudAct::None;
    float color[3] = {1, 1, 1};
};

// Arma en primera persona.
struct Weapon {
    bool enabled = true;
    std::string tex;      // sprite (asset png/jpg); vacio = arma basica dibujada
    float scale = 0.5f;   // alto del sprite (fraccion del alto de pantalla)
    float ox = 0, oy = 0; // desplazamiento (fraccion de pantalla)
    float rate = 0.25f;   // segundos entre disparos
    float range = 60.f;
    std::string model;      // arma 3D (asset .fmdl) en lugar del sprite
    float damage = 1.f;
    // proyectil visible
    std::string projTex, projModel;
    float projSize = 0.2f, projSpeed = 40.f, projColor[3] = {1.f, 0.85f, 0.3f};
    int projShape = 0;      // 0 esfera/bala (cubo pequeno), 1 imagen plana (sprite), 2 modelo
    // v8: tipos de arma y municion
    std::string name = "Arma";
    int type = 0;           // 0 de fuego, 1 cuerpo a cuerpo, 2 arrojadiza, 3 granada
    bool startWith = true;  // true = empieza con ella; false = hay que recogerla del suelo
    int magSize = 0;        // balas por cargador (0 = sin recarga)
    int startAmmo = 30;     // balas de reserva con las que empieza
    bool infinite = true;   // disparo infinito
    float recoilAmt = 1.f;  // retroceso (0 = ninguno)
    float reloadTime = 1.2f, meleeRange = 2.2f, blast = 4.f, fuse = 2.f;
};
extern const char* const kWeaponTypeNames[4];

// Opciones al exportar el juego (APK / EXE).
struct ExportCfg {
    std::string appName;                 // nombre de la app en Android (si vacio, el del proyecto)
    std::string appId = "com.mijuego.app";  // paquete: com.tuempresa.tujuego
    std::string verName = "1.0";
    int verCode = 1;
    int orient = 0;                      // 0 horizontal, 1 vertical, 2 automatico
    std::string icon;                    // imagen png del proyecto para el icono
    std::string exeName;                 // nombre del archivo .exe (sin .exe)
    std::string winTitle;                // titulo de la ventana en Windows
    bool fullscreen = false;
    bool hideVirtual = false;            // v10.8: .exe sin botones virtuales (teclado/mouse/control)
    int winW = 1280, winH = 720;
};

enum CamMode { kFirstPerson = 0, kShoulder = 1, kFixed = 2 };
struct PlayerCfg {
    int cam = kFirstPerson;
    std::string model;      // cuerpo del jugador (visible en tercera persona)
    float speed = 4.5f, jump = 7.f;
    // v8
    // linterna (v9)
    bool flashlight = false, flashOnStart = false, flashFlicker = false;
    float flashRange = 22.f, flashAngle = 26.f, flashInt = 1.5f, flashCol[3] = {1.f, 0.95f, 0.8f};
    std::string flashTex;        // dibujo opcional de la luz (vacio = sin dibujo, solo el efecto)
    bool headBob = false;        // v9: la cámara en primera persona se balancea al caminar
    float bobAmt = 1.f;
    int fixedMode = 0;           // v9 camara fija: 0 gira para seguir al jugador, 1 se mueve con el jugador, 2 totalmente fija
    bool vehicle = false;        // v10.4: modo vehículo (carro): acelerar/frenar y girar con botones, la cámara va detrás
    int lockOn = 0;              // v10.7: fijar al enemigo: 0 no, 1 al atacar, 2 siempre
    bool sideView = false;       // v10.7: vista lateral 2.5D (solo se camina de lado)
    bool swipe = false;          // v10.7: deslizar el dedo manda botones "Deslizar izquierda/derecha/arriba/abajo"
    float lockRange = 9.f;
    bool runner = false;         // v10.7: corredor infinito de 3 carriles (avanza solo; deslizar = carril/salto/agacharse)
    float laneW = 3.f;
    int faceExtra = 0;           // v10.8: 0 normal, 2 mira al contrario de donde camina, 3 siempre mira hacia atras
    bool faceMove = true;        // el cuerpo gira hacia donde camina (false = siempre mira al frente)
    float shoulderDist = 2.8f;   // distancia de la camara al hombro
    float mox = 0, moy = 0, moz = 0, myaw = 0, mscale = 1.f;  // ajuste del modelo del jugador
};

// v10.5: pantalla del juego (HUD) lista para usar: barras, minimapa, brújula, mira, estilos de color...
struct GameUi {
    bool on = false;                 // maestro: activa el HUD pro
    bool health = true, shield = false, ammo = true, slots = true, minimap = true, compass = false;
    bool speedo = false, timer = false, score = false, objective = false, hitmark = true, lowHp = true;
    int crosshair = 1;               // 0 ninguna, 1 punto, 2 cruz, 3 círculo, 4 cruz con hueco
    float vignette = 0.25f;          // oscurecer bordes (0 = nada)
    int grade = 0;                   // 0 normal, 1 cine, 2 vibrante, 3 frío, 4 atardecer, 5 retro
    float accent[3] = {0.2f, 0.85f, 0.9f};   // color de las barras
    bool fight = false;              // v10.7: barras de pelea arriba (jugador y rival), nombres y reloj
    std::string nameA = "JUGADOR", nameB = "RIVAL";
    int mapStyle = 0;                // v11.3: 0 círculo, 1 óvalo, 2 rectángulo, 3 cuadrado, 4 teléfono (vertical), 5 anillo transparente
    float mapRange = 28.f;           // cuánto se ve alrededor (metros en 3D)
    float mapSize = 1.f;             // tamaño en pantalla
    bool mapRotate = true;           // 3D: el mapa gira con la cámara
};

using Files = std::map<std::string, std::vector<uint8_t>>;

struct Project {
    std::string name = "juego";
    std::vector<Scene> scenes;
    Files assets;  // texturas, sonidos, modelos
    bool hudDefault = true;       // true = botones por defecto (saltar y disparar)
    std::vector<HudBtn> hud;      // botones propios (si hudDefault == false; vacio = sin botones)
    Weapon weapon;
    std::vector<Weapon> extraWeapons;   // v8: armas extra opcionales (cuerpo a cuerpo, arrojadiza, granada...)
    PlayerCfg player;
    ExportCfg exportCfg;
    bool showVars = false;
    std::string snd[8];           // v9: sonidos del juego (vacio = el de por defecto): paso, salto, aterrizaje, disparo, recarga, golpe, daño, explosión
    std::string keys[12];         // v10.8: teclas propias por accion (vacio = por defecto; ver keymap.h)
    int resH = 1080;              // v10.8: resolucion del juego (alto en pixeles) al jugar / exportar; 0 = la de la pantalla
    int ctl2d = 0;                // v10: controles tactiles/teclado en escenas 2D: 0 ninguno, 1 cruceta, 2 palanca, 3 plataformas (izq/der + saltar)
    GameUi ui;                    // v10.5
    float gi = 0.f;               // v10.3: iluminación global falsa + gráficos pro (0 = apagado, 1 = normal, 1.5 = fuerte)
    float mblur = 0.f;            // v10.2: desenfoque de movimiento de la cámara (0 = apagado, 1 = máximo)
    bool rtx = false;             // v9: modo RTX (sombras suaves, brillos y reflejos extra); apagado por defecto
    int quality = 1;              // v8: calidad general 0 baja, 1 media, 2 alta
    // v11: motor gráfico ajustable
    int gfxShadow = 0;            // resolución de sombras: 0 la del dispositivo, 1=512, 2=1024, 3=2048, 4=4096
    int gfxSoft = 0;              // suavidad de sombras: 0 normal, 1 suave (8 muestras), 2 muy suave (16)
    float gfxSpec = 0.f;          // brillo especular del sol en todos los materiales (0..1)
    float gfxTone = 0.f;          // tono de película ACES (0..1)
    float gfxEv = 0.f;            // exposición (-1..1, en pasos de luz)
    int gfxAniso = 1;             // filtrado anisotrópico de texturas: 1, 4, 8, 16
    int gfxFilter = 0;            // v11.2: filtro de pantalla (0 ninguno, 1 B/N, 2 bandas, 3 caricatura, 4 explosión, 5 realzado, 6 borroso, 7 pixelado, 8 retro, 9 sepia)
    float gfxFilterAmt = 0.5f;
    int gfxPreset = -1;           // último preset elegido (solo informativo): 0 ahorro, 1 equilibrado, 2 alto, 3 ultra
    std::vector<std::string> globalVars;  // variables para todos los objetos y escenas
};

std::vector<HudBtn> defaultHud();

bool loadProject(const Files& files, Project& out, std::string& err);
std::string writeProject(const Project& p);  // genera project.forge
bool loadDemo(Project& out);

const char* kindName(Kind k);

// Garantiza que una escena 3D tenga su objeto "Jugador" (se puede mover y editar como cualquier objeto).
// Su centro esta 0.85 m sobre los pies; Scene::start se mantiene sincronizado.
void ensurePlayer(Scene& s);
int playerIndex(const Scene& s);

}  // namespace forge
