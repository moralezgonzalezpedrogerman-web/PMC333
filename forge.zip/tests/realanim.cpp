// Uso: realanim archivo.fbx|glb -> importa animaciones sobre un esqueleto vacio y reporta
#include <cstdio>
#include <fstream>
#include <iterator>
#include "importer.h"
#include "rig.h"
using namespace forge;
int main(int argc, char** argv) {
    std::ifstream f(argv[1], std::ios::binary);
    std::vector<uint8_t> d((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    Rig rig;
    if (argc > 2) { const char* nm[] = {"cadera","columna","pecho","cuello","cabeza","hombro_i","codo_i","mano_i","muslo_i","rodilla_i","pie_i","hombro_d","codo_d","mano_d","muslo_d","rodilla_d","pie_d"}; int par[] = {-1,0,1,2,3,2,5,6,0,8,9,2,11,12,0,14,15}; for (int i = 0; i < 17; i++) rig.bones.push_back({nm[i], par[i], V3{0, (float)i * 0.05f, 0}}); }
    int added = 0; std::string err;
    bool ok = importAnimations(argv[1], d, "x.fmdl", rig, added, err);
    printf("ok=%d added=%d err=[%s] bones=%zu clips=%zu\n", ok, added, err.c_str(), rig.bones.size(), rig.clips.size());
    for (auto& b : rig.bones) printf(" %s(%d)", b.name.c_str(), b.parent);
    printf("\n");
}
