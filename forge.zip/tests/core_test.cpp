// Prueba del nucleo sin GPU: demo, bloques, fisica basica, paquete y exportacion a .exe.
#include "audioconv.h"
#include "audio.h"
#include "defsounds.h"
#include <cstdio>
#include <cmath>
#include <cstdlib>

#include "game.h"
#include "textscript.h"
#include "video.h"
#include "pack.h"
#include "model.h"
#include "hud.h"
#include "controls.h"

using namespace forge;

#define CHECK(c) do { if (!(c)) { printf("FALLO linea %d: %s\n", __LINE__, #c); return 1; } } while (0)

static Block blk(Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
    Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
}

static Obj* find(Game& g, const char* n) {
    for (auto& o : g.sc->objs) if (o.name == n) return &o;
    return nullptr;
}

static int netTest();
int main() {
    if (netTest()) return 1;
    Project p;
    CHECK(loadDemo(p));
    CHECK(p.scenes.size() == 2);

    // Paquete e exportacion.
    Files f;
    f["project.forge"] = {'a', 'b'};
    f["tex.png"] = {1, 2, 3};
    std::vector<uint8_t> pk, back, out;
    CHECK(packWrite(f, pk));
    Files g2;
    CHECK(packRead(pk.data(), pk.size(), g2) && g2.size() == 2 && g2["tex.png"].size() == 3);
    CHECK(exportExe({'M', 'Z', 0, 0}, pk, out));
    CHECK(!exportExe({1, 2}, pk, out));
    FILE* fp = fopen("fake.exe", "wb");
    CHECK(fp);
    fwrite(out.data(), 1, out.size(), fp);
    fclose(fp);
    CHECK(extractFromExe("fake.exe", back) && back == pk);

    // Juego: menu 2D -> nivel 3D -> puerta -> pasar.
    Game gm;
    gm.load(std::move(p));
    Input in;
    const float dt = 1.f / 60.f, asp = 16.f / 9.f;
    CHECK(gm.sc->name == "Menu" && !gm.sc->is3d);
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    gm.update(dt, in, asp);
    CHECK(gm.sc->name == "Nivel1" && gm.sc->is3d);

    for (int i = 0; i < 120; i++) gm.update(dt, in, asp);
    CHECK(gm.ground);
    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    in.moveY = 0;
    CHECK(gm.pos.z > -3.8f && gm.pos.z < -3.0f);  // la puerta cerrada bloquea

    Obj* door = find(gm, "Puerta");
    CHECK(door);
    float y0 = door->pos.y;
    in.tap = true;
    gm.update(dt, in, asp);
    in.tap = false;
    for (int i = 0; i < 90; i++) gm.update(dt, in, asp);
    CHECK(door->pos.y > y0 + 2.f);                // el bloque "repetir" la subio

    in.moveY = 1;
    for (int i = 0; i < 200; i++) gm.update(dt, in, asp);
    CHECK(gm.pos.z < -8.f);                       // ya pasa por debajo

    Obj* cube = find(gm, "Cubo_giratorio");
    CHECK(cube);
    float yawA = cube->yaw;
    gm.update(dt, in, asp);
    CHECK(cube->yaw != yawA);                     // "para siempre" gira cada frame

    // --- disparo: el evento "Al recibir un disparo" se ejecuta al apuntar a un objeto
    {
        Project q;
        q.name = "tiro";
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {20, 1, 20};
        Obj tgt; tgt.name = "Blanco"; tgt.pos = {0, 1.0f, -5}; tgt.scale = {1, 2, 1};
        Block h; h.op = Op::WhenShot;
        Block b; b.op = Op::SetVar; b.t = "golpes"; b.f[0] = "3+4";
        tgt.blocks = {h, b};
        sc.objs.push_back(floor); sc.objs.push_back(tgt);
        q.scenes.push_back(sc);
        Game g;
        std::string snd;
        g.onSound = [&](const std::string& n) { snd = n; };
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        si.shoot = true;
        for (int i = 0; i < 40; i++) g.update(dt, si, asp);
        CHECK(snd == "disparo");
        CHECK(g.vars["golpes"].num() == 7.0);
    }


    // --- ruta con físicas + pegar al suelo
    {
        Project q;
        Scene sc; sc.name = "A"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {200, 1, 200};
        Obj car; car.name = "Rival"; car.kind = Kind::Model; car.pos = {0, 3.f, 0}; car.scale = {2, 1, 2};
        car.phys = Phys::Dynamic; car.snapGround = true; car.routeOn = true; car.routeSpd = 10.f; car.route = {0, 0, 30, 0, 30, 30};
        sc.objs.push_back(floor); sc.objs.push_back(car);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 240; i++) g.update(dt, si, asp);
        CHECK(std::fabs(g.sc->objs[1].pos.x) + std::fabs(g.sc->objs[1].pos.z) > 3.f);
    }

    // --- clones de NPC con reaparición
    {
        Project q;
        Scene sc; sc.name = "A"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {200, 1, 200};
        Obj npc; npc.name = "Npc"; npc.pos = {10, 0.9f, 10}; npc.scale = {0.6f, 1.8f, 0.6f}; npc.wander = true;
        npc.cloneN = 3; npc.cloneRespawn = true; npc.cloneTotal = 5;
        sc.objs.push_back(floor); sc.objs.push_back(npc);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        auto cnt = [&]() { int c = 0; for (auto& o : g.sc->objs) if (o.clone && o.alive) c++; return c; };
        CHECK(cnt() == 3);
        for (auto& o : g.sc->objs) if (o.clone) { o.alive = false; break; }
        for (int i = 0; i < 120; i++) g.update(dt, si, asp);
        CHECK(cnt() == 3);
        for (int r = 0; r < 4; r++) { for (auto& o : g.sc->objs) if (o.clone && o.alive) { o.alive = false; break; } for (int i = 0; i < 120; i++) g.update(dt, si, asp); }
        CHECK(cnt() < 3);   // se acabó el cupo (5 en total)
    }

    // --- apariencia anterior, variables del dispositivo, escenas independientes
    {
        Project q;
        Scene a; a.name = "A"; a.is3d = false;
        Obj o; o.name = "O"; o.kind = Kind::Cube; o.looks = {"x.png", "y.png", "z.png"}; o.tex = "x.png";
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        o.blocks = {B(Op::WhenStart), B(Op::PrevLook), B(Op::SaveDevVar, "rec", "42"), B(Op::SetVar, "tmp", "7"), B(Op::StartScene, "B")};
        a.objs.push_back(o);
        Scene b2; b2.name = "B"; b2.is3d = false;
        q.scenes.push_back(a); q.scenes.push_back(b2);
        q.globalVars = {"rec"};
        Game g; std::map<std::string, std::string> saved; g.onDevSave = [&](const std::map<std::string, std::string>& m) { saved = m; };
        g.load(std::move(q));
        g.onDevSave = [&](const std::map<std::string, std::string>& m) { saved = m; };
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(saved["rec"] == "42");
        CHECK(g.sc->name == "B");
        CHECK(g.vars["rec"].num() == 42.0);   // la del dispositivo vuelve a cargarse
        CHECK(g.vars["tmp"].num() == 0.0);    // la normal se reinició
        CHECK(g.proj.scenes[0].objs[0].tex == "z.png");
    }

    // --- programar con texto: ida y vuelta entre bloques y código
    {
        std::vector<Block> a, b2; std::string err;
        std::string code = "cuandoempieza()\nsi(\"puntos > 1\")\n  decir(\"hola, \\\"mundo\\\"\")\nfinsi()\nvariable(\"x\", \"5\"); incvariable(\"x\", \"2\")\n";
        CHECK(textToBlocks(code, a, err));
        CHECK(a.size() == 6);
        std::string back = blocksToText(a);
        CHECK(textToBlocks(back, b2, err) && b2.size() == a.size());
        CHECK(b2[2].f[0] == a[2].f[0] && a[2].f[0].find("\"mundo\"") != std::string::npos);
        std::vector<Block> c;
        CHECK(!textToBlocks("bloquefalso(\"a\")\nsi()\n", c, err));
        CHECK(err.find("línea 1") != std::string::npos);
        CHECK(aiPromptText(1).size() > 2000);
    }

    // --- una variable global conserva su valor al cambiar de escena
    {
        Project q;
        Scene a; a.name = "A"; a.is3d = false;
        Obj o; o.name = "O"; o.kind = Kind::Cube;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        o.blocks = {B(Op::WhenStart), B(Op::SetVar, "oro", "9"), B(Op::SetVar, "loc", "4"), B(Op::StartScene, "B")};
        a.objs.push_back(o);
        Scene b2; b2.name = "B"; b2.is3d = false;
        q.scenes.push_back(a); q.scenes.push_back(b2);
        q.globalVars = {"oro"};
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(g.sc->name == "B");
        CHECK(g.vars["oro"].num() == 9.0);
        CHECK(g.vars["loc"].num() == 0.0);
    }

    // --- v11.5: ruta, deambular y auto conducible
    {
        Project q;
        Scene sc; sc.name = "A"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {200, 1, 200};
        Obj car; car.name = "Rival"; car.kind = Kind::Model; car.pos = {0, 0.5f, -10}; car.scale = {2, 1, 2};
        car.routeOn = true; car.routeSpd = 10.f; car.route = {0, -10, 20, -10, 20, 10, 0, 10};
        Obj npc; npc.name = "Npc"; npc.pos = {10, 0.9f, 10}; npc.scale = {0.6f, 1.8f, 0.6f}; npc.wander = true; npc.wanderR = 5.f;
        Obj mine; mine.name = "Mio"; mine.kind = Kind::Model; mine.pos = {-3, 0.5f, 0}; mine.scale = {2, 1, 2}; mine.carMode = true; mine.carHp = 5.f;
        sc.objs.push_back(floor); sc.objs.push_back(car); sc.objs.push_back(npc); sc.objs.push_back(mine);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 30; i++) g.update(dt, si, asp);
        float x0 = 0; int ci = -1, ni = -1, mi = -1;
        for (int i = 0; i < (int)g.sc->objs.size(); i++) { if (g.sc->objs[i].name == "Rival") ci = i; if (g.sc->objs[i].name == "Npc") ni = i; if (g.sc->objs[i].name == "Mio") mi = i; }
        x0 = g.sc->objs[ci].pos.x;
        float nx = g.sc->objs[ni].pos.x, nz = g.sc->objs[ni].pos.z;
        for (int i = 0; i < 300; i++) g.update(dt, si, asp);
        CHECK(std::fabs(g.sc->objs[ci].pos.x - x0) + std::fabs(g.sc->objs[ci].pos.z + 10.f) > 3.f);   // el auto avanzó por la ruta
        {   // la punta marcada (frontOff) debe ir siempre al frente: se gira el frente local con modelMat y se compara con el avance
            int good = 0, tot = 0;
            g.sc->objs[ni].alive = false;   // el NPC no estorba en el circuito
            for (int rep = 0; rep < 40; rep++) {
                V3 p1 = g.sc->objs[ci].pos;
                g.pos = V3{p1.x, g.pos.y, p1.z + 4.f};   // el auto solo corre si el jugador está cerca
                for (int i = 0; i < 6; i++) g.update(dt, si, asp);
                Obj& cc = g.sc->objs[ci];
                V3 mv = cc.pos - p1;
                if (std::sqrt(mv.x * mv.x + mv.z * mv.z) < 0.3f) continue;
                float fa = -cc.frontOff * 0.0174532925f;
                V3 tipLocal{std::sin(fa), 0, -std::cos(fa)};
                M4 mm = modelMat(V3{0, 0, 0}, cc.yaw, V3{1, 1, 1});
                V3 tw{mm.m[0] * tipLocal.x + mm.m[8] * tipLocal.z, 0, mm.m[2] * tipLocal.x + mm.m[10] * tipLocal.z};
                tot++; if (dot(norm(tw), norm(mv)) > 0.6f) good++;;
            }
            CHECK(tot > 5 && good >= tot - 2);
        }
        CHECK(std::fabs(g.sc->objs[ni].pos.x - nx) + std::fabs(g.sc->objs[ni].pos.z - nz) > 0.05f);    // el NPC caminó
        CHECK(std::sqrt((g.sc->objs[ni].pos.x - 10.f) * (g.sc->objs[ni].pos.x - 10.f) + (g.sc->objs[ni].pos.z - 10.f) * (g.sc->objs[ni].pos.z - 10.f)) <= 5.5f);
        g.sc->objs[mi].carEnterD = 6.f;
        g.pos = V3{-3.f, 0, 3.f};
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        CHECK(g.nearCar == mi);
        g.sc->objs[mi].carEnterD = 0.2f;   // distancia corta: lejos del auto no sale «Conducir»
        for (int i = 0; i < 3; i++) g.update(dt, si, asp);
        CHECK(g.nearCar == -1);
        g.sc->objs[mi].carEnterD = 6.f;
        for (int i = 0; i < 3; i++) g.update(dt, si, asp);
        Input bi; bi.buttons.push_back("Conducir");
        g.update(dt, bi, asp);
        CHECK(g.carIdx == mi);
        Input gas; gas.moveY = 1.f;
        float z0 = g.pos.z;
        for (int i = 0; i < 60; i++) g.update(dt, gas, asp);
        CHECK(std::fabs(g.pos.z - z0) + std::fabs(g.pos.x + 3.f) > 1.f);
        CHECK(std::fabs(g.sc->objs[mi].pos.x - g.pos.x) < 0.01f);
        g.hurtPlayer(10.f);   // el auto se destruye y el jugador sigue a pie
        CHECK(g.carIdx < 0 && !g.sc->objs[mi].alive);
        CHECK(g.vars.count("vida") == 0 || g.vars["vida"].num() >= 100.0);
    }

    // --- v11.5: límite del mapa y apoyo sobre montañas
    {
        Project q;
        Scene sc; sc.name = "L"; sc.is3d = true; sc.limMode = 1; sc.limR = 5.f;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {200, 1, 200};
        Obj box; box.name = "Caja"; box.pos = {2, 3, 2}; box.scale = {1, 1, 1}; box.phys = Phys::Dynamic;
        sc.objs.push_back(floor); sc.objs.push_back(box);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        for (int i = 0; i < 400; i++) g.update(dt, fw, asp);
        CHECK(std::sqrt(g.pos.x * g.pos.x + g.pos.z * g.pos.z) <= 5.6f);
        CHECK(g.sc->objs[1].pos.y > 0.2f && g.sc->objs[1].pos.y < 0.8f);   // la caja cayó y quedó apoyada en el suelo
    }

    // --- v11.5: 2D ruta con estela
    {
        Project q;
        Scene sc; sc.name = "D"; sc.is3d = false;
        Obj a; a.name = "Bola"; a.pos = {-300, 0, 0}; a.scale = {80, 80, 1};
        a.routeOn = true; a.routeSpd = 300.f; a.route = {-300, 0, 300, 0, 300, 200, -300, 200}; a.trail = true; a.trailLife = 0.3f;
        sc.objs.push_back(a);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs.size() > 3);                       // dejó copias de la estela
        CHECK(std::fabs(g.sc->objs[0].pos.x + 300.f) + std::fabs(g.sc->objs[0].pos.y) > 50.f);
        size_t cnt = g.sc->objs.size();
        for (int i = 0; i < 600; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs.size() <= cnt + 40);                // las copias se reutilizan
    }

    // --- v11.5j: llantas que siguen y giran, «Fijar a», movimiento 2D por controles
    {
        Project q;
        Scene sc; sc.name = "W"; sc.is3d = true;
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {200, 1, 200};
        Obj car; car.name = "Auto"; car.kind = Kind::Model; car.pos = {0, 0.5f, -10}; car.scale = {2, 1, 4}; car.frontOff = 0.f;
        car.routeOn = true; car.routeSpd = 8.f; car.route = {0, -10, 0, 30};
        Obj wh; wh.name = "Auto_llanta1"; wh.kind = Kind::Model; wh.scale = car.scale; wh.wheelOf = "Auto"; wh.wheelOff = {0.5f, -0.3f, 0.3f}; wh.wheelR = 0.3f; wh.wheelFront = true; wh.solid = false;
        sc.objs.push_back(floor); sc.objs.push_back(car); sc.objs.push_back(wh);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 200; i++) { g.update(dt, si, asp); g.pos = V3{g.sc->objs[1].pos.x, g.pos.y, g.sc->objs[1].pos.z + 4.f}; }
        const Obj& c2 = g.sc->objs[1]; const Obj& w2 = g.sc->objs[2];
        CHECK(std::fabs(w2.pos.x - (c2.pos.x + 1.f)) < 0.05f || std::fabs(w2.pos.x - c2.pos.x) < 3.f);   // la llanta va pegada al auto
        CHECK(std::fabs(w2.pos.z - c2.pos.z) < 3.f);
        CHECK(std::fabs(w2.pitch) > 1.f || std::fabs(w2.roll) > 1.f);                                      // y gira al avanzar
    }
    {
        Project q;
        Scene sc; sc.name = "F"; sc.is3d = false;
        Obj a; a.name = "A"; a.pos = {0, 0, 0}; a.scale = {50, 50, 1};
        Obj m; m.name = "M"; m.pos = {0, 300, 0}; m.scale = {50, 50, 1}; m.vctl = 1; m.vctlSpd = 200.f;
        sc.objs.push_back(a); sc.objs.push_back(m);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        Input mv; mv.buttons.push_back("Derecha");
        float mx = g.sc->objs[1].pos.x;
        for (int i = 0; i < 30; i++) g.update(dt, mv, asp);
        CHECK(g.sc->objs[1].pos.x > mx + 20.f);                // se mueve con el control virtual
    }

    // --- v11.5m: saltos en el aire (1 / doble / triple) solo se recuperan al tocar el suelo
    for (int mode = 0; mode < 3; mode += 2) {
        Project q;
        Scene sc; sc.name = "J"; sc.is3d = false;
        Obj fl; fl.name = "Piso"; fl.pos = {0, -100, 0}; fl.scale = {4000, 100, 1}; fl.solid = true; fl.phys = Phys::Static; fl.yaw = 90.f;
        Obj hero; hero.name = "H"; hero.pos = {0, -20, 0}; hero.scale = {50, 50, 1}; hero.vctl = 2; hero.vctlSpd = 300.f; hero.phys = Phys::Dynamic; hero.jumpMode = mode; hero.yaw = 90.f;
        sc.objs.push_back(fl); sc.objs.push_back(hero);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input none; for (int i = 0; i < 60; i++) g.update(dt, none, asp);
        float y0 = g.sc->objs[1].pos.y, hi = y0;
        for (int i = 0; i < 90; i++) { Input j; j.jump = (i % 12) < 3; g.update(dt, j, asp); hi = std::max(hi, g.sc->objs[1].pos.y); }
        float rise = hi - y0;
        if (mode == 0) CHECK(rise < 150.f); else CHECK(rise > 170.f);
    }
    // --- enemigo 2D que dispara, bala en línea recta, caminata automática y guardado
    {
        Project q;
        Scene sc; sc.name = "E"; sc.is3d = false; sc.map2auto = true; sc.map2autoSpd = 200.f;
        Obj hero; hero.name = "H"; hero.pos = {0, 0, 0}; hero.scale = {50, 50, 1}; hero.vctl = 1; hero.vctlSpd = 300.f; hero.yaw = 90.f;
        Obj en; en.name = "En"; en.pos = {300, 0, 0}; en.scale = {80, 80, 1}; en.yaw = 90.f; en.solid = false;
        en.ai.type = AiType::Shooter; en.ai.sprite = true; en.ai.sight = 30.f; en.ai.rate = 0.5f; en.ai.bdir = 2; en.ai.blife = 0.f; en.ai.boff = true; en.ai.projSpeed = 10.f; en.ai.dmg = 1.f;
        en.ai.anim[kReload].off = true; en.ai.meleeTex = "g.png";
        sc.objs.push_back(hero); sc.objs.push_back(en);
        q.scenes.push_back(sc);
        std::string txt = writeProject(q); Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project back; std::string er; CHECK(loadProject(fl, back, er));
        const Scene& bs = back.scenes[0];
        CHECK(bs.map2auto && std::fabs(bs.map2autoSpd - 200.f) < 0.1f && bs.objs[1].ai.bdir == 2 && bs.objs[1].ai.anim[kReload].off && bs.objs[1].ai.meleeTex == "g.png");
        Game g; g.load(std::move(back));
        Input none; float x0 = g.sc->objs[0].pos.x;
        int bullets = 0; float minBx = 1e9f;
        for (int i = 0; i < 120; i++) {
            g.update(dt, none, asp);
            for (auto& o : g.sc->objs) if (o.alive && o.bullet) { bullets++; minBx = std::min(minBx, o.pos.x); }
        }
        CHECK(g.sc->objs[0].pos.x > x0 + 100.f);        // caminata automática: avanza solo
        CHECK(bullets > 0 && minBx < 290.f);            // la bala sale hacia -x
    }
    // --- ruta dibujada de la bala
    {
        Project q;
        Scene sc; sc.name = "R"; sc.is3d = false;
        Obj hero; hero.name = "H"; hero.pos = {0, 0, 0}; hero.scale = {50, 50, 1}; hero.vctl = 1; hero.yaw = 90.f;
        Obj en; en.name = "En"; en.pos = {300, 0, 0}; en.scale = {80, 80, 1}; en.yaw = 90.f; en.solid = false;
        en.ai.type = AiType::Shooter; en.ai.sprite = true; en.ai.sight = 30.f; en.ai.rate = 0.4f; en.ai.projSpeed = 10.f;
        en.ai.bpaths.push_back({0.f, 200.f, 100.f, 300.f});
        sc.objs.push_back(hero); sc.objs.push_back(en); q.scenes.push_back(sc);
        std::string txt = writeProject(q); Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project back; std::string er; CHECK(loadProject(fl, back, er));
        CHECK(back.scenes[0].objs[1].ai.bpaths.size() == 1 && back.scenes[0].objs[1].ai.bpaths[0].size() == 4);
        Game g; g.load(std::move(back));
        Input none; float maxy = 0.f;
        for (int i = 0; i < 90; i++) { g.update(dt, none, asp); for (auto& o : g.sc->objs) if (o.alive && o.bullet) maxy = std::max(maxy, o.pos.y); }
        CHECK(maxy > 150.f);   // la bala subió siguiendo la ruta dibujada
    }
    // --- v11.5j: mapa 2D (cámara sigue, límites, meta)
    {
        Project q;
        Scene sc; sc.name = "M"; sc.is3d = false; sc.map2on = true; sc.map2x = 100.f; sc.map2y = 0.f;
        Obj part; part.name = "Parte"; part.mapPart = 1; part.pos = {500, 0, 0}; part.scale = {1000, 600, 1}; part.solid = false;
        Obj hero; hero.name = "Heroe"; hero.pos = {0, 0, 0}; hero.scale = {50, 50, 1}; hero.vctl = 1; hero.vctlSpd = 400.f;
        hero.act[2] = "der.png"; hero.act[0] = "quieto.png";
        Obj meta; meta.name = "Meta"; meta.pos = {700, 0, 0}; meta.scale = {60, 200, 1}; meta.goal = true; meta.goalScene = "N"; meta.solid = false;
        sc.objs.push_back(part); sc.objs.push_back(hero); sc.objs.push_back(meta);
        Scene n2; n2.name = "N"; n2.is3d = false;
        q.scenes.push_back(sc); q.scenes.push_back(n2);
        Game g; g.load(std::move(q));
        Input si;
        g.update(dt, si, asp);
        CHECK(std::fabs(g.sc->objs[1].pos.x - 100.f) < 20.f);   // empieza en el inicio elegido
        CHECK(g.sc->objs[1].tex == "quieto.png");
        Input mv; mv.buttons.push_back("Derecha");
        bool changed = false; float maxx = 0;
        for (int i = 0; i < 400 && !changed; i++) { g.update(dt, mv, asp); if (g.sc->name == "M") maxx = std::max(maxx, g.sc->objs[1].pos.x); else changed = true; }
        CHECK(changed);                                          // la meta llevó a otra escena
        CHECK(maxx < 990.f);
    }
    {
        Project q;
        Scene sc; sc.name = "M"; sc.is3d = false; sc.map2on = true;
        Obj part; part.mapPart = 1; part.pos = {0, 0, 0}; part.scale = {600, 400, 1}; part.solid = false;
        Obj hero; hero.name = "H"; hero.scale = {50, 50, 1}; hero.vctl = 1; hero.vctlSpd = 400.f;
        sc.objs.push_back(part); sc.objs.push_back(hero);
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input mv; mv.buttons.push_back("Derecha");
        for (int i = 0; i < 300; i++) g.update(dt, mv, asp);
        CHECK(g.sc->objs[1].pos.x <= 300.f);                    // no sale del mapa
        CHECK(std::fabs(g.cam2x - g.sc->objs[1].pos.x) < 1.f);  // la cámara sigue al héroe
    }

    // --- v11.5: cinemáticas
    {
        Project q;
        Scene sc; sc.name = "C"; sc.is3d = true;
        Obj a; a.name = "Actor"; a.pos = {0, 1, 0}; a.scale = {1, 1, 1};
        sc.objs.push_back(a);
        q.scenes.push_back(sc);
        Cine c; c.name = "Intro"; c.dur = 2.f;
        c.cam.push_back(CineKey{0.f, 0.f, 0.f, V3{0, 5, 10}}); c.cam.push_back(CineKey{2.f, 90.f, 0.f, V3{10, 5, 10}});
        CineTrack tr; tr.obj = "Actor"; tr.keys.push_back(CineTrackKey{0.f, 0.f, V3{0, 1, 0}}); tr.keys.push_back(CineTrackKey{2.f, 0.f, V3{20, 1, 0}});
        c.tracks.push_back(tr);
        q.cines.push_back(c);
        std::string txt = writeProject(q);
        CHECK(txt.find("cine Intro") != std::string::npos);
        Game g;
        g.load(std::move(q));
        g.startCine("intro");
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.cineIdx_ >= 0);
        CHECK(g.sc->objs[0].pos.x > 5.f && g.sc->objs[0].pos.x < 15.f);   // el actor va por su ruta
        CHECK(g.camEye.y > 4.9f && g.camEye.x > 2.f);                       // la cámara sigue sus puntos
        for (int i = 0; i < 200; i++) g.update(dt, si, asp);
        CHECK(g.cineIdx_ < 0);
    }

    // --- bloques: formulas, si/de lo contrario, bucles, mensajes, deslizar
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "S"; sc.is3d = false;
        Obj a; a.name = "A"; a.scale = {100, 100, 1};
        a.blocks = {
            blk(Op::WhenStart),
            blk(Op::SetVar, "n", "0"),
            blk(Op::Repeat, "", "5"), blk(Op::ChangeVar, "n", "2"), blk(Op::LoopEnd),          // n = 10
            blk(Op::If, "", "n > 5 y n < 20"), blk(Op::SetX, "", "n * 3"),                      // x = 30
            blk(Op::Else), blk(Op::SetX, "", "-1"), blk(Op::EndIf),
            blk(Op::If, "", "n = 0"), blk(Op::SetY, "", "999"), blk(Op::Else), blk(Op::ChangeY, "", "7"), blk(Op::EndIf),
            blk(Op::Broadcast, "hola"),
            blk(Op::WhenReceive, "hola"), blk(Op::SetVar, "oido", "unir('si', 1)"),
        };
        Obj b; b.name = "B"; b.scale = {50, 50, 1};
        b.blocks = {
            blk(Op::WhenReceive, "hola"), blk(Op::GlideTo, "", "1", "200", "100"), blk(Op::SetVar, "fin", "1"),
        };
        Obj c; c.name = "C";
        c.blocks = {
            blk(Op::WhenStart), blk(Op::BroadcastWait, "hola"), blk(Op::SetVar, "listo", "posición x + 1"),
        };
        sc.objs = {a, b, c};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 20; i++) g.update(dt, z, asp);
        Obj& A = g.proj.scenes[0].objs[0];
        CHECK(g.vars["n"].num() == 10);
        CHECK(A.pos.x == 30 && A.pos.y == 7);          // "si" verdadero; el segundo "si" va por "de lo contrario"
        CHECK(g.vars["oido"].txt() == "si1");          // difundir mensaje + cuando recibo
        CHECK(g.vars.count("fin") == 0);               // B aun desliza (1 s)
        CHECK(g.vars.count("listo") == 0);             // C espera a que terminen los que recibieron
        for (int i = 0; i < 80; i++) g.update(dt, z, asp);
        Obj& Bo = g.proj.scenes[0].objs[1];
        CHECK(std::fabs(Bo.pos.x - 200) < 0.01f && std::fabs(Bo.pos.y - 100) < 0.01f);
        CHECK(g.vars["fin"].num() == 1);
        CHECK(g.vars["listo"].num() == 1);             // posición x de C (0) + 1
    }

    // --- fisica: una pelota cae por la gravedad, rebota y se detiene sobre el suelo
    {
        auto blk = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "", const char* f2 = "") {
            Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; b.f[2] = f2; return b;
        };
        Project q;
        Scene sc; sc.name = "F"; sc.is3d = false;
        Obj ground; ground.name = "Suelo"; ground.pos = {0, -400, 0}; ground.scale = {2000, 100, 1}; ground.yaw = 90;
        ground.blocks = {blk(Op::WhenStart), blk(Op::PhysStatic)};
        Obj ball; ball.name = "Pelota"; ball.pos = {0, 200, 0}; ball.scale = {60, 60, 1}; ball.yaw = 90;
        ball.blocks = {blk(Op::WhenStart), blk(Op::PhysDynamic), blk(Op::SetBounce, "", "50")};
        sc.objs = {ground, ball};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input z;
        for (int i = 0; i < 600; i++) g.update(dt, z, asp);
        Obj& P = g.proj.scenes[0].objs[1];
        CHECK(P.pos.y < 0 && P.pos.y > -400);          // cayó pero no atravesó el suelo
        CHECK(std::fabs(P.pos.y - (-400 + 50 + 30)) < 8.f);  // reposa sobre el suelo
    }

    // --- la colision gira con el objeto (3D): una pared larga en X girada 90 grados ocupa Z
    {
        Project q;
        Scene sc; sc.name = "R"; sc.is3d = true;
        Obj w; w.kind = Kind::Wall; w.name = "W"; w.pos = {0, 1, 0}; w.scale = {6, 2, 0.4f}; w.yaw = 90;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        sc.objs = {fl, w};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {2.5f, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < -1.f);             // a x=2.5 no hay pared: pasa
        g.pos = {0, 0.05f, 5.f};
        g.vel = V3();
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z > 3.f);              // la pared girada (larga en Z) la detiene
    }

    // --- la colision de un modelo sigue su forma: un plano delgado dentro de una caja de 4 m solo choca en el plano
    {
        ModelData md;
        float vv[4][3] = {{-.5f, -.5f, 0}, {.5f, -.5f, 0}, {.5f, .5f, 0}, {-.5f, .5f, 0}};
        for (auto& p : vv) md.v.insert(md.v.end(), {p[0], p[1], p[2], 0, 0, 1, 0, 0});
        md.idx = {0, 1, 2, 0, 2, 3};
        std::vector<uint8_t> bytes;
        CHECK(modelWrite(md, bytes));
        Project q;
        q.assets["m.fmdl"] = bytes;
        Scene sc; sc.name = "M"; sc.is3d = true;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        Obj m; m.kind = Kind::Model; m.model = "m.fmdl"; m.name = "M"; m.pos = {0, 2, 0}; m.scale = {4, 4, 4};
        sc.objs = {fl, m};
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {0, 0.05f, 5.f};
        for (int i = 0; i < 90; i++) g.update(dt, fw, asp);
        CHECK(g.pos.z < 1.0f && g.pos.z > 0.1f);   // pasa por el espacio vacio y se detiene en el plano
    }

    // --- rampa: el modelo inclinado se puede subir caminando (la superficie cuenta como subida)
    {
        ModelData md;   // plano inclinado: de y=-0.5 (z=+0.5) a y=+0.5 (z=-0.5)
        float vv[4][3] = {{-.5f, -.5f, .5f}, {.5f, -.5f, .5f}, {.5f, .5f, -.5f}, {-.5f, .5f, -.5f}};
        for (auto& p : vv) md.v.insert(md.v.end(), {p[0], p[1], p[2], 0, 0.707f, 0.707f, 0, 0});
        md.idx = {0, 1, 2, 0, 2, 3};
        std::vector<uint8_t> bytes; modelWrite(md, bytes);
        Project q; q.assets["r.fmdl"] = bytes;
        Scene sc; sc.name = "R"; sc.is3d = true;
        Obj fl; fl.kind = Kind::Floor; fl.name = "F"; fl.pos = {0, -0.1f, 0}; fl.scale = {60, 0.2f, 60}; fl.solid = true;
        Obj m; m.kind = Kind::Model; m.model = "r.fmdl"; m.name = "R"; m.pos = {0, 2, 0}; m.scale = {8, 4, 8};
        sc.objs = {fl, m};
        q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input fw; fw.moveY = 1.f;
        g.pos = {0, 0.05f, 6.f};
        float maxY = 0.f;
        for (int i = 0; i < 240; i++) { g.update(dt, fw, asp); maxY = std::max(maxY, g.pos.y); }
        CHECK(maxY > 1.5f);   // subió por la rampa
    }

    // --- el proyecto con bloques se guarda y se carga igual
    {
        Project q;
        loadDemo(q);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(writeProject(r) == txt);
        CHECK(r.scenes[1].objs[5].blocks.size() == q.scenes[1].objs[5].blocks.size());
        CHECK(r.scenes[1].objs[5].blocks[3].f[0] == q.scenes[1].objs[5].blocks[3].f[0]);
    }

    // --- botones por defecto (saltar y disparar) y propios
    {
        auto d = defaultHud();
        bool j = false, sh = false;
        for (auto& b : d) { j |= b.act == HudAct::Jump; sh |= b.act == HudAct::Shoot; }
        CHECK(j && sh);
        Project q;
        loadDemo(q);
        q.hudDefault = false;
        q.hud.clear();                         // "en blanco": sin botones
        q.weapon.rate = 0.4f; q.weapon.tex = "arma.png";
        HudBtn hb; hb.label = "BUM"; hb.act = HudAct::Shoot; hb.x = 0.3f; hb.y = 0.4f; q.hud.push_back(hb);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(!r.hudDefault && r.hud.size() == 1 && r.hud[0].label == "BUM" && r.hud[0].act == HudAct::Shoot);
        CHECK(r.weapon.tex == "arma.png" && r.weapon.rate > 0.39f && r.weapon.rate < 0.41f);
        CHECK(r.scenes.size() == q.scenes.size());
        CHECK(writeProject(r) == txt);        // estable: guardar y cargar no cambia nada
        Hud hud; hud.setup(r);
        CHECK(hud.btns.size() == 1);
        Hud hd; Project dd; loadDemo(dd); hd.setup(dd);
        CHECK(hd.btns.size() >= 2);
    }

    // --- toques: el boton de disparo del HUD dispara
    {
        Project q; loadDemo(q);
        Hud hud; hud.setup(q);
        PlayControls ctl; ctl.hud = &hud; ctl.w = 1600; ctl.h = 900; ctl.is3d = true;
        ctl.begin(0, 1600 * 0.88f, 900 * 0.68f, 0);
        Input i1 = ctl.consume();
        CHECK(i1.shoot);
        ctl.end(0, 50);
        Input i2 = ctl.consume();
        CHECK(!i2.shoot);
    }

    // --- modelo compacto
    {
        ModelData m; m.v = {0,0,0, 0,1,0, 0,0,  1,0,0, 0,1,0, 1,0,  0,0,1, 0,1,0, 0,1};
        m.idx = {0, 1, 2}; m.tex = "t.png"; m.color[0] = 0.5f;
        std::vector<uint8_t> bytes; ModelData r;
        CHECK(modelWrite(m, bytes) && modelRead(bytes.data(), bytes.size(), r));
        CHECK(r.v == m.v && r.idx == m.idx && r.tex == "t.png" && r.color[0] == 0.5f);
        CHECK(!modelRead(bytes.data(), 5, r));
    }

    // --- casa hueca: se entra por la puerta y las paredes siguen bloqueando
    {
        ModelData m;
        auto quad = [&](float x0, float z0, float x1, float z1) {  // pared vertical de y=-0.5 a 0.5
            uint32_t b = (uint32_t)(m.v.size() / 8);
            float P[4][3] = {{x0, -0.5f, z0}, {x1, -0.5f, z1}, {x1, 0.5f, z1}, {x0, 0.5f, z0}};
            for (auto& q : P) m.v.insert(m.v.end(), {q[0], q[1], q[2], 0, 1, 0, 0, 0});
            m.idx.insert(m.idx.end(), {b, b + 1, b + 2, b, b + 2, b + 3});
        };
        quad(-0.5f, -0.5f, 0.5f, -0.5f);   // fondo
        quad(-0.5f, -0.5f, -0.5f, 0.5f);   // izquierda
        quad(0.5f, -0.5f, 0.5f, 0.5f);     // derecha
        quad(-0.5f, 0.5f, -0.15f, 0.5f);   // frente, a la izquierda de la puerta
        quad(0.15f, 0.5f, 0.5f, 0.5f);     // frente, a la derecha de la puerta
        std::vector<uint8_t> bytes;
        CHECK(modelWrite(m, bytes));
        Project q;
        q.assets["casa.fmdl"] = bytes;
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 9.f};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {40, 1, 40};
        Obj casa; casa.name = "Casa"; casa.kind = Kind::Model; casa.model = "casa.fmdl"; casa.pos = {0, 2, 0}; casa.scale = {10, 4, 10};
        sc.objs.push_back(floor); sc.objs.push_back(casa);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        si.moveY = 1;
        for (int i = 0; i < 150; i++) g.update(dt, si, asp);  // 4.5 m/s: cruza la puerta (z = 5) y entra
        CHECK(g.pos.z < 3.f && std::fabs(g.pos.x) < 1.f);
        for (int i = 0; i < 200; i++) g.update(dt, si, asp);
        CHECK(g.pos.z > -4.9f);                              // la pared del fondo la detiene
        // contra la pared de la fachada (fuera de la puerta) no se puede pasar
        Project q2 = g.proj;
        q2.scenes[0].start = {3.f, 0.05f, 9.f};
        for (auto& o : q2.scenes[0].objs) if (o.kind == Kind::Player) o.pos = {3.f, 0.9f, 9.f};
        Game g2;
        g2.load(std::move(q2));
        Input s2;
        for (int i = 0; i < 60; i++) g2.update(dt, s2, asp);
        s2.moveY = 1;
        for (int i = 0; i < 200; i++) g2.update(dt, s2, asp);
        CHECK(g2.pos.z > 4.9f);
    }

    // --- enemigo que dispara, proyectil del jugador, camaras y bloques nuevos
    {
        Project q;
        q.name = "ia";
        q.globalVars = {"vida", "puntos"};
        q.weapon.projSpeed = 40.f;
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60};
        Obj en; en.name = "Malo"; en.kind = Kind::Item; en.pos = {0, 0.9f, -12}; en.scale = {0.8f, 1.8f, 0.8f};
        en.solid = true;
        en.ai.type = AiType::Shooter; en.ai.hp = 3; en.ai.dmg = 5; en.ai.rate = 0.5f; en.ai.sight = 30;
        Obj ctl; ctl.name = "Control"; ctl.kind = Kind::Cube; ctl.pos = {20, 1, 20}; ctl.solid = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        ctl.blocks = {B(Op::WhenStart), B(Op::SetCamera, "Cámara fija"), B(Op::PlaySoundWait, "x"), B(Op::SetVar, "fin", "1"),
                      };
        Obj w2 = ctl; w2.name = "Espera"; w2.pos = {25, 1, 20};
        w2.blocks = {B(Op::WhenStart), B(Op::WaitUntil, "", "\"go\" = 1"), B(Op::SetVar, "ok", "1")};
        sc.objs.push_back(floor); sc.objs.push_back(en); sc.objs.push_back(ctl); sc.objs.push_back(w2);
        sc.cam = {0, 8, 12};
        q.scenes.push_back(sc);
        Game g;
        g.soundLen = [](const std::string&) { return 2.f; };
        g.load(std::move(q));
        CHECK(playerIndex(*g.sc) >= 0);
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(g.camMode == kFixed);
        CHECK(std::fabs(g.camEye.y - 8.f) < 1e-3f);
        CHECK(g.vars["fin"].num() == 0.0);        // la musica aun suena: el guion espera
        for (int i = 0; i < 160; i++) g.update(dt, si, asp);
        CHECK(g.vars["fin"].num() == 1.0);
        CHECK(g.vars["vida"].num() < 100.0);      // el enemigo disparo y dio
        g.camMode = kFirstPerson;
        g.vars["vida"] = Val(100.0);
        g.yaw = 0;
        si.shoot = true;
        for (int i = 0; i < 400; i++) g.update(dt, si, asp);
        CHECK(!find(g, "Malo")->alive);           // el jugador lo derribo
        CHECK(g.vars["puntos"].num() >= 10.0);
        CHECK(g.vars["ok"].num() == 0.0);         // "esperar hasta" sigue esperando
        g.vars["go"] = Val(1.0);
        for (int i = 0; i < 5; i++) g.update(dt, si, asp);
        CHECK(g.vars["ok"].num() == 1.0);
    }

    // --- guardar y cargar: enemigo, jugador, arma, proyectil y camara
    {
        Project q;
        q.player.cam = kShoulder; q.player.model = "yo.fmdl"; q.player.speed = 6.f;
        q.weapon.model = "pistola.fmdl"; q.weapon.projShape = 2; q.weapon.projModel = "bala.fmdl"; q.weapon.damage = 2.5f;
        Scene sc; sc.name = "N"; sc.cam = {1, 2, 3};
        Obj e; e.name = "E"; e.kind = Kind::Item;
        e.ai.type = AiType::Melee; e.ai.sprite = true; e.ai.hp = 9; e.ai.anim[kWalk].frames = {"a.png", "b.png"}; e.ai.anim[kWalk].fps = 8;
        e.ai.anim[kAttack].lunge = 0.7f; e.ai.projTex = "p.png";
        sc.objs.push_back(e);
        q.scenes.push_back(sc);
        Project r;
        std::string err;
        Files fl; fl["project.forge"] = std::vector<uint8_t>();
        std::string txt = writeProject(q);
        fl["project.forge"].assign(txt.begin(), txt.end());
        CHECK(loadProject(fl, r, err));
        CHECK(r.player.cam == kShoulder && r.player.model == "yo.fmdl" && r.player.speed == 6.f);
        CHECK(r.weapon.model == "pistola.fmdl" && r.weapon.projShape == 2 && r.weapon.projModel == "bala.fmdl" && r.weapon.damage == 2.5f);
        const Obj& re = r.scenes[0].objs[0];
        CHECK(r.scenes[0].cam.z == 3.f);
        CHECK(re.ai.type == AiType::Melee && re.ai.sprite && re.ai.hp == 9.f && re.ai.projTex == "p.png");
        CHECK(re.ai.anim[kWalk].frames.size() == 2 && re.ai.anim[kWalk].frames[1] == "b.png" && re.ai.anim[kWalk].fps == 8.f);
        CHECK(re.ai.anim[kAttack].lunge == 0.7f);
    }

    // --- clones, romper en pedazos, ir hacia otro objeto
    {
        Project q;
        Scene sc; sc.name = "N"; sc.is3d = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {0, 0, 0};
        a.blocks = {B(Op::WhenStart), B(Op::CreateClone), B(Op::CreateClone),
                    B(Op::WhenCloneStart), B(Op::ChangeVar, "n", "1"), B(Op::MoveTowards, "Meta", "50"), B(Op::BreakApart, "", "6")};
        Obj m; m.name = "Meta"; m.kind = Kind::Cube; m.pos = {100, 0, 0}; m.solid = false;
        sc.objs.push_back(a); sc.objs.push_back(m);
        q.scenes.push_back(sc);
        Game g;
        g.load(std::move(q));
        Input si;
        for (int i = 0; i < 6; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs.size() == 4);                 // original + meta + 2 clones
        CHECK(g.vars["n"].num() == 2.0);               // cada clon ejecuto su guion una vez
        CHECK(g.sc->objs[2].clone && !g.sc->objs[2].alive);  // el clon se rompio
        CHECK(!g.debris.empty());
        for (int i = 0; i < 400; i++) g.update(dt, si, asp);
        CHECK(g.debris.empty());                       // los pedazos desaparecen solos
        CHECK(g.sc->objs[0].alive);                    // el original sigue
    }

    // --- particulas y capa de camara: se emiten, se guardan y se cargan
    {
        Project q;
        Scene sc; sc.name = "N"; sc.is3d = true;
        Obj e; e.name = "Fogata"; e.kind = Kind::Cube; e.pos = {0, 1, -5}; e.solid = false;
        fxPreset(e.fx, 1);
        sc.objs.push_back(e);
        sc.overlays.push_back(Overlay{"marco.png", 0.5f, 0.4f, 0.8f, 0.7f, 0.6f});
        sfxPreset(sc.sfx, 1);
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Project r;
        std::string err;
        Files fl; fl["project.forge"].assign(txt.begin(), txt.end());
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes[0].overlays.size() == 1 && r.scenes[0].overlays[0].tex == "marco.png" && r.scenes[0].overlays[0].alpha == 0.6f);
        CHECK(r.scenes[0].sfx.scan > 0.5f && r.scenes[0].sfx.track == 1.f);
        const Obj* fo = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.name == "Fogata") fo = &o;
        CHECK(fo && fo->fx.on && fo->fx.glow && fo->fx.rate == 40.f);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.parts.size() > 10 && g.parts.size() < 120);   // nacen y mueren
    }
    {   // v6: eventos de disparo/boton/movimiento, objetos bloqueados, animaciones del jugador
        Project q;
        q.name = "v6";
        q.globalVars = {"vida"};
        q.weapon.projSpeed = 40.f;
        q.hudDefault = false;
        HudBtn hb; hb.label = "Granada"; hb.x = 0.5f; hb.y = 0.5f; hb.r = 0.1f; hb.act = HudAct::Script;
        q.hud.push_back(hb);
        Scene sc; sc.name = "N"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60};
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {20, 1, 20}; a.solid = false; a.locked = true;
        a.blocks = {B(Op::WhenPlayerShoots), B(Op::ChangeVar, "tiros", "1"),
                    B(Op::WhenButton, "Granada"), B(Op::ChangeVar, "granadas", "1"),
                    B(Op::WhenPlayerMoves), B(Op::SetVar, "camino", "1"),
                    B(Op::WhenObjMoves, "M"), B(Op::ChangeVar, "mueve", "1")};
        sc.objs.push_back(floor); sc.objs.push_back(a);
        q.scenes.push_back(sc);
        ensurePlayer(q.scenes[0]);
        Obj& pl = q.scenes[0].objs[playerIndex(q.scenes[0])];
        pl.ai.sprite = true;
        pl.ai.anim[kWalk].frames.push_back("paso.png");
        std::string txt = writeProject(q);
        CHECK(txt.find("script") != std::string::npos);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.hud.size() == 1 && r.hud[0].act == HudAct::Script);
        const Obj* ra = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.name == "A") ra = &o;
        CHECK(ra && ra->locked);
        const Obj& rp = r.scenes[0].objs[playerIndex(r.scenes[0])];
        CHECK(rp.ai.sprite && rp.ai.type == AiType::None && rp.ai.anim[kWalk].frames.size() == 1);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(g.vars.count("tiros") == 0 && g.vars.count("camino") == 0);
        si.shoot = true;
        g.update(dt, si, asp);
        si.shoot = false;
        for (int i = 0; i < 3; i++) g.update(dt, si, asp);
        CHECK(g.vars["tiros"].num() >= 1);
        si.buttons.push_back("granada");
        g.update(dt, si, asp);
        si.buttons.clear();
        g.update(dt, si, asp);
        CHECK(g.vars["granadas"].num() == 1);
        si.moveY = 1.f;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(g.vars["camino"].num() == 1);
    }
    {   // terreno deformable: la colisión sigue la forma y se guarda
        Project q;
        q.name = "terreno";
        Scene sc; sc.name = "T"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj fl; fl.name = "Suelo"; fl.kind = Kind::Floor; fl.pos = {0, -0.1f, 0}; fl.scale = {40, 0.2f, 40}; fl.solid = true;
        terrainInit(fl, 40);
        for (int i = 0; i < 6; i++) terrainBrush(fl, 0.f, -9.f, 6.f, 0.5f, 0);
        float hill = terrainSurface(fl, 0.f, -9.f);
        CHECK(hill > 0.5f);
        CHECK(terrainSurface(fl, 100.f, 0.f) < -1e8f);
        float tt = 0;
        CHECK(rayTerrain(fl, V3{0, 20, -9}, V3{0, -1, 0}, 100.f, tt) && std::fabs((20.f - tt) - hill) < 0.1f);
        sc.objs.push_back(fl);
        q.scenes.push_back(sc);
        ensurePlayer(q.scenes[0]);
        std::string txt = writeProject(q);
        Files fl2; fl2["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl2, r, err));
        const Obj* rf = nullptr;
        for (auto& o : r.scenes[0].objs) if (o.kind == Kind::Floor) rf = &o;
        CHECK(rf && rf->tn == 40 && std::fabs(terrainSurface(*rf, 0.f, -9.f) - hill) < 0.05f);
        Game g;
        g.load(std::move(r));
        Input si;
        for (int i = 0; i < 30; i++) g.update(dt, si, asp);
        CHECK(g.pos.y < 0.2f);
        si.moveY = 1.f;
        float maxY = 0;
        for (int i = 0; i < 240; i++) { g.update(dt, si, asp); maxY = std::max(maxY, g.pos.y); }
        CHECK(g.pos.z < -4.f);   // avanzó
        CHECK(maxY > 1.5f);      // y subió la montaña (altura máx. ~3 m)
        CHECK(g.pos.y < 0.2f);   // y volvió a bajar
    }
    {   // v8: mientras / repetir hasta / fijar objetivo
        Project q;
        q.name = "v8";
        Scene sc; sc.name = "L"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60}; floor.solid = true;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = {20, 1, 20}; a.solid = false;
        a.blocks = {B(Op::WhenStart), B(Op::SetVar, "n", "0"), B(Op::While, "", "n < 5"), B(Op::ChangeVar, "n", "1"), B(Op::LoopEnd),
                    B(Op::SetVar, "m", "0"), B(Op::RepeatUntil, "", "m = 3"), B(Op::ChangeVar, "m", "1"), B(Op::LoopEnd),
                    B(Op::SetVar, "fin", "1"), B(Op::SetTarget, "Enemigo más cercano")};
        Obj en; en.name = "E"; en.kind = Kind::Cube; en.pos = {0, 1, -10}; en.ai.type = AiType::Shooter;
        sc.objs = {floor, a, en};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.vars["n"].num() == 5);
        CHECK(g.vars["m"].num() == 3);
        CHECK(g.vars["fin"].num() == 1);
        CHECK(g.targetOn_);
        CHECK(std::fabs(g.yaw) < 0.3f);   // el enemigo esta al frente (-z)
    }
    {   // v8: armas (municion, recarga, recoger del suelo) y ajustes de jugador
        Project q;
        q.name = "armas";
        q.weapon.infinite = false; q.weapon.magSize = 3; q.weapon.startAmmo = 6; q.weapon.rate = 0.05f; q.weapon.projSpeed = 0;
        Weapon m; m.name = "Espada"; m.type = 1; m.startWith = false; m.meleeRange = 3.f; m.damage = 5.f;
        q.extraWeapons.push_back(m);
        q.player.faceMove = false; q.player.shoulderDist = 4.f; q.player.mox = 0.5f; q.player.mscale = 1.5f;
        Scene sc; sc.name = "W"; sc.is3d = true; sc.start = {0, 0.05f, 0};
        Obj floor; floor.name = "Suelo"; floor.kind = Kind::Floor; floor.pos = {0, -0.5f, 0}; floor.scale = {60, 1, 60}; floor.solid = true;
        Obj it; it.name = "Item"; it.kind = Kind::Cube; it.pos = {0, 0.5f, -1.5f}; it.solid = false; it.giveWeapon = "Espada";
        sc.objs = {floor, it};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.extraWeapons.size() == 1 && r.extraWeapons[0].name == "Espada" && !r.extraWeapons[0].startWith && r.extraWeapons[0].type == 1);
        CHECK(!r.weapon.infinite && r.weapon.magSize == 3 && r.weapon.startAmmo == 6);
        CHECK(!r.player.faceMove && std::fabs(r.player.shoulderDist - 4.f) < 1e-3f && std::fabs(r.player.mscale - 1.5f) < 1e-3f);
        Game g; g.load(std::move(r));
        Input si;
        g.update(dt, si, asp);
        CHECK(g.curW_ == 0 && g.owned_.size() == 1);
        si.shoot = true;
        for (int i = 0; i < 12; i++) g.update(dt, si, asp);
        CHECK(g.wMag_[0] == 0 || g.reloadT_ > 0 || g.wAmmo_[0] < 6);   // gasto balas y empezo a recargar
        si.shoot = false;
        for (int i = 0; i < 100; i++) g.update(dt, si, asp);
        CHECK(g.wMag_[0] == 3 && g.wAmmo_[0] == 3);                    // recargo del cargador
        si.moveY = 1.f;
        for (int i = 0; i < 60; i++) g.update(dt, si, asp);
        CHECK(g.owned_.size() == 2 && g.curW_ == 1);                   // recogio la espada del suelo
    }
    {   // v8: video (con reproductor falso)
        struct Fake { int plays = 0, pauses = 0, stops = 0, seeks = 0; bool fin = false; } fk;
        VideoApi& api = videoApi();
        api.open = [&](int, const std::string&, const std::vector<uint8_t>&) { return true; };
        api.control = [&](int, int cmd, float) { if (cmd == 0) { fk.plays++; fk.fin = false; } else if (cmd == 1) fk.pauses++; else if (cmd == 2) fk.stops++; else fk.seeks++; };
        api.frame = [&](int, int&, int&, std::vector<uint8_t>&) { return false; };
        api.finished = [&](int) { return fk.fin; };
        api.close = [&](int) {};
        Project q; q.name = "vid";
        Scene sc; sc.name = "V"; sc.is3d = false;
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "TV"; a.video = "clip.mp4"; a.noColor = false;
        a.blocks = {B(Op::WhenStart), B(Op::PlayVideoTimes, "", "2"), B(Op::Wait, "", "0.2"), B(Op::PauseVideo), B(Op::Wait, "", "0.2"), B(Op::ResumeVideo)};
        sc.objs = {a};
        q.scenes.push_back(sc);
        q.assets["clip.mp4"] = {1, 2, 3};
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes[0].objs[0].video == "clip.mp4");
        r.assets["clip.mp4"] = {1, 2, 3};
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 90; i++) g.update(dt, si, asp);
        CHECK(fk.plays >= 2 && fk.pauses == 1);
        fk.fin = true;                       // termino la 1a vuelta: debe reiniciar (2 veces en total)
        int before = fk.plays;
        g.update(dt, si, asp);
        CHECK(fk.plays == before + 1);
        fk.fin = true;
        g.update(dt, si, asp);               // 2a vuelta termina: se detiene
        CHECK(g.vid_[0].state == 0);
        api = VideoApi();
    }
    {   // v9: vegetacion, mar, atmosfera, RTX, camara fija y mantener en pantalla
        Project q; q.name = "v9"; q.rtx = true; q.player.fixedMode = 2; q.player.headBob = true; q.player.bobAmt = 1.5f;
        Scene sc; sc.name = "S"; sc.is3d = false; sc.sea = true; sc.seaY = 1.5f; sc.fogMode = 1; sc.atmoStyle = 1; sc.atmoAmt = 2.5f; sc.atmo = 2;
        VegLayer v; v.name = "Pasto A"; v.style = 2; v.pts = {1, 0, 2, 1, 30, 3, 0, 4, 0.8f, 90};
        sc.veg.push_back(v);
        GroundLayer gl; gl.name = "Roca"; gl.preset = 2; gl.pts = {1, 0, 1, 2, 5, 0, 5, 3};
        sc.gnd.push_back(gl);
        auto B = [](Op op, const char* t = "", const char* f0 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; return b; };
        Obj a; a.name = "A"; a.pos = V3{0, 0, 0}; a.scale = V3{1, 1, 1};
        a.blocks = {B(Op::WhenStart), B(Op::KeepOnScreen), B(Op::ChangeX, "", "999"), B(Op::TiltCamRight, "", "20")};
        sc.objs = {a};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        const Scene& rs = r.scenes[0];
        CHECK(r.rtx && r.player.fixedMode == 2 && r.player.headBob && r.player.bobAmt > 1.4f);
        CHECK(r.scenes[0].gnd.size() == 1 && r.scenes[0].gnd[0].pts.size() == 8 && r.scenes[0].gnd[0].preset == 2);
        CHECK(rs.sea && rs.seaY == 1.5f && rs.fogMode == 1 && rs.atmoStyle == 1 && rs.atmoAmt > 2.4f);
        CHECK(rs.veg.size() == 1 && rs.veg[0].pts.size() == 10 && rs.veg[0].style == 2 && rs.veg[0].name == "Pasto A");
        Game g; g.load(std::move(r));
        Input si;
        for (int i = 0; i < 6; i++) g.update(dt, si, asp);
        CHECK(g.camRollTarget > 0.3f);
        CHECK(g.sc->objs[0].pos.x < g.stageW() * 0.5f && g.sc->objs[0].pos.x > 100.f);   // se quedo en el borde, no se salio
    }
    {   // v9: congelar, sonidos por defecto, linterna
        Project q; q.name = "v9b"; q.player.flashlight = true; q.player.flashOnStart = true; q.snd[3] = "mi.wav";
        Scene sc; sc.name = "S"; sc.is3d = true; sc.shadowAmt = 0.4f;
        Obj pl; pl.kind = Kind::Player; pl.name = "Jugador";
        Obj a; a.name = "A"; a.pos = V3{0, 1, 0}; a.scale = V3{1, 1, 1}; a.phys = Phys::Dynamic;
        sc.objs = {pl, a};
        q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.player.flashlight && r.player.flashOnStart && r.snd[3] == "mi.wav" && std::fabs(r.scenes[0].shadowAmt - 0.4f) < 1e-3f);
        Game g; g.load(std::move(r));
        std::vector<std::string> played;
        g.onSound = [&](const std::string& s) { played.push_back(s); };
        CHECK(g.flashOn_);
        g.worldFrozen_ = true;
        float y0 = g.sc->objs[1].pos.y;
        Input si;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(std::fabs(g.sc->objs[1].pos.y - y0) < 1e-4f);   // congelado: no cae
        g.worldFrozen_ = false;
        for (int i = 0; i < 20; i++) g.update(dt, si, asp);
        CHECK(g.sc->objs[1].pos.y < y0 - 0.001f);              // descongelado: cae
        g.playerFrozen_ = true;
        V3 p0 = g.pos;
        si.moveY = 1.f;
        for (int i = 0; i < 10; i++) g.update(dt, si, asp);
        CHECK(len(g.pos - p0) < 1e-4f);                        // jugador congelado
        auto w = makeDefaultSound("disparo");
        CHECK(w.size() > 1000 && w[0] == 'R');
    }
    {   // v10.5: HUD pro y botones correr/agachar se guardan y cargan
        Project q;
        loadDemo(q);
        q.ui.on = true; q.ui.shield = true; q.ui.compass = true; q.ui.crosshair = 4; q.ui.grade = 3; q.ui.vignette = 0.5f;
        q.hudDefault = false;
        HudBtn hb; hb.label = "CORRER"; hb.act = HudAct::Sprint; q.hud.push_back(hb);
        hb.label = "AGACHAR"; hb.act = HudAct::Crouch; q.hud.push_back(hb);
        std::string txt = writeProject(q);
        Files f; f["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(f, r, err));
        CHECK(r.ui.on && r.ui.shield && r.ui.compass && r.ui.crosshair == 4 && r.ui.grade == 3 && r.ui.vignette > 0.49f);
        CHECK(r.hud.size() == 2 && r.hud[0].act == HudAct::Sprint && r.hud[1].act == HudAct::Crouch);
        CHECK(writeProject(r) == txt);
        Game g; g.load(r);
        CHECK(g.vars.count("escudo") && g.vars["escudo"].num() == 100.0);
        g.vars["vida"] = Val(100.0);
        g.hurtPlayer(30.f);
        CHECK(g.vars["escudo"].num() == 70.0 && g.vars["vida"].num() == 100.0);   // el escudo absorbe primero
        g.vars["escudo"] = Val(10.0);
        g.hurtPlayer(30.f);
        CHECK(g.vars["escudo"].num() == 0.0 && g.vars["vida"].num() == 80.0);
    }
    printf("OK\n");
    return 0;
}
// (v10.7) red local: dos nodos se ven entre si por UDP; si el entorno no permite broadcast, solo se avisa.
#include "../core/net.h"
#include <chrono>
#include <thread>
static int netTest() {
    forge::Net a, b; a.setPort(47791); b.setPort(47791);
    if (!a.start("test", "A") || !b.start("test", "B")) { std::fprintf(stderr, "net: sin sockets, prueba omitida\n"); return 0; }
    for (int i = 0; i < 40; i++) { a.tick(i * 0.06, 1, 2, 3, 0, "s"); b.tick(i * 0.06, 4, 5, 6, 0, "s"); std::this_thread::sleep_for(std::chrono::milliseconds(5)); }
    if (a.peers().empty() && b.peers().empty()) { std::fprintf(stderr, "net: este entorno no entrega broadcast, prueba omitida\n"); return 0; }
    a.sendMsg("hola"); a.sendVar("puntos", "7");
    for (int i = 40; i < 50; i++) { b.tick(i * 0.06, 0, 0, 0, 0, "s"); }
    auto m = b.takeMsgs(); auto v = b.takeVars();
    if (m.empty() || m[0] != "hola" || v.empty() || v[0].second != "7") { std::fprintf(stderr, "FALLO red: mensajes\n"); return 1; }
    {   // v11.5z: voltear imagen 2D y tamaño negativo
        Project q; q.name = "flip"; Scene sc; sc.name = "s"; sc.is3d = false;
        Obj o; o.name = "boton"; o.kind = Kind::Cube; o.scale = V3{-200, 100, 1}; o.flipY = true;
        sc.objs.push_back(o); q.scenes.push_back(sc);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes[0].objs.size() >= 1 && r.scenes[0].objs[0].flipY && !r.scenes[0].objs[0].flipX);
        Game g; g.load(std::move(r));
        const Obj& go = g.sc->objs[0];
        CHECK(go.scale.x == 200.f && go.flipX && go.flipY);   // el negativo se volvió «voltear» y el tamaño quedó positivo
    }
    {   // v11.5z3: listas, contar, repetir con pausa, ancho/alto
        auto B = [](Op op, const char* t = "", const char* f0 = "", const char* f1 = "") { Block b; b.op = op; b.t = t; b.f[0] = f0; b.f[1] = f1; return b; };
        Project q; q.name = "lst"; Scene sc; sc.name = "s"; sc.is3d = false;
        Obj o; o.name = "x"; o.kind = Kind::Cube; o.scale = V3{100, 50, 1};
        o.blocks = {B(Op::WhenStart), B(Op::SetVar, "suma", "0"), B(Op::SetVar, "n", "0"),
                    B(Op::ListAdd, "L", "10"), B(Op::ListAdd, "L", "20"), B(Op::ListAdd, "L", "30"), B(Op::ListInsert, "L", "5", "1"),
                    B(Op::ListRemove, "L", "4"),
                    B(Op::ForEach, "c", "'L'"), B(Op::ChangeVar, "suma", "c"), B(Op::LoopEnd),
                    B(Op::ForRange, "i", "1", "4"), B(Op::ChangeVar, "n", "i"), B(Op::LoopEnd),
                    B(Op::SetVar, "largo", "largo de lista('L')"), B(Op::SetVar, "seg", "elemento de lista('L', 2)"),
                    B(Op::SetWidth, "", "50"), B(Op::SetVar, "ancho", "width"),
                    B(Op::RepeatEvery, "", "3", "0.1"), B(Op::ChangeVar, "rep", "1"), B(Op::LoopEnd), B(Op::SetVar, "fin", "1")};
        sc.objs.push_back(o); q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input si;
        for (int i = 0; i < 120; i++) g.update(1.f / 30.f, si, 1.78f);
        CHECK(g.vars["suma"].num() == 35.0);   // lista = 5,10,20 (se quitó el 30)
        CHECK(g.vars["n"].num() == 10.0);      // 1+2+3+4
        CHECK(g.vars["largo"].num() == 3.0 && g.vars["seg"].num() == 10.0);
        CHECK(g.vars["ancho"].num() == 50.0);
        CHECK(g.vars["rep"].num() == 3.0 && g.vars["fin"].num() == 1.0);
    }
    {   // v11.5z4: controles por escena, punta/estela, apariencias, colisión con varios del mismo nombre
        Project q; q.name = "z4"; q.ctl2d = 1;
        Scene a; a.name = "a"; a.is3d = false; a.ctl2d = 4;
        Obj o; o.name = "bala"; o.kind = Kind::Cube; o.routeFace = true; o.routeFaceOff = 90.f; o.trailGap = 55.f; o.trail = true;
        o.looks = {"x.png", "y.png"}; o.tex = "z.png";
        a.objs.push_back(o);
        Scene b; b.name = "b"; b.is3d = false; q.scenes.push_back(a); q.scenes.push_back(b);
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err;
        CHECK(loadProject(fl, r, err));
        CHECK(r.scenes.size() == 2 && r.scenes[0].ctl2d == 4 && r.scenes[1].ctl2d == -1 && r.ctl2d == 1);
        const Obj& ro = r.scenes[0].objs[0];
        CHECK(ro.routeFaceOff == 90.f && ro.trailGap == 55.f);
        Game g; g.load(std::move(r));
        CHECK(g.sc->objs[0].tex == "x.png");   // manda la primera apariencia de la lista
    }
    {   // audio m4a/ogg: se reconoce, se convierte con el gancho de la plataforma y el WAV resultante suena
        CHECK(Audio::isAudioFile("Mi Musica.M4A") && Audio::isAudioFile("a.ogg") && Audio::isAudioFile("a.aac"));
        CHECK(audioNeedsConversion("x.m4a") && !audioNeedsConversion("x.mp3") && !audioNeedsConversion("x.wav"));
        std::vector<int16_t> pcm(4410 * 2, 1000);
        audioConvHook() = [&](const std::string&, const std::vector<uint8_t>& in, std::vector<uint8_t>& out) {
            if (in.empty()) return false;
            out = makeWav16(pcm.data(), pcm.size(), 2, 44100); return true; };
        std::vector<uint8_t> wav;
        CHECK(audioConvertToWav("x.m4a", {1, 2, 3}, wav) && wav.size() == 44 + pcm.size() * 2);
        Files fl; fl["x.wav"] = wav;
        CHECK(!audioConvertToWav("x.m4a", {}, wav));
        audioConvHook() = nullptr;
        Audio au; CHECK(au.init(true));
        au.setAssets(fl);
        CHECK(au.has("x") && au.length("x") > 0.05f);
    }
    {   // "poco a poco": tamaño, transparencia y giro con duración
        Project q; q.name = "t"; Scene sc; sc.name = "e"; sc.is3d = false;
        Obj a; a.name = "A"; a.scale = {50, 50, 1};
        a.blocks = {blk(Op::WhenStart), blk(Op::GlideSize, "", "200", "1"), blk(Op::GlideTransp, "", "60", "0.5"),
                    blk(Op::GlideTurn, "", "90", "0.5"), blk(Op::SetVar, "fin", "1")};
        sc.objs = {a}; q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input z; float dt = 1.f / 60.f, asp = 1.f;
        for (int i = 0; i < 30; i++) g.update(dt, z, asp);
        const Obj& A = g.proj.scenes[0].objs[0];
        CHECK(A.scale.x > 60.f && A.scale.x < 95.f);        // a medio camino (50 -> 100)
        CHECK(g.vars.count("fin") == 0);
        for (int i = 0; i < 150; i++) g.update(dt, z, asp);
        CHECK(std::fabs(A.scale.x - 100.f) < 0.5f && std::fabs(A.transp - 60.f) < 0.5f && std::fabs(A.yaw - 90.f) < 0.5f);
        CHECK(g.vars.count("fin") == 1);
    }
    {   // cámara 2D: zoom, fija y siguiendo un objeto
        Project q; q.name = "t"; Scene sc; sc.name = "e"; sc.is3d = false;
        Obj a; a.name = "A"; a.pos = {300, 40, 0};
        a.blocks = {blk(Op::WhenStart), blk(Op::Cam2Zoom, "", "200"), blk(Op::Cam2Follow, "A")};
        sc.objs = {a}; q.scenes.push_back(sc);
        Game g; g.load(std::move(q));
        Input z; for (int i = 0; i < 5; i++) g.update(1.f / 60.f, z, 1.f);
        CHECK(std::fabs(g.view2H() - kView2DHeight * 0.5f) < 0.01f);
        CHECK(g.cam2x == 300.f && g.cam2y == 40.f);
    }
    {   // apuntar con la mira: bloque, zoom suave, guardado y vuelta a lo normal
        Project q; q.name = "t"; Scene sc; sc.name = "e"; sc.is3d = true;
        Obj a; a.name = "A"; a.blocks = {blk(Op::WhenStart), blk(Op::AimOn), blk(Op::Wait, "", "1"), blk(Op::AimOff)};
        sc.objs = {a}; q.scenes.push_back(sc);
        q.player.fov = 80.f; q.player.aimFov = 30.f; q.player.aimWx = 0.05f;
        std::string txt = writeProject(q);
        Files fl; fl["project.forge"] = std::vector<uint8_t>(txt.begin(), txt.end());
        Project r; std::string err; CHECK(loadProject(fl, r, err));
        CHECK(r.player.fov == 80.f && r.player.aimFov == 30.f && std::fabs(r.player.aimWx - 0.05f) < 1e-4f);
        Game g; g.load(std::move(r));
        Input z; float dt = 1.f / 60.f;
        CHECK(std::fabs(g.curFov() - 80.f) < 0.01f);
        for (int i = 0; i < 40; i++) g.update(dt, z, 1.f);
        CHECK(g.aiming && g.aimK > 0.9f && g.curFov() < 35.f);
        for (int i = 0; i < 90; i++) g.update(dt, z, 1.f);
        CHECK(!g.aiming && g.aimK < 0.05f && g.curFov() > 75.f);
        Input m; m.aim = true;
        for (int i = 0; i < 40; i++) g.update(dt, m, 1.f);
        CHECK(g.aimK > 0.9f);                               // clic derecho / botón mantiene la mira
    }
    return 0;
}
