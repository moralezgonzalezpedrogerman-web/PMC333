// Uso: realzip archivo.zip  -> importa el modelo como lo haria el editor y dice el resultado.
#include <cstdio>
#include <fstream>
#include <iterator>
#include <chrono>
#include "importer.h"
#include "model.h"
using namespace forge;
int main(int argc, char** argv) {
    std::ifstream f(argv[1], std::ios::binary);
    std::vector<uint8_t> d((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    Files assets; std::string name, err;
    auto t0 = std::chrono::steady_clock::now();
    bool ok = importModelZip(d, assets, name, err);
    double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    printf("ok=%d err=[%s] name=%s %.1fs assets=%zu\n", ok, err.c_str(), name.c_str(), s, assets.size());
    if (ok) { ModelData m; bool r = modelRead(assets[name].data(), assets[name].size(), m); printf("read=%d tris=%zu verts=%zu\n", r, m.idx.size()/3, m.v.size()/8);
      for (auto& kv : assets) { std::ofstream o("/tmp/claude-0/x1/out_"+kv.first, std::ios::binary); o.write((const char*)kv.second.data(), kv.second.size()); }
      for (auto& kv : assets) printf("  %s %zu\n", kv.first.c_str(), kv.second.size()); }
}
