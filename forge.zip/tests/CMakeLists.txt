# Pruebas del nucleo, importadores y editor (sin pantalla). Uso: cmake -S tests -B build-tests
cmake_minimum_required(VERSION 3.20)
project(forge_tests CXX C)
set(CMAKE_CXX_STANDARD 17)
set(FORGE_ROOT ${CMAKE_CURRENT_SOURCE_DIR}/..)
set(FORGE_WITH_EDITOR ON)
include(${FORGE_ROOT}/cmake/deps.cmake)

file(GLOB CORE ${FORGE_ROOT}/core/*.cpp)
file(GLOB EDITOR ${FORGE_ROOT}/editor/*.cpp)
set(IMGUI ${IMGUI_DIR}/imgui.cpp ${IMGUI_DIR}/imgui_draw.cpp ${IMGUI_DIR}/imgui_tables.cpp
    ${IMGUI_DIR}/imgui_widgets.cpp ${IMGUI_DIR}/misc/cpp/imgui_stdlib.cpp)
set_source_files_properties(${UFBX_DIR}/ufbx.c PROPERTIES LANGUAGE C)
add_library(forge_all STATIC ${CORE} ${EDITOR} ${IMGUI} ${UFBX_DIR}/ufbx.c)
target_include_directories(forge_all PUBLIC ${FORGE_ROOT}/core ${FORGE_ROOT}/editor ${STB_DIR} ${IMGUI_DIR}
    ${MINIAUDIO_DIR} ${CGLTF_DIR} ${UFBX_DIR})
target_link_libraries(forge_all PUBLIC ${CMAKE_DL_LIBS} pthread)
target_compile_definitions(forge_all PUBLIC FORGE_TESTING)

enable_testing()
foreach(t core_test import_test editor_test)
  add_executable(${t} ${FORGE_ROOT}/tests/${t}.cpp)
  target_link_libraries(${t} forge_all)
  add_test(NAME ${t} COMMAND ${t})
endforeach()

add_executable(realzip ${FORGE_ROOT}/tests/realzip.cpp)
add_executable(realanim ${FORGE_ROOT}/tests/realanim.cpp)
target_link_libraries(realanim forge_all)
target_link_libraries(realzip forge_all)
add_executable(apkcli ${FORGE_ROOT}/tests/apkcli.cpp)
target_link_libraries(apkcli forge_all)
