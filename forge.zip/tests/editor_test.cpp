// Prueba headless del editor: ImGui real sin backend, Renderer nulo.
#include "editor.h"
#include "fsutil.h"
#include "imgui.h"
#include "templates.h"
#include "library.h"
#include "model.h"
#include "game.h"
#include "catrobat.h"
#include <cstdio>
#include <cstdlib>
using namespace forge;

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FALLO %s:%d %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)

static void frame(Editor& e, float mx = -1, float my = -1, bool down = false) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(1280, 720);
    io.DeltaTime = 1.f / 60;
    io.AddMousePosEvent(mx, my);
    io.AddMouseButtonEvent(0, down);
    ImGui::NewFrame();
    e.frame(nullptr, 1280, 720, 1.f / 60);
    ImGui::Render();
}

int main() {
    char tmpl[] = "/tmp/forge_edXXXXXX";
    std::string dir = mkdtemp(tmpl);
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    unsigned char* px; int fw, fh;
    io.Fonts->GetTexDataAsRGBA32(&px, &fw, &fh);

    EditorHost h;
    h.dataDir = dir;
    h.loadRuntime = [](std::vector<uint8_t>& o) { o = {'M', 'Z', 1, 2, 3}; return true; };
    std::vector<std::string> saved;
    h.saveOut = [&](const std::string& n, const std::string&) { saved.push_back(n); };
    Audio audio; audio.init(true);
    Editor e(h);
    e.init(&audio);

    for (int i = 0; i < 5; i++) frame(e);
    CHECK(e.screen() == Screen::Projects);
    CHECK(e.newProject("prueba", true));
    {  // biblioteca: todo se genera, los modelos se leen y los triangulos miran hacia afuera
        Files lf;
        for (auto& it : libraryItems()) CHECK(libraryAdd(it.name, lf));
        for (auto& it : libraryItems()) {
            if (it.kind != 2) continue;
            ModelData md;
            CHECK(modelRead(lf[it.name].data(), lf[it.name].size(), md));
            int bad = 0;
            for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
                const float *a = &md.v[md.idx[t] * 8], *b = &md.v[md.idx[t + 1] * 8], *c = &md.v[md.idx[t + 2] * 8];
                float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                if (nx * a[3] + ny * a[4] + nz * a[5] <= 0) bad++;
            }
            if (bad) printf("%s: %d triangulos al reves\n", it.name.c_str(), bad);
            CHECK(bad == 0);
        }
    }
    for (int ti = 0; ti < templateCount(); ti++) {  // cada plantilla se guarda, se vuelve a leer y corre sin fallar
        Project tp;
        buildTemplate(ti, tp);
        Files fl;
        { std::string t = writeProject(tp); fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end()); }
        Project back; std::string er;
        CHECK(loadProject(fl, back, er));
        CHECK(back.scenes.size() == 1 && back.scenes[0].objs.size() == tp.scenes[0].objs.size());
        if (back.scenes.empty()) continue;
        Game gm; gm.load(std::move(back));
        Input in;
        for (int f = 0; f < 120; f++) gm.update(1.f / 60.f, in, 1.7f);
    }
    CHECK(e.screen() == Screen::Edit);
    e.showObjs = e.showProps = e.showWorld = e.showHud = e.showAssets = true;
    // paginas: escenas -> escena -> objeto (3 pestanas), menus y editores
    CHECK(e.page() == Page::Scenes);
    for (int i = 0; i < 5; i++) frame(e);
    e.setScene(1);
    e.setPage(Page::SceneHome);
    for (int i = 0; i < 5; i++) frame(e);
    {
        Scene& S = e.project().scenes[e.sceneIndex()];
        CHECK(!S.objs.empty());
        e.openObject(0);
        for (int t = 0; t < 3; t++) { e.setTab(t); for (int i = 0; i < 4; i++) frame(e); }
        e.setTab(0);
        for (int i = 0; i < 4; i++) frame(e, 200, 200 + i, i % 2 == 0);
    }
    e.setPage(Page::SceneHome);
    for (int i = 0; i < 3; i++) frame(e);
    e.setPage(Page::Viewport);
    for (int i = 0; i < 5; i++) frame(e);

    // logica de bloques: anadir con cierres, mover grupos, rangos
    {
        Obj o;
        int a = e.addBlock(o, Op::WhenStart);
        CHECK(a == 0 && o.blocks.size() == 1);
        int b = e.addBlock(o, Op::Repeat);      // Repeat + LoopEnd
        CHECK(b == 1 && o.blocks.size() == 3 && o.blocks[2].op == Op::LoopEnd);
        e.addBlock(o, Op::If);                  // If + Else + EndIf
        CHECK(o.blocks.size() == 6 && o.blocks[5].op == Op::EndIf);
        e.addBlock(o, Op::WhenTap);
        e.addBlock(o, Op::Wait);
        int end;
        CHECK(Editor::blockRange(o.blocks, 0, end) && end == 6);   // el guion completo
        CHECK(Editor::blockRange(o.blocks, 1, end) && end == 3);   // el bucle
        CHECK(Editor::blockRange(o.blocks, 3, end) && end == 6);   // el si completo
        CHECK(!Editor::blockRange(o.blocks, 2, end));              // un cierre no se mueve solo
        // mover el Wait dentro del bucle (antes de su Fin)
        CHECK(Editor::moveRange(o.blocks, 7, 2));
        CHECK(o.blocks[2].op == Op::Wait && o.blocks[3].op == Op::LoopEnd);
        CHECK(!Editor::moveRange(o.blocks, 1, 2));                 // no dentro de si mismo
        // mover el bucle completo al final
        int n = (int)o.blocks.size();
        CHECK(Editor::moveRange(o.blocks, 1, n));
        CHECK(o.blocks.back().op == Op::LoopEnd);
        Obj e2;
        e.addBlock(e2, Op::Wait);                                  // sin evento: agrega "Cuando se inicie"
        CHECK(e2.blocks.size() == 2 && e2.blocks[0].op == Op::WhenStart);
    }
    // editor de formulas, elegir texto y paleta (se abren y se dibujan)
    e.setScene(0);
    e.openObject(0);
    {
        Obj& ob = e.project().scenes[0].objs[0];
        int bi = e.addBlock(ob, Op::SetVar);
        (void)bi;
        e.setTab(0);
        for (int i = 0; i < 3; i++) frame(e);
        e.openPalette();
        for (int i = 0; i < 4; i++) frame(e);
        e.openFormula(bi, 0, "1 + 2");
        for (int i = 0; i < 4; i++) frame(e);
        e.openChoose(bi);
        for (int i = 0; i < 4; i++) frame(e);
        e.onText("hola", true);
    }
    e.setPage(Page::Scenes);
    for (int i = 0; i < 3; i++) frame(e);

    // anadir objetos de todos los tipos
    for (Kind k : {Kind::Cube, Kind::Floor, Kind::Wall, Kind::Item, Kind::Light, Kind::Player}) e.addObject(k);
    CHECK(!e.project().scenes.empty());
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.addScene(false);
    e.setScene(e.project().scenes.size() - 1);
    e.addObject(Kind::Cube);
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.setScene(0);

    // objetos de juego (enemigos, puertas, llaves...) en una escena 3D y partida corta con ellos
    {
        e.setScene(1);
        size_t before = e.project().scenes[1].objs.size();
        for (int id : {0, 1, 2, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25}) e.addObjectPreset(id);
        CHECK(e.project().scenes[1].objs.size() == before + 20);
        bool shooter = false, melee = false;
        for (auto& o : e.project().scenes[1].objs) {
            if (o.ai.type == AiType::Shooter) shooter = true;
            if (o.ai.type == AiType::Melee) melee = true;
        }
        CHECK(shooter && melee);
        CHECK(playerIndex(e.project().scenes[1]) >= 0);
        e.startPlay();
        for (int i = 0; i < 400; i++) frame(e);
        e.stopPlay();
        e.setScene(0);
    }

    // gestos: toque y arrastre
    frame(e, 600, 300, true);
    for (int i = 0; i < 5; i++) frame(e, 600 + i * 10, 300, true);
    frame(e, 650, 300, false);

    // importar un png minimo y audio falso
    std::vector<uint8_t> junk = {1, 2, 3};
    e.onFile("x.wav", junk);
    for (int i = 0; i < 3; i++) frame(e);

    CHECK(e.saveProject());
    std::vector<uint8_t> pk, exe; std::string err;
    CHECK(e.buildPack(pk));
    CHECK(e.buildExe(exe, err));
    CHECK(exe.size() > pk.size());

    // jugar
    e.startPlay();
    CHECK(e.screen() == Screen::Play);
    for (int i = 0; i < 30; i++) frame(e);
    e.stopPlay();
    CHECK(e.screen() == Screen::Edit);

    e.closeProject();
    frame(e);
    CHECK(e.screen() == Screen::Projects);
    CHECK(e.openProject("prueba"));
    for (int i = 0; i < 5; i++) frame(e);
    e.closeProject();
    for (int i = 0; i < 3; i++) frame(e);

    {   // Pocket Code: .catrobat dentro de un .rar sin comprimir
        std::string xml = "<program><header><programName>Demo PC</programName><screenWidth>720</screenWidth><screenHeight>1280</screenHeight></header>"
            "<scenes><scene><name>Inicio</name><objectList><object type=\"Sprite\" name=\"Fondo\"/>"
            "<object type=\"Sprite\" name=\"Gato\"><scriptList><script type=\"StartScript\"><brickList>"
            "<brick type=\"PlaceAtBrick\"><formulaList><formula category=\"X_POSITION\"><type>NUMBER</type><value>5</value></formula>"
            "<formula category=\"Y_POSITION\"><type>NUMBER</type><value>7</value></formula></formulaList></brick>"
            "<brick type=\"ForeverBrick\"/><brick type=\"MoveNStepsBrick\"><formulaList><formula category=\"STEPS\"><type>NUMBER</type><value>3</value></formula></formulaList></brick>"
            "<brick type=\"LoopEndlessBrick\"/><brick type=\"WeirdBrick\"/></brickList></script></scriptList></object></objectList></scene></scenes></program>";
        ResMap rm; rm["code.xml"] = std::vector<uint8_t>(xml.begin(), xml.end());
        Project cp; int nb = 0, ns = 0; std::string er;
        CHECK(catrobatConvert(rm, cp, nb, ns, er));
        CHECK(cp.scenes.size() == 1 && cp.scenes[0].objs.size() == 2 && cp.scenes[0].name == "Inicio");
        CHECK(nb == 4 && ns == 1);
        CHECK(cp.scenes[0].objs[1].blocks.size() == 5 && cp.scenes[0].objs[1].blocks[1].op == Op::PlaceAt && cp.scenes[0].objs[1].blocks[1].f[1] == "7");
        // RAR4 con un archivo almacenado
        std::vector<uint8_t> rar = {'R','a','r','!',0x1a,7,0, 0,0,0x74,0,0,0,0};
        std::string nm = "code.xml";
        uint32_t n = (uint32_t)xml.size();
        std::vector<uint8_t> h(32 - 7, 0);
        h[0] = h[1] = 0;
        std::vector<uint8_t> blk = {0,0,0x74,0,0,(uint8_t)(32 + nm.size()),0};
        blk.resize(32 + nm.size(), 0);
        for (int i = 0; i < 4; i++) { blk[7 + i] = (n >> (8 * i)) & 255; blk[11 + i] = (n >> (8 * i)) & 255; }
        blk[25] = 0x30; blk[26] = (uint8_t)nm.size();
        memcpy(&blk[32], nm.data(), nm.size());
        rar.assign({'R','a','r','!',0x1a,7,0});
        rar.insert(rar.end(), blk.begin(), blk.end());
        rar.insert(rar.end(), xml.begin(), xml.end());
        ResMap rr; int un = 0;
        CHECK(rarRead(rar, rr, un, er) && rr.count("code.xml") && rr["code.xml"].size() == xml.size() && un == 0);
        e.onFile("juego.rar", rar);
        for (int i = 0; i < 3; i++) frame(e);
    }
    ImGui::DestroyContext();
    fs::removeTree(dir);
    printf(fails ? "editor_test: %d fallos\n" : "editor_test: OK\n", fails);
    return fails ? 1 : 0;
}
