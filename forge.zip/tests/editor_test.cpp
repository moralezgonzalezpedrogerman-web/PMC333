// Prueba headless del editor: ImGui real sin backend, Renderer nulo.
#include "editor.h"
#include "help.h"
#include "fsutil.h"
#include "imgui.h"
#include "templates.h"
#include "library.h"
#include "model.h"
#include "uifont.h"
#include "rig.h"
#include "game.h"
#include "catrobat.h"
#include <cstdio>
#include <cstdlib>
using namespace forge;

static int fails = 0;
#define CHECK(c) do { if (!(c)) { printf("FALLO %s:%d %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)

static void frame(Editor& e, float mx = -1, float my = -1, bool down = false) {
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2(1280, 720);
    io.DeltaTime = 1.f / 60;
    io.AddMousePosEvent(mx, my);
    io.AddMouseButtonEvent(0, down);
    ImGui::NewFrame();
    e.frame(nullptr, 1280, 720, 1.f / 60);
    ImGui::Render();
}

int main() {
    {   // formas básicas: mallas válidas, dentro del cubo unitario, caras hacia afuera y se guardan/leen como modelo
        for (int id = 0; id < kShapeCount; id++) {
            ModelData m;
            CHECK(makeShape(id, m));
            CHECK(m.idx.size() % 3 == 0 && m.v.size() % 8 == 0 && !m.idx.empty());
            float lo = 1e9f, hi = -1e9f; bool inside = true;
            for (size_t k = 0; k < m.v.size(); k += 8) for (int a = 0; a < 3; a++) { lo = std::min(lo, m.v[k + a]); hi = std::max(hi, m.v[k + a]); if (std::fabs(m.v[k + a]) > 0.5001f) inside = false; }
            if (!inside) printf("forma %d fuera del cubo\n", id); CHECK(inside);
            int bad = 0;
            for (size_t t = 0; t < m.idx.size(); t += 3) {   // el giro de cada triángulo debe coincidir con su normal
                const float *a = &m.v[m.idx[t] * 8], *b = &m.v[m.idx[t + 1] * 8], *c = &m.v[m.idx[t + 2] * 8];
                float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                float vn = (a[3] + b[3] + c[3]) * nx + (a[4] + b[4] + c[4]) * ny + (a[5] + b[5] + c[5]) * nz;
                if (vn < -1e-9f) bad++;
            }
            if (bad) printf("forma %d: %d triangulos al reves\n", id, bad); CHECK(bad == 0);
            std::vector<uint8_t> bytes; ModelData r;
            CHECK(modelWrite(m, bytes) && modelRead(bytes.data(), bytes.size(), r) && r.idx.size() == m.idx.size());
        }
    }

    char tmpl[] = "/tmp/forge_edXXXXXX";
    std::string dir = mkdtemp(tmpl);
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    unsigned char* px; int fw, fh;
    io.Fonts->GetTexDataAsRGBA32(&px, &fw, &fh);

    EditorHost h;
    h.dataDir = dir;
    h.loadRuntime = [](std::vector<uint8_t>& o) { o = {'M', 'Z', 1, 2, 3}; return true; };
    std::vector<std::string> saved;
    h.saveOut = [&](const std::string& n, const std::string&) { saved.push_back(n); };
    Audio audio; audio.init(true);
    Editor e(h);
    e.init(&audio);

    for (int i = 0; i < 5; i++) frame(e);
    CHECK(e.screen() == Screen::Projects);
    {   // v10.6: la ayuda tiene guías completas y todos sus dibujos se pueden pintar
        const HelpFolder& R = helpRoot();
        CHECK(R.sub.size() >= 8);
        int guides = 0, steps = 0;
        std::function<void(const HelpFolder&)> walk = [&](const HelpFolder& f) {
            for (auto& g : f.guides) {
                guides++;
                CHECK(!g.title.empty() && !g.steps.empty());
                for (auto& st : g.steps) {
                    steps++;
                    CHECK(st.text.size() > 10);
                    if (!st.pic.empty()) {
                        std::string k = st.pic.substr(0, st.pic.find('|'));
                        CHECK(k == "bar" || k == "menu" || k == "btn" || k == "tabs" || k == "list" || k == "blocks" || k == "hud" || k == "skel" || k == "view" || k == "text" || k == "car");
                    }
                }
            }
            for (auto& s2 : f.sub) walk(s2);
        };
        walk(R);
        CHECK(guides >= 60 && steps >= 250);
        e.openHelp();
        for (int i = 0; i < 2; i++) frame(e);
        CHECK(e.helpIsOpen());
        std::function<void(const HelpFolder&)> show = [&](const HelpFolder& f) {
            for (auto& g : f.guides) {
                e.helpOpenGuide(g.title);
                for (size_t k = 0; k < g.steps.size(); k++) { e.helpSetStep((int)k); frame(e); }
            }
            for (auto& s2 : f.sub) show(s2);
        };
        show(R);
        e.closeHelp();
        frame(e);
    }
    CHECK(e.newProject("prueba", true));
    {  // biblioteca: todo se genera, los modelos se leen y los triangulos miran hacia afuera
        Files lf;
        for (auto& it : libraryItems()) CHECK(libraryAdd(it.name, lf));
        for (auto& it : libraryItems()) {
            if (it.kind != 2) continue;
            ModelData md;
            CHECK(modelRead(lf[it.name].data(), lf[it.name].size(), md));
            int bad = 0;
            for (size_t t = 0; t + 2 < md.idx.size(); t += 3) {
                const float *a = &md.v[md.idx[t] * 8], *b = &md.v[md.idx[t + 1] * 8], *c = &md.v[md.idx[t + 2] * 8];
                float ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                if (nx * a[3] + ny * a[4] + nz * a[5] <= 0) bad++;
            }
            if (bad) printf("%s: %d triangulos al reves\n", it.name.c_str(), bad);
            CHECK(bad == 0);
        }
    }
    {   // editor de cinemáticas: se abre con datos y dibuja sin fallar, incluida la vista previa
        Cine c; c.name = "Intro"; c.dur = 4.f;
        CineKey k1; k1.t = 0; k1.eye = {0, 5, 10}; k1.yaw = 0; k1.pitch = -20;
        CineKey k2; k2.t = 3; k2.eye = {10, 6, 0}; k2.yaw = 90; k2.pitch = -10;
        c.cam = {k1, k2};
        CineTrack tr; tr.obj = "Jugador"; CineTrackKey a; a.p = {0, 1, 0}; CineTrackKey b; b.t = 2; b.p = {5, 1, 0}; tr.keys = {a, b};
        c.tracks.push_back(tr);
        e.project().cines.push_back(c);
        e.openCineEditor();
        for (int i = 0; i < 4; i++) frame(e);
        CHECK(e.project().cines.size() == 1);
    }
    for (int ti = 0; ti < templateCount(); ti++) {  // cada plantilla se guarda, se vuelve a leer y corre sin fallar
        Project tp;
        buildTemplate(ti, tp);
        Files fl;
        { std::string t = writeProject(tp); fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end()); }
        Project back; std::string er;
        CHECK(loadProject(fl, back, er));
        CHECK(back.scenes.size() == 4 && back.scenes[1].objs.size() == tp.scenes[1].objs.size());
        if (back.scenes.empty()) continue;
        Game gm; gm.load(std::move(back));
        Input in;
        for (int f = 0; f < 120; f++) gm.update(1.f / 60.f, in, 1.7f);
    }
    {   // zona prohibida pintada: un solo objeto, se guarda/lee y bloquea el paso
        Project tp; buildTemplate(16, tp);
        Scene& sc = tp.scenes[1];
        sc.blkDisc(5.f, 5.f, 3.f, 1);
        CHECK(sc.blkAt(5.f, 5.f) && !sc.blkAt(20.f, 20.f));
        std::string t = writeProject(tp); Files fl; fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
        Project back; std::string er; CHECK(loadProject(fl, back, er));
        CHECK(back.scenes[1].blkAt(5.f, 5.f) && !back.scenes[1].blkAt(20.f, 20.f) && back.scenes[1].zones.empty());
    }
    {   // v10.7: comportamiento de las plantillas nuevas
        auto run = [&](int id, int frames, const std::vector<std::string>& btns, bool shoot, Game& gm) {
            Project tp; buildTemplate(id, tp);
            Files fl; { std::string t = writeProject(tp); fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end()); }
            Project back; std::string er; loadProject(fl, back, er);
            gm.load(std::move(back)); gm.enterScene(gm.proj.scenes[1].name);
            for (int f = 0; f < frames; f++) { Input in; in.buttons = btns; in.shoot = shoot; gm.update(1.f / 60.f, in, 1.7f); }
        };
        {   // Battle Royale: la zona se cierra; fuera de ella el jugador pierde vida
            Game g; run(17, 120, {}, false, g);
            CHECK(g.vars["zona"].num() > 90.0);
            g.pos.x = 100.f; g.pos.z = 100.f;   // lejos del centro
            double v0 = g.vars["vida"].num();
            for (int f = 0; f < 200; f++) { Input in; g.update(1.f / 60.f, in, 1.7f); }
            CHECK(g.vars["vida"].num() < v0);
        }
        {   // Ciudad abierta y mazmorra: arrancan con vida y reglas
            Game a; run(18, 60, {}, false, a); CHECK(a.vars["tiempo"].num() > 200.0 && a.vars["vida"].num() == 100.0);
            Game b; run(19, 60, {}, false, b); CHECK(b.vars["vida"].num() == 100.0);
        }
        { Game g; run(10, 240, {}, false, g);  CHECK(g.pos.z < -20.f); CHECK(g.vars["distancia"].num() > 5.0); }
        { Game g; run(10, 20, {}, false, g);
          for (int f = 0; f < 40; f++) { Input in; if (f == 0) in.buttons = {"Deslizar derecha"}; g.update(1.f / 60.f, in, 1.7f); }
          CHECK(g.pos.x > 2.0f); }
        { Game g; run(14, 90, {}, false, g); CHECK(std::fabs(std::sin(g.yaw)) > 0.9f); CHECK(g.vars["vidaRival"].num() > 50.0); }
        {   // v10.9: pelea 3D: camina hacia el rival (sin salirse del plano) y los puños le quitan vida
            Game g; run(14, 5, {}, false, g);
            float x0 = g.pos.x, z0 = g.pos.z;
            for (int f = 0; f < 90; f++) { Input in; in.moveX = 1.f; g.update(1.f / 60.f, in, 1.7f); }
            CHECK(g.pos.x > x0 + 2.f); CHECK(std::fabs(g.pos.z - z0) < 0.05f);
            for (int f = 0; f < 240; f++) { Input in; in.shoot = true; g.update(1.f / 60.f, in, 1.7f); }
            CHECK(g.vars["vidaRival"].num() < 100.0);
        }
        {   // 2.5D: escena nueva de lado se guarda y se lee
            Project tp; buildTemplate(14, tp); tp.scenes[1].side25 = true;
            std::string t = writeProject(tp); Files fl; fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
            Project back; std::string er; CHECK(loadProject(fl, back, er)); CHECK(back.scenes[1].side25);
        }
        {   // tipografía de la interfaz (Roboto) trae acentos, ñ, ¿ y ¡
            ImFontAtlas at;
            static const ImWchar rg[] = {0x0020, 0x00FF, 0};
            ImFontConfig fc; fc.FontDataOwnedByAtlas = false;
            ImFont* f = at.AddFontFromMemoryTTF((void*)kUiFontData, (int)kUiFontLen, 16.f, &fc, rg);
            unsigned char* px; int fw, fh; at.GetTexDataAsRGBA32(&px, &fw, &fh);
            CHECK(f && f->FindGlyphNoFallback(0xF1) && f->FindGlyphNoFallback(0xE1) && f->FindGlyphNoFallback(0xBF) && f->FindGlyphNoFallback(0xA1));
        }
        {   // paquetes por defecto: maniquí animado, armas y piezas
            Files fa;
            CHECK(libraryHas("lib_maniqui.fmdl") && libraryHas("lib_kn_blasterA.fmdl") && libraryHas("lib_kk_star_yellow.fmdl"));
            CHECK(libraryAdd("lib_maniqui.fmdl", fa) && fa.count("lib_maniqui.fanim") && fa.count("lib_maniqui_tex.png"));
            Rig rg; std::string tx(fa["lib_maniqui.fanim"].begin(), fa["lib_maniqui.fanim"].end());
            CHECK(rigRead(tx, rg) && rg.bones.size() > 20 && rg.clips.size() >= 10 && rg.model == "lib_maniqui.fmdl");
            CHECK(libraryAdd("lib_kk_star_yellow.fmdl", fa) && fa.count("lib_kk_textura.png"));
            libraryPrune(fa, "model lib_maniqui.fmdl");
            CHECK(fa.count("lib_maniqui.fmdl") && fa.count("lib_maniqui.fanim") && fa.count("lib_maniqui_tex.png") && !fa.count("lib_kk_star_yellow.fmdl") && !fa.count("lib_kk_textura.png"));
        }
        {   // editor de modelos por bloques: guarda .fmdl y .fvox y se puede leer
            Editor ev(h); ev.init(&audio); ev.openVoxEditor();
            CHECK(!ev.voxSave(false));   // vacío no guarda
            for (int i = 0; i < 4; i++) ev.vox_[(0 * 16 + 5) * 16 + 4 + i] = 4;
            ev.vox_[(1 * 16 + 5) * 16 + 5] = 7;
            ev.voxName_ = "prueba";
            CHECK(ev.voxSave(false));
            auto mi = ev.edit_.proj.assets.find("prueba.fmdl");
            CHECK(mi != ev.edit_.proj.assets.end());
            ModelData md; CHECK(modelRead(mi->second.data(), mi->second.size(), md));
            CHECK(!md.idx.empty() && md.tex == "vox_paleta.png" && ev.edit_.proj.assets.count("prueba.fvox"));
        }
        {   // inclinación (pitch/roll) se guarda y se lee
            Project tp; buildTemplate(14, tp); tp.scenes[1].objs.back().pitch = 30.f; tp.scenes[1].objs.back().roll = 180.f;
            std::string t = writeProject(tp); Files fl; fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
            Project back; std::string er; CHECK(loadProject(fl, back, er));
            CHECK(back.scenes[1].objs.back().pitch == 30.f); CHECK(back.scenes[1].objs.back().roll == 180.f);
        }
        {   // v11: cielo con diseño y ajustes del motor gráfico se guardan y se leen
            Project tp; buildTemplate(14, tp); tp.scenes[1].skyStyle = 5; tp.scenes[1].skyTex = "mi cielo.png";
            tp.gfxShadow = 4; tp.gfxSoft = 2; tp.gfxSpec = 0.5f; tp.gfxTone = 0.25f; tp.gfxEv = -0.5f; tp.gfxAniso = 8; tp.gfxPreset = 3;
            std::string t = writeProject(tp); Files fl; fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
            Project back; std::string er; CHECK(loadProject(fl, back, er));
            CHECK(back.scenes[1].skyStyle == 5); CHECK(back.scenes[1].skyTex == "mi cielo.png");
            CHECK(back.gfxShadow == 4 && back.gfxSoft == 2 && back.gfxAniso == 8 && back.gfxPreset == 3);
            CHECK(back.gfxSpec == 0.5f && back.gfxTone == 0.25f && back.gfxEv == -0.5f);
        }
        {   // v11.2: filtro, metálico y bloques nuevos se guardan; las reglas de empuje y los límites de pantalla funcionan
            Project tp; buildTemplate(14, tp); tp.gfxFilter = 3; tp.gfxFilterAmt = 0.75f; tp.mblur = 2.5f;
            tp.scenes[1].objs[0].metal = true;
            Block pb; pb.op = Op::PushedBy; pb.t = "Jugador"; Block kb; kb.op = Op::KeepOnScreen; kb.t = "Arriba y abajo";
            tp.scenes[1].objs[0].blocks.push_back(pb); tp.scenes[1].objs[0].blocks.push_back(kb);
            std::string t = writeProject(tp); Files fl; fl["project.forge"] = std::vector<uint8_t>(t.begin(), t.end());
            Project back; std::string er; CHECK(loadProject(fl, back, er));
            CHECK(back.gfxFilter == 3 && back.gfxFilterAmt == 0.75f && back.scenes[1].objs[0].metal);
            CHECK(back.scenes[1].objs[0].blocks.size() >= 2 && back.scenes[1].objs[0].blocks[back.scenes[1].objs[0].blocks.size() - 2].op == Op::PushedBy);
            CHECK(std::string(opInfo(Op::SolidWall).key) == "colision");
        }
        {   // 2D: nada sale girado (90 = sin girar)
            for (int id : {4, 5, 11, 12, 13, 15, 16}) { Project tp; buildTemplate(id, tp); if (tp.scenes[1].is3d) continue; for (auto& o : tp.scenes[1].objs) CHECK(o.yaw != 0.f); }
        }
        { Game g; run(7, 120, {}, true, g); CHECK(g.vars["vida"].num() > 0.0); }
        { Game g; run(2, 60, {"Acelerar"}, false, g); float dx = g.pos.x - 0.f, dz = g.pos.z - 46.f; CHECK(dx * dx + dz * dz > 4.f);
          float fx = std::sin(g.bodyYaw), fz = -std::cos(g.bodyYaw); CHECK(dx * fx + dz * fz > 0.f); }
        { Game g; run(15, 200, {"Derecha"}, false, g); CHECK(g.vars["vida"].num() > 0.0); }
        { Game g; run(4, 120, {}, false, g); CHECK(g.vars["vidas"].num() == 3.0); }
        { Game g; run(5, 120, {"B"}, false, g); CHECK(g.vars["vidas"].num() > 0.0); }
    }
    CHECK(e.screen() == Screen::Edit);
    e.showObjs = e.showProps = e.showWorld = e.showHud = e.showAssets = true;
    // paginas: escenas -> escena -> objeto (3 pestanas), menus y editores
    CHECK(e.page() == Page::Scenes);
    for (int i = 0; i < 5; i++) frame(e);
    e.setScene(1);
    e.setPage(Page::SceneHome);
    for (int i = 0; i < 5; i++) frame(e);
    {
        Scene& S = e.project().scenes[e.sceneIndex()];
        CHECK(!S.objs.empty());
        e.openObject(0);
        for (int t = 0; t < 3; t++) { e.setTab(t); for (int i = 0; i < 4; i++) frame(e); }
        e.setTab(0);
        for (int i = 0; i < 4; i++) frame(e, 200, 200 + i, i % 2 == 0);
    }
    e.setPage(Page::SceneHome);
    for (int i = 0; i < 3; i++) frame(e);
    e.setPage(Page::Viewport);
    for (int i = 0; i < 5; i++) frame(e);

    // logica de bloques: anadir con cierres, mover grupos, rangos
    {
        Obj o;
        int a = e.addBlock(o, Op::WhenStart);
        CHECK(a == 0 && o.blocks.size() == 1);
        int b = e.addBlock(o, Op::Repeat);      // Repeat + LoopEnd
        CHECK(b == 1 && o.blocks.size() == 3 && o.blocks[2].op == Op::LoopEnd);
        e.addBlock(o, Op::If, true);            // If + Else + EndIf (con sino)
        CHECK(o.blocks.size() == 6 && o.blocks[5].op == Op::EndIf);
        {   // "Si" simple: solo If + EndIf, sin De lo contrario
            Obj q; e.addBlock(q, Op::If);
            CHECK(q.blocks.size() == 3 && q.blocks[1].op == Op::If && q.blocks[2].op == Op::EndIf);
        }
        e.addBlock(o, Op::WhenTap);
        e.addBlock(o, Op::Wait);
        int end;
        CHECK(Editor::blockRange(o.blocks, 0, end) && end == 6);   // el guion completo
        CHECK(Editor::blockRange(o.blocks, 1, end) && end == 3);   // el bucle
        CHECK(Editor::blockRange(o.blocks, 3, end) && end == 6);   // el si completo
        CHECK(!Editor::blockRange(o.blocks, 2, end));              // un cierre no se mueve solo
        // mover el Wait dentro del bucle (antes de su Fin)
        CHECK(Editor::moveRange(o.blocks, 7, 2));
        CHECK(o.blocks[2].op == Op::Wait && o.blocks[3].op == Op::LoopEnd);
        CHECK(!Editor::moveRange(o.blocks, 1, 2));                 // no dentro de si mismo
        // mover el bucle completo al final
        int n = (int)o.blocks.size();
        CHECK(Editor::moveRange(o.blocks, 1, n));
        CHECK(o.blocks.back().op == Op::LoopEnd);
        Obj e2;
        e.addBlock(e2, Op::Wait);                                  // sin evento: agrega "Cuando se inicie"
        CHECK(e2.blocks.size() == 2 && e2.blocks[0].op == Op::WhenStart);
    }
    // editor de formulas, elegir texto y paleta (se abren y se dibujan)
    e.setScene(0);
    e.openObject(0);
    {
        Obj& ob = e.project().scenes[0].objs[0];
        int bi = e.addBlock(ob, Op::SetVar);
        (void)bi;
        e.setTab(0);
        for (int i = 0; i < 3; i++) frame(e);
        e.openPalette();
        for (int i = 0; i < 4; i++) frame(e);
        e.openFormula(bi, 0, "1 + 2");
        for (int i = 0; i < 4; i++) frame(e);
        e.openChoose(bi);
        for (int i = 0; i < 4; i++) frame(e);
        e.onText("hola", true);
    }
    e.setPage(Page::Scenes);
    for (int i = 0; i < 3; i++) frame(e);

    // anadir objetos de todos los tipos
    for (Kind k : {Kind::Cube, Kind::Floor, Kind::Wall, Kind::Item, Kind::Light, Kind::Player}) e.addObject(k);
    CHECK(!e.project().scenes.empty());
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.addScene(false);
    e.setScene(e.project().scenes.size() - 1);
    e.addObject(Kind::Cube);
    e.select(0);
    for (int i = 0; i < 5; i++) frame(e);
    e.setScene(0);

    // objetos de juego (enemigos, puertas, llaves...) en una escena 3D y partida corta con ellos
    {
        e.setScene(1);
        size_t before = e.project().scenes[1].objs.size();
        for (int id : {0, 1, 2, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25}) e.addObjectPreset(id);
        CHECK(e.project().scenes[1].objs.size() == before + 20);
        bool shooter = false, melee = false;
        for (auto& o : e.project().scenes[1].objs) {
            if (o.ai.type == AiType::Shooter) shooter = true;
            if (o.ai.type == AiType::Melee) melee = true;
        }
        CHECK(shooter && melee);
        CHECK(playerIndex(e.project().scenes[1]) >= 0);
        e.startPlay();
        for (int i = 0; i < 400; i++) frame(e);
        e.stopPlay();
        e.setScene(0);
    }

    // gestos: toque y arrastre
    frame(e, 600, 300, true);
    for (int i = 0; i < 5; i++) frame(e, 600 + i * 10, 300, true);
    frame(e, 650, 300, false);

    // importar un png minimo y audio falso
    std::vector<uint8_t> junk = {1, 2, 3};
    e.onFile("x.wav", junk);
    for (int i = 0; i < 3; i++) frame(e);

    CHECK(e.saveProject());
    std::vector<uint8_t> pk, exe; std::string err;
    CHECK(e.buildPack(pk));
    CHECK(e.buildExe(exe, err));
    CHECK(exe.size() > pk.size());

    // jugar
    e.startPlay();
    CHECK(e.screen() == Screen::Play);
    for (int i = 0; i < 30; i++) frame(e);
    e.stopPlay();
    CHECK(e.screen() == Screen::Edit);

    e.closeProject();
    frame(e);
    CHECK(e.screen() == Screen::Projects);
    CHECK(e.openProject("prueba"));
    for (int i = 0; i < 5; i++) frame(e);
    e.closeProject();
    for (int i = 0; i < 3; i++) frame(e);

    {   // deformación por impacto
        Project dp; Scene ds; ds.is3d = true;
        Obj mo; mo.kind = Kind::Model; mo.model = "lib_t.fmdl"; mo.deform = true; mo.deformAmt = 0.8f; mo.pos = V3{0, 1, -5};
        ds.objs.push_back(mo);
        Obj pl; pl.kind = Kind::Player; pl.name = "Jugador"; ds.objs.push_back(pl);
        ModelData md; md.v = {-.5f,-.5f,-.5f, 0,0,1, 0,0,  .5f,-.5f,-.5f, 0,0,1, 1,0,  0,.5f,-.5f, 0,0,1, .5f,1}; md.idx = {0, 1, 2};
        std::vector<uint8_t> mb; modelWrite(md, mb);
        dp.assets["lib_t.fmdl"] = mb; dp.scenes.push_back(ds);
        Game gm; gm.load(std::move(dp));
        gm.dentObj(0, V3{0, 1.4f, -5.5f}, V3{0, 0, -1}, 1.f);
        const std::vector<float>* sv = nullptr; const std::vector<uint32_t>* si = nullptr; unsigned long long sg = 0;
        // el golpe viene hacia -Z y la cara mira hacia +Z (la contraria): no debe abollar; por eso se prueba el lado correcto
        gm.dentObj(0, V3{0, 1, -4.5f}, V3{0, 0, -1}, 1.f);
        CHECK(gm.skinVerts(0, "lib_t.fmdl", sv, si, sg) && sv && sv->size() == 24);
        float moved = 0; for (int k = 0; k < 3; k++) moved += std::fabs((*sv)[k * 8 + 2] - md.v[k * 8 + 2]);
        CHECK(moved > 0.001f);
    }
    {   // estudio de música
        MusicSong ms;
        for (int g = 0; g < 8; g++) {
            musicPreset(ms, g);
            auto w = musicRender(ms);
            CHECK(w.size() > 44 + 20000 && w[0] == 'R');
            bool loud = false; for (size_t i = 44; i + 1 < w.size(); i += 2) { int16_t v = (int16_t)(w[i] | (w[i + 1] << 8)); if (std::abs(v) > 3000) { loud = true; break; } }
            CHECK(loud);
        }
        for (int k = 0; k < 8; k++) CHECK(sfxRender(k, 1.f, 1.f, 3).size() > 1000);
        e.openMusic();
        for (int i = 0; i < 3; i++) frame(e);
        e.closeMusic();
    }
    {   // físicas: reparto de impulso entre dos objetos dinámicos y bloque de empujón
        Project pp; Scene ps; ps.is3d = true;
        Obj a; a.name = "A"; a.kind = Kind::Cube; a.pos = V3{0, 5, 0}; a.phys = Phys::Dynamic; a.mass = 1; a.bounce = 0.2f; a.gravScale = 0.f;
        Block bi; bi.op = Op::WhenStart; a.blocks.push_back(bi);
        Block im; im.op = Op::PhysImpulse; im.f[0] = "6"; im.f[1] = "0"; im.f[2] = "0"; a.blocks.push_back(im);
        Obj b; b.name = "B"; b.kind = Kind::Cube; b.pos = V3{3, 5, 0}; b.phys = Phys::Dynamic; b.mass = 1; b.bounce = 0.2f; b.gravScale = 0.f;
        Obj pl; pl.kind = Kind::Player; pl.name = "Jugador"; pl.pos = V3{0, 0, 30};
        ps.objs.push_back(a); ps.objs.push_back(b); ps.objs.push_back(pl);
        pp.scenes.push_back(ps);
        Game g2; g2.load(std::move(pp));
        Input in0;
        float bx0 = g2.sc->objs[1].pos.x;
        for (int i = 0; i < 180; i++) g2.update(1.f / 60.f, in0, 1.7f);
        CHECK(g2.sc->objs[0].pos.x > 0.5f);          // el empujón movió a A
        CHECK(g2.sc->objs[1].pos.x > bx0 + 0.3f);    // y al chocar le pasó impulso a B
    }
    {   // el clip de caminar del jugador y del enemigo debe reproducirse
        Project cp2; Scene cs; cs.is3d = true;
        ModelData md2; md2.v = {-.5f,-.5f,0, 0,0,1, 0,0,  .5f,-.5f,0, 0,0,1, 1,0,  0,.5f,0, 0,0,1, .5f,1}; md2.idx = {0, 1, 2};
        std::vector<uint8_t> mb2; modelWrite(md2, mb2);
        cp2.assets["m.fmdl"] = mb2;
        Rig rg; rg.model = "m.fmdl"; rg.bones.push_back({"a", -1, V3{0, 0, 0}}); rg.bones.push_back({"b", 0, V3{0, 0.4f, 0}});
        RigClip c1; c1.name = "caminar"; c1.len = 1; for (int k = 0; k < 2; k++) { RigKey rk; rk.t = (float)k; rk.pose.rot.assign(2, Quat()); rk.pose.rot[1] = qAxisAngle(V3{1, 0, 0}, k * 1.2f); c1.keys.push_back(rk); }
        rg.clips.push_back(c1);
        Rig other = rg; other.clips.clear(); RigClip c0 = c1; c0.name = "otra"; other.clips.push_back(c0);   // otro archivo del mismo modelo, que va antes por orden alfabético
        std::string rt0 = rigWrite(other); cp2.assets["a_primero.fanim"] = std::vector<uint8_t>(rt0.begin(), rt0.end());
        std::string rt = rigWrite(rg); cp2.assets["r.fanim"] = std::vector<uint8_t>(rt.begin(), rt.end());
        cp2.player.model = "m.fmdl";
        Obj pl; pl.kind = Kind::Player; pl.name = "Jugador"; pl.pos = V3{0, 1, 0}; pl.ai.anim[kWalk].clip = "caminar"; cs.objs.push_back(pl);
        Obj en; en.kind = Kind::Model; en.model = "m.fmdl"; en.pos = V3{0, 1, -6}; en.ai.type = AiType::Melee; en.ai.sight = 30; en.ai.speed = 2; en.ai.anim[kWalk].clip = "caminar"; cs.objs.push_back(en);
        cp2.scenes.push_back(cs);
        Game g3; g3.load(std::move(cp2));
        Input iw; iw.moveY = 1.f;
        for (int i = 0; i < 40; i++) g3.update(1.f / 60.f, iw, 1.7f);
        const std::vector<float>* sv = nullptr; const std::vector<uint32_t>* si = nullptr; unsigned long long sg = 0;
        std::string why = "enemigo";
        CHECK(g3.skinVerts(1, "m.fmdl", sv, si, sg));
        CHECK(g3.skinVerts(0, "m.fmdl", sv, si, sg));
    }
    {   // Pocket Code: .catrobat dentro de un .rar sin comprimir
        std::string xml = "<program><header><programName>Demo PC</programName><screenWidth>720</screenWidth><screenHeight>1280</screenHeight></header>"
            "<scenes><scene><name>Inicio</name><objectList><object type=\"Sprite\" name=\"Fondo\"/>"
            "<object type=\"Sprite\" name=\"Gato\"><scriptList><script type=\"StartScript\"><brickList>"
            "<brick type=\"PlaceAtBrick\"><formulaList><formula category=\"X_POSITION\"><type>NUMBER</type><value>5</value></formula>"
            "<formula category=\"Y_POSITION\"><type>NUMBER</type><value>7</value></formula></formulaList></brick>"
            "<brick type=\"ForeverBrick\"/><brick type=\"MoveNStepsBrick\"><formulaList><formula category=\"STEPS\"><type>NUMBER</type><value>3</value></formula></formulaList></brick>"
            "<brick type=\"LoopEndlessBrick\"/><brick type=\"WeirdBrick\"/></brickList></script></scriptList></object></objectList></scene></scenes></program>";
        ResMap rm; rm["code.xml"] = std::vector<uint8_t>(xml.begin(), xml.end());
        Project cp; int nb = 0, ns = 0; std::string er;
        CHECK(catrobatConvert(rm, cp, nb, ns, er));
        CHECK(cp.scenes.size() == 1 && cp.scenes[0].objs.size() == 2 && cp.scenes[0].name == "Inicio");
        CHECK(nb == 4 && ns == 1);
        CHECK(cp.scenes[0].objs[1].blocks.size() == 5 && cp.scenes[0].objs[1].blocks[1].op == Op::PlaceAt && cp.scenes[0].objs[1].blocks[1].f[1] == "5.46875");
        // RAR4 con un archivo almacenado
        std::vector<uint8_t> rar = {'R','a','r','!',0x1a,7,0, 0,0,0x74,0,0,0,0};
        std::string nm = "code.xml";
        uint32_t n = (uint32_t)xml.size();
        std::vector<uint8_t> h(32 - 7, 0);
        h[0] = h[1] = 0;
        std::vector<uint8_t> blk = {0,0,0x74,0,0,(uint8_t)(32 + nm.size()),0};
        blk.resize(32 + nm.size(), 0);
        for (int i = 0; i < 4; i++) { blk[7 + i] = (n >> (8 * i)) & 255; blk[11 + i] = (n >> (8 * i)) & 255; }
        blk[25] = 0x30; blk[26] = (uint8_t)nm.size();
        memcpy(&blk[32], nm.data(), nm.size());
        rar.assign({'R','a','r','!',0x1a,7,0});
        rar.insert(rar.end(), blk.begin(), blk.end());
        rar.insert(rar.end(), xml.begin(), xml.end());
        ResMap rr; int un = 0;
        CHECK(rarRead(rar, rr, un, er) && rr.count("code.xml") && rr["code.xml"].size() == xml.size() && un == 0);
        e.onFile("juego.rar", rar);
        for (int i = 0; i < 3; i++) frame(e);
    }
    ImGui::DestroyContext();
    fs::removeTree(dir);
    printf(fails ? "editor_test: %d fallos\n" : "editor_test: OK\n", fails);
    return fails ? 1 : 0;
}
