# Runtime de Windows (el .exe que se une al paquete del juego).
cmake_minimum_required(VERSION 3.20)
project(forge_runtime CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Sin DLLs externas: el .exe debe funcionar solo.
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")

include(cmake/deps.cmake)
set(GLFW_BUILD_DOCS OFF CACHE BOOL "" FORCE)
set(GLFW_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(GLFW_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(GLFW_INSTALL OFF CACHE BOOL "" FORCE)
FetchContent_Declare(glfw GIT_REPOSITORY https://github.com/glfw/glfw.git GIT_TAG 3.4 GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(glfw)

file(GLOB CORE_SOURCES CONFIGURE_DEPENDS core/*.cpp)
set(IMGUI_SOURCES ${IMGUI_DIR}/imgui.cpp ${IMGUI_DIR}/imgui_draw.cpp ${IMGUI_DIR}/imgui_tables.cpp
    ${IMGUI_DIR}/imgui_widgets.cpp ${IMGUI_DIR}/backends/imgui_impl_glfw.cpp
    ${IMGUI_DIR}/backends/imgui_impl_opengl3.cpp)
add_executable(forge_runtime WIN32 platform/windows/main.cpp ${CORE_SOURCES} ${IMGUI_SOURCES})
target_include_directories(forge_runtime PRIVATE core ${STB_DIR} ${IMGUI_DIR} ${IMGUI_DIR}/backends ${MINIAUDIO_DIR})
target_compile_definitions(forge_runtime PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN _CRT_SECURE_NO_WARNINGS)
target_link_libraries(forge_runtime PRIVATE glfw)
if(MSVC)
  target_link_options(forge_runtime PRIVATE /ENTRY:mainCRTStartup)
  target_compile_options(forge_runtime PRIVATE /utf-8)
endif()

# Editor completo para Windows (junto con forge_runtime.exe, que usa para exportar juegos a .exe).
if(WIN32)
  forge_fetch(cgltf https://github.com/jkuhlmann/cgltf.git v1.14 TRUE)
  forge_fetch(ufbx  https://github.com/ufbx/ufbx.git 5955c5c0b042ac2dc6f32955ab206aaec0620cfc FALSE)
  file(GLOB EDITOR_SOURCES CONFIGURE_DEPENDS editor/*.cpp)
  set_source_files_properties(${UFBX_DIR}/ufbx.c PROPERTIES LANGUAGE C)
  enable_language(C)
  add_executable(pmaker_editor WIN32 platform/windows/editor_main.cpp ${EDITOR_SOURCES} ${CORE_SOURCES} ${IMGUI_SOURCES}
      ${IMGUI_DIR}/misc/cpp/imgui_stdlib.cpp ${UFBX_DIR}/ufbx.c)
  target_include_directories(pmaker_editor PRIVATE core editor ${STB_DIR} ${IMGUI_DIR} ${IMGUI_DIR}/backends ${MINIAUDIO_DIR}
      ${CGLTF_DIR} ${UFBX_DIR})
  target_compile_definitions(pmaker_editor PRIVATE NOMINMAX WIN32_LEAN_AND_MEAN _CRT_SECURE_NO_WARNINGS)
  target_link_libraries(pmaker_editor PRIVATE glfw comdlg32 shell32 ole32)
  if(MSVC)
    target_link_options(pmaker_editor PRIVATE /ENTRY:mainCRTStartup /STACK:67108864)
    target_compile_options(pmaker_editor PRIVATE /utf-8)
  endif()
endif()
